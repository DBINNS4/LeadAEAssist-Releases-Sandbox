'use strict';

// services/ffmpegService.js
// Centralized FFmpeg / ffprobe helpers.
// This is just the old ipc/ffmpeg.handlers.js logic moved into a reusable module.

const { spawn, execFile } = require('child_process');
const fs = require('fs');
const ffmpegBridge = require('../utils/ffmpegBridge');
const { getBinaryPaths, ffprobeJson } = ffmpegBridge;
const ffmpegCaps = require('../utils/ffmpegCapabilities');

const { ffmpegPath, ffprobePath } = getBinaryPaths();
const FFPROBE_TIMEOUT_MS = 12000;
const FFMPEG_MAX_CAPTURE_BYTES = 64 * 1024;
const FFMPEG_KILL_GRACE_MS = 1500;

function createFfmpegError({ code, message, stderrTail = '', stdoutTail = '', exitCode = null, signal = null, timeoutMs }) {
  const error = {
    code,
    message,
    stderrTail,
    stdoutTail,
    exitCode,
    signal: signal || null
  };
  if (Number.isFinite(timeoutMs)) {
    error.timeoutMs = timeoutMs;
  }
  return error;
}

function isTimeoutError(err) {
  if (!err) return false;
  return err.code === 'ETIMEDOUT' || err.killed || err.signal === 'SIGTERM' || /ETIMEDOUT/i.test(err.message || '');
}

function buildTimeoutError(timeoutMs) {
  return { code: 'FFPROBE_TIMEOUT', message: 'metadata probe timed out', timeoutMs };
}

// Supported FFmpeg binary sources. We intentionally do NOT accept arbitrary paths
// from the renderer (or any untrusted caller).
const ALLOWED_FFMPEG_SOURCES = new Set(['bundled', 'system']);

function resolveFfmpegBin(source = 'bundled') {
  const s = typeof source === 'string' ? source : 'bundled';
  const normalized = ALLOWED_FFMPEG_SOURCES.has(s) ? s : 'bundled';
  const systemBin = process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg';

  if (normalized === 'bundled') {
    // Prefer the bundled binary if present; fall back to PATH-resolved "ffmpeg" in dev.
    try {
      if (ffmpegPath && fs.existsSync(ffmpegPath)) return ffmpegPath;
    } catch {
      // ignore
    }
  }
  return systemBin;
}

function normalizeArgs(args) {
  if (!Array.isArray(args)) {
    throw new Error('❌ FFmpeg args must be an array');
  }
  const out = [];
  for (const a of args) {
    // Prevent null bytes from sneaking into arguments.
    const s = String(a ?? '');
    if (s.includes('\u0000')) {
      throw new Error('❌ FFmpeg args contain an invalid null byte');
    }
    out.push(s);
  }
  return out;
}

/**
 * Run FFmpeg and capture stdout/stderr.
 * Mirrors the old 'exec-ffmpeg' IPC handler behavior exactly.
 */
function runFfmpeg(args = [], options = {}) {
  const ffmpegBin = resolveFfmpegBin(options?.source);
  const safeArgs = normalizeArgs(args);
  const maxCaptureBytes = Number.isFinite(options?.maxCaptureBytes)
    ? Math.max(1024, Math.trunc(options.maxCaptureBytes))
    : FFMPEG_MAX_CAPTURE_BYTES;
  const timeoutMs = Number.isFinite(options?.timeoutMs)
    ? Math.max(0, Math.trunc(options.timeoutMs))
    : 0;
  const abortSignal = options?.signal;

  const createTailBuffer = maxBytes => {
    const chunks = [];
    let total = 0;

    return {
      append(chunk) {
        if (!chunk || maxBytes <= 0) return;
        let buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk));
        if (buf.length > maxBytes) {
          buf = buf.subarray(buf.length - maxBytes);
          chunks.length = 0;
          total = 0;
        }
        chunks.push(buf);
        total += buf.length;

        while (total > maxBytes && chunks.length) {
          const first = chunks[0];
          const overflow = total - maxBytes;
          if (first.length <= overflow) {
            chunks.shift();
            total -= first.length;
          } else {
            chunks[0] = first.subarray(overflow);
            total -= overflow;
          }
        }
      },
      toString() {
        if (!chunks.length) return '';
        return Buffer.concat(chunks, total).toString();
      }
    };
  };

  return new Promise((resolve, reject) => {
    const proc = spawn(ffmpegBin, safeArgs, { stdio: ['ignore', 'pipe', 'pipe'] });
    const stderrTail = createTailBuffer(maxCaptureBytes);
    const stdoutTail = createTailBuffer(maxCaptureBytes);
    let timeoutId = null;
    let killGraceId = null;
    let settled = false;
    let cancelledBy = null;

    const cleanup = () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
      if (killGraceId) {
        clearTimeout(killGraceId);
        killGraceId = null;
      }
      if (abortSignal && typeof abortSignal.removeEventListener === 'function') {
        abortSignal.removeEventListener('abort', onAbort);
      }
    };

    const buildPayload = (code, signal) => ({
      exitCode: Number.isInteger(code) ? code : null,
      signal: signal || null,
      stdout: stdoutTail.toString(),
      stderr: stderrTail.toString(),
      maxCaptureBytes
    });

    const requestStop = reason => {
      if (settled || cancelledBy) return;
      cancelledBy = reason;
      if (proc.exitCode === null && !proc.killed) {
        proc.kill('SIGTERM');
        killGraceId = setTimeout(() => {
          if (proc.exitCode === null && !proc.killed) {
            proc.kill('SIGKILL');
          }
        }, FFMPEG_KILL_GRACE_MS);
      }
    };

    function onAbort() {
      requestStop('abort');
    }

    proc.stdout.on('data', chunk => {
      stdoutTail.append(chunk);
    });

    proc.stderr.on('data', chunk => {
      stderrTail.append(chunk);
    });

    if (timeoutMs > 0) {
      timeoutId = setTimeout(() => {
        requestStop('timeout');
      }, timeoutMs);
    }

    if (abortSignal && typeof abortSignal.addEventListener === 'function') {
      abortSignal.addEventListener('abort', onAbort, { once: true });
      if (abortSignal.aborted) onAbort();
    }

    proc.on('error', err => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(createFfmpegError({
        code: 'FFMPEG_SPAWN_ERROR',
        message: err?.message || 'FFmpeg failed to start',
        stderrTail: stderrTail.toString(),
        stdoutTail: stdoutTail.toString(),
        exitCode: null,
        signal: null
      }));
    });

    proc.on('close', (code, signal) => {
      if (settled) return;
      settled = true;
      cleanup();
      const payload = buildPayload(code, signal);

      if (cancelledBy === 'timeout') {
        reject(createFfmpegError({
          code: 'FFMPEG_TIMEOUT',
          message: `FFmpeg timed out after ${timeoutMs}ms`,
          stderrTail: payload.stderr,
          stdoutTail: payload.stdout,
          exitCode: payload.exitCode,
          signal: payload.signal,
          timeoutMs
        }));
        return;
      }
      if (cancelledBy === 'abort') {
        reject(createFfmpegError({
          code: 'FFMPEG_ABORTED',
          message: 'FFmpeg execution aborted',
          stderrTail: payload.stderr,
          stdoutTail: payload.stdout,
          exitCode: payload.exitCode,
          signal: payload.signal
        }));
        return;
      }

      if (payload.exitCode === 0) {
        resolve(payload);
      } else {
        reject(createFfmpegError({
          code: 'FFMPEG_EXIT_NON_ZERO',
          message: payload.stderr || `FFmpeg exited with code ${payload.exitCode}`,
          stderrTail: payload.stderr,
          stdoutTail: payload.stdout,
          exitCode: payload.exitCode,
          signal: payload.signal
        }));
      }
    });
  });
}

/**
 * Thin wrapper for ffprobe that returns raw stdout.
 * Mirrors the old 'exec-ffprobe' handler.
 */
function runFfprobe(args = [], options = {}) {
  const timeoutMs = Number.isFinite(options?.timeoutMs)
    ? Math.max(0, options.timeoutMs)
    : FFPROBE_TIMEOUT_MS;
  return new Promise((resolve, reject) => {
    execFile(ffprobePath, args, { timeout: timeoutMs }, (error, stdout) => {
      if (error) {
        if (isTimeoutError(error)) {
          reject(buildTimeoutError(timeoutMs));
          return;
        }
        reject(error.message);
        return;
      }
      resolve(stdout);
    });
  });
}

/**
 * JSON ffprobe helper (same behavior as old 'ffprobe-json').
 */
async function runFfprobeJson(filePath, extraArgs = [], options = {}) {
  try {
    return await ffprobeJson(filePath, extraArgs, options);
  } catch (err) {
    if (err?.code === 'FFPROBE_TIMEOUT') {
      return { error: err };
    }
    return { error: String(err?.message || err) };
  }
}

/**
 * ffprobe wrapper that returns parsed JSON or an { error } object.
 * Mirrors the old 'probe-media' handler.
 */
function probeMedia(filePath, options = {}) {
  const timeoutMs = Number.isFinite(options?.timeoutMs)
    ? Math.max(0, options.timeoutMs)
    : FFPROBE_TIMEOUT_MS;
  const args = [
    '-v',
    'quiet',
    '-print_format',
    'json',
    '-show_format',
    '-show_streams',
    filePath
  ];

  return new Promise(resolve => {
    execFile(ffprobePath, args, { timeout: timeoutMs }, (error, stdout) => {
      if (error) {
        if (isTimeoutError(error)) {
          resolve({ error: buildTimeoutError(timeoutMs) });
          return;
        }
        resolve({ error: error.message });
        return;
      }
      try {
        resolve(JSON.parse(stdout));
      } catch (err) {
        resolve({ error: err.message });
      }
    });
  });
}

/**
 * Capabilities – same as old ffmpeg:get-capabilities.
 */
function getCapabilities() {
  return ffmpegCaps.getCapabilities();
}

/**
 * Output formats whitelist – same as old get-ffmpeg-formats.
 */
function getMuxerFormats() {
  const whitelist = ['mov', 'mp4', 'mxf', 'matroska', 'webm', 'avi', 'wav', 'mp3'];
  const muxers = ffmpegCaps.listMuxers(whitelist);
  return muxers.map(muxer => ({
    format: muxer.name,
    description: muxer.description
  }));
}

module.exports = {
  FFMPEG_MAX_CAPTURE_BYTES,
  runFfmpeg,
  runFfprobe,
  runFfprobeJson,
  probeMedia,
  getCapabilities,
  getMuxerFormats
};
