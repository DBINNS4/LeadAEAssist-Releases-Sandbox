'use strict';
// services/mediaService.js
const path = require('path');
const fs = require('fs');

/**
 * Placeholder for source metadata extraction. Keep behavior identical to current get-source-metadata.
 * Inject any heavy work here later; handlers just call into this service.
 */
async function getSourceMetadata(appRoot, filePath) {
  try {
    // Example behavior: return basic fs stats with basename/extname
    const st = await fs.promises.stat(filePath);
    return {
      path: filePath,
      name: path.basename(filePath),
      ext: path.extname(filePath),
      size: st.size,
      mtime: st.mtimeMs,
    };
  } catch (err) {
    return { error: err.message };
  }
}

module.exports = { getSourceMetadata };
