'use strict';
// services/bridgeServerService.js
// Stable static bridge server for CEP + Adobe Automate.
// Single HTTP + WebSocket server on 127.0.0.1:32123 with a shared token.

const http = require('http');
const crypto = require('crypto');
const WebSocket = require('ws');

// Preferred port for local bridge discovery.
const PREFERRED_BRIDGE_PORT = 32123;
const BRIDGE_SERVICE_ID = 'lead-ae-assist-bridge';
const RETRY_BACKOFF_MS = [200, 450, 900];
const BRIDGE_INSTANCE_NONCE =
  process.env.CEP_BRIDGE_INSTANCE_NONCE ||
  `${process.pid}-${crypto.randomBytes(12).toString('hex')}`;
process.env.CEP_BRIDGE_INSTANCE_NONCE = BRIDGE_INSTANCE_NONCE;

// Global state for the running server + WS
let server = null;
let wsServer = null;
let activePort = PREFERRED_BRIDGE_PORT;
const wsClients = new Set();
let wsConnSeq = 0;
// Subscribers for inbound CEP → backend messages
const messageSubscribers = new Set();

const initialEnvToken = process.env.CEP_BRIDGE_TOKEN || null;
let token = null;
let expiresAt = 0; // ms since epoch
let tokenVersion = 0;
let tokenTtlMs = 60 * 60 * 1000;
let rotationTimer = null;
let tokenSource = 'generated';

// Track listen readiness + last error so callers can surface actionable diagnostics.
let serverReady = false;
let serverError = null; // { code, message }
let serverStartPromise = null;
let startupStatus = 'idle'; // idle | started | started_fallback_ephemeral | reused_existing | in_use_by_other | bind_failed
let usingExternalBridge = false;

function bridgeRequestHandler(req, res) {
  const remoteAddr = req.socket?.remoteAddress || 'unknown';

  // CORS + preflight handling (CEP fetch() will preflight when using Authorization header)
  if (!applyCors(req, res)) {
    recordFailedAuth(remoteAddr);
    res.setHeader('content-type', 'application/json');
    res.writeHead(403);
    return res.end(JSON.stringify({ ok: false, error: 'origin_not_allowed' }));
  }

  if (req.method === 'OPTIONS') {
    // Preflight requests must NOT require auth, otherwise the browser reports "Failed to fetch".
    res.writeHead(204);
    return res.end();
  }

  const url = new URL(req.url || '/', 'http://127.0.0.1');
  const path = url.pathname;

  // Health + handshake must be probeable without credentials for collision detection.
  if (path === '/health' && req.method === 'GET') {
    res.setHeader('content-type', 'application/json');
    res.writeHead(200);
    return res.end(
      JSON.stringify({
        ok: true,
        expiresAt,
        bridgeId: BRIDGE_SERVICE_ID,
        instanceNonce: BRIDGE_INSTANCE_NONCE,
      })
    );
  }

  if (path === '/handshake' && req.method === 'GET') {
    res.setHeader('content-type', 'application/json');
    res.writeHead(200);
    return res.end(
      JSON.stringify({
        ok: true,
        bridgeId: BRIDGE_SERVICE_ID,
        protocol: 'bearer_v1',
        instanceNonce: BRIDGE_INSTANCE_NONCE,
      })
    );
  }

  if (isRateLimited(remoteAddr)) {
    res.setHeader('content-type', 'application/json');
    res.writeHead(429);
    return res.end(JSON.stringify({ ok: false, error: 'rate_limited' }));
  }

  const auth = req.headers['authorization'] || '';
  const { token: currentToken } = ensureToken();
  const expected = `Bearer ${currentToken}`;
  if (auth !== expected) {
    recordFailedAuth(remoteAddr);
    res.setHeader('content-type', 'application/json');
    res.writeHead(401);
    return res.end(JSON.stringify({ ok: false, error: 'unauthorized' }));
  }

  // Successful auth: clear any prior failures for this client.
  failedAuth.delete(remoteAddr);

  if (path === '/heartbeat' && req.method === 'GET') {
    res.setHeader('content-type', 'application/json');
    res.writeHead(200);
    return res.end(
      JSON.stringify({ ok: true, bridgeId: BRIDGE_SERVICE_ID, instanceNonce: BRIDGE_INSTANCE_NONCE })
    );
  }

  res.setHeader('content-type', 'application/json');
  res.writeHead(404);
  return res.end(JSON.stringify({ ok: false, error: 'not_found' }));
}

// Naive per-IP failed auth tracker to avoid brute‑force on the shared token.
const failedAuth = new Map();
const MAX_FAILED_PER_WINDOW = 16;
const FAILURE_WINDOW_MS = 60 * 1000;

function ensureToken(ttlMs = tokenTtlMs) {
  const now = Date.now();
  if (!token || now > expiresAt - 5000 || ttlMs !== tokenTtlMs) {
    tokenTtlMs = ttlMs;
    const previous = token;
    const userToken = initialEnvToken;
    // Prefer existing env var if set, otherwise generate one.
    token =
      userToken ||
      crypto.randomBytes(24).toString('base64url');
    tokenSource = userToken ? 'env' : 'generated';
    process.env.CEP_BRIDGE_TOKEN = token;
    expiresAt = now + tokenTtlMs;
    if (previous !== token) {
      tokenVersion += 1;

      // Drop any WS clients that authenticated with an older token.
      // This needs to happen anywhere the token rotates (not just inside the rotation timer),
      // otherwise callers like getCredentials() could rotate the token without forcing re-auth.
      for (const ws of wsClients) {
        if (ws.__tokenVersion !== tokenVersion) {
          try {
            ws.close(4001, 'token_rotated');
          } catch {
            // ignore
          }
        }
      }
    }
  }
  return { token, expiresAt, tokenVersion };
}

function scheduleTokenRotation() {
  if (rotationTimer) return;
  rotationTimer = setInterval(() => {
    if (!token || !expiresAt) return;
    const now = Date.now();
    if (now <= expiresAt - 5000) return;

    // Rotation + client eviction is handled inside ensureToken.
    ensureToken(tokenTtlMs);
  }, Math.min(Math.max(tokenTtlMs / 2, 5 * 60 * 1000), 30 * 60 * 1000));
}

function recordFailedAuth(remoteAddr) {
  const now = Date.now();
  const key = remoteAddr || 'unknown';
  const entry = failedAuth.get(key) || { count: 0, first: now, blockUntil: 0 };

  if (now - entry.first > FAILURE_WINDOW_MS) {
    entry.count = 1;
    entry.first = now;
  } else {
    entry.count += 1;
  }

  if (entry.count >= MAX_FAILED_PER_WINDOW) {
    entry.blockUntil = now + FAILURE_WINDOW_MS;
  }

  failedAuth.set(key, entry);
}

function isRateLimited(remoteAddr) {
  const key = remoteAddr || 'unknown';
  const entry = failedAuth.get(key);
  if (!entry) return false;

  const now = Date.now();
  if (entry.blockUntil && now < entry.blockUntil) return true;

  if (now - entry.first > FAILURE_WINDOW_MS) {
    failedAuth.delete(key);
    return false;
  }

  return false;
}

function isAllowedOrigin(originHeader) {
  if (!originHeader) return true;
  const origin = String(originHeader);
  if (origin === 'null') return true;
  if (origin.startsWith('file://')) return true;

  try {
    const url = new URL(origin);
    const isLoopbackHost =
      url.hostname === '127.0.0.1' ||
      url.hostname === 'localhost';
    const isExpectedProtocol =
      url.protocol === 'http:' ||
      url.protocol === 'https:';

    if (isLoopbackHost && isExpectedProtocol) {
      return true;
    }
  } catch {
    return false;
  }

  return false;
}

function applyCors(req, res) {
  const origin = req.headers.origin;

  // CEP panels frequently run with Origin: null (file://) or other custom schemes.
  // We still validate obvious localhost/file/null cases via isAllowedOrigin().
  if (origin && !isAllowedOrigin(origin)) {
    return false;
  }

  if (origin && isAllowedOrigin(origin)) {
    res.setHeader('Access-Control-Allow-Origin', String(origin));
    res.setHeader('Vary', 'Origin');
  } else {
    // Conservative default when no Origin header is present.
    res.setHeader('Access-Control-Allow-Origin', 'null');
  }

  const reqHeaders = req.headers['access-control-request-headers'];
  res.setHeader(
    'Access-Control-Allow-Headers',
    reqHeaders ? String(reqHeaders) : 'Authorization, Content-Type'
  );
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Max-Age', '86400');
  if (req.headers['access-control-request-private-network'] === 'true') {
    res.setHeader('Access-Control-Allow-Private-Network', 'true');
  }
  return true;
}

function ensureHttpServer() {
  if (server || usingExternalBridge) return server;

  ensureToken();

  serverReady = false;
  serverError = null;
  startupStatus = 'starting';

  server = http.createServer(bridgeRequestHandler);

  serverStartPromise = new Promise((resolve, reject) => {
    server.once('listening', () => {
      activePort = Number(server.address()?.port) || activePort;
      serverReady = true;
      serverError = null;
      startupStatus = 'started';
      resolve(true);
    });

    server.once('error', async (err) => {
      serverReady = false;
      const code = err?.code || 'ERR_SERVER_LISTEN';
      if (code !== 'EADDRINUSE') {
        const message = err?.message || 'Bridge server failed to start.';
        startupStatus = 'bind_failed';
        serverError = { code: 'bind_failed', message };
        try {
          console.error('[bridgeServerService] HTTP server error:', err);
        } catch {
          // ignore logging error
        }
        reject(err);
        return;
      }

      try {
        server.close();
      } catch {
        // ignore
      }
      server = null;

      const probe = await probeExistingBridge();
      if (probe.status === 'healthy') {
        const { token: tokenCandidate } = ensureToken();
        const authProbe = await probeAuthenticatedBridge(tokenCandidate);

        activePort = PREFERRED_BRIDGE_PORT;
        if (authProbe.statusCode === 200) {
          usingExternalBridge = true;
          serverReady = true;
          startupStatus = 'reused_existing';
          serverError = null;
          resolve(true);
          return;
        }

        const fallbackStarted = await startEphemeralFallbackServer();
        if (fallbackStarted) {
          resolve(true);
          return;
        }

        startupStatus = 'in_use_by_other';
        serverError = {
          code: 'in_use_by_other',
          message: `Bridge port ${PREFERRED_BRIDGE_PORT} is occupied by a bridge process that failed token authentication (HTTP ${authProbe.statusCode || 'unknown'}).`,
          remediation: 'Close other LEAD AE – ASSIST instances or align CEP_BRIDGE_TOKEN across processes, then retry.',
        };
        reject(new Error(serverError.message));
        return;
      }

      const fallbackStarted = await startEphemeralFallbackServer();
      if (fallbackStarted) {
        resolve(true);
        return;
      }

      serverReady = false;
      serverError = {
        code: 'bind_failed',
        message: `Preferred bridge port ${PREFERRED_BRIDGE_PORT} is unavailable and fallback startup failed.`,
        remediation: 'Retry LEAD AE – ASSIST. If the issue persists, restart your system bridge helper.',
      };
      reject(new Error(serverError.message));
    });
  });

  server.listen(PREFERRED_BRIDGE_PORT, '127.0.0.1', () => {
    try {
      console.log(
        `[bridgeServerService] Listening on http://127.0.0.1:${PREFERRED_BRIDGE_PORT}`
      );
    } catch {
      // ignore logging error
    }
  });

  return server;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function probeRequest(pathname, timeoutMs = 500) {
  return new Promise((resolve) => {
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: PREFERRED_BRIDGE_PORT,
        path: pathname,
        method: 'GET',
        timeout: timeoutMs,
      },
      (res) => {
        let data = '';
        res.setEncoding('utf8');
        res.on('data', chunk => {
          data += chunk;
        });
        res.on('end', () => {
          let json = null;
          try {
            json = data ? JSON.parse(data) : null;
          } catch {
            // ignore parse errors
          }
          resolve({ ok: true, statusCode: res.statusCode, json });
        });
      }
    );

    req.on('timeout', () => {
      req.destroy();
      resolve({ ok: false, reason: 'timeout' });
    });
    req.on('error', (error) => resolve({ ok: false, reason: error?.code || 'error' }));
    req.end();
  });
}

async function probeExistingBridge() {
  const [health, handshake] = await Promise.all([
    probeRequest('/health'),
    probeRequest('/handshake'),
  ]);

  const healthOk =
    health.ok &&
    health.statusCode === 200 &&
    health.json &&
    health.json.ok === true &&
    health.json.bridgeId === BRIDGE_SERVICE_ID;

  const handshakeOk =
    handshake.ok &&
    handshake.statusCode === 200 &&
    handshake.json &&
    handshake.json.ok === true &&
    handshake.json.bridgeId === BRIDGE_SERVICE_ID &&
    handshake.json.protocol === 'bearer_v1';

  const marker = health.json?.instanceNonce;
  const markerOk =
    typeof marker === 'string' &&
    marker.length > 0 &&
    marker === handshake.json?.instanceNonce;

  if (healthOk && handshakeOk && markerOk) {
    return {
      status: 'healthy',
      health,
      handshake,
      instanceNonce: marker,
      ownerMatch: marker === BRIDGE_INSTANCE_NONCE,
    };
  }

  return { status: 'unhealthy', health, handshake };
}

async function probeAuthenticatedBridge(tokenCandidate) {
  return new Promise(resolve => {
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: PREFERRED_BRIDGE_PORT,
        path: '/heartbeat',
        method: 'GET',
        timeout: 500,
        headers: {
          Authorization: `Bearer ${tokenCandidate || ''}`,
        },
      },
      (res) => {
        res.resume();
        res.on('end', () => resolve({ ok: true, statusCode: res.statusCode }));
      }
    );

    req.on('timeout', () => {
      req.destroy();
      resolve({ ok: false, statusCode: 0, reason: 'timeout' });
    });
    req.on('error', (error) => resolve({ ok: false, statusCode: 0, reason: error?.code || 'error' }));
    req.end();
  });
}

async function startEphemeralFallbackServer() {
  for (const delayMs of RETRY_BACKOFF_MS) {
    await sleep(delayMs);
    try {
      const fallbackServer = http.createServer(bridgeRequestHandler);
      await new Promise((resolve, reject) => {
        fallbackServer.once('error', reject);
        fallbackServer.once('listening', resolve);
        fallbackServer.listen(0, '127.0.0.1');
      });

      server = fallbackServer;
      activePort = Number(fallbackServer.address()?.port) || activePort;
      serverReady = true;
      startupStatus = 'started_fallback_ephemeral';
      serverError = null;
      return true;
    } catch (fallbackErr) {
      startupStatus = 'bind_failed';
      serverError = {
        code: 'bind_failed',
        message: fallbackErr?.message || 'Bridge fallback bind failed.',
        remediation: 'Verify local firewall/security tooling is not blocking localhost binds.',
      };
    }
  }
  return false;
}

function ensureWsServer() {
  if (usingExternalBridge) return null;
  if (wsServer) return wsServer;
  const srv = ensureHttpServer();
  ensureToken();

  wsServer = new WebSocket.Server({ server: srv });

  wsServer.on('error', (err) => {
    try {
      console.error('[bridgeServerService] WS server error:', err);
    } catch {
      // ignore logging error
    }
  });


  wsServer.on('connection', (ws, req) => {
    const remoteAddr = req.socket?.remoteAddress || 'unknown';
    const connId = ++wsConnSeq;

    try {
      if (isRateLimited(remoteAddr)) {
        try {
          ws.close(1013, 'rate_limited');
        } catch {
          // ignore
        }
        return;
      }

      const origin = req.headers.origin;
      if (!isAllowedOrigin(origin)) {
        recordFailedAuth(remoteAddr);
        try {
          ws.close(1008, 'origin_not_allowed');
        } catch {
          // ignore
        }
        return;
      }

      const proto = (req.headers['sec-websocket-protocol'] || '')
        .split(',')
        .map(s => s.trim());
      // Expect ["Bearer", "<token>"]
      const supplied = proto[1] || '';
      const { token: currentToken, tokenVersion: currentVersion } = ensureToken();
      if (!supplied || supplied !== currentToken) {
        recordFailedAuth(remoteAddr);
        try {
          ws.close(1008, 'unauthorized');
        } catch {
          // ignore
        }
        return;
      }

      // Successful auth: clear any prior failures for this client.
      failedAuth.delete(remoteAddr);

      const originHeader = String(req.headers.origin || '');
      const ua = String(req.headers['user-agent'] || '');
      const protoHeader = String(req.headers['sec-websocket-protocol'] || '');

      console.log(
        `[bridgeServerService] WS#${connId} connected from ${remoteAddr} ` +
        `clients=${wsClients.size + 1} ` +
        `origin=${originHeader || '(none)'} ` +
        `ua=${ua ? ua.slice(0, 120) : '(none)'} ` +
        `proto=${protoHeader ? protoHeader.slice(0, 120) : '(none)'}`
      );

      ws.__tokenVersion = currentVersion;
      ws.__connId = connId;
      ws.__connectedAt = Date.now();
      ws.__remoteAddr = remoteAddr;
      wsClients.add(ws);
      ws.on('close', (code, reasonBuf) => {
        wsClients.delete(ws);
        const ageMs = Date.now() - (ws.__connectedAt || Date.now());
        const reason = (() => {
          try {
            return reasonBuf ? reasonBuf.toString('utf8') : '';
          } catch {
            return '';
          }
        })();
        console.log(
          `[bridgeServerService] WS#${connId} closed ` +
          `from=${remoteAddr} code=${code} reason=${reason || '(none)'} ` +
          `ageMs=${ageMs} clients=${wsClients.size}`
        );
      });
      ws.on('error', (err) => {
        wsClients.delete(ws);
        console.log(
          `[bridgeServerService] WS#${connId} error from=${remoteAddr} ` +
          `err=${err?.message || String(err)} clients=${wsClients.size}`
        );
      });
      // CEP → backend messages (JSON over WS)
      ws.on('message', data => {
        if (!messageSubscribers.size) return;
        let msg = null;
        try {
          if (typeof data === 'string') {
            msg = JSON.parse(data);
          } else {
            msg = JSON.parse(data.toString('utf8'));
          }
        } catch {
          // ignore non‑JSON payloads
          return;
        }
        for (const fn of messageSubscribers) {
          try {
            fn(msg, ws);
          } catch {
            // ignore individual handler errors
          }
        }
      });
    } catch {
      try {
        ws.close(1011, 'internal');
      } catch {
        // ignore
      }
    }
  });

  return wsServer;
}

/**
 * Start or reuse the bridge server.
 * Returns { server, token, port, expiresAt } synchronously.
 */
function startServer(ttlMs = 60 * 60 * 1000) {
  ensureToken(ttlMs);
  ensureHttpServer();
  scheduleTokenRotation();
  return { server, token, tokenSource, port: activePort, expiresAt };
}

/**
 * Async credentials getter used by bridgeAuthService / IPC bridge.
 */
async function getCredentials() {
  const { token: t, tokenSource: source, port: p, expiresAt: e } = startServer();

  // Wait for the underlying server to be actually listening (or fail with a real error).
  if (serverStartPromise) {
    try {
      await serverStartPromise;
    } catch {
      // handled via serverError below
    }
  }

  if (!serverReady) {
    return {
      ok: false,
      code: serverError?.code || 'bind_failed',
      status: startupStatus === 'starting' ? 'bind_failed' : startupStatus,
      error: serverError?.message || 'Bridge server is not ready.',
      remediation: serverError?.remediation || 'Retry start. If the issue persists, restart LEAD AE – ASSIST.',
      port: activePort || p,
    };
  }

  ensureWsServer();

  return {
    ok: true,
    token: t,
    tokenSource: source,
    port: activePort || p,
    expiresAt: e,
    status: startupStatus,
    diagnostics: {
      reusedExisting: startupStatus === 'reused_existing',
      usingExternalBridge,
      preferredPort: PREFERRED_BRIDGE_PORT,
    },
  };
}

/**
 * Broadcast a message to all connected CEP panel sockets.
 */
function broadcast(msg) {
  ensureWsServer();
  // Critical: if there are no CEP clients, do NOT stringify large payloads.
  // JSON.stringify on big job objects can stall the Electron main thread and freeze the UI.
  if (!wsClients || wsClients.size === 0) return;

  let payload;
  if (typeof msg === 'string') {
    payload = msg;
  } else {
    try {
      payload = JSON.stringify(msg);
    } catch {
      // Never let a serialization error take down the bridge.
      return;
    }
  }
  for (const ws of wsClients) {
    try {
      ws.send(payload);
    } catch {
      // ignore failures per client
    }
  }
}

/**
 * Subscribe to CEP → backend messages.
 * handler(msg, ws) where msg is a parsed JSON object.
 * Returns an unsubscribe function.
 */
function onMessage(handler) {
  if (typeof handler !== 'function') return () => {};
  messageSubscribers.add(handler);
  return () => {
    messageSubscribers.delete(handler);
  };
}

module.exports = {
  startServer,
  getCredentials,
  broadcast,
  onMessage,
  __test: {
    isAllowedOrigin,
    applyCors,
    probeExistingBridge,
    resetState: async () => {
      if (wsServer) {
        try { wsServer.close(); } catch {
          // ignore
        }
      }
      wsServer = null;

      if (server) {
        await new Promise(resolve => {
          try {
            server.close(() => resolve());
          } catch {
            resolve();
          }
        });
      }
      server = null;
      serverReady = false;
      serverError = null;
      serverStartPromise = null;
      startupStatus = 'idle';
      activePort = PREFERRED_BRIDGE_PORT;
      usingExternalBridge = false;
      wsClients.clear();
      messageSubscribers.clear();
    },
  },
};
