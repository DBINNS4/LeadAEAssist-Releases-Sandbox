'use strict';

// services/telemetryService.js
// Crash + error reporting integration (Option A): Sentry hosted.
//
// Design goals:
//  - Initialize early in the main process.
//  - Respect a persisted user preference (state.json -> preferences.crashReporting).
//  - Avoid leaking secrets: scrub obvious key/token values.
//  - Provide a small API for runtime enable/disable toggling (Preferences UI).

const fs = require('fs');
const path = require('path');

const { readState, writeState } = require('../utils/state');
const { ensureUserDataSubdir } = require('../utils/appPaths');

let _Sentry = null;
let _inited = false;
let _dsn = null;
let _enabled = true;
let _offlineMode = false;
let _appRootDir = path.join(__dirname, '..');
let _initError = null;
const _messageDedupe = new Map();
const DEFAULT_MESSAGE_DEDUPE_WINDOW_MS = 60 * 1000;
const MAX_DEDUPE_KEYS = 500;

const SENSITIVE_KEY_RE = /(api.?key|token|secret|password|authorization|bearer|cookie)/i;

// We treat *values* as potentially sensitive too (not just object keys).
// This avoids leaking tokens embedded in URLs (e.g. app:///index.html?token=...).
const URL_LIKE_RE = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//;
const APP_URL_PREFIXES = ['app:///', 'file:///'];
const HOME_PATH_RE = /\/(Users|home)\/[^\/]+/g;
const WIN_USER_RE = /\\Users\\[^\\]+/gi;

function sanitizeStringValue(input) {
  if (typeof input !== 'string') return input;
  let s = input;

  // 1) Strip query strings + fragments from URL-like values.
  // We do this even if the URL is app:/// or file:///.
  const isUrlLike = URL_LIKE_RE.test(s) || APP_URL_PREFIXES.some(p => s.startsWith(p));
  if (isUrlLike) {
    const q = s.indexOf('?');
    const h = s.indexOf('#');
    const cut = (q === -1) ? h : (h === -1 ? q : Math.min(q, h));
    if (cut !== -1) s = s.slice(0, cut);
  }

  // 2) Scrub obvious username segments in common home directory paths.
  // Note: we intentionally do NOT touch stack frame filenames because it can break sourcemap matching.
  s = s.replace(HOME_PATH_RE, (_m, root) => `/${root}/<redacted>`);
  s = s.replace(WIN_USER_RE, '\\Users\\<redacted>');

  return s;
}


function isExpectedUpdaterApplyErrorText(input) {
  const msg = String(input || '');
  return /ditto:|shipit|could not lstat|could not read update request|could not locate update bundle/i.test(msg);
}

function getSentryEventPrimaryMessage(event) {
  if (typeof event?.message === 'string' && event.message.trim()) return event.message.trim();
  const value = event?.exception?.values?.[0]?.value;
  return typeof value === 'string' ? value.trim() : '';
}

function sanitizeBreadcrumb(breadcrumb) {
  if (!breadcrumb || typeof breadcrumb !== 'object') return breadcrumb;
  const b = { ...breadcrumb };
  if (typeof b.message === 'string') b.message = sanitizeStringValue(b.message);
  if (typeof b.category === 'string') b.category = sanitizeStringValue(b.category);
  if (b.data && typeof b.data === 'object') b.data = scrubDeep(b.data);
  return b;
}

function safeJsonParse(str) {
  try {
    return JSON.parse(str);
  } catch {
    return null;
  }
}

function readJsonFile(filePath) {
  try {
    if (!filePath) return null;
    if (!fs.existsSync(filePath)) return null;
    const raw = fs.readFileSync(filePath, 'utf8');
    return safeJsonParse(raw);
  } catch {
    return null;
  }
}

function getPrefEnabled() {
  try {
    const defaultStatePath = path.join(_appRootDir, 'config', 'state.json');
    const defaultState = readJsonFile(defaultStatePath);
    const defaultPrefs = (defaultState && typeof defaultState.preferences === 'object')
      ? defaultState.preferences
      : {};
    // Legacy default is ON, but we prefer the shipped default if present.
    const defaultCrashReporting = (typeof defaultPrefs.crashReporting === 'boolean')
      ? defaultPrefs.crashReporting
      : true;

    // Avoid noisy warnings on first run when state.json isn't created yet.
    const userStatePath = path.join(ensureUserDataSubdir('config'), 'state.json');
    if (!fs.existsSync(userStatePath)) return defaultCrashReporting;

    const state = readState() || {};
    const prefs = (state.preferences && typeof state.preferences === 'object') ? state.preferences : {};

    // Use persisted preference if present; otherwise fall back to the shipped default.
    return (typeof prefs.crashReporting === 'boolean')
      ? prefs.crashReporting
      : defaultCrashReporting;
  } catch {
    return true;
  }
}

function scrubDeep(value, depth = 0) {
  if (depth > 4) return value;
  if (value == null) return value;

  if (typeof value === 'string') {
    return sanitizeStringValue(value);
  }

  if (Array.isArray(value)) {
    return value.map(v => scrubDeep(v, depth + 1));
  }

  if (typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      if (SENSITIVE_KEY_RE.test(String(k))) {
        out[k] = '[REDACTED]';
      } else {
        out[k] = scrubDeep(v, depth + 1);
      }
    }
    return out;
  }

  return value;
}

function sanitizeSentryEvent(event) {
  try {
    if (!event || typeof event !== 'object') return event;

    // Remove SDK-populated identifiers before we scrub nested data.
    // We delete keys rather than redacting to avoid accidental rehydration downstream.
    if ('user' in event) delete event.user;
    if ('server_name' in event) delete event.server_name;
    if ('userId' in event) delete event.userId;
    if ('user_id' in event) delete event.user_id;
    if ('username' in event) delete event.username;

    if (typeof event.message === 'string') {
      event.message = sanitizeStringValue(event.message);
    }

    if (event.exception && Array.isArray(event.exception.values)) {
      event.exception.values = event.exception.values.map(value => {
        if (!value || typeof value !== 'object') return value;
        if (typeof value.value === 'string') {
          return { ...value, value: sanitizeStringValue(value.value) };
        }
        return value;
      });
    }

    // Electron apps often have file:// URLs, query params, etc.
    // We don't need request context for crash triage, and it can leak tokens.
    if ('request' in event) delete event.request;

    if (event.extra && typeof event.extra === 'object') {
      event.extra = scrubDeep(event.extra);
    }
    if (event.contexts && typeof event.contexts === 'object') {
      const contexts = { ...event.contexts };
      if (contexts.device && typeof contexts.device === 'object') {
        const device = { ...contexts.device };
        if ('name' in device) delete device.name;
        if ('id' in device) delete device.id;
        if ('device_id' in device) delete device.device_id;
        if ('serial_number' in device) delete device.serial_number;
        if ('hostname' in device) delete device.hostname;
        contexts.device = device;
      }
      if (contexts.os && typeof contexts.os === 'object') {
        const os = { ...contexts.os };
        if ('name' in os) delete os.name;
        if ('hostname' in os) delete os.hostname;
        contexts.os = os;
      }
      event.contexts = scrubDeep(contexts);
    }
    if (event.tags && typeof event.tags === 'object') {
      event.tags = scrubDeep(event.tags);
    }

    if (Array.isArray(event.breadcrumbs)) {
      event.breadcrumbs = event.breadcrumbs
        .map(b => sanitizeBreadcrumb(b))
        .filter(Boolean);
    }
  } catch {
    // Never break error reporting.
  }

  return event;
}

function resolveDsn() {
  // Priority: env
  const envDsn = process.env.SENTRY_DSN || process.env.SENTRY_ELECTRON_DSN;
  if (typeof envDsn === 'string' && envDsn.trim()) return envDsn.trim();

  // Next: userData config (lets you ship builds without hardcoding DSN)
  const userDataPath = process.env.USER_DATA_PATH;
  if (userDataPath) {
    const userCfg = path.join(userDataPath, 'config', 'sentry.json');
    const j = readJsonFile(userCfg);
    if (j && typeof j.dsn === 'string' && j.dsn.trim()) return j.dsn.trim();
  }

  // Next: app config
  const appCfg = path.join(_appRootDir, 'config', 'sentry.json');
  const j = readJsonFile(appCfg);
  if (j && typeof j.dsn === 'string' && j.dsn.trim()) return j.dsn.trim();

  return null;
}


function isOfflineModeEnabled() {
  try {
    const state = readState() || {};
    return !!state?.preferences?.offlineMode;
  } catch {
    return false;
  }
}

function getState() {
  return {
    configured: !!_dsn,
    enabled: !!_enabled,
    inited: !!_inited,
    initError: _initError ? String(_initError?.message || _initError) : null,
  };
}

let _didLogSentryFrameSample = false;

function rewriteFrameFilename(filename) {
  if (typeof filename !== 'string') return filename;
  if (filename.startsWith('app:///')) return filename;

  // Normalize Windows paths so we can match consistently.
  const normalized = filename.replace(/\\/g, '/');

  // We only rewrite our app bundles. Leave everything else alone.
  const marker = '/dist-obfuscated/';
  const idx = normalized.lastIndexOf(marker);
  if (idx !== -1) {
    const tail = normalized.slice(idx + marker.length);
    return tail ? `app:///dist-obfuscated/${tail}` : 'app:///dist-obfuscated';
  }

  return filename;
}

function isAbsolutePathValue(value) {
  if (typeof value !== 'string') return false;
  return path.posix.isAbsolute(value) || path.win32.isAbsolute(value);
}

function scrubFramePaths(frame) {
  if (!frame || typeof frame !== 'object') return;

  for (const [key, value] of Object.entries(frame)) {
    if (key === 'filename') continue;
    if (key === 'abs_path') {
      delete frame.abs_path;
      continue;
    }
    if (typeof value === 'string' && isAbsolutePathValue(value)) {
      frame[key] = sanitizeStringValue(value);
    }
  }
}

function rewriteStacktraceFrames(frames) {
  if (!Array.isArray(frames)) return;
  for (const frame of frames) {
    if (!frame || typeof frame !== 'object') continue;
    if (typeof frame.filename === 'string') {
      const next = rewriteFrameFilename(frame.filename);
      if (next !== frame.filename) frame.filename = next;
    }
    scrubFramePaths(frame);
  }
}

function rewriteEventFilenamesForSourcemaps(event) {
  try {
    if (!event || typeof event !== 'object') return event;

    // Exceptions
    const values = (event.exception && Array.isArray(event.exception.values))
      ? event.exception.values
      : [];

    for (const v of values) {
      rewriteStacktraceFrames(v && v.stacktrace && v.stacktrace.frames);
    }

    // Message events can also contain a top-level stacktrace.
    rewriteStacktraceFrames(event.stacktrace && event.stacktrace.frames);
  } catch {
    // ignore
  }
  return event;
}

function maybeLogFrameSample(event) {
  try {
    if (process.env.SENTRY_DEBUG_FRAMES !== 'true') return;
    if (_didLogSentryFrameSample) return;
    _didLogSentryFrameSample = true;

    const filenames = [];

    const pushFrames = (frames) => {
      if (!Array.isArray(frames)) return;
      for (const f of frames) {
        const fn = f && typeof f.filename === 'string' ? f.filename : '';
        if (fn) filenames.push(fn);
        if (filenames.length >= 8) break;
      }
    };

    const values = event?.exception?.values;
    if (Array.isArray(values)) {
      for (const v of values) {
        pushFrames(v?.stacktrace?.frames);
        if (filenames.length >= 8) break;
      }
    }

    pushFrames(event?.stacktrace?.frames);

     
    console.log('[telemetry] Sentry frame filename sample:', filenames);
  } catch {
    // ignore
  }
}

function setCrashUploadEnabled(uploadEnabled) {
  try {
    const { crashReporter } = require('electron');
    if (crashReporter && typeof crashReporter.setUploadToServer === 'function') {
      crashReporter.setUploadToServer(!!uploadEnabled);
    }
  } catch {
    // ignore
  }
}


function refreshNetworkGates() {
  try {
    _offlineMode = isOfflineModeEnabled();
  } catch {
    _offlineMode = false;
  }
  // Offline Mode always overrides crash upload.
  try { setCrashUploadEnabled(_enabled && !_offlineMode); } catch {}
  return { ok: true, offlineMode: _offlineMode };
}

function init(options = {}) {
  try {
    if (typeof options.appRootDir === 'string' && options.appRootDir.trim()) {
      _appRootDir = options.appRootDir.trim();
    }

    _enabled = getPrefEnabled();
    _offlineMode = isOfflineModeEnabled();
    _dsn = resolveDsn();

    if (!_dsn) {
      // No DSN: keep telemetry inactive and harmless.
      return { ok: false, reason: 'missing_dsn', ...getState() };
    }

    // Require lazily so "npm install" errors are obvious.
    _Sentry = require('@sentry/electron/main');

    // Don't double-init.
    if (_inited) {
      // Still enforce upload enable/disable if preference changed.
      setCrashUploadEnabled(_enabled && !_offlineMode);
      return { ok: true, ...getState() };
    }

    const { app } = require('electron');

    // IMPORTANT: This must match the release name used when uploading sourcemaps to Sentry.
    // We intentionally use the packaged app version (package.json "version") so
    // symbolication works reliably without depending on runtime env vars.
    const release = app.getVersion?.() || '0.0.0';

    const environment = process.env.SENTRY_ENVIRONMENT
      || process.env.NODE_ENV
      || ((options.isPackaged ?? app.isPackaged) ? 'production' : 'development');

    _Sentry.init({
      dsn: _dsn,
      release,
      environment,
      beforeBreadcrumb(breadcrumb /*, hint */) {
        // If the user disabled crash reporting, don't even record breadcrumbs.
        if (!_enabled) return null;
        if (_offlineMode) return null;

        const b = sanitizeBreadcrumb(breadcrumb);

        // Reduce the risk of leaking file paths via verbose console breadcrumbs.
        // Keep warnings/errors; drop noisy info/log/debug.
        const level = String(b?.level || '').toLowerCase();
        const isConsole = String(b?.category || '').toLowerCase() === 'console';
        if (isConsole && (level === 'log' || level === 'info' || level === 'debug')) return null;

        return b;
      },
      beforeSend(event /*, hint */) {
        if (!_enabled) return null;
        if (_offlineMode) return null;
        if (isExpectedUpdaterApplyErrorText(getSentryEventPrimaryMessage(event))) return null;

        // Keep stack frame URLs deterministic so Sentry sourcemaps match reliably.
        // This also strips machine-specific file paths from renderer stack traces.
        rewriteEventFilenamesForSourcemaps(event);
        maybeLogFrameSample(event);

        return sanitizeSentryEvent(event);
      },
    });

    _inited = true;

    // Native crash upload honor user preference.
    setCrashUploadEnabled(_enabled);

    return { ok: true, ...getState() };
  } catch (err) {
    _initError = err;
    try {
      console.error('❌ Telemetry init failed:', err?.message || err);
    } catch {
      // ignore
    }
    return { ok: false, reason: 'init_failed', ...getState() };
  }
}

function persistEnabledPreference(enabled) {
  try {
    const state = readState() || {};
    const prefs = (state.preferences && typeof state.preferences === 'object') ? state.preferences : {};
    const nextState = { ...state, preferences: { ...prefs, crashReporting: !!enabled } };
    const writeResult = writeState(nextState);
    if (!writeResult?.ok) {
      throw writeResult?.error || new Error('Unknown telemetry preference persistence error');
    }
    return { ok: true };
  } catch (error) {
    try {
      console.error('❌ Failed to persist telemetry preference:', error?.message || error);
    } catch {
      // ignore
    }
    return { ok: false, error };
  }
}

function setEnabled(enabled, { persist = false } = {}) {
  _enabled = !!enabled;
  let persistError = null;
  if (persist) {
    const persisted = persistEnabledPreference(_enabled);
    if (!persisted?.ok) persistError = persisted?.error || new Error('Failed to persist telemetry preference');
  }

  // If Sentry isn't configured, this still updates the preference and returns.
  setCrashUploadEnabled(_enabled && !_offlineMode);
  if (persistError) {
    return { ok: false, reason: 'persist_failed', error: String(persistError?.message || persistError), ...getState() };
  }
  return { ok: true, ...getState() };
}

function normalizeLevel(level) {
  const normalized = String(level || 'info').toLowerCase();
  switch (normalized) {
    case 'fatal':
    case 'critical':
      return 'fatal';
    case 'error':
    case 'warning':
    case 'warn':
    case 'log':
    case 'info':
    case 'debug':
      if (normalized === 'warn') return 'warning';
      return normalized;
    default:
      return 'info';
  }
}

function applyScopeData(scope, { tags, extra, contexts } = {}) {
  try {
    if (tags && typeof tags === 'object') {
      const safeTags = scrubDeep(tags);
      for (const [k, v] of Object.entries(safeTags)) {
        if (v == null) continue;
        try { scope.setTag(String(k), sanitizeStringValue(String(v))); } catch {}
      }
    }
    if (extra && typeof extra === 'object') {
      const safeExtra = scrubDeep(extra);
      for (const [k, v] of Object.entries(safeExtra)) {
        if (v == null) continue;
        try { scope.setExtra(String(k), v); } catch {}
      }
    }
    if (contexts && typeof contexts === 'object') {
      const safeContexts = scrubDeep(contexts);
      for (const [k, v] of Object.entries(safeContexts)) {
        if (v == null) continue;
        try { scope.setContext(sanitizeStringValue(String(k)), v); } catch {}
      }
    }
  } catch {
    // ignore
  }
}

function buildMessageDedupeKey({ message, level, tags, dedupeKey }) {
  if (dedupeKey != null) return String(dedupeKey);

  const base = {
    message: sanitizeStringValue(String(message || '')),
    level: normalizeLevel(level),
    tags: tags && typeof tags === 'object' ? scrubDeep(tags) : undefined
  };
  return JSON.stringify(base);
}

function shouldSuppressMessage({ message, level, tags, dedupeKey, dedupeWindowMs }) {
  const windowMs = Number.isFinite(Number(dedupeWindowMs))
    ? Math.max(0, Number(dedupeWindowMs))
    : DEFAULT_MESSAGE_DEDUPE_WINDOW_MS;
  if (windowMs <= 0) return false;

  const key = buildMessageDedupeKey({ message, level, tags, dedupeKey });
  const now = Date.now();
  const lastAt = _messageDedupe.get(key);
  if (Number.isFinite(lastAt) && (now - lastAt) < windowMs) {
    return true;
  }
  _messageDedupe.set(key, now);

  if (_messageDedupe.size > MAX_DEDUPE_KEYS) {
    const cutoff = now - windowMs;
    for (const [seenKey, seenAt] of _messageDedupe.entries()) {
      if (seenAt < cutoff) _messageDedupe.delete(seenKey);
      if (_messageDedupe.size <= MAX_DEDUPE_KEYS) break;
    }
  }
  return false;
}

function captureException(err, { tags, extra, contexts } = {}) {
  try {
    if (!_inited || !_Sentry) return;
    if (!_enabled) return;
    if (_offlineMode) return;

    const e = (err instanceof Error)
      ? err
      : new Error(typeof err === 'string' ? err : 'Non-Error thrown');

    if (typeof _Sentry.withScope === 'function') {
      _Sentry.withScope(scope => {
        applyScopeData(scope, { tags, extra, contexts });
        _Sentry.captureException(e);
      });
      return;
    }

    // Fallback: capture without per-event scope.
    _Sentry.captureException(e);
  } catch {
    // Never throw from telemetry.
  }
}

function captureMessage(message, {
  level = 'info',
  tags,
  extra,
  contexts,
  dedupeKey,
  dedupeWindowMs = DEFAULT_MESSAGE_DEDUPE_WINDOW_MS
} = {}) {
  try {
    if (!_inited || !_Sentry) return;
    if (!_enabled) return;
    if (_offlineMode) return;

    const text = sanitizeStringValue(String(message || ''));
    if (!text) return;

    if (shouldSuppressMessage({ message: text, level, tags, dedupeKey, dedupeWindowMs })) {
      return;
    }

    const resolvedLevel = normalizeLevel(level);
    if (typeof _Sentry.withScope === 'function') {
      _Sentry.withScope(scope => {
        applyScopeData(scope, { tags, extra, contexts });
        _Sentry.captureMessage(text, resolvedLevel);
      });
      return;
    }

    _Sentry.captureMessage(text, resolvedLevel);
  } catch {
    // Never throw from telemetry.
  }
}

module.exports = {
  init,
  getState,
  refreshNetworkGates,
  setEnabled,
  captureException,
  captureMessage,
};
