'use strict';

const fs = require('fs');
const path = require('path');

const stateStore = require('../utils/state');
const runtimeAssetService = require('./runtimeAssetService');
const chromiumAssetService = require('./chromiumAssetService');
const whisperAssetService = require('./whisperAssetService');

const CHROMIUM_FEATURES = new Set([
  'chromium',
  'browser',
  'chrome',
  'speed-test',
  'network-test'
]);

const WHISPER_FEATURES = new Set([
  'whisper',
  'transcription-model',
  'local-transcription',
  'transcription'
]);

function readOfflineModePreference() {
  try {
    const readState = stateStore && typeof stateStore.readState === 'function'
      ? stateStore.readState
      : null;
    const state = readState ? (readState() || {}) : {};
    return !!state?.preferences?.offlineMode;
  } catch {
    return false;
  }
}

function normalizeAssetRequest(request = {}) {
  if (typeof request === 'string' && request.trim()) {
    return { assetId: request.trim() };
  }
  if (!request || typeof request !== 'object') return {};

  const out = { ...request };
  if (typeof out.assetId === 'string') out.assetId = out.assetId.trim();
  if (typeof out.feature === 'string') out.feature = out.feature.trim();
  if (typeof out.kind === 'string') out.kind = out.kind.trim();
  if (typeof out.target === 'string') out.target = out.target.trim();
  if (typeof out.language === 'string') out.language = out.language.trim();
  if (typeof out.platform === 'string') out.platform = out.platform.trim();
  if (typeof out.arch === 'string') out.arch = out.arch.trim();
  if (typeof out.requestId === 'string') out.requestId = out.requestId.trim();
  return out;
}

function normalizeFeatureName(value) {
  return String(value || '').trim().toLowerCase();
}

function sanitizeAssetDescriptor(desc = {}) {
  const out = {
    type: desc.type || null,
    installPath: desc.installPath || null,
    installDir: desc.installDir || null,
    archiveFormat: desc.archiveFormat || null,
    relativeUrl: desc.relativeUrl || null,
    downloadUrl: desc.downloadUrl || null,
    sha256: desc.sha256 || null,
    size: Number.isFinite(Number(desc.size)) ? Number(desc.size) : null,
    entrypoint: desc.entrypoint || null,
    seedPaths: Array.isArray(desc.seedPaths) ? [...desc.seedPaths] : []
  };

  if (!out.installPath) delete out.installPath;
  if (!out.installDir) delete out.installDir;
  if (!out.archiveFormat) delete out.archiveFormat;
  if (!out.relativeUrl) delete out.relativeUrl;
  if (!out.downloadUrl) delete out.downloadUrl;
  if (!out.sha256) delete out.sha256;
  if (out.size == null) delete out.size;
  if (!out.entrypoint) delete out.entrypoint;
  if (!out.seedPaths.length) delete out.seedPaths;

  return out;
}

function computeInstalledPathFromDescriptor(assetId, desc = {}, options = {}) {
  if (!desc || typeof desc !== 'object') return null;
  const { assetsRoot } = runtimeAssetService.computeAssetPaths({ userDataPath: options.userDataPath });
  if (desc.installPath) return path.join(assetsRoot, desc.installPath);
  if (desc.installDir) return path.join(assetsRoot, desc.installDir);
  return runtimeAssetService.getInstalledAssetPath(assetId, { userDataPath: options.userDataPath }) || null;
}

function _resolveDescriptor(assetId, options = {}) {
  const desc = runtimeAssetService.getAssetDescriptor(assetId, { isPackaged: !!options.isPackaged });
  if (!desc) {
    const err = new Error(`Runtime asset ${assetId} is not present in the packaged manifest.`);
    err.code = 'ASSET_MISSING';
    err.assetId = assetId;
    throw err;
  }
  return desc;
}

function resolveRuntimeAssetRequest(request = {}, options = {}) {
  const normalized = normalizeAssetRequest(request);
  const isPackaged = !!options.isPackaged;

  if (normalized.assetId) {
    const assetId = normalized.assetId;
    const descriptor = _resolveDescriptor(assetId, { isPackaged });
    return {
      request: normalized,
      kind: 'asset',
      feature: normalizeFeatureName(normalized.feature || normalized.kind || normalized.target) || 'asset',
      assetId,
      descriptor,
      descriptorSummary: sanitizeAssetDescriptor(descriptor)
    };
  }

  const feature = normalizeFeatureName(normalized.feature || normalized.kind || normalized.target);
  if (CHROMIUM_FEATURES.has(feature)) {
    const platform = normalized.platform || options.platform || process.platform;
    const arch = normalized.arch || options.arch || process.arch;
    const assetId = chromiumAssetService.getChromiumAssetId({ platform, arch });
    if (!assetId) {
      const err = new Error(`Chromium runtime asset is not configured for ${platform}/${arch}.`);
      err.code = 'ASSET_UNSUPPORTED_PLATFORM';
      err.platform = platform;
      err.arch = arch;
      throw err;
    }

    const descriptor = _resolveDescriptor(assetId, { isPackaged });
    return {
      request: normalized,
      kind: 'chromium',
      feature: 'chromium',
      assetId,
      platform,
      arch,
      descriptor,
      descriptorSummary: sanitizeAssetDescriptor(descriptor)
    };
  }

  if (WHISPER_FEATURES.has(feature)) {
    const language = whisperAssetService.normalizeWhisperLanguage(normalized.language || options.language || 'en');
    const assetId = whisperAssetService.getWhisperModelAssetId({ language });
    const descriptor = _resolveDescriptor(assetId, { isPackaged });
    return {
      request: normalized,
      kind: 'whisper',
      feature: 'whisper',
      assetId,
      language,
      modelFile: whisperAssetService.getWhisperModelFileName({ language }),
      descriptor,
      descriptorSummary: sanitizeAssetDescriptor(descriptor)
    };
  }

  const err = new Error('Runtime asset request must include a supported feature/kind/target or an explicit assetId.');
  err.code = 'ASSET_REQUEST_INVALID';
  throw err;
}

async function ensureResolvedRuntimeAsset(resolved, options = {}) {
  const offline = (typeof options.offline === 'boolean') ? options.offline : readOfflineModePreference();

  if (resolved.kind === 'chromium') {
    return chromiumAssetService.ensureChromiumExecutablePath({
      ...resolved.request,
      ...options,
      assetId: resolved.assetId,
      platform: resolved.platform,
      arch: resolved.arch,
      offline
    });
  }

  if (resolved.kind === 'whisper') {
    return whisperAssetService.ensureWhisperModelPath({
      ...resolved.request,
      ...options,
      assetId: resolved.assetId,
      language: resolved.language,
      offline
    });
  }

  return runtimeAssetService.ensureAsset(resolved.assetId, {
    ...resolved.request,
    ...options,
    assetId: resolved.assetId,
    offline
  });
}

function resolveInstalledRuntimeAssetSnapshot(resolved, options = {}) {
  const offline = (typeof options.offline === 'boolean') ? options.offline : readOfflineModePreference();
  const descriptor = resolved.descriptor || runtimeAssetService.getAssetDescriptor(resolved.assetId, {
    isPackaged: !!options.isPackaged
  }) || {};
  const expectedPath = computeInstalledPathFromDescriptor(resolved.assetId, descriptor, options);
  const installed = !!(expectedPath && fs.existsSync(expectedPath));
  let executablePath = null;
  let modelPath = null;
  let ready = installed;

  if (installed && resolved.kind === 'chromium') {
    executablePath = chromiumAssetService.resolveChromiumExecutableFromAssetRoot(expectedPath, descriptor, {
      platform: resolved.platform,
      arch: resolved.arch
    });
    ready = !!executablePath;
  }

  if (installed && resolved.kind === 'whisper') {
    modelPath = expectedPath;
    ready = true;
  }

  return {
    assetId: resolved.assetId,
    kind: resolved.kind,
    feature: resolved.feature,
    language: resolved.language || null,
    modelFile: resolved.modelFile || null,
    platform: resolved.platform || null,
    arch: resolved.arch || null,
    descriptor: sanitizeAssetDescriptor(descriptor),
    expectedPath: expectedPath || null,
    path: installed ? expectedPath : null,
    installed,
    ready,
    executablePath,
    modelPath,
    offline
  };
}

module.exports = {
  readOfflineModePreference,
  normalizeAssetRequest,
  normalizeFeatureName,
  sanitizeAssetDescriptor,
  computeInstalledPathFromDescriptor,
  resolveRuntimeAssetRequest,
  ensureResolvedRuntimeAsset,
  resolveInstalledRuntimeAssetSnapshot
};
