'use strict';
// services/bridgeAuthService.js
// Minimal secure handshake: ephemeral token, short TTL, and a bridge.json the CEP panel can read.
// We DO NOT stand up a server here; we just publish token + port from the bridge server service.
//
// IMPORTANT:
// - The Premiere CEP panel cannot call Electron IPC. It reads bridge.json directly from disk.
// - The bridge server rotates its token on a schedule.
//   Therefore we must keep bridge.json fresh even if no renderer asks for credentials.

const { fs } = require('../utils/nativeFs');
const path = require('path');
const { app } = require('electron');
const { getCredentials } = require('./bridgeServerService');
const { renameReplaceSync, uniqueTempPath } = require('../utils/fsSafe');

let current = null; // { token, expiresAt, port, tokenSource, baseUrl, filePaths }

let autoRefreshStarted = false;
let autoRefreshTimer = null;
let autoRefreshInFlight = false;
let autoRefreshBackoffMs = 1000;
const autoRefreshBackoffMaxMs = 30000;

// The bridge server rotates at expiresAt - 5000ms.
// We aim to refresh inside that window so the server generates the new token,
// and then we immediately write it to disk for CEP.
const ROTATE_PREEMPT_MS = 2500;

function isDebugUiEnabled() {
  return !app?.isPackaged || process.env.DEBUG_UI === 'true';
}

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  try { fs.chmodSync(dir, 0o700); } catch {}
  return dir;
}

function resolveBridgeDir() {
  return ensureDir(path.join(app.getPath('userData'), 'bridge'));
}

function resolveConfigDir() {
  return ensureDir(path.join(app.getPath('userData'), 'config'));
}

function getBridgeFileTargets() {
  const targets = new Set();
  // Canonical location preferred by modern CEP loaders.
  targets.add(path.join(resolveBridgeDir(), 'bridge.json'));
  // Legacy location used by older builds and some startup writers.
  targets.add(path.join(resolveConfigDir(), 'bridge.json'));
  return Array.from(targets);
}

function hasRequiredCredentialFields(payload) {
  if (!payload || typeof payload !== 'object') return false;
  return payload.token != null && payload.expiresAt != null && payload.port != null;
}

function invalidCredentialResult(reason) {
  return {
    ok: false,
    error: reason,
  };
}

async function newCredentials() {
  const creds = await getCredentials(); // { ok:true, token, port, expiresAt, tokenSource } or { ok:false, ... }
  if (creds && creds.ok === false) {
    return creds;
  }

  if (!hasRequiredCredentialFields(creds)) {
    return invalidCredentialResult('bridge_credentials_invalid_payload');
  }

  const port = Number(creds.port);
  const expiresAt = Number(creds.expiresAt);
  if (!Number.isFinite(port) || port <= 0 || !Number.isFinite(expiresAt) || !creds.token) {
    return invalidCredentialResult('bridge_credentials_missing_required_fields');
  }

  const baseUrl = Number.isFinite(port) && port > 0 ? `http://127.0.0.1:${port}` : undefined;
  const filePath = path.join(resolveBridgeDir(), 'bridge.json');
  return {
    ok: true,
    ...creds,
    port,
    expiresAt,
    baseUrl,
    debugUI: isDebugUiEnabled(),
    filePath,
    filePaths: getBridgeFileTargets(),
  };
}

function atomicWriteJson(filePath, payload) {
  const tmpPath = uniqueTempPath(filePath, '.tmp');
  const serialized = JSON.stringify(payload, null, 2);

  try {
    fs.writeFileSync(tmpPath, serialized, { encoding: 'utf8', mode: 0o600 });
    renameReplaceSync(tmpPath, filePath);
    try { fs.chmodSync(filePath, 0o600); } catch {}
  } catch (err) {
    try { fs.unlinkSync(tmpPath); } catch {}
    throw err;
  }
}

function writeBridgeFiles(info) {
  const payload = {
    token: info.token,
    expiresAt: info.expiresAt,
    port: info.port,
    tokenSource: info.tokenSource || undefined,
    baseUrl: info.baseUrl,
    debugUI: !!info.debugUI,
  };

  const targets = Array.isArray(info.filePaths) ? info.filePaths : [];
  for (const p of targets) {
    if (!p) continue;
    atomicWriteJson(p, payload);
  }
  return targets;
}

function clearAutoRefreshTimer() {
  if (autoRefreshTimer) {
    clearTimeout(autoRefreshTimer);
    autoRefreshTimer = null;
  }
}

function scheduleAutoRefreshIn(delayMs) {
  clearAutoRefreshTimer();
  const ms = Math.max(250, Number(delayMs || 0));
  autoRefreshTimer = setTimeout(() => {
    autoRefreshTimer = null;
    void autoRefreshTick('backoff');
  }, ms);
  try { autoRefreshTimer.unref?.(); } catch {}
}

function scheduleAutoRefresh(expiresAt) {
  clearAutoRefreshTimer();

  const now = Date.now();
  const exp = Number(expiresAt || 0);

  // Unknown expiry: poll occasionally.
  let delayMs = 30000;

  if (Number.isFinite(exp) && exp > 0) {
    const untilExpiry = exp - now;
    // Aim to run shortly before expiry, inside the bridge server rotation window.
    delayMs = Math.max(1000, untilExpiry - ROTATE_PREEMPT_MS);
    if (untilExpiry <= 0) delayMs = 250;
  }

  autoRefreshTimer = setTimeout(() => {
    autoRefreshTimer = null;
    void autoRefreshTick('timer');
  }, delayMs);

  try { autoRefreshTimer.unref?.(); } catch {}
}

async function refreshAndMaybeWrite({ forceWrite = false } = {}) {
  const now = Date.now();
  const next = await newCredentials();
  if (next && next.ok === false) {
    return next;
  }

  if (!hasRequiredCredentialFields(next)) {
    return invalidCredentialResult('bridge_credentials_invalid_payload');
  }

  if (!next.filePath) {
    next.filePath = path.join(resolveBridgeDir(), 'bridge.json');
  }

  if (!Array.isArray(next.filePaths) || next.filePaths.length === 0) {
    next.filePaths = getBridgeFileTargets();
  }

  if (!Number.isFinite(Number(next.port)) || !Number.isFinite(Number(next.expiresAt)) || !next.token) {
    return invalidCredentialResult('bridge_credentials_missing_required_fields');
  }

  const hasMeaningfulChange =
    !current ||
    current.token !== next.token ||
    Number(current.port) !== Number(next.port) ||
    current.expiresAt !== next.expiresAt;

  const nearExpiry =
    !!current &&
    Number.isFinite(current.expiresAt) &&
    now > (Number(current.expiresAt) - 60 * 1000);

  if (forceWrite || hasMeaningfulChange || nearExpiry) {
    current = next;
    writeBridgeFiles(current);
  } else {
    // Keep the in-memory snapshot even if we skip IO.
    current = current || next;
  }

  return {
    ok: true,
    token: current.token,
    expiresAt: current.expiresAt,
    port: current.port,
    tokenSource: current.tokenSource,
    baseUrl: current.baseUrl,
    debugUI: !!current.debugUI,
    filePath: current.filePath,
    filePaths: current.filePaths,
  };
}

async function autoRefreshTick() {
  if (!autoRefreshStarted) return;
  if (autoRefreshInFlight) return;
  autoRefreshInFlight = true;

  try {
    const res = await refreshAndMaybeWrite({ forceWrite: false });

    if (res && res.ok === false) {
      autoRefreshBackoffMs = Math.min(
        autoRefreshBackoffMaxMs,
        Math.floor(autoRefreshBackoffMs * 1.6)
      );
      scheduleAutoRefreshIn(autoRefreshBackoffMs);
      return;
    }

    autoRefreshBackoffMs = 1000;
    scheduleAutoRefresh(res.expiresAt);
  } catch {
    autoRefreshBackoffMs = Math.min(
      autoRefreshBackoffMaxMs,
      Math.floor(autoRefreshBackoffMs * 1.6)
    );
    scheduleAutoRefreshIn(autoRefreshBackoffMs);
  } finally {
    autoRefreshInFlight = false;
  }
}

function startBridgeCredentialAutoRefresh() {
  if (autoRefreshStarted) return;
  autoRefreshStarted = true;

  const kick = async () => {
    try {
      const res = await refreshAndMaybeWrite({ forceWrite: true });
      if (res && res.ok !== false) {
        scheduleAutoRefresh(res.expiresAt);
      } else {
        scheduleAutoRefreshIn(autoRefreshBackoffMs);
      }
    } catch {
      scheduleAutoRefreshIn(autoRefreshBackoffMs);
    }
  };

  // Avoid calling app.getPath('userData') before Electron is ready, where possible.
  if (app?.isReady?.()) {
    void kick();
    return;
  }

  if (typeof app?.whenReady === 'function') {
    app.whenReady().then(() => kick()).catch(() => kick());
    return;
  }

  void kick();
}

async function getBridgeInfo() {
  // Ensure the on-disk bridge.json stays fresh for CEP, even if no renderer polls.
  startBridgeCredentialAutoRefresh();
  return refreshAndMaybeWrite({ forceWrite: false });
}

// Start automatically in the main process so CEP can always read a fresh token.
startBridgeCredentialAutoRefresh();

module.exports = { getBridgeInfo, startBridgeCredentialAutoRefresh };
