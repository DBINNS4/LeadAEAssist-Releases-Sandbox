'use strict';
// services/probeService.js
const { execFile, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

/**
 * Run ffprobe and return parsed JSON or raw stdout based on args.
 * @param {string} ffprobePath
 * @param {string[]} args
 * @returns {Promise<string>}
 */
function runFfprobe(ffprobePath, args) {
  return new Promise((resolve, reject) => {
    execFile(ffprobePath, args, (error, stdout) => {
      if (error) reject(error);
      else resolve(stdout);
    });
  });
}

/**
 * Read precomputed ffmpeg capabilities or return a minimal object.
 * @returns {Promise<object>}
 */
async function getCapabilities() {
  try {
    const capsPath = path.join(process.resourcesPath, 'ffmpegCapabilities.json');
    if (fs.existsSync(capsPath)) {
      const raw = await fs.promises.readFile(capsPath, 'utf8');
      return JSON.parse(raw);
    }
    return { error: 'Capabilities file not found' };
  } catch (err) {
    return { error: String((err && err.message) || err) };
  }
}

/**
 * List formats via ffmpeg -formats (best-effort fallback; parse lightly).
 * @param {string} ffmpegBin
 */
async function listFormats(ffmpegBin) {
  return new Promise(resolve => {
    const proc = spawn(ffmpegBin, ['-hide_banner', '-formats'], { stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '';
    proc.stdout.on('data', chunk => {
      out += chunk.toString();
    });
    proc.on('close', () => resolve(out));
    proc.on('error', () => resolve(''));
  });
}

module.exports = { runFfprobe, getCapabilities, listFormats };
