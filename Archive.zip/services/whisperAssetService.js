'use strict';

const fs = require('fs');

const runtimeAssetService = require('./runtimeAssetService');

function normalizeWhisperLanguage(language) {
  const normalized = String(language || 'en').trim().toLowerCase();
  return normalized || 'en';
}

function wantsMultilingualWhisperModel(language) {
  return normalizeWhisperLanguage(language) !== 'en';
}

function getWhisperModelFileName(options = {}) {
  return wantsMultilingualWhisperModel(options.language) ? 'ggml-base.bin' : 'ggml-base.en.bin';
}

function getWhisperModelAssetId(options = {}) {
  return wantsMultilingualWhisperModel(options.language)
    ? 'whisper.model.base.multi'
    : 'whisper.model.base.en';
}

function readOfflineModePreference() {
  try {
    const stateStore = require('../utils/state');
    const readState = stateStore && typeof stateStore.readState === 'function'
      ? stateStore.readState
      : null;
    const state = readState ? (readState() || {}) : {};
    return !!state?.preferences?.offlineMode;
  } catch {
    return false;
  }
}

function resolveWhisperOfflineOption(options = {}) {
  if (typeof options.offline === 'boolean') return options.offline;
  return readOfflineModePreference();
}

function buildWhisperDependencyMessage(error, options = {}) {
  const language = normalizeWhisperLanguage(options.language);
  const assetId = String(options.assetId || getWhisperModelAssetId({ language })).trim();
  const modelFile = getWhisperModelFileName({ language });
  const installPath = String(
    options.installPath || runtimeAssetService.getInstalledAssetPath(assetId) || ''
  ).trim() || '(unknown)';
  const requestedLanguageLabel = language === 'en' ? 'English' : `language "${language}"`;
  const details = [
    `Asset ID: ${assetId}`,
    `Model file: ${modelFile}`,
    `Expected installed path: ${installPath}`
  ].join('\n');

  switch (String(error?.code || '').trim()) {
    case 'ASSET_OFFLINE_BLOCKED':
      return [
        `Whisper transcription model is not installed yet, and Offline Mode is enabled. Disable offline mode or pre-seed the runtime asset ${assetId}, then retry.`,
        details
      ].join('\n');
    case 'ASSET_CHECKSUM_MISMATCH':
      return [
        'Downloaded Whisper transcription model failed checksum verification. Remove the installed copy and retry after publishing a fresh manifest or asset build.',
        details
      ].join('\n');
    case 'ASSET_MISSING_CHECKSUM':
      return [
        'Whisper transcription model download is blocked because the packaged manifest entry is missing a checksum.',
        details
      ].join('\n');
    case 'ASSET_MISSING':
      return [
        `Whisper transcription model could not be prepared for ${requestedLanguageLabel}.`,
        details
      ].join('\n');
    default:
      return [
        'Whisper transcription model dependency is not available.',
        details,
        `Error: ${error?.message || String(error)}`
      ].join('\n');
  }
}

function createWhisperDependencyError(error, options = {}) {
  if (error?.__isWhisperDependencyError) return error;

  const language = normalizeWhisperLanguage(options.language);
  const assetId = String(options.assetId || getWhisperModelAssetId({ language })).trim();
  const installPath = String(
    options.installPath || runtimeAssetService.getInstalledAssetPath(assetId) || ''
  ).trim() || null;
  const wrapped = new Error(buildWhisperDependencyMessage(error, {
    ...options,
    language,
    assetId,
    installPath
  }));

  wrapped.code = String(error?.code || 'WHISPER_ASSET_UNAVAILABLE');
  wrapped.cause = error;
  wrapped.assetId = assetId;
  wrapped.installPath = installPath;
  wrapped.language = language;
  wrapped.__isWhisperDependencyError = true;
  return wrapped;
}

async function ensureWhisperModelPath(options = {}) {
  const language = normalizeWhisperLanguage(options.language);
  const assetId = String(options.assetId || getWhisperModelAssetId({ language })).trim();
  const offline = resolveWhisperOfflineOption(options);

  try {
    const ensured = await runtimeAssetService.ensureAsset(assetId, {
      ...options,
      language,
      offline
    });

    const modelPath = String(
      ensured?.path || runtimeAssetService.getInstalledAssetPath(assetId) || ''
    ).trim();

    if (!modelPath || !fs.existsSync(modelPath)) {
      const err = new Error(`Whisper model file is missing after asset installation (${assetId}).`);
      err.code = 'ASSET_MISSING';
      err.assetId = assetId;
      err.installPath = modelPath || runtimeAssetService.getInstalledAssetPath(assetId) || null;
      throw err;
    }

    return {
      ok: true,
      assetId,
      language,
      modelFile: getWhisperModelFileName({ language }),
      modelPath,
      source: ensured?.source || 'installed',
      offline
    };
  } catch (error) {
    throw createWhisperDependencyError(error, { ...options, language, assetId });
  }
}

module.exports = {
  normalizeWhisperLanguage,
  wantsMultilingualWhisperModel,
  getWhisperModelFileName,
  getWhisperModelAssetId,
  resolveWhisperOfflineOption,
  buildWhisperDependencyMessage,
  createWhisperDependencyError,
  ensureWhisperModelPath
};
