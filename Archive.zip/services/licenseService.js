// services/licenseService.js
// Main-process-only licensing / entitlement verification.
//
// Goal: boring, professional subscription behavior.
//  - Paddle handles billing.
//  - Your entitlement service (Fly) issues short-lived signed entitlement tokens.
//  - The desktop app verifies tokens locally (public key only) and gates features.
//
// Operational states:
//  - ACTIVE: valid signed entitlement token installed (tier pro/enterprise).
//  - TRIAL: valid signed entitlement token installed (trialing subscription or trial tier).
//  - LOCKED: no valid token, token expired beyond grace, device mismatch, or claim/signature failure.
//
// Security posture:
//  - NO local “trial start” clocks. Trials come from server tokens.
//  - No private keys are ever stored in the desktop app.
//  - Minimal anti-clock-rollback for offline grace using a monotonic-ish maxObserved timestamp.

'use strict';

const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');

let isPackaged = false;
try {
  const { app } = require('electron');
  isPackaged = app?.isPackaged ?? false;
} catch {
  isPackaged = false;
}

const secureStore = require('../modules/secureStore');

// Portable license file (optional)
const DEFAULT_LICENSE_FILE_PATH = path.join(os.homedir(), '.leadai_license');
// Dev-only legacy fallback (never trusted in packaged builds)
const BUNDLED_DEV_LICENSE_PATH = path.join(__dirname, '..', 'legal', '.leadai_license');

// Secure storage keys
const SECRET_KEY_LICENSE_TOKEN = 'licenseToken';
const SECRET_KEY_DEVICE_ID = 'deviceId';
// Minimal offline-grace hardening (anti clock rollback)
const SECRET_KEY_LICENSE_LAST_OK_MS = 'licenseLastOkMs';
const SECRET_KEY_LICENSE_MAX_OBSERVED_MS = 'licenseMaxObservedMs';

// Settings
const SUBSCRIPTION_OFFLINE_GRACE_MS = 5 * 24 * 60 * 60 * 1000; // 5 days (user requirement)
const REFRESH_SOON_MS = 24 * 60 * 60 * 1000; // 24h
const CLOCK_ROLLBACK_TOLERANCE_MS = 5 * 60 * 1000; // 5 minutes

const DEBUG_LOGS = process.env.DEBUG_LOGS === 'true';

// DEV SAFETY:
// In non-packaged builds, fail open by default so you can build without bricking yourself.
// To force real enforcement in dev: LEADAE_DEV_ENFORCE_LICENSE=1
const DEV_FAIL_OPEN = !isPackaged && process.env.LEADAE_DEV_ENFORCE_LICENSE !== '1';

// Always-available recovery surfaces when locked
const LOCKED_FEATURES_LIST = ['preferences', 'log-viewer', 'account', 'speed-test'];

// Default feature sets
const DEFAULT_FEATURES_BY_TIER = {
  trial: ['*'],
  pro: ['*'],
  enterprise: ['*']
};

const FEATURE_ALIASES = {
  settings: 'preferences',
  prefs: 'preferences',
  logs: 'log-viewer',
  log: 'log-viewer',
  utilities: 'nle-utilities',
  project: 'project-organizer',
  organizer: 'project-organizer',
  subtitle: 'subtitle-editor',
  subscription: 'account',
  billing: 'account',
  license: 'account'
};

function _normalizeFeatureKey(featureKey) {
  const raw = String(featureKey || '').trim();
  if (!raw) return '';
  const k = raw.toLowerCase();
  return FEATURE_ALIASES[k] || k;
}

function _normalizeTier(tier) {
  const t = String(tier || '').trim().toLowerCase();
  if (t === 'enterprise' || t === 'ent') return 'enterprise';
  if (t === 'pro' || t === 'professional') return 'pro';
  if (t === 'trial' || t === 'trialing') return 'trial';
  // Default to pro (paid product). Token must still be valid + signed.
  return 'pro';
}

function _featuresListToMap(list) {
  const map = {};
  for (const item of list || []) {
    const k = _normalizeFeatureKey(item);
    if (!k) continue;
    map[k] = true;
  }
  return map;
}

const LOCKED_FEATURES_MAP = _featuresListToMap(LOCKED_FEATURES_LIST);

function _normalizeFeatures(features, tier) {
  if (features === '*') return { '*': true };

  if (Array.isArray(features)) {
    return _featuresListToMap(features);
  }

  if (features && typeof features === 'object') {
    const out = {};
    for (const [k0, v] of Object.entries(features)) {
      const k = _normalizeFeatureKey(k0);
      if (!k) continue;
      if (k === '*') {
        out['*'] = !!v;
        continue;
      }
      out[k] = !!v;
    }
    return out;
  }

  const fallbackList = DEFAULT_FEATURES_BY_TIER[_normalizeTier(tier)] || DEFAULT_FEATURES_BY_TIER.pro;
  return _featuresListToMap(fallbackList);
}

function _base64UrlToBuffer(b64url) {
  const s = String(b64url || '').trim();
  if (!s) return Buffer.alloc(0);
  const b64 = s.replace(/-/g, '+').replace(/_/g, '/');
  const padLen = (4 - (b64.length % 4)) % 4;
  const padded = b64 + '='.repeat(padLen);
  return Buffer.from(padded, 'base64');
}

function _parseJws(token) {
  const t = String(token || '').trim();
  const parts = t.split('.');
  if (parts.length !== 3) throw new Error('Invalid entitlement token format');
  const [h, p, s] = parts;
  const header = JSON.parse(_base64UrlToBuffer(h).toString('utf8'));
  const payload = JSON.parse(_base64UrlToBuffer(p).toString('utf8'));
  const signature = _base64UrlToBuffer(s);
  return { header, payload, signature, signingInput: `${h}.${p}` };
}

const PUBLIC_KEY_CONFIG_ENV_PATH = 'LEADAE_LICENSE_PUBLIC_KEYS_CONFIG_PATH';
const PUBLIC_KEY_CONFIG_FILE_NAME = 'license-verification-keys.json';

// Verification keys are loaded from a config artifact so we can rotate keys safely.
// SECURITY: In packaged builds, we do NOT honor env-path overrides, because that would let
// end users point the app at their own keyset and mint their own "valid" tokens.
let _verificationKeyConfigCache = null;
let _warnedIgnoredEnvConfigPath = false;

function _resolvePublicKeyConfigCandidates() {
  const out = [];

  const envPath = String(process.env[PUBLIC_KEY_CONFIG_ENV_PATH] || '').trim();
  if (envPath) {
    if (!isPackaged) {
      out.push(envPath);
    } else if (DEBUG_LOGS && !_warnedIgnoredEnvConfigPath) {
      console.warn(`licenseService: ignoring ${PUBLIC_KEY_CONFIG_ENV_PATH} in packaged builds`);
      _warnedIgnoredEnvConfigPath = true;
    }
  }

  // If a managed installer or updater drops a config next to app resources, prefer it.
  if (typeof process.resourcesPath === 'string' && process.resourcesPath.trim()) {
    out.push(path.join(process.resourcesPath, 'config', PUBLIC_KEY_CONFIG_FILE_NAME));
  }

  // Default: repo path in dev, app.asar path in production.
  out.push(path.join(__dirname, '..', 'config', PUBLIC_KEY_CONFIG_FILE_NAME));
  return out;
}

function _getVerificationKeyConfig() {
  if (_verificationKeyConfigCache) return _verificationKeyConfigCache;

  const candidates = _resolvePublicKeyConfigCandidates();

  for (const candidate of candidates) {
    try {
      if (!candidate || !fs.existsSync(candidate)) continue;
      const raw = fs.readFileSync(candidate, 'utf8');
      const parsed = JSON.parse(raw);

      const keys = parsed?.keys;
      if (!keys || typeof keys !== 'object' || Array.isArray(keys)) continue;

      const defaultKid = (typeof parsed.defaultKid === 'string') ? parsed.defaultKid.trim() : '';
      _verificationKeyConfigCache = {
        sourcePath: candidate,
        defaultKid,
        keys
      };

      if (DEBUG_LOGS) {
        const kids = Object.keys(keys || {});
        console.warn(`licenseService: loaded verification keys from ${candidate} (kids=${kids.join(',') || 'none'}, defaultKid=${defaultKid || 'none'})`);
      }

      return _verificationKeyConfigCache;
    } catch (err) {
      if (DEBUG_LOGS) console.warn('licenseService: failed to parse verification key config:', candidate, err?.message || err);
    }
  }

  const msg = `licenseService: no verification key config found. Checked: ${candidates.join(', ')}`;
  if (isPackaged) console.error(msg);
  else if (DEBUG_LOGS) console.warn(msg);

  _verificationKeyConfigCache = { sourcePath: null, defaultKid: '', keys: {} };
  return _verificationKeyConfigCache;
}

function _isKeyWithinDeprecationWindow(meta) {
  if (!meta || typeof meta !== 'object') return true;
  const status = String(meta.status || '').trim().toLowerCase();
  if (!status || status === 'active') return true;
  if (status !== 'deprecated') return false;

  const cutoff = meta.acceptUntil || meta.deprecatedUntil || null;
  if (!cutoff) return false;

  const cutoffMs = (typeof cutoff === 'number') ? cutoff : Date.parse(String(cutoff));
  if (!Number.isFinite(cutoffMs)) return false;
  return Date.now() <= cutoffMs;
}

function _getPublicKeyPemForKid(kid) {
  // Dev-only override. Never allow env overrides in packaged builds.
  const allowEnvKeyOverride = (!isPackaged);
  if (allowEnvKeyOverride && process.env.LEADAE_LICENSE_PUBLIC_KEY_PEM) {
    return String(process.env.LEADAE_LICENSE_PUBLIC_KEY_PEM);
  }

  const cfg = _getVerificationKeyConfig();
  const keys = cfg?.keys || {};

  const requestedKid = (typeof kid === 'string') ? kid.trim() : '';
  if (requestedKid) {
    const entry = keys[requestedKid];
    if (entry && _isKeyWithinDeprecationWindow(entry)) {
      return String(entry.publicKeyPem || entry.pem || '');
    }
    return '';
  }

  let fallbackKid = (typeof cfg?.defaultKid === 'string') ? cfg.defaultKid.trim() : '';
  if (!fallbackKid) {
    const kids = Object.keys(keys || {});
    if (kids.length === 1) fallbackKid = kids[0];
  }

  const fallbackEntry = fallbackKid ? keys[fallbackKid] : null;
  if (fallbackEntry && _isKeyWithinDeprecationWindow(fallbackEntry)) {
    return String(fallbackEntry.publicKeyPem || fallbackEntry.pem || '');
  }

  return '';
}

function _verifyJws(token) {
  const { header, payload, signature, signingInput } = _parseJws(token);
  const alg = String(header?.alg || '').trim();
  if (!alg || alg.toLowerCase() === 'none') throw new Error('Entitlement token uses an unsupported alg');

  const publicKeyPem = _getPublicKeyPemForKid(header?.kid);
  let keyObj;
  try {
    keyObj = crypto.createPublicKey(publicKeyPem);
  } catch {
    throw new Error('Entitlement public key is invalid or missing');
  }

  const data = Buffer.from(signingInput, 'utf8');
  let ok = false;

  if (alg === 'RS256') {
    ok = crypto.verify('RSA-SHA256', data, keyObj, signature);
  } else if (alg === 'EdDSA' || alg === 'Ed25519') {
    ok = crypto.verify(null, data, keyObj, signature);
  } else {
    throw new Error(`Unsupported entitlement alg: ${alg}`);
  }

  if (!ok) throw new Error('Entitlement signature verification failed');
  return payload;
}

function _parseExpiryMs(payload) {
  if (payload && typeof payload.exp === 'number' && Number.isFinite(payload.exp)) {
    return Math.floor(payload.exp * 1000);
  }
  const expiresAt = payload?.expiresAt ?? payload?.expires ?? null;
  if (typeof expiresAt === 'number' && Number.isFinite(expiresAt)) {
    return expiresAt < 10_000_000_000 ? Math.floor(expiresAt * 1000) : Math.floor(expiresAt);
  }
  if (typeof expiresAt === 'string' && expiresAt.trim()) {
    const ms = Date.parse(expiresAt);
    if (Number.isFinite(ms)) return ms;
  }
  return null;
}

function _parsePeriodEndMs(payload) {
  const v = payload?.periodEnd ?? payload?.period_end ?? payload?.periodEndsAt ?? payload?.period_ends_at ?? null;
  if (typeof v === 'number' && Number.isFinite(v)) {
    return v < 10_000_000_000 ? Math.floor(v * 1000) : Math.floor(v);
  }
  if (typeof v === 'string' && v.trim()) {
    const ms = Date.parse(v);
    if (Number.isFinite(ms)) return ms;
    const n = Number(v);
    if (Number.isFinite(n)) return n < 10_000_000_000 ? Math.floor(n * 1000) : Math.floor(n);
  }
  return null;
}

function _looksLikeJws(token) {
  const t = String(token || '').trim();
  if (!t) return false;
  const parts = t.split('.');
  return parts.length === 3 && parts.every(p => p.length > 0);
}

function _safeReadFileText(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return '';
  }
}

function _readNumberSecret(key) {
  try {
    const v = secureStore.loadSecret(key);
    if (typeof v === 'number' && Number.isFinite(v)) return v;
    if (typeof v === 'string' && v.trim()) {
      const n = Number(v);
      if (Number.isFinite(n)) return n;
    }
  } catch {}
  return null;
}

function _writeNumberSecret(key, n) {
  try { secureStore.saveSecret(key, Number(n)); } catch {}
}

function _generateDeviceId() {
  try {
    if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  } catch {}
  try {
    const { v4 } = require('uuid');
    return v4();
  } catch {
    return crypto.randomBytes(16).toString('hex');
  }
}

function getOrCreateDeviceId() {
  try {
    const existing = secureStore.loadSecret(SECRET_KEY_DEVICE_ID);
    if (typeof existing === 'string' && existing.trim()) return existing.trim();
  } catch {}

  const id = _generateDeviceId();
  try { secureStore.saveSecret(SECRET_KEY_DEVICE_ID, id); } catch {}
  return id;
}

function _lockedEntitlement(reason) {
  return {
    status: 'LOCKED',
    tier: 'none',
    features: LOCKED_FEATURES_MAP,
    expiresAt: null,
    periodEndsAt: null,
    refreshByAt: null,
    needsSync: false,
    warning: null,
    valid: false,
    reason: reason || 'no_license',
    _source: 'none'
  };
}

function _monotonicNowMs() {
  const wall = Date.now();
  const prev = _readNumberSecret(SECRET_KEY_LICENSE_MAX_OBSERVED_MS);
  if (Number.isFinite(prev) && (wall + CLOCK_ROLLBACK_TOLERANCE_MS) < prev) {
    // Clock moved backwards beyond tolerance.
    return { now: prev, tamper: true };
  }
  const next = Math.max(wall, Number.isFinite(prev) ? prev : 0);
  if (!Number.isFinite(prev) || next > prev) {
    _writeNumberSecret(SECRET_KEY_LICENSE_MAX_OBSERVED_MS, next);
  }
  return { now: next, tamper: false };
}

function _normalizeEntitlementFromPayload(payload, source) {
  const tier = _normalizeTier(payload?.tier ?? payload?.licenseTier ?? payload?.plan ?? payload?.productTier ?? 'pro');
  const features = _normalizeFeatures(payload?.features, tier);

  const { now, tamper } = _monotonicNowMs();
  if (tamper) {
    return _lockedEntitlement('clock_rollback_detected');
  }

  // Claims expected by the desktop verifier
  const iss = (typeof payload?.iss === 'string') ? payload.iss.trim() : '';
  const aud = payload?.aud;
  const EXPECTED_TOKEN_ISS = String(process.env.LEADAE_TOKEN_ISS || 'leadaeassist-entitlement').trim();
  const EXPECTED_TOKEN_AUD = String(process.env.LEADAE_TOKEN_AUD || 'leadaeassist-desktop').trim();
  const issOk = !EXPECTED_TOKEN_ISS || (iss && iss === EXPECTED_TOKEN_ISS);
  const audOk =
    !EXPECTED_TOKEN_AUD ||
    ((typeof aud === 'string' && aud.trim() === EXPECTED_TOKEN_AUD) ||
     (Array.isArray(aud) && aud.some(v => typeof v === 'string' && v.trim() === EXPECTED_TOKEN_AUD)));

  const refreshByMs = _parseExpiryMs(payload);
  const periodEndMs = _parsePeriodEndMs(payload);

  // Access end: paid-through if periodEnd exists, otherwise refreshBy.
  const accessEndMs = periodEndMs || refreshByMs;

  const refreshOverdue = (typeof refreshByMs === 'number' && Number.isFinite(refreshByMs) && now > refreshByMs);
  const accessExpired = (typeof accessEndMs === 'number' && Number.isFinite(accessEndMs) && now > accessEndMs);

  const claimedStatusRaw = String(
    payload?.status ??
    payload?.subscriptionStatus ??
    payload?.subscription_status ??
    payload?.entitlementStatus ??
    ''
  ).trim().toLowerCase();
  const statusImpliesTrial =
    claimedStatusRaw === 'trial' ||
    claimedStatusRaw === 'trialing' ||
    claimedStatusRaw.includes('trial');

  // Treat "trialing pro" as TRIAL while keeping tier=pro for features.
  const isTrial = (tier === 'trial') || statusImpliesTrial || (payload?.trial === true);

  // Offline grace: allow running after refresh-by expiration when period is still valid.
  // Applies to pro/enterprise (including trialing pro), but is always capped by periodEnd when present.
  const withinOfflineGrace =
    (tier === 'pro' || tier === 'enterprise') &&
    refreshOverdue &&
    typeof refreshByMs === 'number' &&
    Number.isFinite(refreshByMs) &&
    now <= (refreshByMs + SUBSCRIPTION_OFFLINE_GRACE_MS) &&
    (periodEndMs == null || now <= periodEndMs);

  const refreshRequired = (tier === 'pro' || tier === 'enterprise') && refreshOverdue && !withinOfflineGrace;

  const expired = accessExpired || refreshRequired;

  // Device binding (optional): if a token includes deviceId and is not floating, it must match.
  const floating = payload?.floating === true || payload?.isFloating === true || String(payload?.seatType || '').toLowerCase() === 'floating';
  const boundDeviceId = String(payload?.deviceId || payload?.device_id || payload?.machineId || payload?.machine_id || '').trim();
  const localDeviceId = getOrCreateDeviceId();
  const deviceMismatch = !!boundDeviceId && !floating && boundDeviceId !== localDeviceId;

  // exp is required for pro/trial; enterprise may be perpetual (no exp) if you choose.
  const missingExp = (refreshByMs == null) && tier !== 'enterprise';

  const valid = !expired && !deviceMismatch && issOk && audOk && !missingExp;
  const status = valid ? (isTrial ? 'TRIAL' : 'ACTIVE') : 'LOCKED';

  let reason = null;
  if (!issOk) reason = 'issuer_mismatch';
  else if (!audOk) reason = 'audience_mismatch';
  else if (missingExp) reason = 'missing_exp';
  else if (deviceMismatch) reason = 'device_mismatch';
  else if (accessExpired) reason = (isTrial ? 'trial_expired' : 'license_expired');
  else if (refreshRequired) reason = 'refresh_required';

  const needsSync =
    (tier === 'pro' || tier === 'enterprise') &&
    typeof refreshByMs === 'number' &&
    Number.isFinite(refreshByMs) &&
    (refreshOverdue || (refreshByMs - now) <= REFRESH_SOON_MS);

  const warning = withinOfflineGrace ? 'offline_grace' : (needsSync ? 'refresh_soon' : null);

  if (valid) {
    _writeNumberSecret(SECRET_KEY_LICENSE_LAST_OK_MS, now);
  }

  let trial = null;
  if (isTrial && typeof accessEndMs === 'number' && Number.isFinite(accessEndMs)) {
    const msRemaining = Math.max(0, accessEndMs - now);
    const daysRemaining = Math.max(0, Math.ceil(msRemaining / (24 * 60 * 60 * 1000)));
    trial = { msRemaining, daysRemaining };
  }

  return {
    status,
    tier,
    features,
    expiresAt: accessEndMs ? new Date(accessEndMs).toISOString() : null,
    periodEndsAt: periodEndMs ? new Date(periodEndMs).toISOString() : null,
    refreshByAt: refreshByMs ? new Date(refreshByMs).toISOString() : null,
    valid,
    reason,
    warning,
    needsSync,
    trial,
    _source: source || 'token',
    _expired: expired,
    _deviceMismatch: deviceMismatch,
    _boundDeviceId: boundDeviceId || null,
    _floating: !!floating
  };
}

function _loadFromTokenString(token, sourceLabel) {
  const payload = _verifyJws(token);
  return _normalizeEntitlementFromPayload(payload, sourceLabel || 'token');
}

function _loadFromLicenseFile(filePath) {
  const raw = _safeReadFileText(filePath);
  const trimmed = String(raw || '').trim();
  if (!trimmed) return null;

  if (_looksLikeJws(trimmed)) {
    return _loadFromTokenString(trimmed, `file:${filePath}`);
  }

  let parsed;
  try {
    parsed = JSON.parse(trimmed);
  } catch {
    parsed = null;
  }

  if (parsed && typeof parsed === 'object') {
    const token = parsed.token || parsed.licenseToken || parsed.entitlementToken || parsed.jwt;
    if (typeof token === 'string' && _looksLikeJws(token)) {
      return _loadFromTokenString(token, `file:${filePath}`);
    }

    // DEV-only legacy unsigned format (features map)
    if (!isPackaged && parsed.features && typeof parsed.features === 'object') {
      const tier = _normalizeTier(parsed.tier ?? parsed.licenseTier ?? 'enterprise');
      const features = _normalizeFeatures(parsed.features, tier);
      return {
        status: 'ACTIVE',
        tier,
        features,
        expiresAt: null,
        periodEndsAt: null,
        refreshByAt: null,
        needsSync: false,
        warning: null,
        valid: true,
        reason: null,
        _source: `dev-legacy:${filePath}`,
        _expired: false
      };
    }
  }

  return null;
}

let _cached = null;

function _maybeRefreshIfExpired() {
  const iso = _cached?.refreshByAt || _cached?.expiresAt;
  if (!iso || typeof iso !== 'string') return;
  const expMs = Date.parse(iso);
  if (!Number.isFinite(expMs)) return;
  if (Date.now() <= expMs) return;
  _cached = _loadEntitlementOnce();
}

function _loadEntitlementOnce() {
  // Ensure stable device id early.
  try { getOrCreateDeviceId(); } catch {}

  // 1) Secure storage token
  try {
    const token = secureStore.loadSecret(SECRET_KEY_LICENSE_TOKEN);
    if (typeof token === 'string' && _looksLikeJws(token)) {
      return _loadFromTokenString(token, 'secure-store');
    }
  } catch (err) {
    if (DEBUG_LOGS) console.warn('licenseService: failed to load token from secure store:', err?.message || err);
  }

  // 2) Portable home license file
  try {
    if (fs.existsSync(DEFAULT_LICENSE_FILE_PATH)) {
      const ent = _loadFromLicenseFile(DEFAULT_LICENSE_FILE_PATH);
      if (ent) return ent;
    }
  } catch (err) {
    if (DEBUG_LOGS) console.warn('licenseService: failed to read home license file:', err?.message || err);
  }

  // 3) DEV-only bundled unsigned license
  if (!isPackaged) {
    try {
      if (fs.existsSync(BUNDLED_DEV_LICENSE_PATH)) {
        const ent = _loadFromLicenseFile(BUNDLED_DEV_LICENSE_PATH);
        if (ent) return ent;
      }
    } catch {}
  }

  return _lockedEntitlement('no_license');
}

function _effectiveFeatures(ent) {
  if (DEV_FAIL_OPEN) return _normalizeFeatures('*', 'pro');
  if (!ent || ent.status === 'LOCKED' || !ent.valid) return LOCKED_FEATURES_MAP;
  return ent.features || _normalizeFeatures('*', 'pro');
}

function getEntitlement(options = {}) {
  const force = !!options.forceReload;
  if (!_cached || force) {
    _cached = _loadEntitlementOnce();
  }

  _maybeRefreshIfExpired();

  const deviceId = getOrCreateDeviceId();
  const effective = _effectiveFeatures(_cached);

  let appVersion = null;
  try {
    const { app } = require('electron');
    appVersion = app?.getVersion?.() || null;
  } catch {}

  const out = {
    status: _cached?.status || (_cached?.valid ? 'ACTIVE' : 'LOCKED'),
    tier: _cached?.tier || 'none',
    features: effective,
    expiresAt: _cached?.expiresAt || null,
    periodEndsAt: _cached?.periodEndsAt || null,
    refreshByAt: _cached?.refreshByAt || null,
    needsSync: _cached?.needsSync === true,
    warning: _cached?.warning || null,
    valid: !!_cached?.valid,
    reason: _cached?.reason || null,
    trial: _cached?.trial || null,
    deviceId,
    appVersion
  };

  if (DEV_FAIL_OPEN && out.status === 'LOCKED') {
    out.status = 'ACTIVE';
    out.tier = 'pro';
    out.valid = true;
    out.reason = 'dev_fail_open';
  }

  return out;
}

function isFeatureEnabled(featureKey) {
  if (DEV_FAIL_OPEN) return true;
  const key = _normalizeFeatureKey(featureKey);
  if (!key) return false;

  if (!_cached) _cached = _loadEntitlementOnce();

  _maybeRefreshIfExpired();

  const effective = _effectiveFeatures(_cached);
  if (effective['*']) return true;
  return !!effective[key];
}

async function installLicenseFromFile(filePath) {
  const p = String(filePath || '').trim();
  if (!p) throw new Error('License file path is required');
  if (!fs.existsSync(p)) throw new Error('License file not found');

  const raw = _safeReadFileText(p);
  const trimmed = String(raw || '').trim();
  if (!trimmed) throw new Error('License file is empty');

  let token = null;
  if (_looksLikeJws(trimmed)) {
    token = trimmed;
  } else {
    try {
      const parsed = JSON.parse(trimmed);
      const candidate = parsed?.token || parsed?.licenseToken || parsed?.entitlementToken || parsed?.jwt;
      if (typeof candidate === 'string' && _looksLikeJws(candidate)) token = candidate;
    } catch {}
  }

  if (token) {
    const ent = _loadFromTokenString(token, `file:${p}`);
    if (!ent?.valid) {
      throw new Error(ent?.reason === 'device_mismatch' ? 'License not valid for this machine' : 'License token is expired or invalid');
    }
    secureStore.saveSecret(SECRET_KEY_LICENSE_TOKEN, token);
    _cached = ent;
    return getEntitlement({ forceReload: true });
  }

  if (!isPackaged) {
    const ent = _loadFromLicenseFile(p);
    if (!ent?.valid) throw new Error('License file is not a recognized dev format');
    _cached = ent;
    return getEntitlement({ forceReload: true });
  }

  throw new Error('License file format not recognized');
}

function clearLicense() {
  try { secureStore.deleteSecret(SECRET_KEY_LICENSE_TOKEN); } catch {}
  _cached = null;
  return getEntitlement({ forceReload: true });
}

module.exports = {
  getEntitlement,
  isFeatureEnabled,
  installLicenseFromFile,
  clearLicense,
  _internal: {
    _normalizeFeatureKey,
    _looksLikeJws,
    getOrCreateDeviceId,
    _verifyJws,
    _getPublicKeyPemForKid,
    _getVerificationKeyConfig,
    _resetVerificationKeyConfigCache: () => {
      _verificationKeyConfigCache = null;
      _warnedIgnoredEnvConfigPath = false;
    }
  }
};
