'use strict';

const { app } = require('electron');
const log = require('electron-log');
const { autoUpdater } = require('electron-updater');
const { readState } = require('../utils/state');

let _initialized = false;
let _sendStatus = null;
let _last = { status: 'idle', info: null };

function getErrorCode(err) {
  if (!err) return '';
  const direct = (typeof err.code === 'string' && err.code.trim()) ? err.code.trim() : '';
  if (direct) return direct;
  const nested = (typeof err.error?.code === 'string' && err.error.code.trim()) ? err.error.code.trim() : '';
  return nested;
}

function isEmptyFeedError(err) {
  const code = getErrorCode(err);
  if (code === 'ERR_UPDATER_NO_PUBLISHED_VERSIONS') return true;

  const msg = String(err?.message || err || '').toLowerCase();
  return msg.includes('no published versions')
    || msg.includes('no updates available')
    || msg.includes('empty channel')
    || msg.includes('cannot find latest.yml')
    || msg.includes('cannot find channel')
    || msg.includes('status code 404');
}

function mapUpdaterError(err) {
  if (isEmptyFeedError(err)) {
    return { status: 'none', info: { reason: 'emptyFeed', code: getErrorCode(err) || null } };
  }
  return { status: 'error', info: String(err) };
}

function _getUpdatePrefs() {
  const state = readState() || {};
  const prefs = (state.preferences && typeof state.preferences === 'object') ? state.preferences : {};
  return {
    checkOnLaunch: prefs.autoUpdateCheckOnLaunch !== false,
    autoDownload: prefs.autoUpdateAutoDownload !== false,
    offlineMode: !!prefs.offlineMode
  };
}

function _setStatus(status, info) {
  _last = { status, info: info ?? null };
  try { _sendStatus?.(status, info); } catch {}
}

function initAutoUpdates({ sendStatus } = {}) {
  if (process.env.NODE_ENV === 'test') return;
  if (_initialized) return;
  _initialized = true;

  _sendStatus = sendStatus || null;

  autoUpdater.logger = log;
  if (process.platform === 'darwin') {
    autoUpdater.autoInstallOnAppQuit = false;
  }

  const prefs = _getUpdatePrefs();
  autoUpdater.autoDownload = !!prefs.autoDownload;

  autoUpdater.on('checking-for-update', () => _setStatus('checking'));
  autoUpdater.on('update-available', info => _setStatus('available', info));
  autoUpdater.on('update-not-available', info => _setStatus('none', info));
  autoUpdater.on('download-progress', progress => _setStatus('progress', progress));
  autoUpdater.on('update-downloaded', info => _setStatus('downloaded', info));
  autoUpdater.on('error', err => {
    const mapped = mapUpdaterError(err);
    _setStatus(mapped.status, mapped.info);
  });

  app.whenReady().then(() => {
    const p = _getUpdatePrefs();
    autoUpdater.autoDownload = !!p.autoDownload;

    if (p.offlineMode) {
      _setStatus('disabled', { reason: 'offlineMode' });
      return;
    }

    if (!p.checkOnLaunch) {
      _setStatus('disabled', { reason: 'optOut' });
      return;
    }

    autoUpdater.checkForUpdates().catch(err => {
      const mapped = mapUpdaterError(err);
      try { _setStatus(mapped.status, mapped.info); } catch {}
      if (mapped.status === 'none' || mapped.status === 'disabled') {
        try { log.info('[autoUpdater] no published updates yet (informational).'); } catch {}
        return;
      }
      try { log.warn('[autoUpdater] checkForUpdates failed:', err); } catch {}
    });
  });
}

async function checkForUpdates() {
  const p = _getUpdatePrefs();
  if (p.offlineMode) {
    _setStatus('disabled', { reason: 'offlineMode' });
    return { ok: false, error: 'Offline Mode enabled' };
  }
  autoUpdater.autoDownload = !!p.autoDownload;
  try {
    await autoUpdater.checkForUpdates();
    return { ok: true, error: null };
  } catch (err) {
    const mapped = mapUpdaterError(err);
    _setStatus(mapped.status, mapped.info);
    if (mapped.status === 'none' || mapped.status === 'disabled') {
      return { ok: true, error: null, status: mapped.status, info: mapped.info };
    }
    return { ok: false, error: String(err?.message || err || 'Update check failed') };
  }
}

async function downloadUpdate() {
  const p = _getUpdatePrefs();
  if (p.offlineMode) {
    _setStatus('disabled', { reason: 'offlineMode' });
    return { ok: false, error: 'Offline Mode enabled' };
  }

  await autoUpdater.downloadUpdate();
  return { ok: true, error: null };
}

function quitAndInstall() {
  const p = _getUpdatePrefs();
  if (p.offlineMode) {
    _setStatus('disabled', { reason: 'offlineMode' });
    throw new Error('Offline Mode enabled');
  }

  autoUpdater.quitAndInstall();
}

function getLastStatus() {
  return _last;
}

module.exports = {
  initAutoUpdates,
  checkForUpdates,
  downloadUpdate,
  quitAndInstall,
  getLastStatus,
  __private: { isEmptyFeedError, mapUpdaterError, getErrorCode }
};
