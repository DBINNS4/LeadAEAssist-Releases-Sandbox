'use strict';
// services/presetService.js
const fs = require('fs');
const path = require('path');
const platformPaths = require('../platform/paths');

function makePresetError(code, message, details = {}) {
  const err = new Error(message);
  err.code = code;
  err.details = details;
  return err;
}

/**
 * Simple JSON preset directory utilities. Paths are examples; adjust as needed.
 */
function presetsRoot() {
  // Keep behavior consistent across platforms:
  //   macOS:  ~/Library/Application Support/LeadAEAssist/config/presets/lead-ae
  //   Win:    %APPDATA%\LeadAEAssist\config\presets\lead-ae
  let userDataRoot = null;
  try {
    const { app } = require('electron');
    if (app && typeof app.getPath === 'function') {
      userDataRoot = app.getPath('userData');
    }
  } catch {
    // ignore
  }

  if (!userDataRoot) userDataRoot = platformPaths.getUserDataRoot('LeadAEAssist');
  const root = path.join(userDataRoot, 'config', 'presets', 'lead-ae');
  if (!fs.existsSync(root)) fs.mkdirSync(root, { recursive: true });
  return root;
}

function listPresets(dir) {
  const base = dir || presetsRoot();
  return fs.readdirSync(base).filter(f => f.endsWith('.json')).map(f => path.join(base, f));
}

async function resolvePresetPath(file, { requireJson = false } = {}) {
  if (typeof file !== 'string' || file.trim() === '') {
    throw makePresetError('PRESET_PATH_REQUIRED', 'Preset file path is required.');
  }

  const root = presetsRoot();
  const rootResolved = path.resolve(root);
  const candidate = path.resolve(rootResolved, file);

  if (requireJson && path.extname(candidate).toLowerCase() !== '.json') {
    throw makePresetError('PRESET_INVALID_EXTENSION', 'Preset file must use a .json extension.', {
      file
    });
  }

  const canonicalRoot = await fs.promises.realpath(rootResolved).catch(() => rootResolved);
  let canonicalCandidate = null;

  try {
    canonicalCandidate = await fs.promises.realpath(candidate);
  } catch {
    const parent = path.dirname(candidate);
    const canonicalParent = await fs.promises.realpath(parent).catch(() => path.resolve(parent));
    canonicalCandidate = path.join(canonicalParent, path.basename(candidate));
  }

  const rel = path.relative(canonicalRoot, canonicalCandidate);
  if (rel.startsWith('..') || path.isAbsolute(rel)) {
    throw makePresetError('PRESET_PATH_OUTSIDE_ROOT', 'Preset path must be inside presets directory.', {
      file,
      resolvedPath: canonicalCandidate
    });
  }

  return canonicalCandidate;
}

async function readJson(file) {
  const safePath = await resolvePresetPath(file, { requireJson: true });
  const raw = await fs.promises.readFile(safePath, 'utf8');
  return JSON.parse(raw);
}

async function deletePreset(file) {
  const safePath = await resolvePresetPath(file, { requireJson: true });
  await fs.promises.unlink(safePath);
  return true;
}

module.exports = { presetsRoot, listPresets, readJson, deletePreset, resolvePresetPath };
