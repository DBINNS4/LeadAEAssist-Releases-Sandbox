'use strict';

const fs = require('fs');
const path = require('path');

const runtimeAssetService = require('./runtimeAssetService');

function getChromiumAssetId(options = {}) {
  const platform = String(options.platform || process.platform || '').trim();
  const arch = String(options.arch || process.arch || '').trim();

  // Keep the existing manifest asset ID stable until we deliberately migrate on-disk/runtime metadata.
  if (platform === 'darwin' && arch === 'arm64') return 'puppeteer.cache.darwin.arm64';
  return null;
}

function getChromiumExecutableNames(platform = process.platform) {
  return new Set(
    platform === 'win32'
      ? ['chrome.exe']
      : ['chrome', 'Chromium', 'Google Chrome for Testing']
  );
}

function resolveEntrypoint(assetRoot, desc) {
  const entrypoint = String(desc?.entrypoint || '').trim();
  if (!entrypoint) return null;

  const candidate = path.join(assetRoot, entrypoint);
  try {
    if (fs.existsSync(candidate)) return candidate;
  } catch {
    // Ignore and fall back to controlled discovery below.
  }
  return null;
}

function findMacAppBinary(appDir, targetNames) {
  const macOsDir = path.join(appDir, 'Contents', 'MacOS');
  let entries;
  try {
    entries = fs.readdirSync(macOsDir, { withFileTypes: true });
  } catch {
    return null;
  }

  for (const entry of entries) {
    if (!entry.isFile()) continue;
    if (targetNames.has(entry.name)) return path.join(macOsDir, entry.name);
  }

  for (const entry of entries) {
    if (!entry.isFile()) continue;
    return path.join(macOsDir, entry.name);
  }

  return null;
}

function resolveChromiumExecutableFromAssetRoot(assetRoot, desc = {}, options = {}) {
  const root = String(assetRoot || '').trim();
  if (!root) return null;

  const byEntrypoint = resolveEntrypoint(root, desc);
  if (byEntrypoint) return byEntrypoint;

  const platform = String(options.platform || process.platform || '').trim() || process.platform;
  const targetNames = getChromiumExecutableNames(platform);
  const maxDepth = Number.isFinite(Number(options.maxDepth)) ? Number(options.maxDepth) : 6;
  const searchRoots = [];
  const preferredChromeRoot = path.join(root, 'chrome');

  try {
    if (fs.existsSync(preferredChromeRoot)) searchRoots.push(preferredChromeRoot);
  } catch {
    // ignore
  }
  searchRoots.push(root);

  const seenRoots = new Set();

  function walk(dir, depth) {
    if (depth < 0) return null;

    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return null;
    }

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isFile()) {
        if (targetNames.has(entry.name)) return fullPath;
        continue;
      }
      if (!entry.isDirectory()) continue;

      if (platform === 'darwin' && entry.name.endsWith('.app')) {
        const appBinary = findMacAppBinary(fullPath, targetNames);
        if (appBinary) return appBinary;
      }

      const nested = walk(fullPath, depth - 1);
      if (nested) return nested;
    }

    return null;
  }

  for (const searchRoot of searchRoots) {
    if (seenRoots.has(searchRoot)) continue;
    seenRoots.add(searchRoot);
    const found = walk(searchRoot, maxDepth);
    if (found) return found;
  }

  return null;
}

async function ensureChromiumExecutablePath(options = {}) {
  const assetId = options.assetId || getChromiumAssetId(options);
  if (!assetId) {
    const err = new Error('Chromium runtime asset is not configured for this platform/architecture.');
    err.code = 'ASSET_UNSUPPORTED_PLATFORM';
    err.platform = String(options.platform || process.platform || '').trim() || process.platform;
    err.arch = String(options.arch || process.arch || '').trim() || process.arch;
    throw err;
  }

  const ensured = await runtimeAssetService.ensureAsset(assetId, options);
  const desc = runtimeAssetService.getAssetDescriptor(assetId, { isPackaged: !!options.isPackaged }) || {};
  const executablePath = resolveChromiumExecutableFromAssetRoot(ensured.path, desc, options);

  if (!executablePath) {
    const err = new Error(`Chromium executable was not found inside installed asset ${assetId}.`);
    err.code = 'BROWSER_MISSING';
    err.assetId = assetId;
    err.assetRoot = ensured.path;
    throw err;
  }

  return {
    ok: true,
    assetId,
    assetRoot: ensured.path,
    executablePath,
    descriptor: desc,
    source: ensured.source || 'installed'
  };
}

module.exports = {
  getChromiumAssetId,
  resolveChromiumExecutableFromAssetRoot,
  ensureChromiumExecutablePath
};
