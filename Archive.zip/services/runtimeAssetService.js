'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const https = require('https');
const { spawn, spawnSync } = require('child_process');

const { loadRuntimeAssetsManifest } = require('../utils/runtimeAssetsManifest');
const { getUserDataPath: getCanonicalUserDataPath } = require('../utils/appPaths');
const { loadPublicRuntimeConfig } = require('../utils/publicRuntimeConfig');
const { sha256FileHex, sha256DirectoryTreeHex } = require('../utils/runtimeAssetIntegrity');

/**
 * Runtime Asset Service
 *
 * - The app ships with a packaged manifest describing required runtime assets.
 * - Assets are installed under userData/assets (NOT userData/cache).
 * - Installs are seeded/downloaded via the main process, verified, and reused.
 * - Obsolete versioned asset roots are pruned conservatively after successful installs.
 */

const _inFlight = new Map();
let _manifestCache = null;
let _manifestCacheKey = '';

const VERSION_SEGMENT_RE = /^(.*?)(\d+(?:\.\d+){1,})(.*)$/;
const DEFAULT_PRUNE_GRACE_PERIOD_MS = 6 * 60 * 60 * 1000;

function _makeAssetError(code, message, meta = {}, cause = null) {
  const err = new Error(message);
  err.code = code;
  if (cause) err.cause = cause;
  Object.assign(err, meta || {});
  return err;
}

function _makeAbortError(message = 'Runtime asset acquisition cancelled.', meta = {}) {
  const err = new Error(message);
  err.name = 'AbortError';
  err.code = 'ABORT_ERR';
  Object.assign(err, meta || {});
  return err;
}

function _isAbortError(error) {
  const name = String(error?.name || '').trim().toLowerCase();
  const code = String(error?.code || '').trim().toLowerCase();
  return (
    name === 'aborterror' ||
    code === 'aborted' ||
    code === 'abort_err'
  );
}

function _safeRm(targetPath, options = {}) {
  if (!targetPath) return;
  try {
    fs.rmSync(targetPath, {
      recursive: !!options.recursive,
      force: true
    });
  } catch {}
}

function _bindAbortSignal(signal, onAbort) {
  if (!signal || typeof signal.addEventListener !== 'function') return () => {};

  let cleaned = false;
  const handler = () => {
    if (cleaned) return;
    try { onAbort(); } catch {}
  };

  try { signal.addEventListener('abort', handler, { once: true }); } catch {}

  return () => {
    if (cleaned) return;
    cleaned = true;
    try { signal.removeEventListener('abort', handler); } catch {}
  };
}

function _startCancellationPoll(options, onCancel) {
  if (typeof options?.isCancelled !== 'function') return () => {};

  let timer = null;
  try {
    timer = setInterval(() => {
      let cancelled = false;
      try {
        cancelled = !!options.isCancelled();
      } catch {
        cancelled = false;
      }

      if (!cancelled) return;
      try { onCancel(); } catch {}
    }, 50);
    if (typeof timer.unref === 'function') timer.unref();
  } catch {
    timer = null;
  }

  return () => {
    if (!timer) return;
    clearInterval(timer);
    timer = null;
  };
}

function _throwIfCancelled(options = {}, meta = {}) {
  const signal = options?.signal || null;
  if (signal?.aborted) {
    throw _makeAbortError(meta.message || 'Runtime asset acquisition cancelled.', meta);
  }

  if (typeof options?.isCancelled === 'function') {
    let cancelled = false;
    try {
      cancelled = !!options.isCancelled();
    } catch (error) {
      throw error;
    }

    if (cancelled) {
      throw _makeAbortError(meta.message || 'Runtime asset acquisition cancelled.', meta);
    }
  }
}

function _attachCallerCancellation(promise, options = {}, meta = {}) {
  if (!promise || (!options?.signal && typeof options?.isCancelled !== 'function')) {
    return promise;
  }

  return new Promise((resolve, reject) => {
    let settled = false;

    const cleanupFns = [];
    const cleanup = () => {
      while (cleanupFns.length) {
        const fn = cleanupFns.pop();
        try { fn(); } catch {}
      }
    };

    const finish = (handler) => (value) => {
      if (settled) return;
      settled = true;
      cleanup();
      handler(value);
    };

    const abort = () => finish(reject)(
      _makeAbortError(meta.message || 'Runtime asset acquisition cancelled.', meta)
    );

    cleanupFns.push(_bindAbortSignal(options.signal, abort));
    cleanupFns.push(_startCancellationPoll(options, abort));

    try {
      _throwIfCancelled(options, meta);
    } catch (error) {
      finish(reject)(error);
      return;
    }

    Promise.resolve(promise).then(finish(resolve), finish(reject));
  });
}

function _addProgressSubscriber(entry, onProgress) {
  if (!entry || typeof onProgress !== 'function') return () => {};

  entry.progressSubscribers.add(onProgress);

  if (entry.lastProgressEvent) {
    try { onProgress(entry.lastProgressEvent); } catch {}
  }

  return () => {
    try { entry.progressSubscribers.delete(onProgress); } catch {}
  };
}

function _emitProgress(entry, patch = {}) {
  if (!entry) return;

  const nextEvent = {
    assetId: entry.assetId,
    phase: String(patch.phase || entry.lastProgressEvent?.phase || 'unknown').trim(),
    status: String(patch.status || entry.lastProgressEvent?.status || 'progress').trim(),
    timestamp: Date.now(),
    ...patch
  };

  if (
    Number.isFinite(Number(nextEvent.bytesReceived)) &&
    Number.isFinite(Number(nextEvent.bytesTotal)) &&
    Number(nextEvent.bytesTotal) > 0
  ) {
    const bytesReceived = Math.max(0, Number(nextEvent.bytesReceived));
    const bytesTotal = Math.max(1, Number(nextEvent.bytesTotal));
    nextEvent.bytesReceived = bytesReceived;
    nextEvent.bytesTotal = bytesTotal;
    nextEvent.progress = Math.max(0, Math.min(1, bytesReceived / bytesTotal));
  }

  entry.lastProgressEvent = nextEvent;

  for (const subscriber of [...entry.progressSubscribers]) {
    try { subscriber(nextEvent); } catch {}
  }
}

function _resetForTests() {
  _manifestCache = null;
  _manifestCacheKey = '';
  _inFlight.clear();
}

function _tryGetElectronApp() {
  try {
    const electron = require('electron');
    // In Electron: electron is an object with app.
    // In plain Node: require('electron') may be a string path to the electron binary.
    if (electron && typeof electron === 'object' && electron.app) return electron.app;
  } catch {}
  return null;
}

function getUserDataPath() {
  // Allow overrides for testing / scripts.
  if (process.env.LEADAE_USERDATA && String(process.env.LEADAE_USERDATA).trim()) {
    return String(process.env.LEADAE_USERDATA).trim();
  }

  // IMPORTANT: Use the app's canonical stable userData path (desktop + CEP agree).
  try {
    if (typeof getCanonicalUserDataPath === 'function') return getCanonicalUserDataPath();
  } catch {}

  // Safe fallback for CLI usage (not relied on in production runtime).
  if (process.platform === 'darwin') {
    return path.join(os.homedir(), 'Library', 'Application Support', 'LeadAEAssist');
  }
  if (process.platform === 'win32') {
    return path.join(process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), 'LeadAEAssist');
  }
  // linux
  return path.join(process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config'), 'LeadAEAssist');
}

function computeAssetPaths({ userDataPath } = {}) {
  const userData = userDataPath || getUserDataPath();
  const assetsRoot = path.join(userData, 'assets');
  const downloadsRoot = path.join(assetsRoot, 'downloads');
  const stateFile = path.join(assetsRoot, 'state.json');
  return { userData, assetsRoot, downloadsRoot, stateFile };
}

function _toPosixRelativePath(value) {
  const raw = String(value || '').trim().replace(/\\+/g, '/').replace(/^\/+|\/+$/g, '');
  if (!raw) return '';
  const normalized = path.posix.normalize(raw);
  if (!normalized || normalized === '.' || normalized.startsWith('../') || normalized === '..') {
    return '';
  }
  return normalized;
}

function _resolveAssetInstallRelativePath(desc) {
  if (!desc || typeof desc !== 'object') return '';
  return _toPosixRelativePath(desc.installPath || desc.installDir || '');
}

function _normalizeAbsolutePath(value) {
  const candidate = String(value || '').trim();
  if (!candidate) return '';
  try {
    return path.resolve(candidate);
  } catch {
    return candidate;
  }
}

function _isPathWithinRoot(rootPath, candidatePath) {
  const root = _normalizeAbsolutePath(rootPath);
  const candidate = _normalizeAbsolutePath(candidatePath);
  if (!root || !candidate) return false;
  if (root === candidate) return true;
  const rel = path.relative(root, candidate);
  return !!rel && !rel.startsWith('..') && !path.isAbsolute(rel);
}

function _safeRealpath(targetPath) {
  try {
    return fs.realpathSync(targetPath);
  } catch {
    return _normalizeAbsolutePath(targetPath);
  }
}

function _pathsEqual(left, right) {
  return _safeRealpath(left) === _safeRealpath(right);
}

function _pathContains(left, right) {
  const outer = _safeRealpath(left);
  const inner = _safeRealpath(right);
  if (!outer || !inner) return false;
  if (outer === inner) return true;
  const rel = path.relative(outer, inner);
  return !!rel && !rel.startsWith('..') && !path.isAbsolute(rel);
}

function _normalizeProtectPaths(pathsList, assetsRoot) {
  const out = new Set();
  for (const candidate of Array.isArray(pathsList) ? pathsList : []) {
    const normalized = _normalizeAbsolutePath(candidate);
    if (!normalized) continue;
    if (assetsRoot && !_isPathWithinRoot(assetsRoot, normalized)) continue;
    out.add(normalized);
  }
  return out;
}

function _pathIsProtected(candidatePath, protectedPaths) {
  const normalizedCandidate = _normalizeAbsolutePath(candidatePath);
  if (!normalizedCandidate) return false;
  for (const protectedPath of protectedPaths || []) {
    if (_pathContains(normalizedCandidate, protectedPath)) return true;
  }
  return false;
}

function _statFreshnessTimestampMs(stats) {
  if (!stats || typeof stats !== 'object') return null;
  const candidates = [stats.birthtimeMs, stats.ctimeMs, stats.mtimeMs]
    .map(value => Number(value))
    .filter(value => Number.isFinite(value) && value > 0);
  if (!candidates.length) return null;
  return Math.max(...candidates);
}

function _parseVersionedSegment(segment) {
  const value = String(segment || '').trim();
  if (!value) return null;
  const match = value.match(VERSION_SEGMENT_RE);
  if (!match) return null;
  return {
    segment: value,
    prefix: match[1] || '',
    version: match[2] || '',
    suffix: match[3] || ''
  };
}

function _matchesVersionedSiblingSegment(name, spec) {
  if (!name || !spec) return false;
  if (spec.prefix && !name.startsWith(spec.prefix)) return false;
  if (spec.suffix && !name.endsWith(spec.suffix)) return false;

  const middle = name.slice(spec.prefix.length, name.length - spec.suffix.length);
  return /^\d+(?:\.\d+){1,}$/.test(middle);
}

function _deriveVersionedSiblingPruneSpec(desc) {
  const installRel = _resolveAssetInstallRelativePath(desc);
  if (!installRel) return null;

  const prune = (desc && typeof desc.prune === 'object') ? desc.prune : null;
  if (prune && String(prune.strategy || '').trim() === 'versioned-siblings') {
    const familyRootRel = _toPosixRelativePath(prune.rootDir || '');
    if (!familyRootRel) return null;

    const relFromRoot = path.posix.relative(familyRootRel, installRel);
    if (!relFromRoot || relFromRoot.startsWith('../') || relFromRoot === '..') return null;

    const keepName = relFromRoot.split('/').filter(Boolean)[0] || '';
    if (!keepName) return null;

    const parsed = _parseVersionedSegment(keepName);
    return {
      familyRootRel,
      keepName,
      prefix: String(prune.matchPrefix || parsed?.prefix || '').trim(),
      suffix: String(prune.matchSuffix || parsed?.suffix || '').trim()
    };
  }

  const segments = installRel.split('/').filter(Boolean);
  for (let index = segments.length - 1; index > 0; index -= 1) {
    const parsed = _parseVersionedSegment(segments[index]);
    if (!parsed) continue;
    return {
      familyRootRel: segments.slice(0, index).join('/'),
      keepName: segments[index],
      prefix: parsed.prefix,
      suffix: parsed.suffix
    };
  }

  return null;
}

function _collectVersionedSiblingPruneFamilies(manifest) {
  const assets = (manifest?.assets && typeof manifest.assets === 'object') ? manifest.assets : {};
  const families = new Map();

  for (const descriptor of Object.values(assets)) {
    if (!descriptor || typeof descriptor !== 'object') continue;
    const spec = _deriveVersionedSiblingPruneSpec(descriptor);
    if (!spec || !spec.familyRootRel || !spec.keepName) continue;

    const key = `${spec.familyRootRel}::${spec.prefix}::${spec.suffix}`;
    if (!families.has(key)) {
      families.set(key, {
        familyRootRel: spec.familyRootRel,
        prefix: spec.prefix || '',
        suffix: spec.suffix || '',
        keepNames: new Set()
      });
    }
    families.get(key).keepNames.add(spec.keepName);
  }

  return [...families.values()];
}

function _collectCurrentManifestInstallPaths(manifest, assetsRoot) {
  const assets = (manifest?.assets && typeof manifest.assets === 'object') ? manifest.assets : {};
  const protectedPaths = new Set();

  for (const descriptor of Object.values(assets)) {
    const relInstallPath = _resolveAssetInstallRelativePath(descriptor);
    if (!relInstallPath) continue;
    protectedPaths.add(path.join(assetsRoot, relInstallPath));
  }

  return protectedPaths;
}

function _resolveExpectedDownloadFilename(assetId, descriptor) {
  if (!assetId || !descriptor || typeof descriptor !== 'object') return '';
  const suffix = descriptor.archiveFormat === 'zip' ? 'zip' : 'download';
  return `${assetId}.${suffix}`;
}

function _collectCurrentDownloadPaths(manifest, downloadsRoot) {
  const assets = (manifest?.assets && typeof manifest.assets === 'object') ? manifest.assets : {};
  const protectedPaths = new Set();

  for (const [assetId, descriptor] of Object.entries(assets)) {
    const filename = _resolveExpectedDownloadFilename(assetId, descriptor);
    if (!filename) continue;
    protectedPaths.add(path.join(downloadsRoot, filename));
    protectedPaths.add(path.join(downloadsRoot, `${filename}.tmp`));
  }

  return protectedPaths;
}

function _collectInFlightProtectedPaths({ isPackaged, userDataPath } = {}) {
  const protectedPaths = new Set();

  for (const [inFlightKey] of _inFlight.entries()) {
    const [assetId, entryUserDataPath, modeFlag] = String(inFlightKey || '').split('::');
    if ((entryUserDataPath || '') !== (userDataPath || '')) continue;
    if ((modeFlag || '') !== (isPackaged ? 'p' : 'd')) continue;

    const descriptor = getAssetDescriptor(assetId, { isPackaged });
    if (!descriptor) continue;

    const relInstallPath = _resolveAssetInstallRelativePath(descriptor);
    if (relInstallPath) {
      protectedPaths.add(path.join(computeAssetPaths({ userDataPath }).assetsRoot, relInstallPath));
    }

    const expectedDownload = _resolveExpectedDownloadFilename(assetId, descriptor);
    if (expectedDownload) {
      protectedPaths.add(path.join(computeAssetPaths({ userDataPath }).downloadsRoot, expectedDownload));
      protectedPaths.add(path.join(computeAssetPaths({ userDataPath }).downloadsRoot, `${expectedDownload}.tmp`));
    }
  }

  return protectedPaths;
}

function _isUsageCheckCommandAvailable(command) {
  const candidate = String(command || '').trim();
  if (!candidate) return false;
  try {
    const result = spawnSync(candidate, ['--version'], { stdio: 'ignore' });
    return !result.error;
  } catch {
    return false;
  }
}

function _isPathLikelyInUse(candidatePath, options = {}) {
  const normalizedCandidate = _normalizeAbsolutePath(candidatePath);
  if (!normalizedCandidate) return { checked: false, inUse: false, method: null };

  if (typeof options.processUsageDetector === 'function') {
    try {
      return options.processUsageDetector(normalizedCandidate);
    } catch {
      return { checked: false, inUse: false, method: 'custom' };
    }
  }

  if (process.platform === 'win32') {
    return { checked: false, inUse: false, method: 'windows-unsupported' };
  }

  if (!_isUsageCheckCommandAvailable('ps')) {
    return { checked: false, inUse: false, method: 'ps-missing' };
  }

  try {
    const result = spawnSync('ps', ['axww', '-o', 'pid=', '-o', 'command='], {
      encoding: 'utf8',
      maxBuffer: 1024 * 1024 * 8
    });

    if (result.error) {
      return { checked: false, inUse: false, method: 'ps-error' };
    }

    if (result.status !== 0) {
      return { checked: false, inUse: false, method: 'ps-nonzero' };
    }

    const haystack = String(result.stdout || '');
    const inUse = haystack.split(/\r?\n/).some(line => line.includes(normalizedCandidate));
    return { checked: true, inUse, method: 'ps-commandline' };
  } catch {
    return { checked: false, inUse: false, method: 'ps-exception' };
  }
}

function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}

function readPackagedManifest({ isPackaged } = {}) {
  // Phase 0 loader lives in utils/runtimeAssetsManifest.js
  const packaged = !!isPackaged;
  const key = packaged ? `packaged:${process.resourcesPath || ''}` : `dev:${process.cwd()}`;
  if (_manifestCache && _manifestCacheKey === key) return _manifestCache;
  _manifestCache = loadRuntimeAssetsManifest({ isPackaged: packaged });
  _manifestCacheKey = key;
  return _manifestCache;
}

function _getAppVersion() {
  const app = _tryGetElectronApp();
  if (app && typeof app.getVersion === 'function') {
    try { return String(app.getVersion() || '').trim(); } catch {}
  }
  try {
    const pkg = require('../package.json');
    return String(pkg?.version || '').trim();
  } catch {}
  return '';
}

function _applyTemplate(str) {
  const s = String(str || '');
  const v = _getAppVersion();
  return s.replace(/\{\{APP_VERSION\}\}/g, v);
}

function _joinUrl(base, rel) {
  const b = String(base || '').replace(/\/+$/, '');
  const r = String(rel || '').replace(/^\/+/, '');
  return b && r ? `${b}/${r}` : (b || r);
}

function getAssetsBaseUrl({ isPackaged } = {}) {
  try {
    const cfg = loadPublicRuntimeConfig({ isPackaged: !!isPackaged, allowDefaults: false });
    const base = String(cfg?.assets?.baseUrl || '').trim();
    return _applyTemplate(base);
  } catch {
    return '';
  }
}

function resolveAssetUrl(desc, { isPackaged } = {}) {
  if (!desc || typeof desc !== 'object') return '';
  const explicit = String(desc.downloadUrl || '').trim();
  if (explicit) return _applyTemplate(explicit);
  const rel = String(desc.relativeUrl || '').trim();
  if (!rel) return '';
  const base = getAssetsBaseUrl({ isPackaged });
  if (!base) return '';
  return _joinUrl(base, rel);
}

function getAssetDescriptor(assetId, { isPackaged } = {}) {
  const man = readPackagedManifest({ isPackaged });
  const assets = man?.assets && typeof man.assets === 'object' ? man.assets : {};
  const d = assets[assetId];
  return (d && typeof d === 'object') ? d : null;
}

function getInstalledAssetPath(assetId, { userDataPath } = {}) {
  const desc = getAssetDescriptor(assetId, { isPackaged: !!_tryGetElectronApp()?.isPackaged });
  if (!desc) return null;
  const { assetsRoot } = computeAssetPaths({ userDataPath });
  if (desc.installPath) return path.join(assetsRoot, desc.installPath);
  if (desc.installDir) return path.join(assetsRoot, desc.installDir);
  return null;
}

function readInstalledState({ userDataPath } = {}) {
  const { assetsRoot, stateFile } = computeAssetPaths({ userDataPath });
  try {
    if (!fs.existsSync(stateFile)) return { schemaVersion: 1, installed: {} };
    const raw = fs.readFileSync(stateFile, 'utf8');
    const j = JSON.parse(raw);
    const installed = (j && typeof j.installed === 'object') ? j.installed : {};
    const schemaVersion = Number(j?.schemaVersion || 1);
    return { schemaVersion: Number.isFinite(schemaVersion) ? schemaVersion : 1, installed };
  } catch {
    // If state is corrupted, do not crash the app; reset to empty.
    return { schemaVersion: 1, installed: {} };
  } finally {
    // ensure assets root exists for later phases
    try { ensureDir(assetsRoot); } catch {}
  }
}

function writeInstalledState(nextState, { userDataPath } = {}) {
  const { assetsRoot, stateFile } = computeAssetPaths({ userDataPath });
  ensureDir(assetsRoot);
  const tmp = `${stateFile}.tmp`;
  const body = JSON.stringify(nextState || { schemaVersion: 1, installed: {} }, null, 2);
  fs.writeFileSync(tmp, body, 'utf8');
  fs.renameSync(tmp, stateFile);
}

function _readInstalledStateEntry(assetId, { userDataPath } = {}) {
  const state = readInstalledState({ userDataPath });
  const installed = (state.installed && typeof state.installed === 'object') ? state.installed : {};
  const entry = (installed[assetId] && typeof installed[assetId] === 'object') ? installed[assetId] : null;
  return { state, entry };
}

function _writeInstalledStateEntry(assetId, entry, { userDataPath, baseState } = {}) {
  const state = (baseState && typeof baseState === 'object')
    ? baseState
    : readInstalledState({ userDataPath });
  state.installed = (state.installed && typeof state.installed === 'object') ? state.installed : {};
  state.installed[assetId] = entry;
  writeInstalledState(state, { userDataPath });
  return state;
}

function _deleteInstalledStateEntry(assetId, { userDataPath, baseState } = {}) {
  const state = (baseState && typeof baseState === 'object')
    ? baseState
    : readInstalledState({ userDataPath });
  state.installed = (state.installed && typeof state.installed === 'object') ? state.installed : {};
  if (Object.prototype.hasOwnProperty.call(state.installed, assetId)) {
    delete state.installed[assetId];
    writeInstalledState(state, { userDataPath });
  }
  return state;
}


function _removeStateEntriesUnderPaths(state, removedPaths) {
  const currentState = (state && typeof state === 'object') ? state : { schemaVersion: 1, installed: {} };
  currentState.installed = (currentState.installed && typeof currentState.installed === 'object')
    ? currentState.installed
    : {};

  const removedAssetIds = [];

  for (const [assetId, entry] of Object.entries(currentState.installed)) {
    const entryPath = _normalizeAbsolutePath(entry?.path);
    if (!entryPath) continue;
    const covered = [...removedPaths].some(removedPath => _pathContains(removedPath, entryPath));
    if (!covered) continue;
    delete currentState.installed[assetId];
    removedAssetIds.push(assetId);
  }

  return removedAssetIds;
}

function _removeStaleStateEntries(currentState, manifest, assetsRoot) {
  const state = (currentState && typeof currentState === 'object') ? currentState : { schemaVersion: 1, installed: {} };
  state.installed = (state.installed && typeof state.installed === 'object') ? state.installed : {};

  const manifestAssets = (manifest?.assets && typeof manifest.assets === 'object') ? manifest.assets : {};
  const removedAssetIds = [];

  for (const [assetId, entry] of Object.entries(state.installed)) {
    const descriptor = manifestAssets[assetId];
    const entryPath = _normalizeAbsolutePath(entry?.path);
    const currentInstallRel = _resolveAssetInstallRelativePath(descriptor);
    const currentInstallPath = currentInstallRel ? path.join(assetsRoot, currentInstallRel) : '';

    const shouldRemove = (
      !descriptor ||
      !entryPath ||
      !_isPathWithinRoot(assetsRoot, entryPath) ||
      !fs.existsSync(entryPath) ||
      (currentInstallPath && !_pathsEqual(currentInstallPath, entryPath))
    );

    if (!shouldRemove) continue;
    delete state.installed[assetId];
    removedAssetIds.push(assetId);
  }

  return removedAssetIds;
}

function _prunePath(candidatePath) {
  const target = _normalizeAbsolutePath(candidatePath);
  if (!target || !fs.existsSync(target)) return false;
  fs.rmSync(target, { recursive: true, force: false, maxRetries: 2, retryDelay: 50 });
  return !fs.existsSync(target);
}

function _bestEffortPruneAfterInstall(options = {}) {
  if (options.skipPrune) return null;
  try {
    return pruneOldAssetVersions(options);
  } catch {
    return null;
  }
}

function pruneOldAssetVersions(options = {}) {
  const isPackaged = options.isPackaged ?? !!_tryGetElectronApp()?.isPackaged;
  const userDataPath = options.userDataPath;
  const now = Number.isFinite(Number(options.now)) ? Number(options.now) : Date.now();
  const gracePeriodMs = Number.isFinite(Number(options.gracePeriodMs))
    ? Math.max(0, Number(options.gracePeriodMs))
    : DEFAULT_PRUNE_GRACE_PERIOD_MS;
  const manifest = options.manifest && typeof options.manifest === 'object'
    ? options.manifest
    : readPackagedManifest({ isPackaged });
  const { assetsRoot, downloadsRoot } = computeAssetPaths({ userDataPath });
  ensureDir(assetsRoot);
  ensureDir(downloadsRoot);

  const protectedPaths = _normalizeProtectPaths(options.protectPaths, assetsRoot);
  for (const currentInstallPath of _collectCurrentManifestInstallPaths(manifest, assetsRoot)) {
    protectedPaths.add(_normalizeAbsolutePath(currentInstallPath));
  }
  for (const currentDownloadPath of _collectCurrentDownloadPaths(manifest, downloadsRoot)) {
    protectedPaths.add(_normalizeAbsolutePath(currentDownloadPath));
  }
  for (const inFlightPath of _collectInFlightProtectedPaths({ isPackaged, userDataPath })) {
    protectedPaths.add(_normalizeAbsolutePath(inFlightPath));
  }

  const result = {
    ok: true,
    removedPaths: [],
    removedStateAssetIds: [],
    skipped: [],
    errors: []
  };

  const removedRoots = new Set();
  const versionFamilies = _collectVersionedSiblingPruneFamilies(manifest);
  for (const family of versionFamilies) {
    const familyRoot = path.join(assetsRoot, family.familyRootRel);
    let entries = [];
    try {
      entries = fs.readdirSync(familyRoot, { withFileTypes: true });
    } catch {
      continue;
    }

    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      if (family.keepNames.has(entry.name)) continue;
      if (!_matchesVersionedSiblingSegment(entry.name, family)) continue;

      const candidateRoot = path.join(familyRoot, entry.name);
      if (!_isPathWithinRoot(assetsRoot, candidateRoot)) {
        result.skipped.push({ path: candidateRoot, reason: 'outside-assets-root' });
        continue;
      }

      if (_pathIsProtected(candidateRoot, protectedPaths)) {
        result.skipped.push({ path: candidateRoot, reason: 'protected' });
        continue;
      }

      let candidateStats = null;
      try {
        candidateStats = fs.statSync(candidateRoot);
      } catch {}

      const usage = _isPathLikelyInUse(candidateRoot, options);
      if (usage?.inUse) {
        result.skipped.push({ path: candidateRoot, reason: 'in-use', method: usage.method || null });
        continue;
      }

      const candidateFreshnessMs = _statFreshnessTimestampMs(candidateStats);
      const candidateAgeMs = candidateFreshnessMs != null ? Math.max(0, now - candidateFreshnessMs) : null;
      if (!usage?.checked && candidateAgeMs != null && candidateAgeMs < gracePeriodMs) {
        result.skipped.push({
          path: candidateRoot,
          reason: 'grace-period',
          method: usage?.method || null,
          ageMs: candidateAgeMs,
          gracePeriodMs
        });
        continue;
      }

      try {
        if (_prunePath(candidateRoot)) {
          removedRoots.add(candidateRoot);
          result.removedPaths.push(candidateRoot);
        }
      } catch (error) {
        result.errors.push({
          path: candidateRoot,
          reason: 'remove-failed',
          code: error?.code || null,
          message: error?.message || String(error)
        });
      }
    }
  }

  try {
    const downloadEntries = fs.readdirSync(downloadsRoot, { withFileTypes: true });
    for (const entry of downloadEntries) {
      if (!entry.isFile()) continue;
      const candidatePath = path.join(downloadsRoot, entry.name);
      if (_pathIsProtected(candidatePath, protectedPaths)) continue;

      try {
        if (_prunePath(candidatePath)) result.removedPaths.push(candidatePath);
      } catch (error) {
        result.errors.push({
          path: candidatePath,
          reason: 'remove-failed',
          code: error?.code || null,
          message: error?.message || String(error)
        });
      }
    }
  } catch {}

  const state = readInstalledState({ userDataPath });
  const removedStateIds = new Set();
  for (const assetId of _removeStateEntriesUnderPaths(state, removedRoots)) {
    removedStateIds.add(assetId);
  }
  for (const assetId of _removeStaleStateEntries(state, manifest, assetsRoot)) {
    removedStateIds.add(assetId);
  }

  result.removedStateAssetIds = [...removedStateIds].sort();
  writeInstalledState(state, { userDataPath });

  return result;
}

function _readFileStateSnapshot(filePath) {
  const stats = fs.statSync(filePath);
  if (!stats.isFile()) {
    throw new Error(`Expected a file asset snapshot target, got: ${filePath}`);
  }

  return {
    size: Number.isFinite(Number(stats.size)) ? Number(stats.size) : null,
    mtimeMs: Number.isFinite(Number(stats.mtimeMs)) ? Math.round(Number(stats.mtimeMs)) : null
  };
}

function _normalizeFileStateSnapshot(snapshot) {
  if (!snapshot || typeof snapshot !== 'object') return { size: null, mtimeMs: null };
  const size = Number.isFinite(Number(snapshot.size)) ? Number(snapshot.size) : null;
  const mtimeMs = Number.isFinite(Number(snapshot.mtimeMs)) ? Math.round(Number(snapshot.mtimeMs)) : null;
  return { size, mtimeMs };
}

function _fileStateSnapshotMatches(left, right) {
  const lhs = _normalizeFileStateSnapshot(left);
  const rhs = _normalizeFileStateSnapshot(right);
  return (
    lhs.size !== null &&
    lhs.mtimeMs !== null &&
    lhs.size === rhs.size &&
    lhs.mtimeMs === rhs.mtimeMs
  );
}

function _getExpectedInstalledFileSha256(desc) {
  if (!desc || desc.type !== 'file') return '';
  return _normalizeSha256(desc.sha256) || _normalizeSha256(desc.seedSha256);
}

function _normalizeInstalledPath(value) {
  return _normalizeAbsolutePath(value);
}

function _maybeReuseInstalledAsset(assetId, desc, installedPath, { userDataPath, emitProgress } = {}) {
  if (!installedPath || !fs.existsSync(installedPath)) return null;
  if (!desc || desc.type !== 'file') {
    return { ok: true, assetId, path: installedPath, source: 'installed' };
  }

  const expectedSha256 = _getExpectedInstalledFileSha256(desc);
  if (!expectedSha256) {
    return { ok: true, assetId, path: installedPath, source: 'installed' };
  }

  const notify = typeof emitProgress === 'function' ? emitProgress : () => {};
  const { state, entry } = _readInstalledStateEntry(assetId, { userDataPath });
  const recordedSha256 = _normalizeSha256(entry?.sha256);
  const recordedPath = _normalizeInstalledPath(entry?.path);
  const normalizedInstalledPath = _normalizeInstalledPath(installedPath);
  const pathMatches = !recordedPath || recordedPath === normalizedInstalledPath;

  if (pathMatches && recordedSha256 === expectedSha256) {
    try {
      const currentSnapshot = _readFileStateSnapshot(installedPath);
      if (_fileStateSnapshotMatches(entry, currentSnapshot)) {
        return { ok: true, assetId, path: installedPath, source: 'installed' };
      }
    } catch {
      // Fall through to a full checksum verification when stat-based reuse is unavailable.
    }
  }

  notify({
    phase: 'verify',
    status: 'start',
    source: 'installed',
    installPath: installedPath,
    checksumSource: 'sha256'
  });

  let actualSha256 = '';
  let currentSnapshot = null;
  let verifyError = null;

  try {
    actualSha256 = _sha256FileHex(installedPath);
    currentSnapshot = _readFileStateSnapshot(installedPath);
  } catch (error) {
    verifyError = error;
  }

  if (!verifyError && actualSha256 === expectedSha256) {
    const nextEntry = {
      ...(entry && typeof entry === 'object' ? entry : {}),
      path: installedPath,
      source: String(entry?.source || 'installed').trim() || 'installed',
      installedAt: Number.isFinite(Number(entry?.installedAt)) ? Number(entry.installedAt) : Date.now(),
      sha256: expectedSha256,
      verifiedAt: Date.now(),
      ...(currentSnapshot || {})
    };

    _writeInstalledStateEntry(assetId, nextEntry, { userDataPath, baseState: state });

    notify({
      phase: 'verify',
      status: 'complete',
      source: 'installed',
      installPath: installedPath,
      checksumSource: 'sha256'
    });

    return { ok: true, assetId, path: installedPath, source: 'installed' };
  }

  notify({
    phase: 'verify',
    status: verifyError ? 'error' : 'stale',
    source: 'installed',
    installPath: installedPath,
    checksumSource: 'sha256',
    expectedSha256,
    actualSha256: actualSha256 || null,
    errorCode: verifyError ? 'ASSET_VERIFY_FAILED' : 'ASSET_CHECKSUM_MISMATCH',
    message: verifyError ? (verifyError.message || String(verifyError)) : `Installed checksum mismatch for ${assetId}`
  });

  _safeRm(installedPath, { recursive: true });
  _deleteInstalledStateEntry(assetId, { userDataPath, baseState: state });
  return null;
}

function _normalizeSha256(value) {
  const normalized = String(value || '').trim().toLowerCase();
  return /^[a-f0-9]{64}$/.test(normalized) ? normalized : '';
}

function _sha256FileHex(filePath) {
  return sha256FileHex(filePath);
}

function _sha256DirectoryTreeHex(dirPath, options) {
  return sha256DirectoryTreeHex(dirPath, options);
}

function _resolveArchiveDirectorySeedDigestTarget(desc, sourcePath) {
  const entrypoint = String(desc?.entrypoint || '').trim().replace(/\\/g, '/');
  const topLevelDir = entrypoint.split('/').filter(Boolean)[0] || '';
  if (!topLevelDir) return { digestPath: sourcePath, rootName: '' };

  try {
    const sourceStats = fs.lstatSync(sourcePath);
    if (sourceStats.isDirectory() && path.basename(sourcePath) === topLevelDir) {
      return { digestPath: sourcePath, rootName: topLevelDir };
    }
  } catch {}

  const nestedPath = path.join(sourcePath, topLevelDir);
  try {
    const nestedStats = fs.lstatSync(nestedPath);
    if (nestedStats.isDirectory()) {
      return { digestPath: nestedPath, rootName: topLevelDir };
    }
  } catch {}

  return { digestPath: sourcePath, rootName: '' };
}

function _getSeedVerificationPlan(desc, sourcePath, sourceStats) {
  if (!desc || !sourcePath || !sourceStats) return { mode: 'none' };

  const archiveSha256 = _normalizeSha256(desc.sha256);
  const seedSha256 = _normalizeSha256(desc.seedSha256);

  if (!archiveSha256 && !seedSha256) return { mode: 'none' };

  if (desc.type === 'file' && sourceStats.isFile()) {
    return {
      mode: 'verify-file',
      expectedSha256: seedSha256 || archiveSha256,
      checksumSource: seedSha256 ? 'seedSha256' : 'sha256'
    };
  }

  if (desc.type === 'dir' && sourceStats.isDirectory()) {
    if (!seedSha256) {
      return {
        mode: 'skip',
        reason: archiveSha256 ? 'directory-seed-has-only-download-sha256' : 'directory-seed-missing-seedSha256'
      };
    }

    return {
      mode: 'verify-directory',
      expectedSha256: seedSha256,
      checksumSource: 'seedSha256'
    };
  }

  if (desc.type === 'archive') {
    if (sourceStats.isFile()) {
      return {
        mode: 'verify-file',
        expectedSha256: archiveSha256 || seedSha256,
        checksumSource: archiveSha256 ? 'sha256' : 'seedSha256'
      };
    }

    if (sourceStats.isDirectory()) {
      if (!seedSha256) {
        return {
          mode: 'skip',
          reason: archiveSha256 ? 'archive-directory-seed-has-only-download-sha256' : 'archive-directory-seed-missing-seedSha256'
        };
      }

      const archiveSeedTarget = _resolveArchiveDirectorySeedDigestTarget(desc, sourcePath);
      return {
        mode: 'verify-directory',
        expectedSha256: seedSha256,
        checksumSource: 'seedSha256',
        digestPath: archiveSeedTarget.digestPath,
        digestRootName: archiveSeedTarget.rootName
      };
    }
  }

  return { mode: 'none' };
}

function _verifySeedCandidate(assetId, desc, sourcePath, sourceStats, installedPath, emitProgress) {
  const plan = _getSeedVerificationPlan(desc, sourcePath, sourceStats);
  if (!plan || plan.mode === 'none') return plan;

  emitProgress({
    phase: 'verify',
    status: 'start',
    source: 'seed',
    candidatePath: sourcePath,
    installPath: installedPath
  });

  if (plan.mode === 'skip') {
    emitProgress({
      phase: 'verify',
      status: 'skipped',
      source: 'seed',
      candidatePath: sourcePath,
      installPath: installedPath,
      reason: plan.reason || null
    });
    return plan;
  }

  const got = plan.mode === 'verify-directory'
    ? _sha256DirectoryTreeHex(
      plan.digestPath || sourcePath,
      plan.digestRootName ? { rootName: plan.digestRootName } : undefined
    )
    : _sha256FileHex(sourcePath);

  if (String(got).toLowerCase() !== String(plan.expectedSha256).toLowerCase()) {
    throw _makeAssetError(
      'ASSET_CHECKSUM_MISMATCH',
      `Seed checksum mismatch for ${assetId}`,
      {
        assetId,
        installPath: installedPath,
        candidatePath: sourcePath,
        checksumSource: plan.checksumSource || null,
        expectedSha256: plan.expectedSha256 || null,
        actualSha256: got || null
      }
    );
  }

  emitProgress({
    phase: 'verify',
    status: 'complete',
    source: 'seed',
    candidatePath: sourcePath,
    installPath: installedPath,
    checksumSource: plan.checksumSource || null
  });

  return {
    ...plan,
    actualSha256: got
  };
}

function _copyAtomic(src, dest) {
  ensureDir(path.dirname(dest));
  const tmp = `${dest}.tmp`;
  _safeRm(tmp);
  fs.copyFileSync(src, tmp);
  try {
    _safeRm(dest, { recursive: true });
    fs.renameSync(tmp, dest);
  } catch (error) {
    _safeRm(tmp);
    throw error;
  }
}

function _copyDirAtomic(srcDir, destDir) {
  ensureDir(path.dirname(destDir));
  const tmp = `${destDir}.tmp`;
  try { fs.rmSync(tmp, { recursive: true, force: true }); } catch {}
  try { fs.rmSync(destDir, { recursive: true, force: true }); } catch {}

  // Preserve symlinks (dereference=false) and timestamps. Node 16+ supports fs.cpSync.
  fs.cpSync(srcDir, tmp, { recursive: true, dereference: false, preserveTimestamps: true });
  fs.renameSync(tmp, destDir);
}

function _resolveSeedCandidates(seedRel, { isPackaged } = {}) {
  const out = [];
  if (!seedRel) return out;
  const s = String(seedRel);
  if (path.isAbsolute(s)) out.push(s);
  // Packaged resources
  if (isPackaged && process.resourcesPath) {
    out.push(path.join(process.resourcesPath, s));
  }
  // Dev workspace
  out.push(path.join(process.cwd(), s));
  return out;
}

function _findFirstExisting(pathsList) {
  for (const p of pathsList) {
    try {
      if (fs.existsSync(p)) return p;
    } catch {}
  }
  return null;
}

function _httpGetFollow(urlStr, redirectsLeft = 5, options = {}) {
  return new Promise((resolve, reject) => {
    let settled = false;

    const finish = (handler) => (value) => {
      if (settled) return;
      settled = true;
      cleanup();
      handler(value);
    };

    const fail = finish(reject);
    const succeed = finish(resolve);

    const cleanupFns = [];
    const cleanup = () => {
      while (cleanupFns.length) {
        const fn = cleanupFns.pop();
        try { fn(); } catch {}
      }
    };

    try {
      _throwIfCancelled(options, {
        assetId: options.assetId,
        phase: 'download',
        url: urlStr
      });

      const u = new URL(urlStr);
      const lib = (u.protocol === 'http:') ? http : https;
      const req = lib.request(
        {
          protocol: u.protocol,
          hostname: u.hostname,
          port: u.port || undefined,
          path: u.pathname + u.search,
          headers: { 'User-Agent': 'LeadAEAssist/asset-fetch' }
        },
        res => {
          const status = res.statusCode || 0;
          const loc = res.headers.location;
          if ([301, 302, 303, 307, 308].includes(status) && loc && redirectsLeft > 0) {
            res.resume();
            const next = new URL(loc, u).toString();
            succeed(_httpGetFollow(next, redirectsLeft - 1, options));
            return;
          }
          if (status < 200 || status >= 300) {
            const chunks = [];
            res.on('data', d => chunks.push(d));
            res.on('end', () => {
              const body = Buffer.concat(chunks).toString('utf8').slice(0, 400);
              fail(new Error(`HTTP ${status} fetching ${urlStr}: ${body}`));
            });
            return;
          }
          cleanup();
          resolve(res);
        }
      );

      const abort = () => {
        const error = _makeAbortError('Runtime asset download cancelled.', {
          assetId: options.assetId,
          phase: 'download',
          url: urlStr
        });
        try { req.destroy(error); } catch {}
        fail(error);
      };

      cleanupFns.push(_bindAbortSignal(options.signal, abort));
      cleanupFns.push(_startCancellationPoll(options, abort));

      req.on('error', fail);
      req.end();
    } catch (e) {
      fail(e);
    }
  });
}

async function _downloadToFile(urlStr, destPath, options = {}) {
  ensureDir(path.dirname(destPath));
  const tmp = `${destPath}.tmp`;
  _safeRm(tmp);

  const assetId = options.assetId || null;
  const installPath = options.installPath || destPath;

  try {
    _throwIfCancelled(options, {
      assetId,
      phase: 'download',
      url: urlStr,
      installPath
    });

    const res = await _httpGetFollow(urlStr, 5, {
      ...options,
      assetId
    });

    const bytesTotalRaw = Number.parseInt(String(res.headers?.['content-length'] || '').trim(), 10);
    const bytesTotal = Number.isFinite(bytesTotalRaw) && bytesTotalRaw >= 0
      ? bytesTotalRaw
      : null;

    if (typeof options.emitProgress === 'function') {
      options.emitProgress({
        phase: 'download',
        status: 'start',
        url: urlStr,
        bytesReceived: 0,
        ...(bytesTotal != null ? { bytesTotal } : {})
      });
    }

    await new Promise((resolve, reject) => {
      const ws = fs.createWriteStream(tmp);
      let settled = false;
      let bytesReceived = 0;

      const cleanupFns = [];
      const cleanup = () => {
        while (cleanupFns.length) {
          const fn = cleanupFns.pop();
          try { fn(); } catch {}
        }
      };

      const finish = (handler) => (value) => {
        if (settled) return;
        settled = true;
        cleanup();
        handler(value);
      };

      const fail = finish((error) => {
        _safeRm(tmp);
        reject(error);
      });

      const succeed = finish(resolve);

      const abort = () => {
        const error = _makeAbortError('Runtime asset download cancelled.', {
          assetId,
          phase: 'download',
          url: urlStr,
          installPath
        });
        try { res.destroy(error); } catch {}
        try { ws.destroy(error); } catch {}
        fail(error);
      };

      cleanupFns.push(_bindAbortSignal(options.signal, abort));
      cleanupFns.push(_startCancellationPoll(options, abort));

      res.on('data', chunk => {
        bytesReceived += chunk.length;

        try {
          _throwIfCancelled(options, {
            assetId,
            phase: 'download',
            url: urlStr,
            installPath
          });
        } catch (error) {
          abort();
          return;
        }

        if (typeof options.emitProgress === 'function') {
          options.emitProgress({
            phase: 'download',
            status: 'progress',
            url: urlStr,
            bytesReceived,
            ...(bytesTotal != null ? { bytesTotal } : {})
          });
        }
      });

      res.on('error', fail);
      ws.on('error', fail);
      ws.on('finish', () => {
        if (typeof options.emitProgress === 'function') {
          options.emitProgress({
            phase: 'download',
            status: 'complete',
            url: urlStr,
            bytesReceived,
            ...(bytesTotal != null ? { bytesTotal } : {})
          });
        }
        succeed();
      });

      res.pipe(ws);
    });

    fs.renameSync(tmp, destPath);
  } catch (error) {
    _safeRm(tmp);
    if (_isAbortError(error) || String(error?.code || '').trim() === 'ASSET_DOWNLOAD_FAILED') {
      throw error;
    }

    throw _makeAssetError(
      'ASSET_DOWNLOAD_FAILED',
      `Failed to download runtime asset ${assetId || '(unknown asset)'} from ${urlStr}: ${error?.message || String(error)}`,
      {
        assetId,
        url: urlStr,
        installPath
      },
      error
    );
  }
}

function _runCommandWithAbort(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    let child = null;
    let settled = false;
    let stdout = '';
    let stderr = '';

    const cleanupFns = [];
    const cleanup = () => {
      while (cleanupFns.length) {
        const fn = cleanupFns.pop();
        try { fn(); } catch {}
      }
    };

    const finish = (handler) => (value) => {
      if (settled) return;
      settled = true;
      cleanup();
      handler(value);
    };

    const fail = finish(reject);
    const succeed = finish(resolve);

    try {
      _throwIfCancelled(options, {
        assetId: options.assetId,
        phase: options.phase || 'install',
        installPath: options.installPath,
        archivePath: options.archivePath
      });

      child = spawn(command, args, {
        stdio: ['ignore', 'pipe', 'pipe']
      });

      const abort = () => {
        const error = _makeAbortError('Runtime asset extraction cancelled.', {
          assetId: options.assetId,
          phase: options.phase || 'install',
          installPath: options.installPath,
          archivePath: options.archivePath
        });

        try {
          if (process.platform === 'win32') child.kill();
          else child.kill('SIGTERM');
        } catch {}

        fail(error);
      };

      cleanupFns.push(_bindAbortSignal(options.signal, abort));
      cleanupFns.push(_startCancellationPoll(options, abort));

      child.stdout.on('data', chunk => {
        stdout += chunk.toString();
      });
      child.stderr.on('data', chunk => {
        stderr += chunk.toString();
      });
      child.on('error', fail);
      child.on('close', (code, signal) => {
        if (code === 0) {
          succeed({ stdout, stderr });
          return;
        }

        const detail = [
          `Command failed: ${command} ${args.join(' ')}`,
          `exit=${code}`,
          signal ? `signal=${signal}` : '',
          stderr ? `stderr=${stderr.trim().slice(0, 500)}` : ''
        ].filter(Boolean).join(' | ');

        const error = new Error(detail || `Command failed: ${command}`);
        error.exitCode = code;
        error.signal = signal || null;
        error.stdout = stdout;
        error.stderr = stderr;
        fail(error);
      });
    } catch (error) {
      fail(error);
    }
  });
}

async function _extractZipToDir(zipPath, outDir, options = {}) {
  ensureDir(outDir);
  if (process.platform === 'darwin') {
    await _runCommandWithAbort('/usr/bin/ditto', ['-x', '-k', zipPath, outDir], {
      ...options,
      archivePath: zipPath,
      installPath: outDir,
      phase: 'install'
    });
    return;
  }
  await _runCommandWithAbort('unzip', ['-q', zipPath, '-d', outDir], {
    ...options,
    archivePath: zipPath,
    installPath: outDir,
    phase: 'install'
  });
}

async function _installZipArchiveAtomic(zipPath, destDir, options = {}) {
  ensureDir(path.dirname(destDir));
  const tmp = `${destDir}.tmp_extract`;
  _safeRm(tmp, { recursive: true });
  ensureDir(tmp);

  if (typeof options.emitProgress === 'function') {
    options.emitProgress({
      phase: 'install',
      status: 'start',
      mode: 'extract',
      archivePath: zipPath,
      installPath: destDir
    });
  }

  try {
    await _extractZipToDir(zipPath, tmp, options);
    _throwIfCancelled(options, {
      assetId: options.assetId,
      phase: 'install',
      archivePath: zipPath,
      installPath: destDir
    });
    _safeRm(destDir, { recursive: true });
    fs.renameSync(tmp, destDir);

    if (typeof options.emitProgress === 'function') {
      options.emitProgress({
        phase: 'install',
        status: 'complete',
        mode: 'extract',
        archivePath: zipPath,
        installPath: destDir
      });
    }
  } catch (error) {
    _safeRm(tmp, { recursive: true });
    if (_isAbortError(error)) throw error;
    throw _makeAssetError(
      'ASSET_EXTRACT_FAILED',
      `Failed to extract runtime asset ${options.assetId || '(unknown asset)'} into ${destDir}: ${error?.message || String(error)}`,
      {
        assetId: options.assetId || null,
        archivePath: zipPath,
        installPath: destDir
      },
      error
    );
  }
}

async function ensureAsset(assetId, options = {}) {
  const isPackaged = options.isPackaged ?? !!_tryGetElectronApp()?.isPackaged;
  const userDataPath = options.userDataPath;
  const offline = !!options.offline;

  const desc = getAssetDescriptor(assetId, { isPackaged });
  if (!desc) {
    const err = new Error(`Unknown assetId: ${assetId}`);
    err.code = 'ASSET_UNKNOWN';
    throw err;
  }
  if (desc.type !== 'file' && desc.type !== 'dir' && desc.type !== 'archive') {
    const err = new Error(`Unsupported asset type for ${assetId}: ${desc.type}`);
    err.code = 'ASSET_UNSUPPORTED';
    throw err;
  }
  if (desc.type === 'file' && !desc.installPath) {
    const err = new Error(`Invalid manifest entry for ${assetId}: missing installPath`);
    err.code = 'ASSET_INVALID';
    throw err;
  }
  if (desc.type === 'dir' && !desc.installDir) {
    const err = new Error(`Invalid manifest entry for ${assetId}: missing installDir`);
    err.code = 'ASSET_INVALID';
    throw err;
  }
  if (desc.type === 'archive' && (!desc.installDir || !desc.archiveFormat)) {
    const err = new Error(`Invalid manifest entry for ${assetId}: archive requires installDir + archiveFormat`);
    err.code = 'ASSET_INVALID';
    throw err;
  }

  const inFlightKey = `${assetId}::${userDataPath || ''}::${isPackaged ? 'p' : 'd'}`;
  const existingEntry = _inFlight.get(inFlightKey);
  if (existingEntry) {
    const unsubscribe = _addProgressSubscriber(existingEntry, options.onProgress);
    const callerPromise = Promise.resolve(existingEntry.promise).finally(unsubscribe);
    return _attachCallerCancellation(callerPromise, options, {
      assetId,
      phase: existingEntry.lastProgressEvent?.phase || 'ensure'
    });
  }

  const entry = {
    assetId,
    progressSubscribers: new Set(),
    lastProgressEvent: null,
    promise: null
  };

  const unsubscribe = _addProgressSubscriber(entry, options.onProgress);
  const emitProgress = (patch) => _emitProgress(entry, patch);

  entry.promise = (async () => {
    const { assetsRoot, downloadsRoot } = computeAssetPaths({ userDataPath });
    ensureDir(assetsRoot);
    ensureDir(downloadsRoot);
    const installedPath = desc.type === 'file'
      ? path.join(assetsRoot, desc.installPath)
      : path.join(assetsRoot, desc.installDir);

    const cancellationOptions = {
      signal: options.signal,
      isCancelled: options.isCancelled
    };

    const baseMeta = {
      assetId,
      installPath: installedPath
    };

    try {
      _throwIfCancelled(cancellationOptions, {
        ...baseMeta,
        phase: 'check'
      });

      // Already installed
      const reusableInstalledAsset = _maybeReuseInstalledAsset(assetId, desc, installedPath, {
        userDataPath,
        emitProgress
      });
      if (reusableInstalledAsset) {
        emitProgress({
          phase: 'complete',
          status: 'reused',
          source: 'installed',
          path: installedPath
        });
        return reusableInstalledAsset;
      }

      // 1) Seed from bundled/dev copies (best-effort; fall back to download when possible)
      let lastSeedError = null;
      let lastSeedCandidate = null;
      const seedPaths = Array.isArray(desc.seedPaths) ? desc.seedPaths : [];
      for (const seedRel of seedPaths) {
        _throwIfCancelled(cancellationOptions, {
          ...baseMeta,
          phase: 'seed'
        });

        const candidates = _resolveSeedCandidates(seedRel, { isPackaged });
        const found = _findFirstExisting(candidates);
        if (!found) continue;

        // Type safety: file assets must seed from a file, dir assets must seed from a directory,
        // archive assets may seed from either a directory tree or a matching archive file.
        let seedStats = null;
        try {
          seedStats = fs.statSync(found);
          if (desc.type === 'file' && !seedStats.isFile()) continue;
          if (desc.type === 'dir' && !seedStats.isDirectory()) continue;
          if (desc.type === 'archive' && !seedStats.isDirectory() && !seedStats.isFile()) continue;
        } catch {
          continue;
        }

        emitProgress({
          phase: 'seed',
          status: 'start',
          source: 'seed',
          candidatePath: found,
          installPath: installedPath
        });

        try {
          const verifiedPlan = _verifySeedCandidate(assetId, desc, found, seedStats, installedPath, emitProgress);

          const installMode = desc.type === 'file'
            ? 'copy'
            : (desc.type === 'archive' && seedStats.isFile() ? 'extract' : 'copy-dir');
          const emitInstallBoundary = !(desc.type === 'archive' && seedStats.isFile());

          if (emitInstallBoundary) {
            emitProgress({
              phase: 'install',
              status: 'start',
              source: 'seed',
              candidatePath: found,
              installPath: installedPath,
              mode: installMode
            });
          }

          if (desc.type === 'file') {
            _copyAtomic(found, installedPath);
          } else if (desc.type === 'archive' && seedStats.isFile()) {
            if (String(desc.archiveFormat).toLowerCase() !== 'zip') {
              throw _makeAssetError(
                'ASSET_UNSUPPORTED',
                `Unsupported seeded archive format for ${assetId}: ${desc.archiveFormat || ''}`,
                {
                  assetId,
                  installPath: installedPath,
                  candidatePath: found
                }
              );
            }

            await _installZipArchiveAtomic(found, installedPath, {
              ...cancellationOptions,
              assetId,
              installPath: installedPath,
              archivePath: found,
              emitProgress
            });
          } else {
            _copyDirAtomic(found, installedPath);
          }

          if (emitInstallBoundary) {
            emitProgress({
              phase: 'install',
              status: 'complete',
              source: 'seed',
              candidatePath: found,
              installPath: installedPath,
              mode: installMode
            });
          }

          const installedEntry = {
            path: installedPath,
            source: 'seed',
            installedAt: Date.now()
          };
          if (desc.type === 'file') {
            const fileSnapshot = _readFileStateSnapshot(installedPath);
            installedEntry.sha256 = _getExpectedInstalledFileSha256(desc) || _normalizeSha256(verifiedPlan?.actualSha256);
            installedEntry.size = fileSnapshot.size;
            installedEntry.mtimeMs = fileSnapshot.mtimeMs;
          }
          _writeInstalledStateEntry(assetId, installedEntry, { userDataPath });

          emitProgress({
            phase: 'complete',
            status: 'complete',
            source: 'seed',
            path: installedPath
          });

          _bestEffortPruneAfterInstall({
            isPackaged,
            userDataPath,
            protectPaths: [installedPath],
            processUsageDetector: options.processUsageDetector,
            gracePeriodMs: options.pruneGracePeriodMs,
            manifest: options.pruneManifest,
            now: options.pruneNow
          });

          return { ok: true, assetId, path: installedPath, source: 'seed' };
        } catch (error) {
          if (_isAbortError(error)) throw error;
          lastSeedError = error;
          lastSeedCandidate = found;
          emitProgress({
            phase: 'seed',
            status: 'skipped',
            source: 'seed',
            reason: 'seed_failed',
            candidatePath: found,
            installPath: installedPath,
            errorCode: error?.code || null,
            message: error?.message || String(error)
          });
          continue;
        }
      }

      // 2) Download (future: once manifest has URLs + sha256)
      const url = resolveAssetUrl(desc, { isPackaged });
      if (!url) {
        // If we found seed candidates but they were invalid, surface the most actionable error.
        if (lastSeedError) throw lastSeedError;
        throw _makeAssetError(
          'ASSET_MISSING',
          `Asset missing and no downloadUrl configured: ${assetId}`,
          {
            assetId,
            installPath: installedPath
          }
        );
      }
      if (offline) {
        const meta = {
          assetId,
          installPath: installedPath,
          url
        };
        if (lastSeedError) {
          meta.lastSeedErrorCode = lastSeedError.code || null;
          meta.lastSeedCandidatePath = lastSeedCandidate || null;
        }
        throw _makeAssetError(
          'ASSET_OFFLINE_BLOCKED',
          `Offline mode: cannot download asset ${assetId}`,
          meta,
          lastSeedError || null
        );
      }
      if (!desc.sha256 || desc.type === 'dir') {
        throw _makeAssetError(
          'ASSET_MISSING_CHECKSUM',
          `Refusing download without sha256 for ${assetId}`,
          {
            assetId,
            installPath: installedPath,
            url
          }
        );
      }

      const dlPath = path.join(downloadsRoot, `${assetId}.${desc.archiveFormat === 'zip' ? 'zip' : 'download'}`);
      await _downloadToFile(url, dlPath, {
        ...cancellationOptions,
        assetId,
        installPath: installedPath,
        emitProgress
      });

      emitProgress({
        phase: 'verify',
        status: 'start',
        source: 'download',
        installPath: installedPath,
        archivePath: dlPath,
        url
      });
      const got = _sha256FileHex(dlPath);
      if (String(got).toLowerCase() !== String(desc.sha256).toLowerCase()) {
        throw _makeAssetError(
          'ASSET_CHECKSUM_MISMATCH',
          `Downloaded checksum mismatch for ${assetId}`,
          {
            assetId,
            installPath: installedPath,
            archivePath: dlPath,
            url
          }
        );
      }
      emitProgress({
        phase: 'verify',
        status: 'complete',
        source: 'download',
        installPath: installedPath,
        archivePath: dlPath,
        url
      });

      if (desc.type === 'file') {
        emitProgress({
          phase: 'install',
          status: 'start',
          source: 'download',
          installPath: installedPath,
          archivePath: dlPath,
          mode: 'copy'
        });
        _copyAtomic(dlPath, installedPath);
        emitProgress({
          phase: 'install',
          status: 'complete',
          source: 'download',
          installPath: installedPath,
          archivePath: dlPath,
          mode: 'copy'
        });
      } else if (desc.type === 'archive' && String(desc.archiveFormat).toLowerCase() === 'zip') {
        await _installZipArchiveAtomic(dlPath, installedPath, {
          ...cancellationOptions,
          assetId,
          installPath: installedPath,
          archivePath: dlPath,
          emitProgress
        });
      } else {
        throw _makeAssetError(
          'ASSET_UNSUPPORTED',
          `Unsupported download/install type for ${assetId}: ${desc.type}/${desc.archiveFormat || ''}`,
          {
            assetId,
            installPath: installedPath,
            archivePath: dlPath,
            url
          }
        );
      }

      const installedEntry = {
        path: installedPath,
        source: 'download',
        installedAt: Date.now(),
        sha256: desc.sha256
      };
      if (desc.type === 'file') {
        const fileSnapshot = _readFileStateSnapshot(installedPath);
        installedEntry.size = fileSnapshot.size;
        installedEntry.mtimeMs = fileSnapshot.mtimeMs;
      }
      _writeInstalledStateEntry(assetId, installedEntry, { userDataPath });

      emitProgress({
        phase: 'complete',
        status: 'complete',
        source: 'download',
        path: installedPath,
        url
      });

      _bestEffortPruneAfterInstall({
        isPackaged,
        userDataPath,
        protectPaths: [installedPath],
        processUsageDetector: options.processUsageDetector,
        gracePeriodMs: options.pruneGracePeriodMs,
        manifest: options.pruneManifest,
        now: options.pruneNow
      });

      return { ok: true, assetId, path: installedPath, source: 'download' };
    } catch (error) {
      emitProgress({
        phase: _isAbortError(error) ? 'cancelled' : (entry.lastProgressEvent?.phase || 'ensure'),
        status: _isAbortError(error) ? 'cancelled' : 'error',
        errorCode: error?.code || null,
        message: error?.message || String(error),
        installPath: installedPath
      });
      throw error;
    }
  })().finally(() => {
    _inFlight.delete(inFlightKey);
  });

  _inFlight.set(inFlightKey, entry);

  const callerPromise = Promise.resolve(entry.promise).finally(unsubscribe);
  return _attachCallerCancellation(callerPromise, options, {
    assetId,
    phase: 'ensure'
  });
}

module.exports = {
  // Pure helper: safe to run under plain Node for quick checks.
  computeAssetPaths,
  // Runtime paths
  getUserDataPath,
  // Manifest
  readPackagedManifest,
  getAssetDescriptor,
  getInstalledAssetPath,
  ensureAsset,
  pruneOldAssetVersions,
  // Installed state (Phase 1: state file only)
  readInstalledState,
  writeInstalledState,
  __private: {
    getAssetsBaseUrl,
    resolveAssetUrl,
    resetForTests: _resetForTests
  }
};
