import express from "express";
import crypto from "crypto";
import { Pool } from "pg";

const app = express();

// Trust proxy so req.ip is correct behind Fly/other reverse proxies
app.set("trust proxy", 1);

// Simple request logging (so fly logs shows activity)
app.use((req, _res, next) => {
  // Avoid logging query strings (device ids, etc.)
  console.log(`[REQ] ${req.method} ${req.path}`);
  next();
});

// NOTE: /health is intentionally honest: it checks DB connectivity and reports guard backend status.
app.get("/health", async (_req, res) => {
  const out = {
    ok: true,
    service: SERVICE_NAME,
    env: PADDLE_ENV,
    db: { configured: Boolean(DATABASE_URL), ok: null },
    guards: {
      backend: GUARDS_BACKEND_ACTIVE,
      ready: GUARDS_BACKEND_READY,
    },
  };

  // DB is required for this service to function (entitlements live in Postgres).
  try {
    await pool.query("SELECT 1");
    out.db.ok = true;
  } catch (_err) {
    out.db.ok = false;
    out.ok = false;
    out.db.error = "db_unreachable";
  }

  if (GUARDS_BACKEND_ACTIVE === "postgres" && !GUARDS_BACKEND_READY) {
    out.ok = false;
    out.guards.error = "guards_not_ready";
  }
  if (GUARDS_BACKEND_ERROR) {
    out.ok = false;
    out.guards.error = "guards_backend_error";
  }

  return res.status(out.ok ? 200 : 503).json(out);
});

const DATABASE_URL = String(process.env.TEST_DATABASE_URL || process.env.DATABASE_URL || "").trim();
const pool = new Pool({ connectionString: DATABASE_URL || undefined });

// Paddle environment: 'sandbox' or 'production' (default).
const PADDLE_ENV = String(process.env.PADDLE_ENV || 'production').trim().toLowerCase();
const SERVICE_NAME = 'entitlement-service';
const toBool = (value) => ['1', 'true', 'yes'].includes(String(value || '').trim().toLowerCase());

const logErr = (reasonCode, err) => {
  const msg = (err && err.message) ? err.message : String(err || "");
  const code = (err && err.code) ? ` code=${err.code}` : "";
  console.error(`[ERR][${SERVICE_NAME}] ${reasonCode}${code} ${msg}`);
};

const RATE_LIMIT_WINDOW_MS = Number(process.env.RATE_LIMIT_WINDOW_MS || 60_000);
const ENTITLEMENT_RATE_LIMIT_MAX = Number(process.env.ENTITLEMENT_RATE_LIMIT_MAX || 60);
const PORTAL_RATE_LIMIT_MAX = Number(process.env.PORTAL_RATE_LIMIT_MAX || 30);

function createRateLimiter({ windowMs, max }) {
  const hits = new Map();
  let lastPrune = 0;

  return {
    check(key, nowMs = Date.now()) {
      const keyStr = String(key || "unknown");

      // opportunistic prune (cheap, good enough)
      if (nowMs - lastPrune > windowMs) {
        for (const [k, v] of hits.entries()) {
          if (!v || v.resetAtMs <= nowMs) hits.delete(k);
        }
        lastPrune = nowMs;
      }

      const existing = hits.get(keyStr);
      if (!existing || existing.resetAtMs <= nowMs) {
        const resetAtMs = nowMs + windowMs;
        hits.set(keyStr, { count: 1, resetAtMs });
        return { ok: true, remaining: Math.max(0, max - 1), resetAtMs };
      }

      if (existing.count >= max) {
        return { ok: false, retryAfterMs: Math.max(0, existing.resetAtMs - nowMs), resetAtMs: existing.resetAtMs };
      }

      existing.count += 1;
      return { ok: true, remaining: Math.max(0, max - existing.count), resetAtMs: existing.resetAtMs };
    },
  };
}

let entitlementLimiter = createRateLimiter({ windowMs: RATE_LIMIT_WINDOW_MS, max: ENTITLEMENT_RATE_LIMIT_MAX });
let portalLimiter = createRateLimiter({ windowMs: RATE_LIMIT_WINDOW_MS, max: PORTAL_RATE_LIMIT_MAX });

// Sandbox-only escape hatch to unblock integration when Paddle's dashboard/API does not expose a webhook signing secret.
// NEVER enable this in production. If enabled outside sandbox, the server will refuse to start.
const PADDLE_WEBHOOK_BYPASS_SIG = toBool(process.env.PADDLE_WEBHOOK_BYPASS_SIG);
const ALLOW_INSECURE_WEBHOOK_BYPASS = toBool(process.env.ALLOW_INSECURE_WEBHOOK_BYPASS);
const WEBHOOK_SIGNATURE_BYPASS_ACTIVE = (
  PADDLE_ENV === 'sandbox' &&
  PADDLE_WEBHOOK_BYPASS_SIG &&
  ALLOW_INSECURE_WEBHOOK_BYPASS
);
const PADDLE_WEBHOOK_MAX_SKEW_SEC = (() => {
  const n = Number(process.env.PADDLE_WEBHOOK_MAX_SKEW_SEC);
  if (!Number.isFinite(n) || n <= 0) return 300;
  return Math.floor(n);
})();
const PADDLE_WEBHOOK_REPLAY_TTL_SEC = (() => {
  const n = Number(process.env.PADDLE_WEBHOOK_REPLAY_TTL_SEC);
  if (!Number.isFinite(n) || n <= 0) return 600;
  return Math.floor(n);
})();

if ((PADDLE_WEBHOOK_BYPASS_SIG || ALLOW_INSECURE_WEBHOOK_BYPASS) && PADDLE_ENV !== 'sandbox') {
  console.error('[FATAL] Webhook bypass flags are set while PADDLE_ENV is not sandbox. Refusing to start.');
  process.exit(1);
}

function logSecurityStartupConfig() {
  console.log(
    `[SECURITY][${SERVICE_NAME}] startup mode: env=${PADDLE_ENV} ` +
    `webhook_bypass_flag=${PADDLE_WEBHOOK_BYPASS_SIG ? 'set' : 'unset'} ` +
    `allow_insecure_bypass_flag=${ALLOW_INSECURE_WEBHOOK_BYPASS ? 'set' : 'unset'} ` +
    `webhook_signature_bypass_active=${WEBHOOK_SIGNATURE_BYPASS_ACTIVE ? 'YES' : 'NO'}`
  );

  if (PADDLE_ENV === 'sandbox' && (PADDLE_WEBHOOK_BYPASS_SIG || ALLOW_INSECURE_WEBHOOK_BYPASS) && !WEBHOOK_SIGNATURE_BYPASS_ACTIVE) {
    console.warn(
      `[SECURITY][${SERVICE_NAME}] bypass flags are partially configured in sandbox; signature bypass remains disabled until both flags are enabled.`
    );
  }

  if (WEBHOOK_SIGNATURE_BYPASS_ACTIVE) {
    console.warn(
      `[SECURITY][${SERVICE_NAME}][BYPASS ACTIVE] HIGH RISK: webhook signature verification bypass is ENABLED in env=${PADDLE_ENV}. ` +
      'Use only for local/sandbox diagnostics and disable immediately after testing.'
    );
  }
}

logSecurityStartupConfig();

// Token claims (must match desktop verifier)
const TOKEN_ISS = String(process.env.LEADAE_TOKEN_ISS || "leadaeassist-entitlement").trim();
const TOKEN_AUD = String(process.env.LEADAE_TOKEN_AUD || "leadaeassist-desktop").trim();

// Short-lived token TTL (seconds). Default: 72h.
const DEFAULT_TOKEN_TTL_SEC = 72 * 60 * 60;
const ENTITLEMENT_TOKEN_TTL_SEC = (() => {
  const n = Number(process.env.ENTITLEMENT_TOKEN_TTL_SEC);
  if (!Number.isFinite(n) || n <= 0) return DEFAULT_TOKEN_TTL_SEC;
  // Clamp: 15 minutes .. 7 days (keep sane)
  return Math.max(15 * 60, Math.min(7 * 24 * 60 * 60, Math.floor(n)));
})();

// Key id for rotation
const SIGNING_KID = String(process.env.ENTITLEMENT_SIGNING_KID || "k1").trim() || "k1";

// Optional verify key set for rotation support (JSON map: { "k1": "-----BEGIN PUBLIC KEY-----..."} )
const VERIFY_PUBLIC_KEYS_PEM_JSON = String(process.env.ENTITLEMENT_VERIFY_PUBLIC_KEYS_PEM_JSON || "").trim();
const VERIFY_PUBLIC_KEY_OBJS_BY_KID = (() => {
  const out = {};
  if (!VERIFY_PUBLIC_KEYS_PEM_JSON) return out;
  try {
    const parsed = JSON.parse(VERIFY_PUBLIC_KEYS_PEM_JSON);
    if (parsed && typeof parsed === "object") {
      for (const [kid, pem] of Object.entries(parsed)) {
        if (typeof kid !== "string" || !kid.trim()) continue;
        if (typeof pem !== "string" || !pem.trim()) continue;
        try {
          out[kid.trim()] = crypto.createPublicKey(pem);
        } catch {
          // ignore invalid entries
        }
      }
    }
  } catch {
    // ignore
  }
  return out;
})();

function parsePaddleSignatureHeader(h) {
  // Paddle may send either:
  //   ts=...,h1=...
  // or
  //   ts=...;h1=...
  // It may also include multiple h1 signatures during secret rotation.
  const parts = String(h || '')
    .split(/[;,]/)
    .map(s => s.trim())
    .filter(Boolean);

  let ts = '';
  const sigs = [];

  for (const part of parts) {
    const i = part.indexOf('=');
    if (i <= 0) continue;
    const k = part.slice(0, i).trim();
    const v = part.slice(i + 1).trim();
    if (!k || !v) continue;
    if (k === 'ts' || k === 't') {
      if (!ts) ts = v;
      continue;
    }
    if (k === 'h1' || k === 'v1' || k === 'sig' || k === 'signature') {
      sigs.push(v);
    }
  }

  return { ts: ts || null, sigs };
}

function decodeSignatureToBuffer(sig) {
  const s = String(sig || "").trim();
  if (!s) return null;

  // hex?
  if (/^[0-9a-fA-F]+$/.test(s) && (s.length % 2 === 0)) {
    try { return Buffer.from(s, "hex"); } catch { /* ignore */ }
  }

  // base64 or base64url
  try {
    let b = s.replace(/-/g, "+").replace(/_/g, "/");
    while (b.length % 4) b += "=";
    return Buffer.from(b, "base64");
  } catch {
    return null;
  }
}

function verifyPaddleSignature({ rawBuf, signatureHeader, secret }) {
  const { ts, sigs } = parsePaddleSignatureHeader(signatureHeader);
  const tsInt = Number.parseInt(String(ts || ''), 10);
  if (!Number.isInteger(tsInt) || tsInt <= 0 || !Array.isArray(sigs) || sigs.length === 0) {
    return { ok: false, ts: null, reason: 'invalid_timestamp' };
  }

  const nowSec = Math.floor(Date.now() / 1000);
  if (Math.abs(nowSec - tsInt) > PADDLE_WEBHOOK_MAX_SKEW_SEC) {
    return { ok: false, ts: tsInt, reason: 'timestamp_out_of_skew' };
  }

  const prefix = Buffer.from(`${tsInt}:`, 'utf8');
  const msg = Buffer.concat([prefix, rawBuf]);
  const expected = crypto.createHmac('sha256', secret).update(msg).digest(); // Buffer

  // Paddle may include multiple signatures (e.g., during secret rotation).
  for (const sig of sigs) {
    const provided = decodeSignatureToBuffer(sig);
    if (!provided) continue;
    if (expected.length !== provided.length) continue;
    try {
      if (crypto.timingSafeEqual(expected, provided)) {
        return { ok: true, ts: tsInt, reason: null };
      }
    } catch {
      // ignore
    }
  }
  return { ok: false, ts: tsInt, reason: 'invalid_signature' };
}

function createReplayStore() {
  const seen = new Map();
  return {
    setIfNew(key, ttlSec, nowMs = Date.now()) {
      if (!key) return false;
      const existing = seen.get(key);
      if (existing && existing > nowMs) return false;
      const expiresAt = nowMs + (Math.max(1, Number(ttlSec) || 1) * 1000);
      seen.set(key, expiresAt);
      // prune expired keys opportunistically
      for (const [k, expires] of seen.entries()) {
        if (expires <= nowMs) seen.delete(k);
      }
      return true;
    },
    clear() {
      seen.clear();
    },
  };
}

let webhookReplayStore = createReplayStore();

// ----------------------------
// Shared guards (Postgres)
// ----------------------------
let GUARDS_BACKEND_ACTIVE = "memory";
let GUARDS_BACKEND_READY = false;
let GUARDS_BACKEND_ERROR = null;

function _guardsForcedPg() {
  const mode = String(process.env.ENTITLEMENT_GUARDS_BACKEND || "auto").trim().toLowerCase();
  return mode === "postgres" || mode === "pg";
}

function resolveGuardsBackend() {
  const mode = String(process.env.ENTITLEMENT_GUARDS_BACKEND || "auto").trim().toLowerCase();
  if (mode === "postgres" || mode === "pg") return "postgres";
  if (mode === "memory" || mode === "inmemory") return "memory";
  // auto:
  const nodeEnv = String(process.env.NODE_ENV || "").trim().toLowerCase();
  if (nodeEnv === "test") return "memory";
  return DATABASE_URL ? "postgres" : "memory";
}

async function ensureGuardsSchema(pgPool) {
  await pgPool.query(`
    CREATE TABLE IF NOT EXISTS webhook_replay_keys (
      key TEXT PRIMARY KEY,
      expires_at TIMESTAMPTZ NOT NULL
    )
  `);
  await pgPool.query(`CREATE INDEX IF NOT EXISTS webhook_replay_keys_expires_at_idx ON webhook_replay_keys (expires_at)`);

  await pgPool.query(`
    CREATE TABLE IF NOT EXISTS rate_limit_buckets (
      scope TEXT NOT NULL,
      bucket_key TEXT NOT NULL,
      window_id BIGINT NOT NULL,
      count INTEGER NOT NULL,
      expires_at TIMESTAMPTZ NOT NULL,
      PRIMARY KEY (scope, bucket_key, window_id)
    )
  `);
  await pgPool.query(`CREATE INDEX IF NOT EXISTS rate_limit_buckets_expires_at_idx ON rate_limit_buckets (expires_at)`);
}

function createPgReplayStore(pgPool) {
  let lastPruneMs = 0;
  const PRUNE_EVERY_MS = 60_000;

  async function prune(nowMs) {
    if (nowMs - lastPruneMs < PRUNE_EVERY_MS) return;
    lastPruneMs = nowMs;
    try {
      await pgPool.query(`DELETE FROM webhook_replay_keys WHERE expires_at <= NOW()`);
    } catch {
      // best-effort
    }
  }

  return {
    backend: "postgres",
    async setIfNew(key, ttlSec, nowMs = Date.now()) {
      const k = String(key || "").trim();
      if (!k) return false;
      const ttl = Math.max(1, Number(ttlSec) || 1);

      prune(nowMs).catch(() => {});

      const sql = `
        INSERT INTO webhook_replay_keys (key, expires_at)
        VALUES ($1, NOW() + ($2 * INTERVAL '1 second'))
        ON CONFLICT (key) DO UPDATE
          SET expires_at = EXCLUDED.expires_at
          WHERE webhook_replay_keys.expires_at <= NOW()
        RETURNING 1 AS ok
      `;
      const r = await pgPool.query(sql, [k, ttl]);
      return r.rowCount > 0;
    },
    async clear() {
      await pgPool.query(`DELETE FROM webhook_replay_keys`);
    },
  };
}

function createPgRateLimiter({ pgPool, scope, windowMs, max }) {
  const w = Math.max(1, Number(windowMs) || 1);
  const m = Math.max(1, Number(max) || 1);
  const s = String(scope || "default").trim() || "default";

  let lastPruneMs = 0;
  const PRUNE_EVERY_MS = Math.max(30_000, w);

  async function prune(nowMs) {
    if (nowMs - lastPruneMs < PRUNE_EVERY_MS) return;
    lastPruneMs = nowMs;
    try {
      await pgPool.query(`DELETE FROM rate_limit_buckets WHERE expires_at <= NOW()`);
    } catch {
      // best-effort
    }
  }

  return {
    backend: "postgres",
    async check(key, nowMs = Date.now()) {
      const keyStr = String(key || "unknown");
      const windowId = Math.floor(nowMs / w);
      const resetAtMs = (windowId + 1) * w;
      const expiresAt = new Date(resetAtMs);

      prune(nowMs).catch(() => {});

      const sql = `
        WITH attempted AS (
          INSERT INTO rate_limit_buckets (scope, bucket_key, window_id, count, expires_at)
          VALUES ($1, $2, $3, 1, $4)
          ON CONFLICT (scope, bucket_key, window_id) DO UPDATE
            SET count = rate_limit_buckets.count + 1
            WHERE rate_limit_buckets.count < $5
          RETURNING count, expires_at
        )
        SELECT
          COALESCE(
            (SELECT count FROM attempted),
            (SELECT count FROM rate_limit_buckets WHERE scope=$1 AND bucket_key=$2 AND window_id=$3)
          ) AS count,
          COALESCE(
            (SELECT expires_at FROM attempted),
            (SELECT expires_at FROM rate_limit_buckets WHERE scope=$1 AND bucket_key=$2 AND window_id=$3)
          ) AS expires_at,
          EXISTS(SELECT 1 FROM attempted) AS allowed
      `;

      const r = await pgPool.query(sql, [s, keyStr, windowId, expiresAt, m]);
      const row = (r.rows && r.rows[0]) ? r.rows[0] : {};
      const allowed = Boolean(row.allowed);
      const count = Number(row.count || 0);
      const expires = (row.expires_at instanceof Date) ? row.expires_at : new Date(row.expires_at || expiresAt);
      const resetMs = Number.isFinite(expires.getTime()) ? expires.getTime() : resetAtMs;

      if (!allowed) {
        return { ok: false, retryAfterMs: Math.max(0, resetMs - nowMs), resetAtMs: resetMs };
      }
      return { ok: true, remaining: Math.max(0, m - count), resetAtMs: resetMs };
    },
  };
}

async function initGuardsBackend() {
  const backend = resolveGuardsBackend();
  const forcedPg = _guardsForcedPg();
  const nodeEnv = String(process.env.NODE_ENV || "").trim().toLowerCase();
  const isProd = (nodeEnv === "production") || (PADDLE_ENV === "production");

  GUARDS_BACKEND_ACTIVE = backend;
  GUARDS_BACKEND_READY = false;
  GUARDS_BACKEND_ERROR = null;

  if (backend !== "postgres") {
    GUARDS_BACKEND_READY = true;
    console.log(`[SECURITY][${SERVICE_NAME}] shared_guards backend=memory active=YES`);
    return;
  }

  if (!DATABASE_URL) {
    const err = new Error("missing_database_url");
    GUARDS_BACKEND_ERROR = err;
    console.error(`[FATAL][${SERVICE_NAME}] shared_guards backend=postgres requires DATABASE_URL but it is missing.`);
    if (isProd || forcedPg) process.exit(1);
    // dev fallback
    GUARDS_BACKEND_ACTIVE = "memory";
    GUARDS_BACKEND_READY = true;
    console.warn(`[WARN][${SERVICE_NAME}] falling back to in-memory guards (dev mode)`);
    return;
  }

  try {
    await pool.query("SELECT 1");
    await ensureGuardsSchema(pool);

    webhookReplayStore = createPgReplayStore(pool);
    entitlementLimiter = createPgRateLimiter({ pgPool: pool, scope: "entitlement", windowMs: RATE_LIMIT_WINDOW_MS, max: ENTITLEMENT_RATE_LIMIT_MAX });
    portalLimiter = createPgRateLimiter({ pgPool: pool, scope: "portal", windowMs: RATE_LIMIT_WINDOW_MS, max: PORTAL_RATE_LIMIT_MAX });

    GUARDS_BACKEND_ACTIVE = "postgres";
    GUARDS_BACKEND_READY = true;
    console.log(`[SECURITY][${SERVICE_NAME}] shared_guards backend=postgres active=YES`);
  } catch (err) {
    GUARDS_BACKEND_ERROR = err;
    console.error(`[ERR][${SERVICE_NAME}] shared_guards postgres init failed: ${err?.message || err}`);
    if (isProd || forcedPg) {
      console.error(`[FATAL][${SERVICE_NAME}] refusing to start without shared guards backend in production/forced mode`);
      process.exit(1);
    }
    // dev fallback
    webhookReplayStore = createReplayStore();
    entitlementLimiter = createRateLimiter({ windowMs: RATE_LIMIT_WINDOW_MS, max: ENTITLEMENT_RATE_LIMIT_MAX });
    portalLimiter = createRateLimiter({ windowMs: RATE_LIMIT_WINDOW_MS, max: PORTAL_RATE_LIMIT_MAX });
    GUARDS_BACKEND_ACTIVE = "memory";
    GUARDS_BACKEND_READY = true;
    console.warn(`[WARN][${SERVICE_NAME}] falling back to in-memory guards (dev mode)`);
  }
}

function deriveWebhookReplayKey({ evt, ts, rawBuf }) {
  const eventId = String(
    evt?.event_id || evt?.eventId || evt?.notification_id || evt?.id || ''
  ).trim();
  if (eventId) return `event:${eventId}`;
  const fingerprint = crypto
    .createHash('sha256')
    .update(`${ts}:`)
    .update(rawBuf)
    .digest('hex');
  return `hash:${fingerprint}`;
}

function b64url(input) {
  return Buffer.from(input)
    .toString("base64")
    .replace(/=/g, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");
}

function b64urlToBuf(s) {
  const raw = String(s || "").trim();
  if (!raw) return Buffer.alloc(0);
  let b = raw.replace(/-/g, "+").replace(/_/g, "/");
  while (b.length % 4) b += "=";
  return Buffer.from(b, "base64");
}

function parseJws(token) {
  const t = String(token || "").trim();
  const parts = t.split(".");
  if (parts.length !== 3) throw new Error("invalid_token_format");
  const [h, p, s] = parts;
  const header = JSON.parse(b64urlToBuf(h).toString("utf8"));
  const payload = JSON.parse(b64urlToBuf(p).toString("utf8"));
  const signature = b64urlToBuf(s);
  return { header, payload, signature, signingInput: `${h}.${p}` };
}

function verifyJwsRS256WithKey(token, publicKeyObj) {
  const { header, payload, signature, signingInput } = parseJws(token);
  const alg = String(header?.alg || "").trim();
  if (alg !== "RS256") throw new Error("unsupported_alg");
  const ok = crypto.verify(
    "RSA-SHA256",
    Buffer.from(signingInput, "utf8"),
    publicKeyObj,
    signature
  );
  if (!ok) throw new Error("bad_signature");
  return payload;
}

function verifyClaimsOrThrow(payloadObj) {
  const iss = String(payloadObj?.iss || "").trim();
  const aud = payloadObj?.aud;
  if (TOKEN_ISS && iss !== TOKEN_ISS) throw new Error("issuer_mismatch");
  if (TOKEN_AUD) {
    const ok =
      (typeof aud === "string" && String(aud).trim() === TOKEN_AUD) ||
      (Array.isArray(aud) && aud.some(v => typeof v === "string" && v.trim() === TOKEN_AUD));
    if (!ok) throw new Error("audience_mismatch");
  }
  const exp = Number(payloadObj?.exp);
  if (!Number.isFinite(exp)) throw new Error("missing_exp");
  if (Math.floor(Date.now() / 1000) >= exp) throw new Error("token_expired");
}

function signJwsRS256(payloadObj, privateKeyPem, opts = {}) {
  const headerObj = { alg: "RS256", typ: "JWT" };
  const kid = typeof opts.kid === "string" ? opts.kid.trim() : "";
  if (kid) headerObj.kid = kid;
  const header = b64url(JSON.stringify(headerObj));
  const payload = b64url(JSON.stringify(payloadObj));
  const signingInput = `${header}.${payload}`;
  const sig = crypto.sign(
    "RSA-SHA256",
    Buffer.from(signingInput, "utf8"),
    privateKeyPem
  );
  return `${signingInput}.${b64url(sig)}`;
}

function verifyEntitlementBearer(token, activePrivateKeyPem) {
  const { header } = parseJws(token);
  const kid = typeof header?.kid === "string" ? header.kid.trim() : "";

  const candidates = [];
  if (kid && VERIFY_PUBLIC_KEY_OBJS_BY_KID[kid]) candidates.push(VERIFY_PUBLIC_KEY_OBJS_BY_KID[kid]);
  for (const k of Object.keys(VERIFY_PUBLIC_KEY_OBJS_BY_KID)) {
    const obj = VERIFY_PUBLIC_KEY_OBJS_BY_KID[k];
    if (obj && !candidates.includes(obj)) candidates.push(obj);
  }
  // Fallback: derive current public key from active private key
  try {
    const derived = crypto.createPublicKey(activePrivateKeyPem);
    if (derived && !candidates.includes(derived)) candidates.push(derived);
  } catch {
    // ignore
  }

  let lastErr = null;
  for (const keyObj of candidates) {
    try {
      return verifyJwsRS256WithKey(token, keyObj);
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("invalid_token");
}

function extractDeviceId(evt) {
  return (
    evt?.data?.custom_data?.device_id ||
    evt?.data?.customData?.device_id ||
    null
  );
}

function extractExpiresAtIso(evt) {
  // Prefer trial end ONLY when it's in the future; otherwise prefer paid period end.
  const trialIso = evt?.data?.trial_dates?.ends_at || null;
  const trialMs = trialIso ? Date.parse(trialIso) : NaN;
  if (Number.isFinite(trialMs) && trialMs > Date.now()) return trialIso;

  return (
    evt?.data?.next_billed_at ||
    evt?.data?.billing_period?.ends_at ||
    evt?.data?.current_billing_period?.ends_at ||
    trialIso ||
    null
  );
}


function inferPlan(evt) {
  // "plan" is the product tier (pro/enterprise). Trial is tracked via status separately.
  const name = String(evt?.data?.items?.[0]?.price?.name || '').toLowerCase();
  if (name.includes('enterprise')) return 'enterprise';
  if (name.includes('pro')) return 'pro';
  // If the price name says "trial", treat as a trial of Pro by default.
  if (name.includes('trial')) return 'pro';
  // Default to pro so paid purchases don't accidentally become "unknown".
  return 'pro';
}

function isActivationEvent(eventType) {
  return (
    eventType === 'subscription.created' ||
    eventType === 'subscription.updated' ||
    eventType === 'subscription.activated' ||
    eventType === 'transaction.completed' ||
    eventType === 'transaction.paid'
  );
}

function isDeactivationEvent(eventType) {
  return (
    eventType === "subscription.canceled" ||
    eventType === "subscription.paused"
  );
}

function extractPaddleStatus(evt) {
  const s = String(evt?.data?.status || '').toLowerCase().trim();
  return s;
}

function inferStatus(eventType, expiresAt, evt) {
  const now = Date.now();
  const future = !!(expiresAt && expiresAt.getTime && expiresAt.getTime() > now);
  const payloadStatus = extractPaddleStatus(evt);

  // If Paddle provides a trial window, treat it as trial even when payload status is "active".
  const trialIso = evt?.data?.trial_dates?.ends_at || null;
  const trialMs = trialIso ? Date.parse(trialIso) : NaN;
  if (Number.isFinite(trialMs) && trialMs > now) {
    return 'trial';
  }

  // Highest priority: explicit deactivation states from Paddle payload
  if (payloadStatus === 'canceled') return future ? 'canceled_pending' : 'inactive';
  if (payloadStatus === 'paused') return future ? 'paused_pending' : 'paused';

  // Transaction event-type fallbacks (some transaction events don't carry a useful status)
  if (eventType === 'transaction.canceled') return future ? 'canceled_pending' : 'inactive';
  if (eventType === 'transaction.updated' && payloadStatus === '') return future ? 'canceled_pending' : 'inactive';

  // Next: trial/active states from payload
  if (payloadStatus.includes('trial')) return 'trial';
  if (payloadStatus === 'active') return 'active';

  // Fallback to event type when payload status is missing/unknown
  if (eventType === 'subscription.canceled') return future ? 'canceled_pending' : 'inactive';
  if (eventType === 'subscription.paused') return future ? 'paused_pending' : 'paused';

  // Treat "updated" as activation ONLY if it isn't telling us it's canceled/paused (handled above)
  if (isActivationEvent(eventType)) return 'active';

  if (isDeactivationEvent(eventType)) return future ? 'canceled_pending' : 'inactive';
  return 'unknown';
}


// Paddle webhooks -> write entitlement state
app.post(
  "/paddle/webhook",
  express.raw({ type: "*/*", limit: "2mb" }),
  async (req, res) => {
    const bypass = WEBHOOK_SIGNATURE_BYPASS_ACTIVE;
    const secret = String(process.env.PADDLE_WEBHOOK_SECRET || '').trim();
    if (!bypass && !secret) return res.status(500).send('missing_webhook_secret');

    const rawBuf = Buffer.isBuffer(req.body)
      ? req.body
      : Buffer.from(String(req.body || ""), "utf8");
    const rawBody = rawBuf.toString("utf8");
    const sigHeader =
      req.get("paddle-signature") || req.get("Paddle-Signature") || "";

    const verification = bypass
      ? { ok: true, ts: null, reason: null }
      : verifyPaddleSignature({ rawBuf, signatureHeader: sigHeader, secret });

    if (!verification.ok) {
      const bodyHash = crypto
        .createHash("sha256")
        .update(rawBuf)
        .digest("hex")
        .slice(0, 12);
      const parsed = parsePaddleSignatureHeader(sigHeader);
      console.log(
        `[WEBHOOK] signature_rejected reason=${verification.reason || 'invalid_signature'} ts=${parsed.ts || "—"} body_sha256=${bodyHash} sig_header=${String(sigHeader).slice(0, 120)}`
      );      return res.status(401).send("invalid_signature");
    }

    let evt;
    try {
      evt = JSON.parse(rawBody);
    } catch {
      console.log("[WEBHOOK] invalid_json");
      return res.status(400).send("invalid_json");
    }

    const replayKey = deriveWebhookReplayKey({ evt, ts: verification.ts, rawBuf });
    let isNew = false;
    try {
      isNew = await webhookReplayStore.setIfNew(replayKey, PADDLE_WEBHOOK_REPLAY_TTL_SEC);
    } catch (err) {
      logErr("E_WEBHOOK_REPLAY_BACKEND", err);
      return res.status(503).send("replay_store_unavailable");
    }

    if (!isNew) {
      console.log(`[WEBHOOK] replay_detected key=${replayKey.slice(0, 32)}...`);
      return res.status(409).send('duplicate_event');
    }

    const eventType = String(evt?.event_type || "");
    const deviceId = extractDeviceId(evt);
    const deviceTag = deviceId
      ? crypto.createHash("sha256").update(deviceId).digest("hex").slice(0, 10)
      : "—";

    console.log(
      `[WEBHOOK] ok event_type=${eventType} device=${deviceTag}${bypass ? ' (sig_bypass)' : ''}`
    );

    if (!eventType) return res.status(400).send("missing event_type");
    if (!deviceId) {
      // Some events won't include it (address.created etc). Ignore safely.
      return res.sendStatus(200);
    }

    const expiresAtIso = extractExpiresAtIso(evt);
    const expiresAt =
      expiresAtIso && Number.isFinite(Date.parse(expiresAtIso))
        ? new Date(Date.parse(expiresAtIso))
        : null;

    const status = inferStatus(eventType, expiresAt, evt);
    // If Paddle doesn't include an explicit trial end in the webhook payload,
    // fall back to a server-authoritative default trial window (7 days).
    let effectiveExpiresAt = expiresAt;
    if (status === 'trial' && !effectiveExpiresAt) {
      const days = Number(process.env.LEADAE_TRIAL_DAYS || 7);
      const ms = (Number.isFinite(days) && days > 0) ? (days * 24 * 60 * 60 * 1000) : (7 * 24 * 60 * 60 * 1000);
      effectiveExpiresAt = new Date(Date.now() + ms);
    }
    const plan = inferPlan(evt);
    const subscriptionId = evt?.data?.subscription_id || evt?.data?.id || evt?.data?.subscriptionId || null;

    // Upsert the row
    try {
      await pool.query(
        `INSERT INTO entitlements (device_id, plan, status, subscription_id, expires_at, updated_at)
         VALUES ($1, $2, $3, $4, $5, now())
         ON CONFLICT (device_id)
         DO UPDATE SET plan=EXCLUDED.plan,
                       status=EXCLUDED.status,
                       subscription_id=EXCLUDED.subscription_id,
                       expires_at=EXCLUDED.expires_at,
                       updated_at=now()`,
        [deviceId, plan, status, subscriptionId, effectiveExpiresAt]
      );
    } catch (e) {
      console.log('[WEBHOOK] db_upsert_failed', e?.message || e);
      return res.status(500).send('db_upsert_failed');
    }

    console.log(
      `[WEBHOOK] upserted device=${deviceTag} status=${status} plan=${plan}`
    );

    res.sendStatus(200);
  }
);

// App -> entitlement token (device-bound bootstrap)
// Use POST JSON so device_id never appears in URLs/logs.
app.post("/entitlement", express.json({ type: "*/*", limit: "64kb" }), async (req, res) => {
  try {
    const deviceId = String(req.body?.device_id || req.body?.deviceId || "").trim();
    const rlKey = `${req.ip || "unknown"}:${deviceId || "_missing"}`;
    let rl;
    try {
      rl = await entitlementLimiter.check(rlKey);
    } catch (err) {
      logErr("E_ENTITLEMENT_RATELIMIT_BACKEND", err);
      return res.status(503).send("rate_limiter_unavailable");
    }
    if (!rl.ok) {
      res.set("Retry-After", String(Math.ceil((rl.retryAfterMs || 0) / 1000)));
      return res.status(429).send("rate_limited");
    }
    if (!deviceId) return res.status(400).send("missing_device_id");

    const { rows } = await pool.query(
      `SELECT device_id, plan, status, subscription_id, expires_at
       FROM entitlements
      WHERE device_id = $1
      LIMIT 1`,
      [deviceId]
    );
    if (!rows.length) return res.status(404).send("not_found");

    const rec = rows[0];
    const nowMs = Date.now();
    const status = String(rec.status || "").toLowerCase();
    const expiresAtMs = rec.expires_at ? new Date(rec.expires_at).getTime() : null;
    const inWindow = typeof expiresAtMs === 'number' && Number.isFinite(expiresAtMs) && expiresAtMs > nowMs;

    // Entitlement rules:
    // - Trial: require a future expires_at (trial end).
    // - Active paid: allow if explicitly active, or if we have a subscription_id and we're still inside the paid window.
    const entitled =
      (status === 'trial' && inWindow) ||
      (status === 'active') ||
      (inWindow && !!rec.subscription_id);

    if (!entitled) return res.status(403).send('not_entitled');
    if (expiresAtMs && expiresAtMs <= nowMs) return res.status(403).send('period_ended');

    const nowSec = Math.floor(nowMs / 1000);
    const periodEndSec = expiresAtMs ? Math.floor(expiresAtMs / 1000) : null;

    // Short-lived tokens: exp = now + TTL (capped to period end)
    let expSec = nowSec + ENTITLEMENT_TOKEN_TTL_SEC;
    if (periodEndSec) expSec = Math.min(expSec, periodEndSec);
    if (expSec <= nowSec) expSec = nowSec + 60; // safety

    const priv = process.env.ENTITLEMENT_SIGNING_PRIVATE_KEY_PEM;
    if (!priv) return res.status(500).send("missing_signing_key");

    // Normalize tier: trial is a status (not a tier) in the desktop app UX.
    // Keep tier as pro/enterprise and expose trialing via the status claim.
    const recPlanRaw = String(rec.plan || 'pro').trim().toLowerCase();
    const tier = (recPlanRaw === 'trial') ? 'pro' : (recPlanRaw || 'pro');

    const token = signJwsRS256(
      {
        iss: TOKEN_ISS,
        aud: TOKEN_AUD,
        iat: nowSec,
        tier,
        status: status || null,
        deviceId: rec.device_id,
        subscriptionId: rec.subscription_id || null,
        periodEnd: periodEndSec || null,
        exp: expSec,
      },
      priv,
      { kid: SIGNING_KID }
    );

    res.type("text/plain").send(token);
  } catch (err) {
    logErr("E_ENTITLEMENT_HANDLER", err);
    return res.status(500).json({ error: "internal_error", code: "E_ENTITLEMENT_HANDLER" });
  }
});

// App -> Paddle Customer Portal URL (manage/cancel/pause/update payment)
app.post("/portal", express.json({ type: "*/*", limit: "64kb" }), async (req, res) => {
  try {
    const short = (v, n = 8) => {
      const s = String(v || "").trim();
      if (!s) return "—";
      return s.length <= n ? s : `${s.slice(0, n)}…`;
    };
    const env = PADDLE_ENV;

    let rl;
    try {
      rl = await portalLimiter.check(req.ip || "unknown");
    } catch (err) {
      logErr("E_PORTAL_RATELIMIT_BACKEND", err);
      return res.status(503).json({ error: "rate_limiter_unavailable", code: "E_PORTAL_RATELIMIT_BACKEND" });
    }
    if (!rl.ok) {
      res.set("Retry-After", String(Math.ceil((rl.retryAfterMs || 0) / 1000)));
      return res.status(429).json({ error: "rate_limited", code: "E_PORTAL_RATELIMIT" });
    }

    // Require token auth. Prefer Authorization header, but accept body token too
    // (some proxies strip Authorization).
    const auth = String(req.get("authorization") || "").trim();
    let token = "";

    // 1) Authorization: Bearer <token>
    if (/^bearer\\s+/i.test(auth)) {
      token = auth.replace(/^bearer\\s+/i, "").trim();
    }

    // 2) Alternate headers (optional)
    if (!token) {
      token = String(req.get("x-leadae-entitlement-token") || req.get("x-entitlement-token") || "").trim();
    }

    // 3) JSON body token (recommended fallback)
    if (!token) {
      token = String(req.body?.token || req.body?.entitlement_token || "").trim();
    }

    if (!token) return res.status(401).json({ error: "missing_bearer_token" });

    const priv = process.env.ENTITLEMENT_SIGNING_PRIVATE_KEY_PEM;
    if (!priv) return res.status(500).json({ error: "missing_signing_key" });

    let payload;
    try {
      payload = verifyEntitlementBearer(token, priv);
      verifyClaimsOrThrow(payload);
    } catch (err) {
      logErr("E_PORTAL_INVALID_TOKEN", err);
      return res.status(401).json({ error: "invalid_token" });
    }

    const subscriptionId = String(payload?.subscriptionId || payload?.subscription_id || "").trim();
    if (!subscriptionId) return res.status(404).json({ error: "missing_subscription_id" });

    try {
      console.log(`[PORTAL] auth ok sub=${short(subscriptionId)} ip=${short(req.ip, 16)} env=${env}`);
    } catch {}

    const apiKey = String(process.env.PADDLE_API_KEY || "").trim();
    if (!apiKey) return res.status(500).json({ error: "missing_paddle_api_key" });

    if (typeof fetch !== "function") {
      return res.status(500).json({ error: "fetch_unavailable" });
    }

    const base = env === "sandbox" ? "https://sandbox-api.paddle.com" : "https://api.paddle.com";

    const headers = {
      Authorization: `Bearer ${apiKey}`,
      "Paddle-Version": "1",
      "Content-Type": "application/json",
    };

    // 1) subscription -> customer_id
    let subResp;
    try {
      subResp = await fetch(`${base}/subscriptions/${encodeURIComponent(subscriptionId)}`, {
        method: "GET",
        headers,
      });
    } catch (err) {
      logErr("E_PADDLE_SUB_FETCH", err);
      return res.status(502).json({ error: "paddle_subscription_fetch_failed", code: "E_PADDLE_SUB_FETCH" });
    }
    if (!subResp.ok) {
      try {
        console.warn(`[PORTAL] sub fetch failed status=${subResp.status} sub=${short(subscriptionId)} env=${env}`);
      } catch {}
      return res.status(502).json({ error: "paddle_subscription_fetch_failed", status: subResp.status });
    }
    const subJson = await subResp.json().catch(() => ({}));
    const customerId = String(subJson?.data?.customer_id || subJson?.data?.customerId || "").trim();
    if (!customerId) return res.status(502).json({ error: "missing_customer_id" });
    try {
      console.log(`[PORTAL] sub ok sub=${short(subscriptionId)} cust=${short(customerId)} env=${env}`);
    } catch {}

    // 2) customer portal session -> URL
    let sessResp;
    try {
      sessResp = await fetch(`${base}/customers/${encodeURIComponent(customerId)}/portal-sessions`, {
        method: "POST",
        headers,
        body: JSON.stringify({ subscription_ids: [subscriptionId] }),
      });
    } catch (err) {
      logErr("E_PADDLE_PORTAL_FETCH", err);
      return res.status(502).json({ error: "paddle_portal_session_failed", code: "E_PADDLE_PORTAL_FETCH" });
    }
    if (!sessResp.ok) {
      try {
        console.warn(
          `[PORTAL] session failed status=${sessResp.status} sub=${short(subscriptionId)} cust=${short(customerId)} env=${env}`
        );
      } catch {}
      return res.status(502).json({ error: "paddle_portal_session_failed", status: sessResp.status });
    }
    const sessJson = await sessResp.json().catch(() => ({}));

    // Paddle returns a few possible URL shapes; pick the first string we find.
    const candidates = [
      sessJson?.data?.urls?.general?.overview,
      sessJson?.data?.urls?.general,
      sessJson?.data?.url,
      sessJson?.url,
    ].filter(v => typeof v === "string" && v.trim());
    const url = candidates.length ? String(candidates[0]).trim() : "";
    if (!url) return res.status(502).json({ error: "missing_portal_url" });

    try {
      console.log(`[PORTAL] ok sub=${short(subscriptionId)} cust=${short(customerId)} env=${env}`);
    } catch {}
    return res.json({ url });
  } catch (err) {
    logErr("E_PORTAL_HANDLER", err);
    return res.status(500).json({ error: "internal_error", code: "E_PORTAL_HANDLER" });
  }
});

const port = Number(process.env.PORT || 3000);

// Bind host selection:
// - Default: bind to 127.0.0.1 (local-only) for safety.
// - On Fly: default to 0.0.0.0 so the service is reachable.
// - Override: set ENTITLEMENT_BIND_HOST to explicitly expose/bind elsewhere.
const isFly = Boolean(process.env.FLY_APP_NAME || process.env.FLY_REGION);

function resolveBindHost() {
  const explicit = String(process.env.ENTITLEMENT_BIND_HOST || "").trim();
  if (explicit) return explicit;
  if (isFly) return "0.0.0.0";
  return "127.0.0.1";
}

const bindHost = resolveBindHost();
async function bootstrap() {
  await initGuardsBackend();

  app.listen(port, bindHost, () => {
    const note = bindHost === "127.0.0.1"
      ? " (local-only)"
      : (String(process.env.ENTITLEMENT_BIND_HOST || "").trim()
        ? " (explicit ENTITLEMENT_BIND_HOST)"
        : " (platform default)");

    console.log(`[${SERVICE_NAME}] listening on http://${bindHost}:${port}${note}`);

    if (bindHost !== "127.0.0.1" && !isFly) {
      console.warn(`[${SERVICE_NAME}] WARNING: bound to a non-local interface. Expose only behind a reverse proxy/firewall.`);
    }
  });
}

if (process.env.NODE_ENV !== "test") {
  bootstrap().catch((err) => {
    console.error(`[FATAL][${SERVICE_NAME}] bootstrap_failed ${err?.message || err}`);
    process.exit(1);
  });
}

export {
  verifyPaddleSignature,
  createReplayStore,
  deriveWebhookReplayKey,
  ensureGuardsSchema,
  createPgReplayStore,
  createPgRateLimiter,
  resolveGuardsBackend,
};
