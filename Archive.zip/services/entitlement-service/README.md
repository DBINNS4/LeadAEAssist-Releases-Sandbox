# Entitlement Service Operational Notes

## Webhook Signature Bypass Safety

The entitlement service supports a temporary webhook signature verification bypass **only** for local/sandbox diagnostics.

### Dual-gate requirement

Bypass is active only when **both** of the following are set:

- `PADDLE_ENV=sandbox`
- `PADDLE_WEBHOOK_BYPASS_SIG=1`
- `ALLOW_INSECURE_WEBHOOK_BYPASS=1`

If bypass-related flags are set while `PADDLE_ENV` is not `sandbox`, the service exits during startup.

### Production policy

- Bypass is forbidden in production.
- Never set `PADDLE_WEBHOOK_BYPASS_SIG` or `ALLOW_INSECURE_WEBHOOK_BYPASS` in production deployments.
- Any environment with `PADDLE_ENV=production` (or unset/defaulting to production) must run with normal Paddle signature verification enabled.

### Startup audit logs

On startup, the service logs a sanitized security-mode summary including:

- `PADDLE_ENV`
- whether each bypass flag is set/unset
- whether bypass is currently active

No secret values are printed.
