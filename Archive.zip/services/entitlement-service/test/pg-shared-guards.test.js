import test from "node:test";
import assert from "node:assert/strict";
import crypto from "crypto";
import { Pool } from "pg";

import { ensureGuardsSchema, createPgReplayStore, createPgRateLimiter } from "../server.js";

const TEST_DATABASE_URL = String(process.env.TEST_DATABASE_URL || "").trim();

if (!TEST_DATABASE_URL) {
  test("pg shared guards integration (skipped)", { skip: "TEST_DATABASE_URL not set" }, () => {});
} else {
  test("replay keys reject duplicates across two logical instances", async () => {
    const poolA = new Pool({ connectionString: TEST_DATABASE_URL });
    const poolB = new Pool({ connectionString: TEST_DATABASE_URL });

    try {
      await ensureGuardsSchema(poolA);
      await poolA.query("DELETE FROM webhook_replay_keys");

      const storeA = createPgReplayStore(poolA);
      const storeB = createPgReplayStore(poolB);

      const key = `evt_${crypto.randomBytes(8).toString("hex")}`;
      assert.equal(await storeA.setIfNew(key, 60), true);
      assert.equal(await storeB.setIfNew(key, 60), false);
    } finally {
      await poolA.end();
      await poolB.end();
    }
  });

  test("rate limits enforce consistently across two logical instances", async () => {
    const poolA = new Pool({ connectionString: TEST_DATABASE_URL });
    const poolB = new Pool({ connectionString: TEST_DATABASE_URL });

    try {
      await ensureGuardsSchema(poolA);
      await poolA.query("DELETE FROM rate_limit_buckets");

      const windowMs = 10_000;
      const max = 3;
      const limiterA = createPgRateLimiter({ pgPool: poolA, scope: "entitlement", windowMs, max });
      const limiterB = createPgRateLimiter({ pgPool: poolB, scope: "entitlement", windowMs, max });

      const key = `ip_device_${crypto.randomBytes(8).toString("hex")}`;
      const now = Date.now();

      assert.equal((await limiterA.check(key, now)).ok, true);
      assert.equal((await limiterB.check(key, now)).ok, true);
      assert.equal((await limiterA.check(key, now)).ok, true);

      const blocked = await limiterB.check(key, now);
      assert.equal(blocked.ok, false);
      assert.ok(typeof blocked.retryAfterMs === "number");
      assert.ok(blocked.retryAfterMs >= 0);
    } finally {
      await poolA.end();
      await poolB.end();
    }
  });
}
