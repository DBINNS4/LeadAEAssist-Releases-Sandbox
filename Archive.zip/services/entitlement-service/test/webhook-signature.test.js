import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'crypto';

import {
  verifyPaddleSignature,
  createReplayStore,
  deriveWebhookReplayKey,
} from '../server.js';

function makeSignedHeader({ rawBuf, secret, ts = Math.floor(Date.now() / 1000) }) {
  const payload = Buffer.concat([Buffer.from(`${ts}:`, 'utf8'), rawBuf]);
  const sigHex = crypto.createHmac('sha256', secret).update(payload).digest('hex');
  return `ts=${ts};h1=${sigHex}`;
}

test('verifyPaddleSignature accepts a valid fresh signature', () => {
  const secret = 'test-secret';
  const rawBuf = Buffer.from(JSON.stringify({ event_type: 'subscription.updated' }), 'utf8');
  const signatureHeader = makeSignedHeader({ rawBuf, secret });

  const result = verifyPaddleSignature({ rawBuf, signatureHeader, secret });

  assert.equal(result.ok, true);
  assert.equal(result.reason, null);
  assert.ok(Number.isInteger(result.ts));
});

test('verifyPaddleSignature rejects stale timestamps', () => {
  const secret = 'test-secret';
  const rawBuf = Buffer.from(JSON.stringify({ event_type: 'subscription.updated' }), 'utf8');
  const oldTs = Math.floor(Date.now() / 1000) - 1200;
  const signatureHeader = makeSignedHeader({ rawBuf, secret, ts: oldTs });

  const result = verifyPaddleSignature({ rawBuf, signatureHeader, secret });

  assert.equal(result.ok, false);
  assert.equal(result.reason, 'timestamp_out_of_skew');
  assert.equal(result.ts, oldTs);
});

test('replay store rejects duplicate webhook events in the retention window', () => {
  const replayStore = createReplayStore();
  const ts = Math.floor(Date.now() / 1000);
  const rawBuf = Buffer.from(JSON.stringify({ event_id: 'evt_123', event_type: 'subscription.updated' }), 'utf8');
  const evt = JSON.parse(rawBuf.toString('utf8'));
  const replayKey = deriveWebhookReplayKey({ evt, ts, rawBuf });

  assert.equal(replayStore.setIfNew(replayKey, 60), true);
  assert.equal(replayStore.setIfNew(replayKey, 60), false);
});
