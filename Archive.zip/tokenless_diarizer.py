# tokenless_diarizer.py
# Token-free diarization using WebRTC VAD + SpeechBrain ECAPA embeddings.
# Returns [{"start": float, "end": float, "speaker": "Speaker N"}, ...]
# Drop-in replacement for your diarize(...) function.

import os
import sys
import json
import numpy as np
import librosa
import webrtcvad

from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score

import torch
from speechbrain.pretrained import EncoderClassifier


# -------------------------
# Audio & VAD utilities
# -------------------------

def _float_to_int16(x: np.ndarray) -> np.ndarray:
    """Convert float32 -1..1 to int16 PCM."""
    x = np.clip(x, -1.0, 1.0)
    return (x * 32767.0).astype(np.int16)


def _frame_generator(samples_i16: np.ndarray, sample_rate: int, frame_ms: int):
    """Yield successive PCM frames (bytes) and their start time in seconds."""
    frame_len = int(sample_rate * frame_ms / 1000)
    offset = 0
    t = 0.0
    step = frame_len
    while offset + frame_len <= len(samples_i16):
        frame = samples_i16[offset:offset + frame_len]
        yield frame.tobytes(), t
        offset += step
        t += frame_ms / 1000.0


def _vad_segments(samples_f32: np.ndarray,
                  sample_rate: int = 16000,
                  frame_ms: int = 30,
                  aggressiveness: int = 3,
                  min_speech_ms: int = 240,
                  pad_ms: int = 120):
    """
    WebRTC VAD-based segmentation.
    Returns list of (start_sec, end_sec).
    """
    vad = webrtcvad.Vad(aggressiveness)
    pcm16 = _float_to_int16(samples_f32)
    frames = list(_frame_generator(pcm16, sample_rate, frame_ms))

    speech_flags = []
    for fb, _t in frames:
        speech_flags.append(vad.is_speech(fb, sample_rate))

    if not any(speech_flags):
        # No speech detected: treat whole file as one segment
        return [(0.0, len(samples_f32) / sample_rate)]

    # Merge consecutive speech frames into segments
    segs = []
    start_t = None
    for flag, (_, t) in zip(speech_flags, frames):
        if flag and start_t is None:
            start_t = t
        elif not flag and start_t is not None:
            end_t = t
            segs.append((start_t, end_t))
            start_t = None
    if start_t is not None:
        last_t = frames[-1][1] + frame_ms / 1000.0
        segs.append((start_t, last_t))

    # Merge short gaps and expand edges by pad_ms
    def _merge_and_pad(segs, pad_s, min_len_s):
        if not segs:
            return []
        merged = []
        cur_start, cur_end = segs[0]
        for s, e in segs[1:]:
            if s - cur_end <= pad_s:
                cur_end = e
            else:
                merged.append((max(0.0, cur_start - pad_s), cur_end + pad_s))
                cur_start, cur_end = s, e
        merged.append((max(0.0, cur_start - pad_s), cur_end + pad_s))
        # drop very short segments
        merged = [(s, e) for (s, e) in merged if (e - s) >= min_len_s]
        return merged

    pad_s = pad_ms / 1000.0
    min_len_s = min_speech_ms / 1000.0
    segs = _merge_and_pad(segs, pad_s, min_len_s)
    return segs


# -------------------------
# Embeddings (ECAPA) utils
# -------------------------

class _ECAPA:
    def __init__(self, device="cpu", source=None):
        """
        source: None -> "speechbrain/spkrec-ecapa-voxceleb"
                or local dir (for offline packaging)
        """
        self.device = torch.device(device if isinstance(device, str) else device)
        source = (source or os.getenv("SB_ECAPA_SOURCE")
                  or "speechbrain/spkrec-ecapa-voxceleb")
        self.clf = EncoderClassifier.from_hparams(
            source=source,
            run_opts={"device": str(self.device)}
        )

    @torch.no_grad()
    def embed(self, wav_f32: np.ndarray, sr: int):
        """
        Returns a (D,) embedding for the chunk.
        Input is float32 -1..1 at sample rate sr.
        """
        wav = torch.from_numpy(wav_f32).float().unsqueeze(0).to(self.device)
        emb = self.clf.encode_batch(wav)  # [B, D]
        emb = emb.squeeze(0).detach().cpu().numpy()
        return emb


def _sliding_windows(segs, wav, sr, win_s=1.5, hop_s=0.75):
    """
    Yield (start, end, slice_array) over VAD segments using sliding windows.
    """
    win = int(win_s * sr)
    hop = int(hop_s * sr)
    for (s, e) in segs:
        s_i = max(0, int(s * sr))
        e_i = min(len(wav), int(e * sr))
        if e_i - s_i <= 0:
            continue
        cur = s_i
        while cur + win <= e_i:
            yield cur / sr, (cur + win) / sr, wav[cur:cur + win]
            cur += hop
        # Tail window if there's a substantial leftover
        if cur < e_i and (e_i - cur) >= int(0.5 * win):
            yield cur / sr, e_i / sr, wav[cur:e_i]


# -------------------------
# Main diarization
# -------------------------

def diarize(file_path,
            num_speakers=None,
            device=None,
            vad_aggr=3,
            vad_frame_ms=30,
            win_s=1.5,
            hop_s=0.75,
            min_k=2,
            max_k=8,
            ecapa_source=None):
    """
    Token-free diarization.
    Args:
      file_path: path to audio file
      num_speakers: int or None (auto-K if None)
      device: "cuda" | "cpu" | None (auto)
      vad_aggr: 0..3 (WebRTC VAD aggressiveness)
      vad_frame_ms: 10, 20, or 30 (WebRTC VAD)
      win_s/hop_s: windowing for embeddings inside VAD segments
      min_k/max_k: bounds for auto cluster count
      ecapa_source: local dir or hub id for SpeechBrain model
    """
    # 1) Load mono @16k for VAD and embeddings
    wav_16k, _ = librosa.load(file_path, sr=16000, mono=True)
    duration = len(wav_16k) / 16000.0

    # 2) VAD -> speech segments
    speech_segs = _vad_segments(
        wav_16k,
        sample_rate=16000,
        frame_ms=vad_frame_ms,
        aggressiveness=vad_aggr,
    )
    if not speech_segs:
        return [{"start": 0.0, "end": duration, "speaker": "Speaker 1"}]

    wav, sr = wav_16k, 16000

    # 3) Sliding windows through VAD regions -> embeddings + timestamps
    windows = list(_sliding_windows(speech_segs, wav, sr, win_s=win_s, hop_s=hop_s))
    if not windows:
        # fallback: treat each VAD region as one window
        windows = [(s, e, wav[max(0, int(s*sr)):min(len(wav), int(e*sr))])
                   for (s, e) in speech_segs]

    # 4) Compute ECAPA embeddings
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    ecapa = _ECAPA(device=device, source=ecapa_source)

    embs = []
    stamps = []
    for s, e, chunk in windows:
        if len(chunk) < int(0.3 * sr):
            continue
        emb = ecapa.embed(chunk.astype(np.float32), sr=sr)
        norm = np.linalg.norm(emb) + 1e-10
        embs.append(emb / norm)
        stamps.append((s, e))

    if len(embs) == 0:
        # no usable windows -> single speaker per speech seg
        return [
            {"start": float(s), "end": float(e), "speaker": "Speaker 1"}
            for (s, e) in speech_segs
        ]

    X = np.vstack(embs)

    # 5) Decide K (speakers)
    if num_speakers is None:
        # Auto-K: try silhouette for k>=2, but allow falling back to 1 speaker
        # when clustering is weak (common for monologues or low-SNR audio).
        min_k_i = max(1, int(min_k))
        max_k_i = max(min_k_i, int(max_k))
        k_max = min(max_k_i, len(X))

        if k_max < 2:
            num_speakers = 1
        else:
            k_min = max(2, min_k_i)  # silhouette requires at least 2 clusters
            best_k, best_score = None, -1.0

            if k_min <= k_max:
                for k in range(k_min, k_max + 1):
                    try:
                        lab = AgglomerativeClustering(
                            n_clusters=k,
                            metric="cosine",
                            linkage="average",
                        ).fit_predict(X)
                        sc = silhouette_score(X, lab, metric="cosine")
                        if sc > best_score:
                            best_score, best_k = sc, k
                    except Exception:
                        continue

            # Heuristic threshold: if we can't find a confident multi-speaker split,
            # prefer a single speaker over arbitrary over-segmentation.
            silhouette_threshold = 0.12
            allow_single = (min_k_i <= 1)

            if allow_single and (best_k is None or best_score < silhouette_threshold):
                num_speakers = 1
            else:
                # Fall back to the smallest allowed multi-speaker count, clamped to feasibility.
                num_speakers = best_k if best_k is not None else min(k_min, k_max)
    else:
        # Respect explicit speaker count, but clamp to feasible bounds.
        try:
            num_speakers = int(num_speakers)
        except Exception:
            num_speakers = 1
        if num_speakers < 1:
            num_speakers = 1
        if num_speakers > len(X):
            num_speakers = len(X)

    labels = AgglomerativeClustering(
        n_clusters=int(num_speakers),
        metric="cosine",
        linkage="average",
    ).fit_predict(X)

    # 6) Convert window-level labels -> merged diarization segments
    order = np.argsort([s for (s, e) in stamps])
    labels = labels[order]
    stamps = [stamps[i] for i in order]

    # Remap cluster labels so "Speaker 1" is the first speaker encountered in time.
    first_start = {}
    for lab, (s, _e) in zip(labels, stamps):
        lab_i = int(lab)
        if lab_i not in first_start:
            first_start[lab_i] = s
    ordered_labels = sorted(first_start.keys(), key=lambda k: first_start[k])
    label_map = {lab: i for i, lab in enumerate(ordered_labels)}
    labels = np.array([label_map[int(l)] for l in labels], dtype=int)

    merged = []
    cur_lab = int(labels[0])
    cur_start, cur_end = stamps[0]

    def _flush():
        merged.append({
            "start": float(cur_start),
            "end": float(cur_end),
            "speaker": f"Speaker {cur_lab + 1}",
        })

    bridge_s = max(hop_s, 0.5) * 0.6  # allow small gaps between windows

    for (lab, (s, e)) in zip(labels[1:], stamps[1:]):
        if lab == cur_lab and s - cur_end <= bridge_s:
            cur_end = max(cur_end, e)
        else:
            _flush()
            cur_lab = int(lab)
            cur_start, cur_end = s, e
    _flush()

    # 7) Clip to audio duration + merge tiny-gap duplicates
    out = []
    for seg in merged:
        seg["start"] = max(0.0, min(seg["start"], duration))
        seg["end"] = max(seg["start"], min(seg["end"], duration))

        if out and out[-1]["speaker"] == seg["speaker"] and \
           seg["start"] - out[-1]["end"] <= 0.25:
            out[-1]["end"] = seg["end"]
        else:
            out.append(seg)

    return out


# -------------------------
# CLI
# -------------------------

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python tokenless_diarizer.py /path/to/audio.wav [num_speakers]")
        sys.exit(1)

    audio_path = sys.argv[1]
    try:
        num_speakers = int(sys.argv[2]) if len(sys.argv) > 2 else None
    except ValueError:
        num_speakers = None

    result = diarize(audio_path, num_speakers=num_speakers)
    print(json.dumps(result, indent=2))
