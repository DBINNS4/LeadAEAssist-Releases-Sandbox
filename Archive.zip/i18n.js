(() => {
  function translatePage() {
    if (!window.i18n) return;
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      const text = window.i18n.t(key);
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        el.placeholder = text;
      } else {
        el.textContent = text;
      }
    });
    document.querySelectorAll('[data-i18n-attr]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (!key) return;
      const attrName = el.getAttribute('data-i18n-attr');
      const text = window.i18n.t(key);
      if (attrName) {
        el.setAttribute(attrName, text);
      }
    });
    document.querySelectorAll('[data-i18n-attrs]').forEach(el => {
      const attrList = el.getAttribute('data-i18n-attrs');
      if (!attrList) return;
      attrList.split(',').forEach(pair => {
        const [rawAttr, rawKey] = pair.split(':');
        const attrName = rawAttr ? rawAttr.trim() : '';
        const key = rawKey ? rawKey.trim() : el.getAttribute('data-i18n');
        if (!attrName || !key) return;
        el.setAttribute(attrName, window.i18n.t(key));
      });
    });
    document.documentElement.setAttribute('lang', window.i18n.language);
  }
  window.translatePage = translatePage;


  const interpolateFallback = (template, options) => {
    if (!template) return '';
    if (!options) return String(template);
    return String(template).replace(/{{\s*([^{}\s]+)\s*}}/g, (match, token) => {
      if (Object.prototype.hasOwnProperty.call(options, token)) {
        return String(options[token]);
      }
      return match;
    });
  };

  const formatI18nMessage = (payload, fallback = '') => {
    if (!payload || typeof payload !== 'object') {
      return typeof payload === 'string' ? payload : String(fallback || '');
    }
    const key = typeof payload.key === 'string' ? payload.key : '';
    const params = payload.params && typeof payload.params === 'object' ? payload.params : {};
    if (!key) return interpolateFallback(fallback, params);
    if (window.i18n?.t) {
      return window.i18n.t(key, { ...params, defaultValue: fallback || key });
    }
    return interpolateFallback(fallback || key, params);
  };
  window.formatI18nMessage = formatI18nMessage;

  const languages = ['en', 'fr', 'es', 'de', 'ja', 'zh'];
  const resources = {};
  const i18n = window.i18next;

  function initI18n() {
    return i18n
      .use(window.i18nextBrowserLanguageDetector)
      .init({
        resources,
        fallbackLng: 'en',
        interpolation: { escapeValue: false }
      })
      .then(() => translatePage());
  }

  let hasRegisteredI18nGlobals = false;

  function registerI18nGlobals() {
    window.i18n = i18n;
    if (hasRegisteredI18nGlobals) return;
    i18n.on('languageChanged', translatePage);
    hasRegisteredI18nGlobals = true;
  }

  Promise.all(
    languages.map(lang =>
      fetch(`./locales/${lang}.json`)
        .then(res => res.json())
        .then(data => {
          resources[lang] = { translation: data };
        })
        .catch(error => {
          console.warn(`[i18n] Failed to load locale "${lang}". Using empty fallback.`, error);
          resources[lang] = { translation: {} };
        })
    )
  )
    .then(() => {
      if (!resources.en) {
        resources.en = { translation: {} };
      }
      registerI18nGlobals();
      return initI18n();
    })
    .catch(error => {
      console.warn('[i18n] Locale bootstrap failed. Continuing with English fallback.', error);
      resources.en = resources.en || { translation: {} };
      registerI18nGlobals();
      return initI18n();
    });
})();
