// Sentry preload bridge
//
// The Sentry Electron renderer SDK communicates with the main process via IPC.
// In hardened Electron configs (contextIsolation: true, nodeIntegration: false),
// the SDK needs a preload bridge to expose this IPC.
//
// IMPORTANT: This is best-effort and must NEVER break app boot.
try {
  require('@sentry/electron/preload');
} catch (_) {
  // ignore
}

const { contextBridge, ipcRenderer } = require('electron');
const { pathToFileURL } = require('url');

// NOTE: Renderer sandbox is enabled. Preload must not rely on Node built-ins
// (fs/path/os) or local CommonJS requires. Use narrowly-scoped IPC for the small
// deterministic helpers the renderer needs (paths, userData, export formatting).
function _unwrapSyncResult(res, channel) {
  if (res && typeof res === 'object') {
    if (res.ok === false) {
      const msg = res.error || `${channel} failed`;
      throw new Error(String(msg));
    }
    if (res.ok === true && 'value' in res) return res.value;
  }
  return res;
}

function _sendSyncValue(channel, ...args) {
  return _unwrapSyncResult(ipcRenderer.sendSync(channel, ...args), channel);
}

async function _invokeValue(channel, ...args) {
  return _unwrapSyncResult(await invokeAllowed(channel, ...args), channel);
}

// Sync IPC budget: keep blocking channels limited to boot-time values needed before
// renderer async hydration can run. Any non-critical helper must use invokeAllowed.
const appInfo = (() => {
  try { return _sendSyncValue('app:get-info-sync'); } catch { return { isPackaged: false, debugUI: false, platform: '', pathSep: '/' }; }
})();

const userDataPath = (() => {
  try { return _sendSyncValue('app:get-user-data-path-sync'); } catch { return null; }
})();

const isPackaged = !!appInfo.isPackaged;

const pathBridge = {
  // Async-first path helpers for renderer hot paths.
  joinAsync: (...parts) => _invokeValue('path:join', ...parts),
  resolveAsync: (...parts) => _invokeValue('path:resolve', ...parts),
  basenameAsync: (p, ext) => _invokeValue('path:basename', p, ext),
  extnameAsync: (p) => _invokeValue('path:extname', p),
  relativeAsync: (from, to) => _invokeValue('path:relative', from, to),
  isAbsoluteAsync: (p) => _invokeValue('path:isAbsolute', p),
  dirnameAsync: (p) => _invokeValue('path:dirname', p),

  // Legacy sync wrappers (avoid in loops/high-frequency UI code).
  join: (...parts) => _sendSyncValue('path:joinSync', ...parts),
  resolve: (...parts) => _sendSyncValue('path:resolveSync', ...parts),
  basename: (p, ext) => _sendSyncValue('path:basenameSync', p, ext),
  extname: (p) => _sendSyncValue('path:extnameSync', p),
  relative: (from, to) => _sendSyncValue('path:relativeSync', from, to),
  isAbsolute: (p) => _sendSyncValue('path:isAbsoluteSync', p),
  dirname: (p) => _sendSyncValue('path:dirnameSync', p),
  sep: () => (appInfo && appInfo.pathSep) ? appInfo.pathSep : '/',
  platform: () => (appInfo && appInfo.platform) ? appInfo.platform : ''
};

function _callTranscribeEngineSync(method, ...args) {
  return _sendSyncValue(`transcribeEngine:${method}Sync`, ...args);
}

function _callTranscribeEngineAsync(method, ...args) {
  return invokeAllowed(`transcribeEngine:${method}`, ...args);
}

// Duplicate checks are filesystem reads (checksum), so keep them behind IPC.
function isDuplicate(src, dest, method = 'sha256') {
  return invokeAllowed('fs:isDuplicate', src, dest, method);
}

// Secrets are accessed via allowlisted IPC only.
// SECURITY: The renderer must never receive secret values (no "get" APIs).
// We expose only boolean state + write-only setters.
const secrets = {
  hasAiApiKey: () => invokeAllowed('secure-store:has-ai-api-key'),
  setAiApiKey: (value) => invokeAllowed('secure-store:set-ai-api-key', value),
  deleteAiApiKey: () => invokeAllowed('secure-store:delete-ai-api-key')
};


const createDialogInvoker = channel => {
  let pendingPromise = null;
  return (...args) => {
    if (pendingPromise) return pendingPromise;
    pendingPromise = invokeAllowed(channel, ...args);
    const reset = () => {
      pendingPromise = null;
    };
    pendingPromise.then(reset, reset);
    return pendingPromise;
  };
};

// Build only the methods you actually need to use in renderer

// ---- IPC allowlists (renderer -> main) ----
// Prevent arbitrary channel access from the renderer. Keep this list tight.
const ALLOWED_INVOKE_CHANNELS = new Set([
  // Dialogs / helpers
  'select-folder',
  'select-files',
  'select-folder-or-files',
  'approve-paths',
  'save-file-dialog',
  'open-file-dialog',
  'show-message-dialog',
  'show-confirm-dialog',
  // Presets
  'list-panel-presets',
  'read-panel-preset',
  'write-panel-preset',
  'delete-panel-preset',
  // Queue
  'queue-start',
  'queue-cancel-job',
  'queue-add-ingest',
  'queue-add-clone',
  'queue-add-transcode',
  'transcode-preflight',
  'cancel-ingest',
  'cancel-transcode',
  'run-clone',
  'cancel-clone',
  'queue-add-transcribe',
  'queue-add-project-organizer',
  'queue-add-adobe',
  // Misc
  'calculate-ingest-bytes',
  'ingest-validate-paths',
  'calculate-clone-bytes',
  'get-folder-tree',
  'get-folder-file-counts',
  'normalize-path',
  'path-exists',
  // Async path helpers (prefer over sync path:*Sync channels in UI loops)
  'path:join',
  'path:resolve',
  'path:basename',
  'path:extname',
  'path:relative',
  'path:isAbsolute',
  'path:dirname',
  // Async fsAccess (preferred over sync sendSync channels)
  'fs:exists',
  'fs:isDuplicate',
  'fs:readTextFile',
  'fs:writeTextFile',
  'fs:writeTextFileAtomic',
  'fs:mkdir',
  'fs:readdir',
  'fs:stat',
  'fs:unlink',
  'fs:copyFile',
  'stat-path',
  'path-stat',
  'run-network-test',
  'cancel-network-test',
  'assets:getStatus',
  'assets:prefetch',
  'assets:cancel',
  'cancel-drive-test',
  'reset-drive-test-cancel',
  'run-drive-test',
  'run-drive-test-random',
  'log-viewer:read-log-files',
  'log-viewer:open-log-folder',
  'is-media-composer-running',
  'get-source-metadata',
  'validate-codex-input',
  'exec-ffprobe',
  'ffprobe-json',
  'exec-ffmpeg',
  'probe-media',
  'expand-paths',
  'secure-store:has-ai-api-key',
  'secure-store:set-ai-api-key',
  'secure-store:delete-ai-api-key',
  'prefs:get-preferences',
  'prefs:set-preferences',
  'prefs:get-qc-delivery',
  'prefs:set-qc-delivery',
  'app:get-version',
  'app:get-version-specs',
  'maintenance:get-info',
  'maintenance:open-temp-folder',
  'maintenance:clear-temp',
  'maintenance:clear-cache',
  'updates:get-status',
  'updates:check',
  'updates:download',
  'updates:quit-and-install',

  // Watch mode (folder automation)
  'start-watch-folder',
  'stop-watch-folder',

  'telemetry:get-state',
  'telemetry:set-enabled',
  // Subtitle editor
  'subtitle-editor-open',
  'subtitle-editor:open',
  'subtitle-editor-export',
  'subtitle-editor-export-scc',
  'subtitle-editor-export-mcc',
  'subtitle-editor-preview-mcc',
  'subtitle-editor-burnin',
  'subtitle-editor-find-latest',
  'subtitle-editor-get-scc-glyphs',
  'subtitle-editor-get-pending-init',
  'shell:show-item-in-folder',
  // Backup
  'backup-get-state',
  'backup-run',
  'backup-pause',
  'backup-resume',
  'backup-add-job',
  'backup-cancel',
  // Bridge
  'bridge:get-credentials',

  // Licensing
  'license:get-tier',
  'license:is-enabled',
  'license:get-entitlement',
  'license:clear',
  'license:select-and-install',
  'license:sync-entitlement',
  'billing:open-checkout',
  'billing:open-portal',

  // CEP panel installer
  'cep:get-status',
  'cep:install',
  'cep:uninstall',
  'cep:open-folder',

  // Codex/spec and FFmpeg capability APIs
  'codex:list-formats',
  'codex:list-audio-codecs',
  'codex:get-compatibility',
  'codex:get-audio-constraints',
  'codex:is-audio-container-valid',
  'codex:get-spec',
  'codex:get-format-capabilities',
  'ffmpeg:get-capabilities',
  'get-ffmpeg-formats',

  // Async transcribe engine helpers
  'transcribeEngine:generateSRT',
  'transcribeEngine:generateVTT',
  'transcribeEngine:generateSCC',
  'transcribeEngine:generateSegmentTextWithTokenTiming',
  'transcribeEngine:validateMccContentQc',
  'transcribeEngine:validateSccContentQc'
]);

const ALLOWED_SEND_CHANNELS = new Set([
  // UI chrome
  'ui:set-collapsed',
  'prefs:set-qc-delivery',
  'preset-saved',
  'transcribe-final-words',
  'adobe-utilities-log-message'
]);

const ALLOWED_ON_CHANNELS = new Set([
  'auto-connect-leadae',
  'auto-update-status',
  'app-critical-error',
  'backup-state',
  'clone:done',
  'clone:progress',
  'drive-test-progress',
  'drive-test-warning',
  'assets:progress',
  'live-transcript-line',
  'prefs:qc-delivery-updated',
  'premiere-create-bins',
  'premiere-import-media',
  'preset-deleted',
  'preset-saved',
  'queue-job-added',
  'queue-job-cancelling',  
  'queue-job-cancelled',
  'queue-job-complete',
  'queue-job-failed',
  'queue-job-progress',
  'queue-job-start',
  'license:changed',
  'toggle-fields',
  'transcription-preview',
  'transcribe-discrepancies',
  'transcribe-log-message',
  'transcribe-open-reconcile',
  'watch-log',
  'ui:collapsed-applied'
]);

const ALLOWED_ON_PATTERNS = [
  // Live log fan-out channels: "<panel>-log-message"
  /^(ingest|clone|transcode|transcribe|adobe-utilities|nle-utilities|project-organizer|preferences|speed-test|comparison|resolution|system|watch)-log-message$/
];

const ALLOWED_LOG_PANELS = new Set([
  'ingest',
  'clone',
  'transcode',
  'transcribe',
  'adobe-utilities',
  'nle-utilities',
  'project-organizer',
  'preferences',
  'speed-test',
  'comparison',
  'resolution',
  'system',
  'watch'
]);

function isAllowedChannel(channel, allowedSet, allowedPatterns = []) {
  if (allowedSet && allowedSet.has(channel)) return true;
  if (Array.isArray(allowedPatterns)) {
    for (const re of allowedPatterns) {
      try {
        if (re && typeof re.test === 'function' && re.test(channel)) return true;
      } catch {
        // ignore
      }
    }
  }
  return false;
}

function invokeAllowed(channel, ...args) {
  if (!isAllowedChannel(channel, ALLOWED_INVOKE_CHANNELS)) {
    // Avoid crashing UI event handlers in the renderer when a channel is blocked.
    // We still *block* the call, but we surface a clear console error.
    const err = new Error(`Blocked ipc.invoke channel: ${channel}`);
    try { console.error(err); } catch {}
    return Promise.reject(err);
  }
  return ipcRenderer.invoke(channel, ...args);
}

function sendAllowed(channel, ...args) {
  if (!isAllowedChannel(channel, ALLOWED_SEND_CHANNELS)) {
    // Do not throw synchronously: an exception here can break unrelated UI logic
    // (e.g. tab switching) since send() is often called inside click handlers.
    try { console.error(`Blocked ipc.send channel: ${channel}`); } catch {}
    return false;
  }
  return ipcRenderer.send(channel, ...args);
}

function onAllowed(channel, listener) {
  if (!isAllowedChannel(channel, ALLOWED_ON_CHANNELS, ALLOWED_ON_PATTERNS)) {
    // Renderer event subscription should fail closed without killing startup.
    try { console.error(`Blocked ipc.on channel: ${channel}`); } catch {}
    return;
  }
  return ipcRenderer.on(channel, listener);
}

function offAllowed(channel, listener) {
  if (!isAllowedChannel(channel, ALLOWED_ON_CHANNELS, ALLOWED_ON_PATTERNS)) {
    // Mirror onAllowed security behavior: fail closed without sync throw.
    try { console.error(`Blocked ipc.off channel: ${channel}`); } catch {}
    return;
  }
  return ipcRenderer.off(channel, listener);
}

function removeListenerAllowed(channel, listener) {
  if (!isAllowedChannel(channel, ALLOWED_ON_CHANNELS, ALLOWED_ON_PATTERNS)) {
    // Mirror onAllowed security behavior: fail closed without sync throw.
    try { console.error(`Blocked ipc.removeListener channel: ${channel}`); } catch {}
    return;
  }
  return ipcRenderer.removeListener(channel, listener);
}

function removeAllListenersAllowed(channel) {
  if (!isAllowedChannel(channel, ALLOWED_ON_CHANNELS, ALLOWED_ON_PATTERNS)) {
    try { console.error(`Blocked ipc.removeAllListeners channel: ${channel}`); } catch {}
    return;
  }
  return ipcRenderer.removeAllListeners(channel);
}

function normalizeFsResultOrThrow(res, channel) {
  if (res && typeof res === 'object' && res.ok === false) {
    throw new Error(res.error || `${channel} failed`);
  }
  if (res && typeof res === 'object' && res.ok === true && 'value' in res) {
    return res.value;
  }
  return res;
}

function toStructuredIpcError(error, fallbackMessage) {
  const msg = (error && typeof error === 'object' && typeof error.message === 'string' && error.message.trim())
    ? error.message
    : fallbackMessage;
  const wrapped = new Error(msg);
  if (error && typeof error === 'object') {
    wrapped.code = error.code;
    wrapped.stderrTail = error.stderrTail;
    wrapped.stdoutTail = error.stdoutTail;
    wrapped.exitCode = error.exitCode;
    wrapped.signal = error.signal;
    if (Number.isFinite(error.timeoutMs)) {
      wrapped.timeoutMs = error.timeoutMs;
    }
    wrapped.structured = error;
  }
  return wrapped;
}

function syncValueOrThrow(channel, ...args) {
  const res = ipcRenderer.sendSync(channel, ...args);
  return normalizeFsResultOrThrow(res, channel);
}

async function invokeFsValueOrThrow(channel, ...args) {
  const res = await invokeAllowed(channel, ...args);
  return normalizeFsResultOrThrow(res, channel);
}

const LEGACY_SYNC_FS_ENABLED = String(process?.env?.LEAD_AE_ENABLE_LEGACY_SYNC_FS || '').trim() === '1';

const api = {
  // 🔹 Electron-safe actions
  selectFolder: createDialogInvoker('select-folder'),
  selectFiles: createDialogInvoker('select-files'),
  selectFolderOrFiles: createDialogInvoker('select-folder-or-files'),
  approvePaths: createDialogInvoker('approve-paths'),
  saveFile: createDialogInvoker('save-file-dialog'),
  openFile: createDialogInvoker('open-file-dialog'),
  invoke: invokeAllowed,
  on: onAllowed,
  off: offAllowed,
  removeListener: removeListenerAllowed,
  removeAllListeners: removeAllListenersAllowed,
  send: sendAllowed,
  cancelIngest: () => invokeAllowed('cancel-ingest'),
  cancelTranscode: (jobId) => invokeAllowed('cancel-transcode', jobId),
  runClone: (config) => invokeAllowed('run-clone', config),
  cancelClone: () => invokeAllowed('cancel-clone'),
  getSourceMetadata: (file) => invokeAllowed('get-source-metadata', file),
  validateCodexInput: (metadata, entry) => invokeAllowed('validate-codex-input', { metadata, codexEntry: entry }),
  scanFolderTree: (rootPath) => invokeAllowed('get-folder-tree', rootPath), 
  // FFprobe/FFmpeg execution is mediated by the main process.
  // SECURITY: the renderer may NOT supply an executable path.
  execFFprobe: (args) => {
    if (!Array.isArray(args)) {
      throw new Error('execFFprobe expects an array of args');
    }
    return invokeAllowed('exec-ffprobe', args);
  },
  ffprobeJson: (filePath, extraArgsOrOptions, options) => {
    const hasExtraArgs = Array.isArray(extraArgsOrOptions);
    const extraArgs = hasExtraArgs ? extraArgsOrOptions : [];
    const opts = hasExtraArgs
      ? (options && typeof options === 'object' ? options : {})
      : (extraArgsOrOptions && typeof extraArgsOrOptions === 'object' ? extraArgsOrOptions : {});
    return invokeAllowed('ffprobe-json', filePath, extraArgs, opts);
  },
  execFFmpeg: (args, options = {}) => {
    // Signature: execFFmpeg(args[, options])
    // SECURITY: the renderer may NOT supply an executable path.
    if (!Array.isArray(args)) {
      throw new Error('execFFmpeg expects an array of args');
    }
    const opts = (options && typeof options === 'object') ? options : {};
    return invokeAllowed('exec-ffmpeg', args, opts).then(res => {
      if (res && typeof res === 'object' && res.ok === false) {
        throw toStructuredIpcError(res.error, 'FFmpeg failed');
      }
      if (res && typeof res === 'object' && res.ok === true && 'value' in res) {
        return res.value;
      }
      return res;
    });
  },
  probeMedia: (file, options = {}) => invokeAllowed('probe-media', file, options || {}),
  // Promise-based (keeps renderer simple)
  readLogFiles: (dir) => invokeAllowed('log-viewer:read-log-files', dir),
  openLogFolder: (dir) => invokeAllowed('log-viewer:open-log-folder', dir),
  isMediaComposerRunning: () => invokeAllowed('is-media-composer-running'),
  expandPaths: (paths, options = {}) =>
    invokeAllowed('expand-paths', paths, options),
      
  getRealPath: async (file, dataTransfer, index) => {
    // Debug: real path info

  // ✅ Best-case: file.path is available
  if (file?.path) {
    // file.path exists
    return file.path;
  }

  // ✅ Always try to decode file:// URIs
  try {
    const list = dataTransfer?.getData?.('text/uri-list');

    if (list) {
      const entries = list.split(/\r?\n/).filter(Boolean);
      const idx = typeof index === 'number' ? index : 0;
      const uri = entries[idx];

      if (uri?.startsWith('file://')) {
        const decoded = decodeURI(uri.replace(/^file:\/\//, ''));
        return decoded;
      }
    }
  } catch (err) {
    console.error('❌ getRealPath fallback failed:', err);
  }

  // 🧪 Last resort
  if (file?.name) {
    console.warn('⚠️ Could not resolve full path. Returning filename only:', file.name);
    return file.name;
  }

  return null;
},

  assets: {
    getStatus: (request = {}) => invokeAllowed('assets:getStatus', request),
    prefetch: (request = {}, options = {}) => invokeAllowed('assets:prefetch', request, options),
    cancel: (request = {}) => invokeAllowed('assets:cancel', request),
    onProgress: (cb) => {
      if (typeof cb !== 'function') return () => {};
      const listener = (_event, payload) => cb(payload);
      onAllowed('assets:progress', listener);
      return () => offAllowed('assets:progress', listener);
    }
  },

  // ✅ Native dialog helpers
  showMessageDialog: async (options) => invokeAllowed('show-message-dialog', options),
  showConfirmDialog: async (messageOrOptions) => invokeAllowed('show-confirm-dialog', messageOrOptions),
  showConfirm: async (messageOrOptions) => invokeAllowed('show-confirm-dialog', messageOrOptions),

  // 🔹 SAFE fs/path helpers
  joinPathAsync: (...args) => pathBridge.joinAsync(...args),
  pathResolveAsync: (...args) => pathBridge.resolveAsync(...args),
  basenameAsync: (p, ext) => (typeof ext === 'string') ? pathBridge.basenameAsync(p, ext) : pathBridge.basenameAsync(p),
  extnameAsync: (p) => pathBridge.extnameAsync(p),
  relativeAsync: (from, to) => pathBridge.relativeAsync(from, to),
  isAbsoluteAsync: (p) => pathBridge.isAbsoluteAsync(p),
  dirnameAsync: (p) => pathBridge.dirnameAsync(p),
  resolvePathAsync: (...args) => pathBridge.joinAsync(userDataPath, ...args),

  joinPath: (...args) => pathBridge.join(...args),
  // IMPORTANT: This is a true OS path resolver (does NOT prepend userDataPath).
  // Use this for resolving user-selected filesystem paths (e.g., scope paths in panels).
  pathResolve: (...args) => pathBridge.resolve(...args),
  resolvePath: (...args) => pathBridge.join(userDataPath, ...args),

  // Async fs helpers normalize both legacy { ok, value|error } and plain return contracts.
  fileExistsAsync: async (filePath) => {
    try {
      return !!(await invokeFsValueOrThrow('fs:exists', filePath));
    } catch {
      return false;
    }
  },
  readTextFileAsync: (filePath, encoding) => invokeFsValueOrThrow('fs:readTextFile', filePath, encoding),
  writeTextFileAsync: (filePath, content, encoding) => invokeFsValueOrThrow('fs:writeTextFile', filePath, content, encoding),
  writeTextFileAtomicAsync: (filePath, content, encoding) => invokeAllowed('fs:writeTextFileAtomic', filePath, content, encoding),
  mkdirAsync: (dir) => invokeFsValueOrThrow('fs:mkdir', dir),
  readdirAsync: (dir, opts) => invokeFsValueOrThrow('fs:readdir', dir, opts || {}),
  unlinkAsync: (filePath) => invokeFsValueOrThrow('fs:unlink', filePath),
  copyFileAsync: (src, dest) => invokeFsValueOrThrow('fs:copyFile', src, dest),
  fsStat: (filePath) => invokeFsValueOrThrow('fs:stat', filePath),

  // Legacy sync fs helpers (opt-in only via LEAD_AE_ENABLE_LEGACY_SYNC_FS=1).
  ...(LEGACY_SYNC_FS_ENABLED ? {
    fileExists: (filePath) => {
      try { return !!ipcRenderer.sendSync('fs:existsSync', filePath); } catch { return false; }
    },
    readTextFile: (filePath, encoding) => syncValueOrThrow('fs:readTextFileSync', filePath, encoding),
    writeTextFile: (filePath, content, encoding) => syncValueOrThrow('fs:writeTextFileSync', filePath, content, encoding),
    readdir: (dir, opts) => syncValueOrThrow('fs:readdirSync', dir, opts || {}),
    readdirWithTypes: (dir) => syncValueOrThrow('fs:readdirSync', dir, { withFileTypes: true }),
    readdirSync: (dir, opts) => syncValueOrThrow('fs:readdirSync', dir, opts || {}),
    readdirWithTypesSync: (dir) => syncValueOrThrow('fs:readdirSync', dir, { withFileTypes: true }),
    unlink: (filePath) => syncValueOrThrow('fs:unlinkSync', filePath),
    mkdir: (dir) => syncValueOrThrow('fs:mkdirSync', dir),
    copyFile: (src, dest) => syncValueOrThrow('fs:copyFileSync', src, dest),
    statSync: (filePath) => syncValueOrThrow('fs:statSync', filePath),
  } : {}),
  stat: (filePath) => invokeAllowed('stat-path', filePath),
  basename: (p, ext) => (typeof ext === 'string') ? pathBridge.basename(p, ext) : pathBridge.basename(p),
  extname: (p) => pathBridge.extname(p),
  relative: (from, to) => pathBridge.relative(from, to),
  isAbsolute: (p) => pathBridge.isAbsolute(p),
  dirname: (p) => pathBridge.dirname(p),
  sep: () => pathBridge.sep(),
  platform: pathBridge.platform()
};

// ✅ Expose api, license, and utils
contextBridge.exposeInMainWorld("utils", {
  isDuplicate,
  joinPathAsync: (...parts) => pathBridge.joinAsync(...parts),
  baseNameAsync: (p, ext) => (typeof ext === 'string') ? pathBridge.basenameAsync(p, ext) : pathBridge.basenameAsync(p),
  joinPath: (...parts) => pathBridge.join(...parts),
  baseName: (p, ext) => (typeof ext === 'string') ? pathBridge.basename(p, ext) : pathBridge.basename(p)
});

contextBridge.exposeInMainWorld('electron', {
  ...api,
  userDataPath,
  secrets,
  DEBUG_UI: !!appInfo.debugUI,
  isPackaged,
  // Build proper file:/// URLs cross-platform
  pathToFileURL: (p) => {
    try { return pathToFileURL(p).toString(); } catch { return null; }
  },
  onTranscriptionPreview: (cb) => {
    if (typeof cb !== 'function') return () => {};
    const listener = (_e, data) => cb(data);
    onAllowed('transcription-preview', listener);
    return () => ipcRenderer.removeListener('transcription-preview', listener);
  },
  // License/entitlement changes (after Sync Subscription, Install License, Clear License)
  onLicenseChanged: (cb) => {
    if (typeof cb !== 'function') return () => {};
    const listener = (_e, ent) => cb(ent);
    onAllowed('license:changed', listener);
    return () => ipcRenderer.removeListener('license:changed', listener);
  }
});

// Codex/spec proxy (renderer → main)
contextBridge.exposeInMainWorld('codex', {
  listFormats: () => invokeAllowed('codex:list-formats'),
  listAudioCodecs: () => invokeAllowed('codex:list-audio-codecs'),
  getCompatibility: (format) => invokeAllowed('codex:get-compatibility', { format }),
  getAudioConstraints: (codec) => invokeAllowed('codex:get-audio-constraints', { codec }),
  isAudioContainerValid: (codec, container) => invokeAllowed('codex:is-audio-container-valid', { codec, container }),
  getSpec: () => invokeAllowed('codex:get-spec'),
  getFormatCapabilities: (format) => invokeAllowed('codex:get-format-capabilities', { format })
});

// 🔎 FFmpeg capabilities (encoders/muxers), unified and cached in main
contextBridge.exposeInMainWorld('ffmpeg', {
  getCapabilities: () => invokeAllowed('ffmpeg:get-capabilities'),
  // Kept for back-compat where panels expect the old list
  getMuxerWhitelist: () => invokeAllowed('get-ffmpeg-formats')
});

contextBridge.exposeInMainWorld('logPanel', {
  log: (panel, msg, opts = {}) => {
    const p = String(panel || '').trim();
    if (!ALLOWED_LOG_PANELS.has(p)) {
      throw new Error(`Blocked logPanel target: ${p || '(empty)'}`);
    }
    ipcRenderer.send(`${p}-log-message`, {
      msg,
      detail: opts.detail || '',
      isError: opts.isError || false,
      isWarning: opts.isWarning || false,
      level: opts.level || (opts.isWarning ? 'warn' : opts.isError ? 'error' : undefined),
      fileId: opts.fileId || '',
      jobId: opts.jobId || '',
      stage: opts.stage || '',
      meta: (opts.meta && typeof opts.meta === 'object' && !Array.isArray(opts.meta)) ? opts.meta : undefined,
      timestamp: (typeof opts.timestamp === 'number' && Number.isFinite(opts.timestamp)) ? opts.timestamp : undefined
    });
  }
});

contextBridge.exposeInMainWorld('transcribeEngine', {
  // Writers / export helpers used by the main Transcribe panel
  generatePlainText: (...args) => _callTranscribeEngineSync('generatePlainText', ...args),
  generateSRT: (...args) => _callTranscribeEngineAsync('generateSRT', ...args),
  generateSRTSync: (...args) => _callTranscribeEngineSync('generateSRT', ...args),
  generateVTT: (...args) => _callTranscribeEngineAsync('generateVTT', ...args),
  generateVTTSync: (...args) => _callTranscribeEngineSync('generateVTT', ...args),
  generateSyncableScriptCSV: (...args) => _callTranscribeEngineSync('generateSyncableScriptCSV', ...args),
  generateMarkersTXT: (...args) => _callTranscribeEngineSync('generateMarkersTXT', ...args),
  generateXML: (...args) => _callTranscribeEngineSync('generateXML', ...args),
  generateSegmentTextWithTokenTiming: (...args) => _callTranscribeEngineAsync('generateSegmentTextWithTokenTiming', ...args),
  generateSegmentTextWithTokenTimingSync: (...args) => _callTranscribeEngineSync('generateSegmentTextWithTokenTiming', ...args),



  // Subtitle Editor helpers (SCC/MCC + 608 preview)
  generateSCC: (...args) => _callTranscribeEngineAsync('generateSCC', ...args),
  generateSCCSync: (...args) => _callTranscribeEngineSync('generateSCC', ...args),
  wrap608: (...args) => _callTranscribeEngineSync('wrap608', ...args),
  wrap608WithMeta: (...args) => _callTranscribeEngineSync('wrap608WithMeta', ...args),
  validateMccContentQc: (...args) => _callTranscribeEngineAsync('validateMccContentQc', ...args),
  validateMccContentQcSync: (...args) => _callTranscribeEngineSync('validateMccContentQc', ...args),
  validateSccContentQc: (...args) => _callTranscribeEngineAsync('validateSccContentQc', ...args),
  validateSccContentQcSync: (...args) => _callTranscribeEngineSync('validateSccContentQc', ...args),

  // Timecode math (required for deterministic DF/NDF display in Subtitle Editor)
  parseTime: (...args) => _callTranscribeEngineSync('parseTime', ...args),
  parseTimecode: (...args) => _callTranscribeEngineSync('parseTimecode', ...args),
  msToTC: (...args) => _callTranscribeEngineSync('msToTC', ...args),
  formatTimecodes: (...args) => _callTranscribeEngineSync('formatTimecodes', ...args),
  formatTimecode: (...args) => _callTranscribeEngineSync('formatTimecode', ...args)
});

// 🔑 Real license API via IPC (no stubs)
contextBridge.exposeInMainWorld('license', {
  getLicenseTier: () => invokeAllowed('license:get-tier'),
  isFeatureEnabled: (featureKey) => invokeAllowed('license:is-enabled', featureKey),
  getEntitlement: (options = {}) => invokeAllowed('license:get-entitlement', options),
  clear: () => invokeAllowed('license:clear'),
  selectAndInstall: () => invokeAllowed('license:select-and-install'),
  syncEntitlement: (options = {}) => invokeAllowed('license:sync-entitlement', options)
});

contextBridge.exposeInMainWorld('billing', {
  openCheckout: (options = {}) => invokeAllowed('billing:open-checkout', options),
  openPortal: (options = {}) => invokeAllowed('billing:open-portal', options)
});

contextBridge.exposeInMainWorld('preferences', {
  get: () => invokeAllowed('prefs:get-preferences'),
  set: (payload) => invokeAllowed('prefs:set-preferences', payload)
});
// Minimal surface for the pop-out editor
// Buffer and fan-out subtitle editor init payloads
let __subtitleInitPayload = null;
const __subtitleInitHandlers = new Set();
ipcRenderer.on('subtitleEditor:init', (_evt, data) => {
  __subtitleInitPayload = data || {};
  for (const fn of __subtitleInitHandlers) {
    try { fn(__subtitleInitPayload); } catch {}
  }
});

contextBridge.exposeInMainWorld('subtitleEditor', {
  open: async (payload = {}) => {
    const res = await invokeAllowed('subtitle-editor:open', payload);
    // Convert structured failures (e.g. license gating) into a rejected promise
    // so callers get consistent try/catch behavior.
    if (res && res.ok === false) {
      const err = new Error(res.error || 'Failed to open Subtitle Editor');
      err.code = 'ERR_SUBTITLE_EDITOR_OPEN';
      throw err;
    }
    return res;
  },
  onInit: (cb) => {
    if (typeof cb !== 'function') return () => {};
    __subtitleInitHandlers.add(cb);
    // If the payload already arrived, deliver it immediately.
    if (__subtitleInitPayload) setTimeout(() => {
      try { cb(__subtitleInitPayload); } catch {}
    }, 0);
    // Return unsubscribe
    return () => __subtitleInitHandlers.delete(cb);
  }
});
