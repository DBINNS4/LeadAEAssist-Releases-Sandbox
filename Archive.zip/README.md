# LEAD AE – ASSIST

LEAD AE – ASSIST is an Electron desktop application for assistant editors and post teams. It combines verified media ingest, batch transcoding, transcription and caption export, Premiere automation through a bundled CEP panel, project-setup tooling, diagnostics, and offline help in a single app.

This repository is the application source and packaging workspace for that desktop app.

---

## What the app does

The product is organized around a set of operational panels rather than a single monolithic workflow:

- **Ingest** — verified copy, dual-copy backup, duplicate skipping, extension filtering, Clone Mode, and Watch Mode.
- **Transcode** — batch transcode, watch-folder transcode, audio-only exports, LUT application, metadata preservation, caption attach into MXF, and output verification.
- **Transcribe** — transcript export, subtitle export (`.srt`, `.vtt`), broadcast caption export (`.scc`, `.mcc`), script CSV, burn-in output, translation, diarization, and Subtitle Editor handoff.
- **Adobe Automate** — copy-first workflow that can import verified files into Premiere, build bins, create proxies, and attach them back through the Premiere CEP panel.
- **Subtitle Editor** — separate editor window for `.json`, `.srt`, `.vtt`, `.scc`, and `.mcc` documents with QC, preview, correction export, burn-in, SCC/MCC export, and MCC service-aware editing.
- **Project Organizer** — creates standardized project folder trees and can copy starter assets into the generated structure.
- **Speed Test** — storage and network benchmarking before copy, transcode, or watch-folder operations.
- **NLE Utilities** — Avid reset/rebuild tools plus Adobe cache, autosave, and preview cleanup.
- **Log Viewer** — reads the app’s canonical raw log library, supports live updates, filtering, and TXT/JSON/CSV export.
- **Preferences / Account & Licensing** — app-wide settings, secure API key handling, runtime behavior, CEP install/repair, licensing, billing, and support version info.

The repo also includes a bundled **offline help system** under `help/`, localized UI strings under `locales/`, and a signed/distributable **Premiere CEP panel** under `cep/` + `build/`.

---

## Read this before trying to run or package the app

This source snapshot includes the core Electron app, help content, CEP extension source, configuration, and build scripts. It does **not** include every path referenced by the full workspace.

The code and scripts expect some generated, private, or externally staged paths that are absent from this archive, including:

- `services/` — several runtime services are imported by `main.js`, `ipc/`, `modules/`, `utils/`, and `ai/transcribeEngine.js`.
- `test/` — test scripts exist, but the expected test tree is not present in this snapshot.
- `resources/help/` — generated from `help/` by `npm run build:help`.
- `resources/cep/extensions/` — generated from `cep/extensions/` by `npm run copy:adobe-utils`.
- `dist-obfuscated/` — generated renderer bundles and source maps used for packaged builds.
- `extra/ffmpeg/` — required FFmpeg/FFprobe binaries for runtime media operations and packaging validation.
- `python_embedded/`, `venv_embedded/`, `whisper-static/`, `whisper-static-metal/` — referenced by packaging and local AI/transcription flows.
- `vendor/puppeteer/chrome` or a matching Chromium stage directory — used when preparing runtime assets.
- `whisper.cpp/` models or matching staged Whisper assets — used in development/runtime-asset preparation.
- `tools/zxpsigncmd/` — required for signing the Premiere CEP archive during release packaging.

That means this archive is best treated as the **app source snapshot**, not automatically as a complete, turnkey release workspace. Restore or generate the missing pieces before expecting all scripts to work exactly as written.

---

## Product and architecture overview

### Main process

`main.js` is the application entrypoint. It is responsible for:

- creating the main app window and the separate help/editor windows
- installing strict content security policy rules
- starting the secure loopback bridge used by the Premiere CEP panel
- registering IPC handlers from `ipc/`
- running FFmpeg startup checks
- loading startup dependencies and queue contracts
- applying offline-network gating and external-navigation guards
- wiring telemetry, licensing, updates, watch registries, and startup maintenance

### Preload and renderer boundary

`preload.js` exposes a narrow, allowlisted API into the renderer through `contextBridge`.

Important characteristics of this boundary:

- renderer access is **allowlisted by channel**, not open-ended
- the preferred filesystem path is **async IPC**, not ad-hoc direct Node access
- sync IPC is intentionally restricted to boot-critical reads only
- secrets are **write-only from the renderer side**; the renderer never receives the actual stored API key back

### IPC layer

`ipc/index.js` registers domain-specific handler modules such as:

- `ingest.handlers.js`
- `transcode.handlers.js`
- `transcribe.handlers.js`
- `subtitleEditor.handlers.js`
- `license.handlers.js`
- `billing.handlers.js`
- `prefs.handlers.js`
- `telemetry.handlers.js`
- `assets.handlers.js`
- `cepInstaller.handlers.js`

This keeps UI wiring separate from long-running job logic.

### Domain modules

The heavy lifting lives in `modules/`, for example:

- `ingest.js`
- `transcode.js`
- `transcribe.js`
- `project-organizer.js`
- `adobe-utilities.js`
- `backupQueue.js`
- `queueManager.js`
- `cepBridge.js`
- `secureStore.js`
- `logUtils.js`
- caption encode/decode helpers such as `sccEncoder.js`, `sccDecoder.js`, `mccDecoder.js`, `cea708Encoder.js`, and `cea708Decoder.js`

### AI and subtitle pipeline

`ai/` contains the text/subtitle/caption formatting and parsing layer:

- transcription normalization and preparation
- Whisper-oriented helpers
- SRT/VTT parsing, validation, and writing
- SCC shaping and output writing
- subtitle parser aggregation
- plain text formatting

This code is shared between Transcribe, Subtitle Editor, and some QC/export flows.

### Renderer structure

The UI is split into panel-specific renderer files such as:

- `renderer.ingest.js`
- `renderer.transcode.js`
- `renderer.transcribe.js`
- `renderer.adobe-utilities.js`
- `renderer.project-organizer.js`
- `renderer.nle-utilities.js`
- `renderer.preferences.js`
- `renderer.log-viewer.js`
- `renderer.speed-test.js`
- `renderer.subtitleEditor.js`

`renderer.js` handles global tab switching, preset defaults, panel bootstrapping, and shared UI plumbing.

### Offline help system

The help docs live in `help/` as markdown source. They are compiled into a static offline help bundle under `resources/help/` by `scripts/build-help.js`.

The help build is intentionally:

- offline
- deterministic
- free of runtime markdown parsing
- compatible with a strict CSP

### Adobe / Premiere integration

The Premiere integration is a CEP panel with source-of-truth files under:

- `cep/extensions/com.leadae.panel/`

Packaging and installation expect mirrored/generated artifacts under:

- `resources/cep/extensions/com.leadae.panel/`
- `resources/cep/zxp/LeadAEAssist_CEP.zxp`

The desktop app talks to the CEP panel through a tokenized loopback bridge rather than by exposing random network endpoints.

---

## Repository layout

```text
.
├── main.js                    # Electron main process
├── preload.js                 # secure renderer bridge
├── index.html                 # main app shell
├── subtitle-editor.html       # subtitle editor window
├── renderer*.js               # panel/window renderer code
├── ai/                        # transcription, subtitle, and caption utilities
├── ipc/                       # main-process IPC handlers
├── modules/                   # job runners and app business logic
├── utils/                     # shared helpers, guards, startup/runtime asset code
├── platform/                  # platform-specific path helpers
├── cep/                       # Premiere CEP extension source
├── build/                     # packaging, signing, post-pack hooks
├── scripts/                   # build/test/release/runtime-asset scripts
├── config/                    # runtime config, defaults, manifests, keysets
├── help/                      # source markdown for offline help
├── docs/                      # maintainer docs and runbooks
├── locales/                   # UI translations
├── legal/                     # third-party notices and licenses
└── images/                    # product assets/icons
```

### Important generated outputs

These are expected during normal development or packaging, but are not canonical source:

- `resources/help/` — generated help bundle
- `resources/cep/extensions/` — mirrored CEP panel for packaging/runtime
- `resources/cep/zxp/LeadAEAssist_CEP.zxp` — signed CEP archive
- `dist-obfuscated/` — obfuscated renderer bundles + source maps
- `release/` — Electron build artifacts and staged runtime assets

---

## Development prerequisites

### Required base tooling

- **Node.js + npm** — this repo uses npm and ships a `package-lock.json`.
- **Electron dependencies installed locally** through `npm install`.
- **FFmpeg and FFprobe** available through the repo’s expected runtime location (`extra/ffmpeg/`) or a supported override.

### Required for full feature coverage

Depending on what you are testing, you may also need:

- the missing `services/` directory from the full workspace
- the app’s runtime/public config files under `config/`
- CEP signing assets for packaging
- staged runtime assets for Chromium and Whisper models
- local Python/venv resources for WhisperX, diarization, or packaged AI flows
- the Premiere CEP panel mirror under `resources/cep/extensions/`

### Host platform note

The app source includes cross-platform path handling and user-data paths for macOS and Windows, but the current Electron Builder configuration is set up for **macOS arm64 distribution artifacts** (`zip` and `pkg`).

If you are packaging releases, assume macOS is the supported build host.

---

## First-time setup

From the repository root:

```bash
npm install
npm run copy:adobe-utils
npm start
```

What those steps do:

- `npm install` installs dependencies and Husky hooks.
- `npm run copy:adobe-utils` regenerates `resources/cep/extensions/` from the canonical CEP source in `cep/extensions/`.
- `npm start` rebuilds the help bundle and the renderer Sentry bundle, then launches Electron in development mode with `DEBUG_UI=true`.

### Why `copy:adobe-utils` matters

`npm start` does **not** regenerate the CEP mirror for you. If `resources/cep/extensions/` is missing or stale, Premiere-panel-related flows can fail even though the app window opens.

### Why `dist-obfuscated/` may be absent in development

The development script does not generate the full obfuscated renderer set. The app’s script loader is designed to fall back to the plain `renderer*.js` files in development.

Packaged builds are stricter and generate obfuscated assets as part of packaging.

---

## Common development commands

### Day-to-day

```bash
npm start                 # launch the Electron app in development
npm run lint              # run ESLint + legacy dialog audit
npm run lint:fix          # fix what ESLint can fix
npm test                  # run Jest + node:test suites
npm run test:jest         # renderer/browser-oriented tests
npm run test:node         # Node-only suites discovered by scripts/run-node-tests.js
```

### Build and validation helpers

```bash
npm run build:help                # generate resources/help
npm run copy:adobe-utils          # mirror cep/extensions -> resources/cep/extensions
npm run verify:cep-sync           # assert CEP source and packaged mirror match
npm run build:renderer-sentry     # build dist-obfuscated/renderer.sentry.js
npm run verify:csp                # content-security-policy verification
npm run verify:package-config     # package config and runtime-asset guardrails
npm run verify:timecode           # timecode + caption self-tests
npm run codex:audit               # codex compatibility audit
npm run sign:cep-zxp              # sign the Premiere CEP archive
```

### Packaging and release

```bash
npm run build:select-runtime-config
npm run assets:prepare
npm run package
./scripts/dist.sh
LEADAE_BUILD_ENV=prod ./scripts/dist.sh
```

### Important note about tests in this snapshot

The package scripts reference a `test/` tree and `services/entitlement-service/test`, but those directories are not present in this archive. Treat the test commands as part of the **full workspace contract**, not guaranteed to be runnable from this source snapshot alone.

---

## Configuration model

### Public runtime config

The app loads non-secret runtime settings from `config/public.runtime*.json` and from selected environment overrides.

These files contain safe, public client-side values such as:

- entitlement service URL
- allowed portal/billing hosts
- Paddle environment/client token/prices
- runtime asset base URL

Relevant files:

- `config/public.runtime.example.json`
- `config/public.runtime.json`
- `config/public.runtime.prod.json`
- `config/public.runtime.selected.json`

### Never put secrets in public runtime config

This repo intentionally treats `public.runtime*.json` as **public** desktop configuration. Do not store server secrets, shared client auth secrets, or private signing material there.

### Runtime selection

Packaging uses `LEADAE_BUILD_ENV` and `scripts/select-runtime-config.js` to select the correct runtime config and write `config/public.runtime.selected.json`.

Supported values:

- `sandbox`
- `prod`

Do **not** manually swap files around for release builds. Use the selection script or the canonical packaging wrapper.

### Defaults and persisted app state

Important config files in source:

- `config/defaults.json` — product defaults
- `config/runtime.assets.manifest.json` — packaged runtime-asset manifest
- `config/license-verification-keys.json` — public verification keyset for entitlement validation
- `config/sentry.json` / `config/sentry.example.json` — crash-reporting DSN config
- `config/state.json` — sample/default persisted state snapshot in this repo

At runtime, the user’s live mutable state is stored under the app data directory, not back into the repository checkout.

### Sensitive values

Sensitive values such as the AI API key are stored through `modules/secureStore.js`, separate from plain `state.json` storage.

The renderer can detect whether a key exists and can update or delete it, but it does not get the raw secret value back.

---

## Key environment variables

The repo uses a fairly large set of environment flags. These are the ones most likely to matter in normal work.

### Development / runtime

- `DEBUG_UI=true` — enables development UI behavior; `npm start` sets this.
- `NODE_ENV=development|production|test` — standard environment mode.
- `USER_DATA_PATH` — override the app’s user-data location.
- `OPENAI_API_KEY` — used by WhisperAPI and translation paths in development if no key is stored in the app.
- `FFMPEG_DIR` — override FFmpeg binary location when supported by the bridge layer.
- `LEADAE_ENTITLEMENT_URL`, `PADDLE_ENV`, `PADDLE_CLIENT_TOKEN`, `PADDLE_PRICE_MONTHLY`, `PADDLE_PRICE_YEARLY`, `LEADAE_ASSETS_BASE_URL`, `LEADAE_PORTAL_ALLOWED_HOSTS` — public runtime config overrides.
- `LEAD_AE_ENABLE_LEGACY_SYNC_FS=1` — temporary compatibility flag for legacy sync-only renderer filesystem flows during migration. Do not rely on this long-term.

### Runtime asset staging

- `LEADAE_BUILD_ENV=sandbox|prod`
- `LEADAE_WHISPER_BASE_EN_PATH`
- `LEADAE_WHISPER_BASE_MULTI_PATH`
- `LEADAE_CHROMIUM_STAGE_DIR`
- legacy alias: `LEADAE_PUPPETEER_CHROME_DIR`

### Packaging / signing

- `CEP_P12_PATH`
- `CEP_P12_PASSWORD`
- `CEP_TSA_URL`
- `CSC_NAME`
- `APPLE_NOTARYTOOL_PROFILE`
- optional Apple notarization/signing values referenced by build hooks such as `APPLE_ID`, `APPLE_TEAM_ID`, and `APPLE_APP_SPECIFIC_PASSWORD`

### Publish behavior

- `LEADAE_PUBLISH_MODE=always|never|onTag|onTagOrDraft`
- `LEADAE_PUBLISH_RUNTIME_ASSETS=1` to upload staged runtime assets after packaging

---

## Runtime assets

The packaged app no longer assumes Chromium and Whisper models are permanently bundled inside the app package.

The runtime asset system uses:

- `config/runtime.assets.manifest.json`
- `scripts/build-runtime-assets-manifest.js`
- `scripts/prepare-runtime-assets.js`
- `scripts/publish-runtime-assets.js`
- startup/runtime helpers in `utils/runtimeAssetsManifest.js`, `utils/runtimeAssetIntegrity.js`, `utils/startupRuntimeAssets.js`, and related IPC handlers

### Assets currently described in the manifest

The manifest in this snapshot declares assets for:

- Whisper English base model
- Whisper multilingual base model
- Chromium archive for macOS arm64

### Expected workflow

1. Select runtime config with `LEADAE_BUILD_ENV`.
2. Stage assets with `npm run assets:prepare`.
3. Ship the packaged manifest inside the app.
4. Optionally publish staged assets with `npm run assets:publish`.

### Important packaging rule

Do not reintroduce vendored Chromium or bundled Whisper model directories into the app package. The build scripts explicitly guard against that.

---

## Premiere CEP panel and Adobe bridge

Premiere integration has three distinct pieces:

1. **CEP source** in `cep/extensions/com.leadae.panel/`
2. **Packaged mirror** in `resources/cep/extensions/com.leadae.panel/`
3. **Signed installable archive** at `resources/cep/zxp/LeadAEAssist_CEP.zxp`

The desktop app can install/repair the user-scope CEP panel from Preferences.

### CEP host target

The extension manifest targets Premiere hosts:

- `PPRO`
- `PPROBeta`

### Bridge design

The app uses a secure loopback bridge with credentials and tokenized messaging rather than an open, unauthenticated control socket. The Electron side exposes bridge info through IPC, and the CEP side talks back over localhost.

### Common dev gotcha

If the Premiere workflow is broken, verify these before digging deeper:

- `resources/cep/extensions/` was regenerated from `cep/extensions/`
- the signed ZXP exists for packaging/install tests
- the CEP panel is installed in the user CEP folder
- the bridge is running and the panel is connected

---

## Security model

This repo is stricter than the average “just wire Electron to the filesystem and pray” app.

### Renderer isolation

The renderer is sandboxed and uses preload mediation instead of unrestricted Node APIs.

### IPC allowlisting

Only explicitly allowed IPC channels are exposed to the renderer.

### Filesystem path approval

Renderer-initiated file access is restricted to:

- allowlisted app data subdirectories
- user-approved file/folder roots selected through native dialogs

Path guards reject:

- unapproved paths
- non-absolute paths by default
- network/URI schemes in path contexts

### Offline Mode

Offline Mode is a real network gate, not a cosmetic toggle. Non-local network access is blocked while localhost/loopback services remain available for internal workflows such as the CEP bridge.

### Secret storage

Sensitive values are encrypted and stored separately from ordinary JSON preferences.

### Desktop entitlement verification

The desktop app ships public verification keys, not private signing keys. Verification key rotation is documented in `docs/license-key-rotation-runbook.md`.

---

## Logging, data locations, and support artifacts

The app’s canonical runtime data root is `LeadAEAssist` under the user’s application support/appdata location.

Typical locations:

### macOS

```text
~/Library/Application Support/LeadAEAssist/
```

### Windows

```text
%APPDATA%\LeadAEAssist\
```

### Important subfolders

- `logs/` — raw per-job and watch-session logs
- `config/` — persisted state and presets
- `cache/` — app cache
- `temp/` — temporary working files
- `previews/` — preview-related files

### Panel log behavior

Not every workflow writes the same kind of output-side log:

- **Ingest** can write destination-side logs and failure/retry lists.
- **Transcode** can write destination-side logs when enabled.
- **Transcribe** primarily archives raw logs in the app log library.
- **Project Organizer**, **Preferences**, **Account & Licensing**, and **Subtitle Editor** rely more heavily on raw app logs, config state, reports, and screenshots than on destination-side log exports.

### Log Viewer scope

The built-in Log Viewer reads the app’s canonical raw log library. It does **not** recursively inspect arbitrary user output folders.

---

## Localization

The UI currently ships locale files for:

- English
- French
- Spanish
- German
- Japanese
- Chinese

Source files live under `locales/`, and `i18n.js` loads them into the renderer.

---

## Packaging and release notes

Release packaging is documented in `docs/release-packaging.md` and automated through `scripts/dist.sh`.

### Current release assumptions

- supported packaging host: **macOS**
- target artifacts: **`zip` and `pkg` for arm64**
- signing/notarization and CEP signing are part of the canonical release path

### Canonical release commands

Sandbox/test packaging:

```bash
./scripts/dist.sh
```

Production packaging:

```bash
LEADAE_BUILD_ENV=prod ./scripts/dist.sh
```

### What the release path does

The canonical release flow:

- selects the correct runtime config
- stages runtime assets and refreshes the manifest
- rebuilds the help bundle if needed
- regenerates the CEP packaged mirror
- signs the CEP archive
- validates packaging config rules
- runs Electron Builder
- optionally publishes runtime assets

### Packaging workspace requirements

For a successful signed release build you need, at minimum:

- the full workspace, including omitted paths from this snapshot
- Apple signing/notarization access
- CEP signing certificate + password
- FFmpeg binaries
- runtime asset source material for Chromium and Whisper models
- local dependencies installed

---

## Troubleshooting the repository itself

### The app window opens, but Premiere integration is broken

Run:

```bash
npm run copy:adobe-utils
npm run verify:cep-sync
```

### Help window says content is missing

Run:

```bash
npm run build:help
```

### Packaging fails because required files are missing

Check for the missing workspace pieces listed near the top of this README, especially:

- `services/`
- `extra/ffmpeg/`
- `resources/cep/`
- `dist-obfuscated/`
- runtime asset source directories
- signing materials

### Packaging fails because runtime config is “wrong”

Do not hand-edit package-time file swaps. Regenerate the selected runtime config through:

```bash
npm run build:select-runtime-config
```

with the correct `LEADAE_BUILD_ENV`.

### Tests do not run in this archive

That is expected if the missing `test/` tree and related private service folders were not included in the snapshot.

---

## Maintainer notes

- `cep/extensions/` is the **source of truth** for the Premiere panel. `resources/cep/extensions/` is generated.
- `help/` is the **source of truth** for offline help. `resources/help/` is generated.
- Packaged builds expect the signed CEP archive to exist at `resources/cep/zxp/LeadAEAssist_CEP.zxp`.
- Packaged builds expect `dist-obfuscated/` bundles and source maps to be fresh.
- The packaging guards intentionally reject temporary config files, example configs, and any attempt to sneak client secrets into desktop config.
- Runtime assets are externalized on purpose. Do not quietly rebundle them and call it progress.

---

## Legal and third-party notices

Relevant notices in this repo include:

- `LICENSE`
- `legal/NOTICE.md`
- `legal/FFmpeg-LGPLv2.1.txt`
- `legal/Electron-MIT.txt`

The first-party LeadAEAssist codebase and assets are proprietary. Third-party notices under `legal/` do not grant rights to copy or redistribute first-party LeadAEAssist materials.

Review those files before distributing builds externally.

