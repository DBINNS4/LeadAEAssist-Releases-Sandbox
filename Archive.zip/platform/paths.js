'use strict';

// platform/paths.js
// -----------------------------------------------------------------------------
// Cross-platform path helpers.
//
// Goals:
//   • One canonical app data root for BOTH the desktop app and the CEP bridge.
//   • macOS:  ~/Library/Application Support/LeadAEAssist
//   • Windows: %APPDATA%\LeadAEAssist
//   • Keep working in main, preload, and test/CLI contexts.
// -----------------------------------------------------------------------------

const fs = require('fs');
const os = require('os');
const path = require('path');

const DEFAULT_APP_DIR = 'LeadAEAssist';

function _getElectronAppSafe() {
  try {
    // In the main process this yields the real app object.
    // In preload/renderer, electron.app is typically undefined.
    const electron = require('electron');
    const app = electron?.app;
    if (app && typeof app.getPath === 'function') return app;
  } catch {
    // ignore
  }
  return null;
}

function getAppDataBase() {
  // Prefer Electron's authoritative value when available.
  const app = _getElectronAppSafe();
  if (app) {
    try {
      return app.getPath('appData');
    } catch {
      // ignore and fall through
    }
  }

  // Fallbacks for contexts where Electron isn't available.
  if (process.platform === 'win32') {
    return process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  }
  if (process.platform === 'darwin') {
    return path.join(os.homedir(), 'Library', 'Application Support');
  }
  return process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config');
}

function getUserDataRoot(appDirName = DEFAULT_APP_DIR) {
  // If main has already published a canonical path, treat it as the source of truth.
  const env = process.env.USER_DATA_PATH;
  if (typeof env === 'string' && env.trim()) return env;
  return path.join(getAppDataBase(), appDirName);
}

function ensureDirSync(dir) {
  try {
    fs.mkdirSync(dir, { recursive: true });
  } catch {
    // best-effort
  }
  return dir;
}

function getConfigDir(appDirName = DEFAULT_APP_DIR) {
  return path.join(getUserDataRoot(appDirName), 'config');
}

function getLogsDir(appDirName = DEFAULT_APP_DIR) {
  return path.join(getUserDataRoot(appDirName), 'logs');
}

function getPresetsDir(appDirName = DEFAULT_APP_DIR) {
  return path.join(getUserDataRoot(appDirName), 'presets');
}

module.exports = {
  DEFAULT_APP_DIR,
  getAppDataBase,
  getUserDataRoot,
  ensureDirSync,
  getConfigDir,
  getLogsDir,
  getPresetsDir
};
