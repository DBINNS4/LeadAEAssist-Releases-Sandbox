'use strict';

// Central progress event normalization + adapters.
// Canonical payload fields: { id, panel, stage, overall, filePercent, eta, file, status }

function clamp100(x) {
  return Math.max(0, Math.min(100, Number(x) || 0));
}

function normalizeProgressPayload(d = {}) {
  const id = d.id ?? d.jobId;
  const panel = d.panel || 'unknown';
  const stage = d.stage || 'copy';
  const overall = ('overall' in d) ? clamp100(d.overall) : clamp100(d.percent);
  const filePercent = ('filePercent' in d)
    ? clamp100(d.filePercent)
    : (d.percentFile != null ? clamp100(d.percentFile) : undefined);
  const eta = d.eta;
  const file = d.file;
  const status = d.status;

  const payload = { id, panel, stage, overall, filePercent, eta, file, status };
  // Back-compat alias
  payload.percent = overall;
  return payload;
}

function emitProgress(data) {
  const p = normalizeProgressPayload(data);
  try { global.queue?.emit?.('job-progress', p); } catch {
    // Ignore emit errors to avoid breaking reporting
  }
  return p;
}

// Wire an existing ProgressManager to emit the unified contract.
// Expects manager to emit: 'stream-progress', 'overall-progress', 'file-status', 'file-complete'
function bindProgressManager(manager, meta = {}) {
  if (!manager) return () => {};
  const id = meta.id || meta.jobId;
  const panel = meta.panel || 'unknown';
  const stage = meta.stage || 'copy';

  const onStream = (e) => emitProgress({
    id, panel, stage,
    file: e.file,
    filePercent: e.percent,
    overall: e.overall,
    eta: e.eta,
    status: e.statusMap
  });
  const onOverall = (e) => emitProgress({
    id, panel, stage,
    overall: e.overall,
    eta: e.eta,
    status: 'active'
  });
  const onFileStatus = (e) => emitProgress({
    id, panel, stage,
    file: e.file,
    filePercent: e.percent,
    status: e.statusMap
  });
  const onFileComplete = (e) => emitProgress({
    id, panel, stage,
    file: e.file,
    filePercent: 100,
    status: { ...(e.statusMap || {}), complete: true }
  });

  manager.on?.('stream-progress', onStream);
  manager.on?.('overall-progress', onOverall);
  manager.on?.('file-status', onFileStatus);
  manager.on?.('file-complete', onFileComplete);

  return () => {
    try { manager.off?.('stream-progress', onStream); } catch {}
    try { manager.off?.('overall-progress', onOverall); } catch {}
    try { manager.off?.('file-status', onFileStatus); } catch {}
    try { manager.off?.('file-complete', onFileComplete); } catch {}
  };
}

// Weighted stage progress — drop-in replacement for the Adobe StageProgressManager,
// but emits the canonical ProgressEvent.
class StageProgressManager {
  constructor(jobId, stages, panel = 'adobe-utilities') {
    this.jobId = jobId;
    this.panel = panel;
    this.stages = Array.isArray(stages) ? stages : [];
    this.currentIndex = -1;
    this.stagePercent = 0;
    this.totalForStage = 0;
    this.doneForStage = 0;
    this.lastOverall = 0;
  }
  startStage(key, total = 100) {
    this.currentIndex = this.stages.findIndex((s) => s.key === key);
    this.stagePercent = 0;
    this.doneForStage = 0;
    this.totalForStage = total;
    this._emit();
  }
  updateStageProgress(done, total) {
    this.doneForStage = done;
    this.totalForStage = total;
    const pct = total > 0 ? (done / total) * 100 : 0;
    this.stagePercent = Math.max(this.stagePercent, pct); // monotonic within stage
    this._emit();
  }
  completeStage() {
    this.stagePercent = 100;
    this._emit('complete');
  }
  _emit(status = 'active') {
    const stage = this.stages[this.currentIndex] || { key: 'unknown', label: 'Unknown', weight: 1 };
    const prevWeight = this.stages.slice(0, this.currentIndex).reduce((sum, x) => sum + (x.weight || 0), 0);
    const weight = stage.weight || 0;
    const overall01 = Math.max(this.lastOverall, prevWeight + weight * (this.stagePercent / 100));
    this.lastOverall = overall01;
    emitProgress({
      id: this.jobId,
      panel: this.panel,
      stage: stage.key,
      overall: overall01 * 100, // canonical 0..100
      filePercent: this.stagePercent, // stage-local percent
      status
    });
  }
}

module.exports = {
  normalizeProgressPayload,
  emitProgress,
  bindProgressManager,
  StageProgressManager,
};
