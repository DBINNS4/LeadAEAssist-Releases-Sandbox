// utils/cepLoader.js
// Load CSInterface only inside Adobe CEP.
// Kept external (no inline script) to support a strict CSP.

(() => {
  try {
    if (window.__adobe_cep__) {
      const s = document.createElement('script');
      s.src = 'resources/cep/extensions/com.leadae.panel/CSInterface.js';
      document.head.appendChild(s);
    }
  } catch (_) {
    // No-op: CEP environment is optional.
  }
})();
