'use strict';

const fs = require('fs');
const path = require('path');

/**
 * Load non-secret runtime config that can safely ship with the desktop app.
 *
 * Precedence:
 *  1) Explicit env vars (useful for CI / terminal-launched tests)
 *  2) public.runtime.json (packaged resources or dev cwd)
 *  3) Dev-only fallback defaults (optional)
 *
 * IMPORTANT: Never include secrets here. Paddle API keys / webhook secrets stay server-side.
 * Also: do not load any shared "client auth" secret from files in a packaged app. If you
 * choose to use client auth, provide it via explicit env var in controlled environments. 
 */
function loadPublicRuntimeConfig(options = {}) {
  const isPackaged = !!options.isPackaged;
  const allowDefaults = options.allowDefaults === true;

  // Env override (safe public values only)
  const envCfg = {
    entitlementUrl: process.env.LEADAE_ENTITLEMENT_URL,
    portalAllowedHosts: process.env.LEADAE_PORTAL_ALLOWED_HOSTS,
    assets: {
      baseUrl: process.env.LEADAE_ASSETS_BASE_URL
    },
    paddle: {
      env: process.env.PADDLE_ENV,
      clientToken: process.env.PADDLE_CLIENT_TOKEN,
      priceMonthly: process.env.PADDLE_PRICE_MONTHLY,
      priceYearly: process.env.PADDLE_PRICE_YEARLY
    }
  };

  const hasPaddleEnv =
    !!(envCfg.paddle.env && envCfg.paddle.clientToken && (envCfg.paddle.priceMonthly || envCfg.paddle.priceYearly));
  const hasEntitlementUrl = !!(envCfg.entitlementUrl && String(envCfg.entitlementUrl).trim());
  const hasAssetsBaseUrl = !!(envCfg.assets.baseUrl && String(envCfg.assets.baseUrl).trim());

  if (hasPaddleEnv || hasEntitlementUrl || hasAssetsBaseUrl) {
    const envPortalHosts = String(envCfg.portalAllowedHosts || '')
      .split(',')
      .map((v) => v.trim())
      .filter(Boolean);
    return {
      entitlementUrl: String(envCfg.entitlementUrl || '').trim(),
      portalAllowedHosts: envPortalHosts,
      assets: { baseUrl: String(envCfg.assets.baseUrl || '').trim() },
      paddle: {
        env: String(envCfg.paddle.env || '').trim(),
        clientToken: String(envCfg.paddle.clientToken || '').trim(),
        priceMonthly: String(envCfg.paddle.priceMonthly || '').trim(),
        priceYearly: String(envCfg.paddle.priceYearly || '').trim()
      }
    };
  }

  const candidates = isPackaged
    ? [
        path.join(process.resourcesPath, 'config', 'public.runtime.json'),
        path.join(process.resourcesPath, 'public.runtime.json')
      ]
    : [
        path.join(process.cwd(), 'config', 'public.runtime.json')
      ];

  for (const p of candidates) {
    try {
      if (!fs.existsSync(p)) continue;
      const j = JSON.parse(fs.readFileSync(p, 'utf8'));
      if (!j || typeof j !== 'object') continue;
      const entUrl = String(j.entitlementUrl || '').trim();
      const paddle = j.paddle && typeof j.paddle === 'object' ? j.paddle : {};
      const assets = (j.assets && typeof j.assets === 'object') ? j.assets : {};
      const cfg = {
        entitlementUrl: entUrl,
        portalAllowedHosts: Array.isArray(j.portalAllowedHosts)
          ? j.portalAllowedHosts.map((v) => String(v || '').trim()).filter(Boolean)
          : [],
        billingHosts: Array.isArray(j.billingHosts)
          ? j.billingHosts.map((v) => String(v || '').trim()).filter(Boolean)
          : [],
        entitlementHosts: Array.isArray(j.entitlementHosts)
          ? j.entitlementHosts.map((v) => String(v || '').trim()).filter(Boolean)
          : [],
        assets: {
          baseUrl: String(assets.baseUrl || '').trim()
        },
        paddle: {
          env: String(paddle.env || '').trim(),
          clientToken: String(paddle.clientToken || '').trim(),
          priceMonthly: String(paddle.priceMonthly || '').trim(),
          priceYearly: String(paddle.priceYearly || '').trim()
        }
      };
      // Accept partials: entitlementUrl-only is valid for license sync; paddle-only is valid for checkout.
      if (cfg.entitlementUrl || cfg.paddle.clientToken || cfg.assets.baseUrl) return cfg;
    } catch {
      // ignore bad JSON or unreadable file
    }
  }

  if (allowDefaults) {
    // Dev-only convenience defaults. Never relied upon in packaged builds.
    return {
      entitlementUrl: String(process.env.LEADAE_ENTITLEMENT_URL || '').trim(),
      portalAllowedHosts: String(process.env.LEADAE_PORTAL_ALLOWED_HOSTS || '')
        .split(',')
        .map((v) => v.trim())
        .filter(Boolean),
      assets: { baseUrl: String(process.env.LEADAE_ASSETS_BASE_URL || '').trim() },
      paddle: {
        env: String(process.env.PADDLE_ENV || 'sandbox').trim(),
        clientToken: String(process.env.PADDLE_CLIENT_TOKEN || '').trim(),
        priceMonthly: String(process.env.PADDLE_PRICE_MONTHLY || '').trim(),
        priceYearly: String(process.env.PADDLE_PRICE_YEARLY || '').trim()
      }
    };
  }

  return {
    entitlementUrl: '',
    portalAllowedHosts: [],
    billingHosts: [],
    entitlementHosts: [],
    assets: { baseUrl: '' },
    paddle: { env: '', clientToken: '', priceMonthly: '', priceYearly: '' }
  };
}

module.exports = { loadPublicRuntimeConfig };
