// utils/indexStartup.js
// Main-window-only bootstrap that previously lived in an inline <script>.
// Kept external to support a strict CSP.

(() => {
  function bootstrapMainWindow() {
    const isEditorWin = new URLSearchParams(location.search).get('win') === 'subtitle-editor';
    if (isEditorWin) return;

    // Hide all panels by default; renderer.js handles showing the selected one.
    document.querySelectorAll('.panel-section').forEach(panel => panel.classList.add('hidden'));

    // Persist collapsed state so the UI starts in a known-safe baseline.
    try {
      window.electron?.send?.('ui:set-collapsed', true);
    } catch (_) {
      // Ignore if ipc bridge is unavailable (e.g., running outside Electron).
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrapMainWindow, { once: true });
  } else {
    bootstrapMainWindow();
  }
})();
