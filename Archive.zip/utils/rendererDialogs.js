// utils/rendererDialogs.js
// Shared renderer-side helpers for Electron native dialogs and custom typed-confirm modals.

(() => {
  const VALID_TYPES = new Set(['none', 'info', 'error', 'question', 'warning']);
  const FOCUSABLE_SELECTOR = [
    'button:not([disabled])',
    '[href]:not([tabindex="-1"])',
    'input:not([disabled]):not([type="hidden"])',
    'select:not([disabled])',
    'textarea:not([disabled])',
    '[tabindex]:not([tabindex="-1"])'
  ].join(',');

  let textConfirmModalCount = 0;

  const getBridge = () => window.ipc ?? window.electron ?? null;

  function sanitizeText(value, fallback = '', maxLength = 4000) {
    if (value == null) return fallback;
    const normalized = String(value).trim();
    if (!normalized) return fallback;
    return normalized.slice(0, maxLength);
  }

  function sanitizeExpectedText(value, fallback = 'OVERRIDE') {
    const normalized = sanitizeText(value, fallback, 120);
    return normalized || fallback;
  }

  function sanitizeType(value, fallback = 'none') {
    return VALID_TYPES.has(value) ? value : fallback;
  }

  function sanitizeButtons(buttons) {
    if (!Array.isArray(buttons)) return ['OK'];
    const normalized = buttons
      .map((label) => sanitizeText(label, '', 80))
      .filter(Boolean)
      .slice(0, 5);
    return normalized.length ? normalized : ['OK'];
  }

  function clampDialogIndex(value, fallback, maxIndex) {
    const parsed = Number(value);
    if (!Number.isInteger(parsed)) return fallback;
    if (parsed < 0 || parsed > maxIndex) return fallback;
    return parsed;
  }

  function normalizeMessageDialogOptions(input) {
    const raw = (input && typeof input === 'object' && !Array.isArray(input))
      ? input
      : { message: input };

    const buttons = sanitizeButtons(raw.buttons);
    const maxIndex = Math.max(0, buttons.length - 1);
    const normalized = {
      type: sanitizeType(raw.type, 'none'),
      title: sanitizeText(raw.title, 'LEAD AE - ASSIST', 160),
      message: sanitizeText(raw.message, 'Notice'),
      detail: sanitizeText(raw.detail, '', 8000),
      buttons,
      defaultId: clampDialogIndex(raw.defaultId, 0, maxIndex),
      cancelId: clampDialogIndex(raw.cancelId, 0, maxIndex)
    };

    const checkboxLabel = sanitizeText(raw.checkboxLabel, '', 200);
    if (checkboxLabel) normalized.checkboxLabel = checkboxLabel;
    return normalized;
  }

  function normalizeConfirmActionOptions(input) {
    const raw = (input && typeof input === 'object' && !Array.isArray(input))
      ? input
      : { message: input };

    const cancelLabel = sanitizeText(raw.cancelLabel, 'Cancel', 80);
    const okLabel = sanitizeText(raw.okLabel, 'Yes', 80);
    const normalized = {
      type: sanitizeType(raw.type, 'warning'),
      title: sanitizeText(raw.title, 'Confirm', 160),
      message: sanitizeText(raw.message, 'Are you sure?'),
      detail: sanitizeText(raw.detail, '', 8000),
      okLabel,
      cancelLabel,
      defaultId: Number.isInteger(raw.defaultId) ? raw.defaultId : 1,
      cancelId: Number.isInteger(raw.cancelId) ? raw.cancelId : 0
    };

    const checkboxLabel = sanitizeText(raw.checkboxLabel, '', 200);
    if (checkboxLabel) normalized.checkboxLabel = checkboxLabel;
    return normalized;
  }

  function normalizeTextConfirmOptions(input) {
    const raw = (input && typeof input === 'object' && !Array.isArray(input))
      ? input
      : { message: input };

    const expectedText = sanitizeExpectedText(raw.expectedText, 'OVERRIDE');
    return {
      title: sanitizeText(raw.title, 'Confirm action', 160),
      message: sanitizeText(raw.message, `Type ${expectedText} to continue.`, 8000),
      detail: sanitizeText(raw.detail, '', 8000),
      expectedText,
      inputLabel: sanitizeText(raw.inputLabel, `Type ${expectedText} to continue`, 160),
      inputPlaceholder: sanitizeText(raw.inputPlaceholder, expectedText, 120),
      confirmLabel: sanitizeText(raw.confirmLabel, 'Continue', 80),
      cancelLabel: sanitizeText(raw.cancelLabel, 'Cancel', 80),
      hint: sanitizeText(raw.hint, `Type ${expectedText} to confirm this action.`, 240),
      matchMode: raw.matchMode === 'exact' ? 'exact' : 'case-insensitive',
      dismissOnBackdrop: raw.dismissOnBackdrop !== false
    };
  }

  function getFocusableElements(root) {
    if (!root || typeof root.querySelectorAll !== 'function') return [];
    return Array.from(root.querySelectorAll(FOCUSABLE_SELECTOR)).filter((element) => {
      if (!(element instanceof HTMLElement)) return false;
      if (element.hidden) return false;
      if (element.getAttribute('aria-hidden') === 'true') return false;
      return true;
    });
  }

  function valuesMatch(value, expectedText, matchMode = 'case-insensitive') {
    const normalizedInput = String(value ?? '').trim();
    const normalizedExpected = String(expectedText ?? '').trim();
    if (!normalizedExpected) return false;
    if (matchMode === 'exact') {
      return normalizedInput === normalizedExpected;
    }
    return normalizedInput.toUpperCase() === normalizedExpected.toUpperCase();
  }

  async function showMessageDialog(input = {}) {
    const bridge = getBridge();
    if (typeof bridge?.showMessageDialog !== 'function') {
      throw new Error('Native message dialog bridge unavailable');
    }
    return bridge.showMessageDialog(normalizeMessageDialogOptions(input));
  }

  async function confirmAction(input = {}) {
    const bridge = getBridge();
    const normalized = normalizeConfirmActionOptions(input);
    const buttons = [normalized.cancelLabel, normalized.okLabel];
    const okButtonIndex = buttons.length - 1;

    if (typeof bridge?.showMessageDialog === 'function') {
      const result = await bridge.showMessageDialog({
        type: normalized.type,
        title: normalized.title,
        message: normalized.message,
        detail: normalized.detail,
        buttons,
        defaultId: clampDialogIndex(normalized.defaultId, okButtonIndex, buttons.length - 1),
        cancelId: clampDialogIndex(normalized.cancelId, 0, buttons.length - 1),
        checkboxLabel: normalized.checkboxLabel
      });
      return Number(result?.response) === okButtonIndex;
    }

    if (typeof bridge?.showConfirmDialog === 'function') {
      return !!(await bridge.showConfirmDialog(normalized));
    }

    if (typeof bridge?.showConfirm === 'function') {
      return !!(await bridge.showConfirm(normalized));
    }

    throw new Error('Native confirm dialog bridge unavailable');
  }

  async function showNativeNotice(input = {}) {
    const normalized = normalizeMessageDialogOptions(input);
    normalized.type = sanitizeType(input?.type, 'info');
    return showMessageDialog(normalized);
  }

  async function confirmTextInput(input = {}) {
    if (typeof document === 'undefined' || !document.body) {
      throw new Error('Text confirm modal requires document.body');
    }

    const options = normalizeTextConfirmOptions(input);

    return new Promise((resolve) => {
      const modalId = ++textConfirmModalCount;
      const titleId = `renderer-text-confirm-title-${modalId}`;
      const descriptionId = `renderer-text-confirm-description-${modalId}`;
      const detailId = `renderer-text-confirm-detail-${modalId}`;
      const hintId = `renderer-text-confirm-hint-${modalId}`;
      const inputId = `renderer-text-confirm-input-${modalId}`;
      const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;

      let settled = false;
      const overlay = document.createElement('div');
      overlay.className = 'text-confirm-modal';

      const panel = document.createElement('div');
      panel.className = 'panel';
      panel.setAttribute('role', 'dialog');
      panel.setAttribute('aria-modal', 'true');
      panel.setAttribute('aria-labelledby', titleId);
      panel.setAttribute(
        'aria-describedby',
        options.detail ? `${descriptionId} ${detailId} ${hintId}` : `${descriptionId} ${hintId}`
      );
      panel.tabIndex = -1;

      const header = document.createElement('div');
      header.className = 'header';
      const titleEl = document.createElement('strong');
      titleEl.id = titleId;
      titleEl.textContent = options.title;
      const spacer = document.createElement('div');
      spacer.className = 'spacer';
      const closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = 'close';
      closeBtn.textContent = options.cancelLabel;
      header.append(titleEl, spacer, closeBtn);

      const body = document.createElement('div');
      body.className = 'body';
      const messageEl = document.createElement('p');
      messageEl.className = 'message';
      messageEl.id = descriptionId;
      messageEl.textContent = options.message;
      body.appendChild(messageEl);
      if (options.detail) {
        const detailEl = document.createElement('p');
        detailEl.className = 'detail';
        detailEl.id = detailId;
        detailEl.textContent = options.detail;
        body.appendChild(detailEl);
      }
      const row = document.createElement('div');
      row.className = 'row';
      const labelEl = document.createElement('label');
      labelEl.htmlFor = inputId;
      labelEl.textContent = options.inputLabel;
      const inputEl = document.createElement('input');
      inputEl.type = 'text';
      inputEl.id = inputId;
      inputEl.placeholder = options.inputPlaceholder;
      inputEl.autocomplete = 'off';
      inputEl.spellcheck = false;
      inputEl.setAttribute('autocapitalize', 'characters');
      row.append(labelEl, inputEl);
      body.appendChild(row);
      const hintEl = document.createElement('div');
      hintEl.className = 'hint';
      hintEl.id = hintId;
      hintEl.textContent = options.hint;
      body.appendChild(hintEl);

      const footer = document.createElement('div');
      footer.className = 'footer';
      const cancelBtn = document.createElement('button');
      cancelBtn.type = 'button';
      cancelBtn.className = 'btn';
      cancelBtn.textContent = options.cancelLabel;
      const confirmBtn = document.createElement('button');
      confirmBtn.type = 'button';
      confirmBtn.className = 'btn primary';
      confirmBtn.textContent = options.confirmLabel;
      confirmBtn.disabled = true;
      footer.append(cancelBtn, confirmBtn);

      panel.append(header, body, footer);
      overlay.appendChild(panel);

      const cleanup = (result) => {
        if (settled) return;
        settled = true;
        overlay.removeEventListener('mousedown', onBackdropMouseDown);
        overlay.removeEventListener('keydown', onOverlayKeyDown);
        closeBtn.removeEventListener('click', onCancel);
        cancelBtn.removeEventListener('click', onCancel);
        confirmBtn.removeEventListener('click', onConfirm);
        inputEl.removeEventListener('input', syncConfirmState);
        document.removeEventListener('focusin', onDocumentFocusIn, true);
        try { overlay.remove(); } catch {}
        try { previousFocus?.focus(); } catch {}
        resolve(result);
      };

      const onCancel = () => cleanup({ confirmed: false, value: String(inputEl.value || '').trim() });
      const onConfirm = () => {
        if (confirmBtn.disabled) return;
        cleanup({ confirmed: true, value: String(inputEl.value || '').trim() });
      };

      const syncConfirmState = () => {
        const matched = valuesMatch(inputEl.value, options.expectedText, options.matchMode);
        confirmBtn.disabled = !matched;
        confirmBtn.setAttribute('aria-disabled', matched ? 'false' : 'true');
      };

      const onBackdropMouseDown = (event) => {
        if (options.dismissOnBackdrop && event.target === overlay) {
          onCancel();
        }
      };

      const onOverlayKeyDown = (event) => {
        if (event.key === 'Escape') {
          event.preventDefault();
          onCancel();
          return;
        }

        if (event.key === 'Enter' && document.activeElement === inputEl) {
          if (confirmBtn.disabled) {
            event.preventDefault();
            return;
          }
          event.preventDefault();
          onConfirm();
          return;
        }

        if (event.key !== 'Tab') return;

        const focusables = getFocusableElements(panel);
        if (!focusables.length) {
          event.preventDefault();
          panel.focus();
          return;
        }

        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        const active = document.activeElement;

        if (event.shiftKey) {
          if (active === first || !panel.contains(active)) {
            event.preventDefault();
            last.focus();
          }
          return;
        }

        if (active === last) {
          event.preventDefault();
          first.focus();
        }
      };

      const onDocumentFocusIn = (event) => {
        if (settled || overlay.contains(event.target)) return;
        const focusables = getFocusableElements(panel);
        const nextFocus = focusables[0] || inputEl || panel;
        try { nextFocus.focus(); } catch {}
      };

      overlay.addEventListener('mousedown', onBackdropMouseDown);
      overlay.addEventListener('keydown', onOverlayKeyDown);
      closeBtn.addEventListener('click', onCancel);
      cancelBtn.addEventListener('click', onCancel);
      confirmBtn.addEventListener('click', onConfirm);
      inputEl.addEventListener('input', syncConfirmState);
      document.addEventListener('focusin', onDocumentFocusIn, true);

      document.body.appendChild(overlay);
      syncConfirmState();

      const scheduleFocus = typeof window?.requestAnimationFrame === 'function'
        ? window.requestAnimationFrame.bind(window)
        : (fn) => setTimeout(fn, 0);
      scheduleFocus(() => {
        try {
          inputEl.focus();
          inputEl.select();
        } catch {
          try { panel.focus(); } catch {}
        }
      });
    });
  }

  window.rendererDialogs = Object.freeze({
    showMessageDialog,
    showNativeNotice,
    confirmAction,
    confirmTextInput
  });
})();
