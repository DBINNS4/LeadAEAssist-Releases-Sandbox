// utils/formatCapabilities.js
//
// Runtime capabilities for a given output format.
// This exists because FFmpeg builds vary widely ("legal" builds often omit
// libx264/libx265), so UI controls should not be enabled/disabled
// based on static assumptions.

const { detectBestGPUEncoder, getAvailableEncoderSet } = require('./gpuEncoder');
const { getBinaryPaths } = require('./ffmpegBridge');

const __capsCache = new Map();

function getFormatCapabilities(format, ffmpegPathOverride) {
  const formatKey = String(format || '').trim();
  if (!formatKey) return null;

  const { ffmpegPath } = ffmpegPathOverride
    ? { ffmpegPath: ffmpegPathOverride }
    : getBinaryPaths();

  const cacheKey = `${ffmpegPath}::${formatKey}`;
  if (__capsCache.has(cacheKey)) return __capsCache.get(cacheKey);

  const encSet = getAvailableEncoderSet(ffmpegPath);

  let videoEncoder = null;
  const fmt = formatKey.toLowerCase();

  if (fmt.startsWith('prores')) {
    // Prefer the best ProRes encoder available.
    if (encSet.has('prores_ks')) videoEncoder = 'prores_ks';
    else if (encSet.has('prores_aw')) videoEncoder = 'prores_aw';
    else if (encSet.has('prores')) videoEncoder = 'prores';
    else videoEncoder = null;
  } else if (fmt === 'h264') {
    // Prefer libx264 when available.
    videoEncoder = encSet.has('libx264') ? 'libx264' : detectBestGPUEncoder('h264', ffmpegPath);
  } else if (fmt === 'h264_auto_gpu') {
    videoEncoder = detectBestGPUEncoder('h264', ffmpegPath);
  } else if (fmt === 'h265') {
    // Prefer libx265 when available.
    videoEncoder = encSet.has('libx265') ? 'libx265' : detectBestGPUEncoder('hevc', ffmpegPath);
  } else if (fmt === 'vp9') {
    videoEncoder = encSet.has('libvpx-vp9') ? 'libvpx-vp9' : null;
  } else if (fmt === 'av1') {
    if (encSet.has('libaom-av1')) videoEncoder = 'libaom-av1';
    else if (encSet.has('libsvtav1')) videoEncoder = 'libsvtav1';
    else videoEncoder = null;
  } else if (fmt.startsWith('xdcam')) {
    videoEncoder = encSet.has('mpeg2video') ? 'mpeg2video' : null;
  } else if (fmt.startsWith('xavc')) {
    // Prefer x264 if present; otherwise fall back to best H.264 encoder.
    videoEncoder = encSet.has('libx264') ? 'libx264' : detectBestGPUEncoder('h264', ffmpegPath);
  } else if (fmt === 'jpeg2000') {
    if (encSet.has('jpeg2000')) videoEncoder = 'jpeg2000';
    else if (encSet.has('libopenjpeg')) videoEncoder = 'libopenjpeg';
    else videoEncoder = null;
  } else if (fmt === 'ffv1') {
    videoEncoder = encSet.has('ffv1') ? 'ffv1' : null;
  } else if (fmt === 'mjpeg') {
    videoEncoder = encSet.has('mjpeg') ? 'mjpeg' : null;
  } else if (fmt === 'qtrle') {
    videoEncoder = encSet.has('qtrle') ? 'qtrle' : null;
  } else if (fmt === 'dnxhd' || fmt.startsWith('dnxhr_') || fmt.startsWith('dnxhd_')) {
    videoEncoder = encSet.has('dnxhd') ? 'dnxhd' : null;
  } else if (fmt === 'uncompressed_yuv' || fmt === 'uncompressed_rgb') {
    videoEncoder = encSet.has('rawvideo') ? 'rawvideo' : null;
  } else if (fmt.endsWith('_sequence')) {
    // Image sequence formats map to specific image encoders.
    // (These are generally built-in, but we still verify availability.)
    const seqMap = {
      'png_sequence': 'png',
      'tiff_sequence': 'tiff',
      'exr_sequence': 'exr',
      'tga_sequence': 'targa',
      'dpx_sequence': 'dpx',
      // Generic sequence format defaults to PNG.
      'image_sequence': 'png'
    };
    const seqEnc = seqMap[fmt] || 'png';
    videoEncoder = encSet.has(seqEnc) ? seqEnc : (encSet.has('png') ? 'png' : null);
  }

  // Generic fallback: if the format key itself is an encoder name (e.g. dnxhd, cfhd, speedhq, v210),
  // treat it as supported when present in this FFmpeg build.
  if (!videoEncoder && encSet.has(fmt)) {
    videoEncoder = fmt;
  }

  const caps = {
    format: formatKey,
    videoEncoder: videoEncoder,
    encoderAvailable: videoEncoder ? encSet.has(videoEncoder) : false
  };

  __capsCache.set(cacheKey, caps);
  return caps;
}

module.exports = {
  getFormatCapabilities
};
