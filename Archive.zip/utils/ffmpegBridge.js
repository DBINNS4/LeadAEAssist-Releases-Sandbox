'use strict';

// utils/ffmpegBridge.js
// Resolve FFmpeg/FFprobe paths in BOTH dev and packaged builds.
//
// electron-builder default behavior:
// - app code is packed into:   <resources>/app.asar
// - unpacked binaries land in: <resources>/app.asar.unpacked/
//
// IMPORTANT: do not assume process.resourcesPath + '/extra/ffmpeg' exists.
// In most electron-builder setups, binaries are under app.asar.unpacked.

const fs = require('fs');
const path = require('path');
const { spawn, execFile } = require('child_process');

let isPackaged = false;
let electronApp = null;

try {
  const { app } = require('electron');
  electronApp = app || null;
  isPackaged = app?.isPackaged ?? false;
} catch {
  // In unit tests or non-Electron contexts, treat as dev.
  isPackaged = false;
  electronApp = null;
}

function getAppPathSafe() {
  try {
    if (electronApp && typeof electronApp.getAppPath === 'function') {
      return electronApp.getAppPath();
    }
  } catch {
    // ignore
  }
  // Fallback: project root relative to this file.
  return path.join(__dirname, '..');
}

function getBinaryDir() {
  const candidates = [];

  // Optional override for debugging / custom layouts.
  if (process.env.FFMPEG_DIR && typeof process.env.FFMPEG_DIR === 'string') {
    candidates.push(process.env.FFMPEG_DIR);
  }

  if (isPackaged) {
    // Preferred: electron-builder asarUnpack location.
    candidates.push(path.join(process.resourcesPath, 'app.asar.unpacked', 'extra', 'ffmpeg'));
    // Alternate: when using build.extraResources to copy files directly under Resources/.
    candidates.push(path.join(process.resourcesPath, 'extra', 'ffmpeg'));
  }

  // Dev / fallback
  candidates.push(path.join(getAppPathSafe(), 'extra', 'ffmpeg'));
  candidates.push(path.join(__dirname, '..', 'extra', 'ffmpeg'));

  const ffmpegName = process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg';

  for (const dir of candidates) {
    if (!dir) continue;
    try {
      if (fs.existsSync(path.join(dir, ffmpegName))) return dir;
    } catch {
      // ignore and keep scanning
    }
  }

  // Return the first candidate as a best-effort path (callers may show it in errors).
  return candidates[0] || path.join(getAppPathSafe(), 'extra', 'ffmpeg');
}

function getBinaryPaths() {
  const binDir = getBinaryDir();
  const ffmpegName = process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg';
  const ffprobeName = process.platform === 'win32' ? 'ffprobe.exe' : 'ffprobe';

  // Canonical key names used throughout the app.
  const ffmpegPath = path.join(binDir, ffmpegName);
  const ffprobePath = path.join(binDir, ffprobeName);

  return {
    // Preferred keys (used by main.js, gpuEncoder.js, ffmpegService, etc.)
    ffmpegPath,
    ffprobePath,
    binDir,

    // Backwards-compatible aliases (some older code may still use these)
    ffmpeg: ffmpegPath,
    ffprobe: ffprobePath
  };
}

// -----------------------------
// Small FFmpeg/ffprobe helpers
// -----------------------------

function parseAvgFrameRate(value) {
  if (value == null) return null;
  if (typeof value === 'number' && Number.isFinite(value)) return value;

  const s = String(value).trim();
  if (!s) return null;

  // Common ffprobe format: "30000/1001"
  if (s.includes('/')) {
    const [numStr, denStr] = s.split('/', 2);
    const num = parseFloat(numStr);
    const den = parseFloat(denStr);
    if (!Number.isFinite(num) || !Number.isFinite(den) || den === 0) return null;
    return num / den;
  }

  const f = parseFloat(s);
  return Number.isFinite(f) ? f : null;
}

const FFPROBE_JSON_TIMEOUT_MS = 12000;

function isTimeoutError(err) {
  if (!err) return false;
  return err.code === 'ETIMEDOUT' || err.killed || err.signal === 'SIGTERM' || /ETIMEDOUT/i.test(err.message || '');
}

function ffprobeJson(filePath, extraArgs = [], options = {}) {
  const { ffprobePath } = getBinaryPaths();
  const safeExtra = Array.isArray(extraArgs) ? extraArgs.map(a => String(a ?? '')) : [];
  const timeoutMs = Number.isFinite(options?.timeoutMs)
    ? Math.max(0, options.timeoutMs)
    : FFPROBE_JSON_TIMEOUT_MS;
  const args = [
    '-v', 'error',
    '-show_format',
    '-show_streams',
    '-of', 'json',
    ...safeExtra,
    String(filePath ?? '')
  ];

  return new Promise((resolve, reject) => {
    execFile(
      ffprobePath,
      args,
      { maxBuffer: 20 * 1024 * 1024, timeout: timeoutMs },
      (err, stdout, stderr) => {
        if (err) {
          if (isTimeoutError(err)) {
            reject({ code: 'FFPROBE_TIMEOUT', message: 'metadata probe timed out', timeoutMs });
            return;
          }
          const msg = (stderr && String(stderr).trim()) || err.message || String(err);
          reject(new Error(msg));
          return;
        }
        try {
          resolve(JSON.parse(String(stdout || '')));
        } catch (e) {
          reject(e);
        }
      }
    );
  });
}

const FPS_DETECTION_TIMEOUT_MS = 4000;

function detectFrameRate(filePath, options = {}) {
  const { ffprobePath } = getBinaryPaths();
  const timeoutMs = Number.isFinite(options.timeoutMs)
    ? Math.max(0, options.timeoutMs)
    : FPS_DETECTION_TIMEOUT_MS;
  const args = [
    '-v', 'error',
    '-select_streams', 'v:0',
    '-show_entries', 'stream=avg_frame_rate,r_frame_rate',
    '-of', 'json',
    String(filePath ?? '')
  ];

  return new Promise(resolve => {
    execFile(
      ffprobePath,
      args,
      {
        encoding: 'utf-8',
        maxBuffer: 5 * 1024 * 1024,
        timeout: timeoutMs
      },
      (err, stdout) => {
        if (err) {
          resolve(null);
          return;
        }
        try {
          const json = JSON.parse(stdout);
          const stream = Array.isArray(json?.streams) ? json.streams[0] : null;
          const fr = stream?.avg_frame_rate || stream?.r_frame_rate;
          resolve(parseAvgFrameRate(fr));
        } catch {
          resolve(null);
        }
      }
    );
  });
}

async function resolveFps(filePath, config = {}) {
  // Priority:
  //   1) explicit overrides from config
  //   2) ffprobe-detected fps (video)
  //   3) sane default (30)
  const raw = config?.fpsOverride ?? config?.fps;

  if (typeof raw === 'number' && Number.isFinite(raw)) return raw;

  if (typeof raw === 'string') {
    // allow strings like "29.97DF" → 29.97
    const m = raw.trim().toUpperCase().match(/^(\d+(?:\.\d+)?)/);
    if (m) {
      const n = parseFloat(m[1]);
      if (Number.isFinite(n)) return n;
    }
  }

  const detected = await detectFrameRate(filePath, {
    timeoutMs: config?.fpsTimeoutMs
  });
  if (typeof detected === 'number' && Number.isFinite(detected) && detected > 0) return detected;

  return 30;
}

async function getFps(filePath, config = {}) {
  return resolveFps(filePath, config);
}

function convertToWav(inputFile, outputFile, audioTrackIndex = null, setProcess) {
  const { ffmpegPath } = getBinaryPaths();

  try {
    fs.mkdirSync(path.dirname(String(outputFile || '')), { recursive: true });
  } catch {
    // best-effort
  }

  const args = ['-y', '-i', String(inputFile ?? ''), '-vn'];

  if (Number.isInteger(audioTrackIndex) && audioTrackIndex >= 0) {
    // Map a specific audio track when requested.
    args.push('-map', `0:a:${audioTrackIndex}`);
  }

  // Whisper-friendly mono 16k PCM.
  args.push('-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', String(outputFile ?? ''));

  return new Promise((resolve, reject) => {
    const proc = spawn(ffmpegPath, args, { stdio: ['ignore', 'ignore', 'pipe'] });
    if (typeof setProcess === 'function') {
      try { setProcess(proc); } catch { /* ignore */ }
    }
    let stderr = '';
    proc.stderr.on('data', d => {
      stderr += d.toString();
    });
    proc.on('error', err => reject(err));
    proc.on('close', code => {
      if (code === 0) resolve(String(outputFile ?? ''));
      else reject(new Error(stderr || `ffmpeg exited with code ${code}`));
    });
  });
}

module.exports = {
  getBinaryDir,
  getBinaryPaths,
  isPackaged,

  // helpers expected by other modules
  parseAvgFrameRate,
  ffprobeJson,
  detectFrameRate,
  resolveFps,
  getFps,
  convertToWav
};
