// utils/mccQcUtils.js
// Shared helpers for MCC QC defaults.
//
// These helpers are dependency-free so they can be used from both:
//   - ai/outputWriters.js (batch export)
//   - modules/transcribe.js (subtitle editor export)
//
// The goal is to keep MCC QC default semantics in one place to avoid drift.

'use strict';

function _isExplicitTrue(v) {
  return v === true || v === 'true';
}

function _isExplicitFalse(v) {
  return v === false || v === 'false';
}

/**
 * Resolve whether “dual grading” should be enabled for MCC QC.
 *
 * Semantics (kept identical across batch export and editor export):
 *   - If explicitly set true/false in qc config: honor it.
 *   - Otherwise: enable by default for ALL MCC exports.
 */
function resolveMccDualGradeEnabled(qcCfg, compatibilityMode) {
  const cfg = (qcCfg && typeof qcCfg === 'object') ? qcCfg : {};
  const v = (cfg.dualGrade ?? cfg.dualGrading ?? cfg.dual);

  if (_isExplicitFalse(v)) return false;
  if (_isExplicitTrue(v)) return true;

  // Default ON: if we're trying to make the report “impossible to misread”,
  // every export should clearly communicate both:
  //   - the broadcast-grade 708 result
  //   - the legacy-grade 608 projection result
  // unless a caller explicitly disables it.
  void compatibilityMode; // kept for backward compat / logging upstream
  return true;
}

/**
 * Resolve whether we should attempt a native CEA-708 decode + QC pass.
 *
 * In practice:
 *   - Always true when dual grading is enabled.
 *   - Otherwise, only when explicitly requested by qc config.
 */
function resolveMccWant708Qc(qcCfg, dualGradeEnabled) {
  const cfg = (qcCfg && typeof qcCfg === 'object') ? qcCfg : {};
  return !!(
    dualGradeEnabled ||
    cfg.decode708 === true ||
    cfg.include708 === true ||
    cfg.qc708 === true
  );
}



/**
 * Normalize a “QC profile” object into the canonical keys that the QC engine understands.
 *
 * Supported keys (canonical):
 *   - maxCharsPerLine
 *   - maxLinesPerBlock
 *   - maxDurationSec
 *   - maxCps
 *   - maxWpm
 *   - minDurationSec
 *   - minGapSec
 *   - maxItems
 *
 * Notes:
 *   - Null values are preserved (they intentionally disable the corresponding check).
 *   - Invalid numeric values (NaN, non-numeric strings) are ignored.
 */
function _normalizeQcProfile(raw) {
  const src = (raw && typeof raw === 'object') ? raw : null;
  if (!src) return null;

  const hasOwn = (k) => Object.prototype.hasOwnProperty.call(src, k);

  const _numOrNull = (v) => {
    if (v === undefined) return undefined;
    if (v === null) return null;
    if (typeof v === 'string' && v.trim() === '') return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : undefined;
  };

  const pick = (keys) => {
    for (const k of keys) {
      if (hasOwn(k)) return src[k];
    }
    return undefined;
  };

  const out = {};

  const maxCols = _numOrNull(pick(['maxCharsPerLine', 'maxCols', 'maxColumns', 'maxColsPerLine']));
  if (maxCols !== undefined) out.maxCharsPerLine = maxCols;

  const maxLines = _numOrNull(pick(['maxLinesPerBlock', 'maxLines', 'maxRows', 'maxLinesPerCaption']));
  if (maxLines !== undefined) out.maxLinesPerBlock = maxLines;

  const maxDur = _numOrNull(pick(['maxDurationSec', 'maxDurationSeconds', 'maxDurSec', 'maxDur']));
  if (maxDur !== undefined) out.maxDurationSec = maxDur;

  const maxCps = _numOrNull(pick(['maxCps', 'maxCPS', 'cpsMax']));
  if (maxCps !== undefined) out.maxCps = maxCps;

  const maxWpm = _numOrNull(pick(['maxWpm', 'maxWPM', 'wpmMax']));
  if (maxWpm !== undefined) out.maxWpm = maxWpm;

  const minDur = _numOrNull(pick(['minDurationSec', 'minDurationSeconds', 'minDurSec', 'minDur']));
  if (minDur !== undefined) out.minDurationSec = minDur;

  const minGap = _numOrNull(pick(['minGapSec', 'minGapSeconds', 'minGap']));
  if (minGap !== undefined) out.minGapSec = minGap;

  const maxItems = _numOrNull(pick(['maxItems']));
  if (maxItems !== undefined) out.maxItems = maxItems;

  return Object.keys(out).length ? out : null;
}

/**
 * Resolve per-track MCC QC profiles from a single qc config object.
 *
 * Supported config shapes (any of these; all optional):
 *
 * 1) Nested objects:
 *   qc.profile708 / qc.profile608
 *   qc.qcProfile708 / qc.qcProfile608
 *   qc.profiles['708'] / qc.profiles['608']
 *   qc.profiles.cea708 / qc.profiles.cea608
 *
 * 2) Scalar per-track overrides:
 *   qc.maxCps708, qc.maxWpm708, qc.minDurationSec708, qc.minGapSec708, qc.maxCharsPerLine708, ...
 *   qc.maxCps608, qc.maxWpm608, qc.minDurationSec608, qc.minGapSec608, qc.maxCharsPerLine608, ...
 *
 * Returns:
 *   { qcProfile708: object|null, qcProfile608: object|null }
 */
function resolveMccQcProfiles(qcCfg) {
  const cfg = (qcCfg && typeof qcCfg === 'object') ? qcCfg : {};
  const hasOwn = (obj, k) => Object.prototype.hasOwnProperty.call(obj, k);

  const pickObj = (obj, keys) => {
    for (const k of keys) {
      if (hasOwn(obj, k)) {
        const v = obj[k];
        if (v && typeof v === 'object') return v;
      }
    }
    return null;
  };

  const profilesRoot = pickObj(cfg, ['profiles', 'qcProfiles', 'trackProfiles']);

  const fromScalars = (suffix) => {
    const out = {};
    const setNum = (canonKey, keys) => {
      for (const k of keys) {
        if (hasOwn(cfg, k)) {
          out[canonKey] = cfg[k];
          return;
        }
      }
    };

    setNum('maxCharsPerLine', [`maxCharsPerLine${suffix}`, `maxCols${suffix}`, `maxColumns${suffix}`]);
    setNum('maxLinesPerBlock', [`maxLinesPerBlock${suffix}`, `maxLines${suffix}`, `maxRows${suffix}`]);
    setNum('maxDurationSec', [`maxDurationSec${suffix}`, `maxDurationSeconds${suffix}`, `maxDurSec${suffix}`, `maxDur${suffix}`]);
    setNum('maxCps', [`maxCps${suffix}`, `maxCPS${suffix}`]);
    setNum('maxWpm', [`maxWpm${suffix}`, `maxWPM${suffix}`]);
    setNum('minDurationSec', [`minDurationSec${suffix}`, `minDurationSeconds${suffix}`, `minDurSec${suffix}`, `minDur${suffix}`]);
    setNum('minGapSec', [`minGapSec${suffix}`, `minGapSeconds${suffix}`, `minGap${suffix}`]);
    setNum('maxItems', [`maxItems${suffix}`]);

    return Object.keys(out).length ? out : null;
  };

  const raw708 =
    pickObj(cfg, ['qcProfile708', 'profile708', 'p708', 'cea708', 'track708']) ||
    (profilesRoot ? pickObj(profilesRoot, ['708', 'cea708', 'track708', 'svc708']) : null);

  const raw608 =
    pickObj(cfg, ['qcProfile608', 'profile608', 'p608', 'cea608', 'track608', 'legacy608']) ||
    (profilesRoot ? pickObj(profilesRoot, ['608', 'cea608', 'track608', 'legacy608', 'svc608']) : null);

  const scalar708 = fromScalars('708');
  const scalar608 = fromScalars('608');

  const prof708 = _normalizeQcProfile({ ...(raw708 || {}), ...(scalar708 || {}) });
  const prof608 = _normalizeQcProfile({ ...(raw608 || {}), ...(scalar608 || {}) });

  return {
    qcProfile708: prof708,
    qcProfile608: prof608
  };
}


module.exports = {
  resolveMccDualGradeEnabled,
  resolveMccWant708Qc,
  resolveMccQcProfiles
};
