// Thin compatibility shim that delegates to the shared ffmpeg bridge.
const bridge = require('./ffmpegBridge');

const {
  getBinaryPaths,
  convertToWav,
  detectFrameRate,
  resolveFps,
  parseAvgFrameRate,
  getFps
} = bridge;
const { ffmpegPath, ffprobePath } = getBinaryPaths();

module.exports = {
  ffmpegPath,
  ffprobePath,
  convertToWav,
  detectFrameRate,
  resolveFps,
  parseAvgFrameRate,
  getFps,
  __bridge: bridge
};
