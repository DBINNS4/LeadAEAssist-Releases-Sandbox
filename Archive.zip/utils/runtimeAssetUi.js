(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.runtimeAssetUi = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function _translate(options, key, fallback) {
    try {
      if (typeof options?.translate === 'function') {
        const value = options.translate(key, fallback);
        if (typeof value === 'string' && value) return value;
      }
    } catch {}
    return fallback != null ? String(fallback) : String(key || '');
  }

  function _translateTemplate(options, key, fallback, replacements) {
    try {
      if (typeof options?.translateTemplate === 'function') {
        const value = options.translateTemplate(key, fallback, replacements || {});
        if (typeof value === 'string' && value) return value;
      }
    } catch {}

    let template = _translate(options, key, fallback);
    for (const [token, value] of Object.entries(replacements || {})) {
      const pattern = new RegExp(`{{${token}}}`, 'g');
      template = template.replace(pattern, () => String(value ?? ''));
    }
    return template;
  }

  function _normalizeKind(snapshot, options) {
    const raw = String(
      options?.kind ||
      options?.feature ||
      snapshot?.feature ||
      snapshot?.kind ||
      ''
    ).trim().toLowerCase();

    if (raw.includes('chrom')) return 'chromium';
    if (raw.includes('browser')) return 'chromium';
    if (raw.includes('whisper')) return 'whisper';
    if (raw.includes('model')) return 'whisper';
    return raw || 'asset';
  }

  function _subjectLabel(snapshot, options) {
    const kind = _normalizeKind(snapshot, options);
    if (kind === 'chromium') {
      return _translate(options, 'runtimeAssetBrowserDependency', 'browser dependency');
    }
    if (kind === 'whisper') {
      return _translate(options, 'runtimeAssetTranscriptionModel', 'transcription model');
    }
    return _translate(options, 'runtimeAssetDependency', 'runtime dependency');
  }

  function _capitalize(text) {
    const s = String(text || '').trim();
    if (!s) return s;
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  function _formatBytesBinary(bytes) {
    const n = Number(bytes);
    if (!Number.isFinite(n) || n < 0) return null;
    const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB'];
    let value = n;
    let index = 0;
    while (value >= 1024 && index < units.length - 1) {
      value /= 1024;
      index += 1;
    }
    const decimals = index >= 3 ? 1 : 0;
    return `${value.toFixed(decimals)} ${units[index]}`;
  }

  function _normalizeProgressRatio(snapshot, options) {
    const candidates = [
      options?.progressOverride,
      snapshot?.progress?.progress,
      snapshot?.progress,
      snapshot?.ratio,
      snapshot?.percent
    ];

    for (const candidate of candidates) {
      const numeric = Number(candidate);
      if (!Number.isFinite(numeric)) continue;
      if (numeric >= 0 && numeric <= 1) return numeric;
      if (numeric > 1 && numeric <= 100) return numeric / 100;
    }
    return null;
  }

  function _formatProgressLine(snapshot, options) {
    const ratio = _normalizeProgressRatio(snapshot, options);
    const received = Number(snapshot?.progress?.bytesReceived);
    const total = Number(snapshot?.progress?.bytesTotal);
    const receivedLabel = Number.isFinite(received) ? _formatBytesBinary(received) : null;
    const totalLabel = Number.isFinite(total) ? _formatBytesBinary(total) : null;

    if (ratio != null) {
      const percent = `${Math.round(Math.max(0, Math.min(1, ratio)) * 100)}%`;
      if (receivedLabel && totalLabel) {
        return _translateTemplate(
          options,
          'runtimeAssetProgressWithBytes',
          'Progress: {{percent}} ({{received}} / {{total}})',
          {
            percent,
            received: receivedLabel,
            total: totalLabel
          }
        );
      }
      if (receivedLabel) {
        return _translateTemplate(
          options,
          'runtimeAssetProgressReceivedOnly',
          'Progress: {{percent}} ({{received}} downloaded)',
          {
            percent,
            received: receivedLabel
          }
        );
      }
      return _translateTemplate(options, 'runtimeAssetProgressPercent', 'Progress: {{percent}}', { percent });
    }

    if (snapshot?.active) {
      return _translate(options, 'runtimeAssetProgressWorking', 'Progress: working…');
    }

    return null;
  }

  function _phaseLabel(snapshot, options) {
    const phase = String(snapshot?.progress?.phase || snapshot?.phase || '').trim().toLowerCase();
    switch (phase) {
      case 'queue':
      case 'check':
        return _translate(options, 'runtimeAssetStagePreparing', 'Preparing');
      case 'seed':
        return _translate(options, 'runtimeAssetStageSeeding', 'Seeding bundled copy');
      case 'download':
        return _translate(options, 'runtimeAssetStageDownloading', 'Downloading');
      case 'verify':
        return _translate(options, 'runtimeAssetStageVerifying', 'Verifying download');
      case 'install':
        return _translate(options, 'runtimeAssetStageInstalling', 'Installing');
      case 'complete':
        return _translate(options, 'runtimeAssetStageFinishing', 'Finalizing');
      case 'cancelled':
        return _translate(options, 'runtimeAssetStageCancelled', 'Cancelled');
      default:
        return _translate(options, 'runtimeAssetStageWorking', 'Working');
    }
  }

  function _friendlyErrorMessage(snapshot, options) {
    const subject = _subjectLabel(snapshot, options);
    const capitalizedSubject = _capitalize(subject);
    const code = String(snapshot?.error?.code || snapshot?.code || '').trim().toUpperCase();
    const raw = String(snapshot?.error?.message || snapshot?.message || '').trim();

    switch (code) {
      case 'ASSET_OFFLINE_BLOCKED':
        return _translateTemplate(
          options,
          'runtimeAssetOfflineBlockedMessage',
          'Offline Mode is enabled. {{subject}} cannot be downloaded while offline.',
          { subject }
        );
      case 'ASSET_DOWNLOAD_FAILED':
        return _translateTemplate(
          options,
          'runtimeAssetDownloadFailedMessage',
          '{{subject}} download failed. Check your network connection and retry.',
          { subject: capitalizedSubject }
        );
      case 'ASSET_EXTRACT_FAILED':
        return _translateTemplate(
          options,
          'runtimeAssetExtractFailedMessage',
          '{{subject}} could not be installed after download. Retry or reinstall the app.',
          { subject: capitalizedSubject }
        );
      case 'ASSET_CHECKSUM_MISMATCH':
        return _translateTemplate(
          options,
          'runtimeAssetChecksumMismatchMessage',
          'Downloaded {{subject}} failed checksum verification. Retry after publishing a fresh asset build.',
          { subject }
        );
      case 'ASSET_MISSING_CHECKSUM':
        return _translateTemplate(
          options,
          'runtimeAssetMissingChecksumMessage',
          'This build is missing checksum metadata for the required {{subject}}.',
          { subject }
        );
      case 'ASSET_MISSING':
        return _translateTemplate(
          options,
          'runtimeAssetMissingMessage',
          'Required {{subject}} is not available for this build.',
          { subject }
        );
      case 'ABORT_ERR':
      case 'ABORTED':
        return _translateTemplate(
          options,
          'runtimeAssetCancelledMessage',
          '{{subject}} download was cancelled.',
          { subject: capitalizedSubject }
        );
      default:
        return raw || _translateTemplate(
          options,
          'runtimeAssetUnknownFailureMessage',
          '{{subject}} could not be prepared.',
          { subject: capitalizedSubject }
        );
    }
  }

  function _headline(snapshot, options) {
    const subject = _subjectLabel(snapshot, options);
    const capitalizedSubject = _capitalize(subject);
    const phase = String(snapshot?.progress?.phase || snapshot?.phase || '').trim().toLowerCase();
    const state = String(snapshot?.state || '').trim().toLowerCase();

    if (state === 'installed') {
      return _translateTemplate(options, 'runtimeAssetInstalledHeadline', '{{subject}} ready.', {
        subject: capitalizedSubject
      });
    }

    if (state === 'cancelled') {
      return _translateTemplate(options, 'runtimeAssetCancelledHeadline', '{{subject}} download cancelled.', {
        subject: capitalizedSubject
      });
    }

    if (state === 'error') {
      return _translateTemplate(options, 'runtimeAssetErrorHeadline', '{{subject}} update failed.', {
        subject: capitalizedSubject
      });
    }

    switch (phase) {
      case 'seed':
        return _translateTemplate(options, 'runtimeAssetSeedingHeadline', 'Preparing bundled {{subject}}…', {
          subject
        });
      case 'download':
        return _translateTemplate(options, 'runtimeAssetDownloadingHeadline', 'Downloading {{subject}}…', {
          subject
        });
      case 'verify':
        return _translateTemplate(options, 'runtimeAssetVerifyingHeadline', 'Verifying {{subject}} download…', {
          subject
        });
      case 'install':
        return _translateTemplate(options, 'runtimeAssetInstallingHeadline', 'Installing {{subject}}…', {
          subject
        });
      case 'complete':
        return _translateTemplate(options, 'runtimeAssetFinishingHeadline', 'Finalizing {{subject}}…', {
          subject
        });
      case 'queue':
      case 'check':
      default:
        return _translateTemplate(options, 'runtimeAssetPreparingHeadline', 'Preparing {{subject}}…', {
          subject
        });
    }
  }

  function buildRuntimeAssetSummary(snapshot, options) {
    const lines = [];
    const head = _headline(snapshot || {}, options || {});
    if (head) lines.push(head);

    const languageLabel = String(options?.languageLabel || '').trim();
    if (languageLabel) {
      lines.push(_translateTemplate(options, 'runtimeAssetLanguageLine', 'Language: {{language}}', {
        language: languageLabel
      }));
    }

    if (snapshot?.state === 'error') {
      const errorLine = _friendlyErrorMessage(snapshot, options);
      if (errorLine) lines.push(`Error: ${errorLine}`);
      return lines.join('\n').trim();
    }

    const progressLine = _formatProgressLine(snapshot, options);
    if (progressLine) lines.push(progressLine);

    if (snapshot?.active) {
      const stageLabel = _phaseLabel(snapshot, options);
      if (stageLabel) {
        lines.push(_translateTemplate(options, 'runtimeAssetStatusLine', 'Status: {{status}}', {
          status: stageLabel
        }));
      }
    }

    return lines.join('\n').trim();
  }

  function createRuntimeAssetError(input, options) {
    if (input instanceof Error && input.__isRuntimeAssetUiError) return input;

    const snapshot = (input && typeof input === 'object') ? input : {
      error: { message: String(input || 'Runtime asset request failed') }
    };

    const message = _friendlyErrorMessage(snapshot, options);
    const err = new Error(message);
    err.code = String(snapshot?.error?.code || snapshot?.code || 'ASSET_PREFETCH_FAILED').trim() || 'ASSET_PREFETCH_FAILED';
    err.snapshot = snapshot;
    err.__isRuntimeAssetUiError = true;
    return err;
  }

  function _isTerminal(snapshot) {
    const state = String(snapshot?.state || '').trim().toLowerCase();
    return state === 'installed' || state === 'error' || state === 'cancelled';
  }

  async function startRuntimeAssetPrefetch(assetsApi, request, options) {
    if (!assetsApi || typeof assetsApi.prefetch !== 'function') {
      const err = new Error('Runtime asset API is unavailable in the renderer.');
      err.code = 'ASSET_API_UNAVAILABLE';
      throw err;
    }

    const normalizedOptions = options && typeof options === 'object' ? options : {};
    const requestOptions = normalizedOptions.requestOptions && typeof normalizedOptions.requestOptions === 'object'
      ? normalizedOptions.requestOptions
      : {};

    const initial = await assetsApi.prefetch(request || {}, requestOptions);
    if (!initial || initial.ok === false) {
      throw createRuntimeAssetError(initial || {}, normalizedOptions);
    }

    const controller = {
      request: request || {},
      requestId: initial.requestId || null,
      assetId: initial.assetId || null,
      snapshot: initial,
      lastProgressRatio: _normalizeProgressRatio(initial, normalizedOptions),
      immediate: !!(initial.reused || (initial.installed && initial.ready && !initial.active)),
      settled: false,
      _unsubscribe: null,
      _resolve: null,
      _reject: null,
      _cleanup() {
        if (typeof controller._unsubscribe === 'function') {
          try { controller._unsubscribe(); } catch {}
        }
        controller._unsubscribe = null;
      },
      _processSnapshot(snapshot) {
        if (!snapshot || controller.settled) return;
        const matches = normalizedOptions.matchSnapshot
          ? !!normalizedOptions.matchSnapshot(snapshot, controller)
          : (
            (controller.requestId && snapshot.requestId && snapshot.requestId === controller.requestId) ||
            (controller.assetId && snapshot.assetId === controller.assetId)
          );
        if (!matches) return;

        controller.snapshot = snapshot;
        const ratio = _normalizeProgressRatio(snapshot, normalizedOptions);
        if (ratio != null) controller.lastProgressRatio = ratio;

        if (typeof normalizedOptions.onSnapshot === 'function') {
          try { normalizedOptions.onSnapshot(snapshot, controller); } catch {}
        }

        if (!_isTerminal(snapshot)) return;

        controller.settled = true;
        controller._cleanup();

        if (String(snapshot.state || '').trim().toLowerCase() === 'installed') {
          controller._resolve?.(snapshot);
          return;
        }

        controller._reject?.(createRuntimeAssetError(snapshot, normalizedOptions));
      },
      async cancel() {
        if (controller.settled) {
          return controller.snapshot;
        }

        const cancelRequest = {
          requestId: controller.requestId,
          assetId: controller.assetId,
          ...(request && typeof request === 'object' ? request : {})
        };

        const response = (typeof assetsApi.cancel === 'function')
          ? await assetsApi.cancel(cancelRequest)
          : { ok: false, code: 'ASSET_CANCEL_UNAVAILABLE', error: 'Runtime asset cancel API is unavailable.' };

        if (!response || response.ok === false) {
          throw createRuntimeAssetError(response || {}, normalizedOptions);
        }

        if (response.detached || response.cancelled || response.state === 'cancelled' || response.state === 'cancelling') {
          controller.settled = true;
          controller._cleanup();
          const cancelledSnapshot = {
            ...controller.snapshot,
            ...response,
            state: 'cancelled',
            active: false,
            error: {
              code: 'ABORT_ERR',
              message: _friendlyErrorMessage({ error: { code: 'ABORT_ERR' } }, normalizedOptions)
            }
          };
          controller.snapshot = cancelledSnapshot;
          if (typeof normalizedOptions.onSnapshot === 'function') {
            try { normalizedOptions.onSnapshot(cancelledSnapshot, controller); } catch {}
          }
          controller._reject?.(createRuntimeAssetError(cancelledSnapshot, normalizedOptions));
        }

        return response;
      }
    };

    if (typeof normalizedOptions.onSnapshot === 'function') {
      try { normalizedOptions.onSnapshot(initial, controller); } catch {}
    }

    if (controller.immediate) {
      return {
        ...controller,
        promise: Promise.resolve(initial)
      };
    }

    controller.promise = new Promise((resolve, reject) => {
      controller._resolve = resolve;
      controller._reject = reject;
    });

    controller._unsubscribe = (typeof assetsApi.onProgress === 'function')
      ? assetsApi.onProgress((snapshot) => controller._processSnapshot(snapshot))
      : null;

    if (typeof assetsApi.getStatus === 'function') {
      Promise.resolve().then(async () => {
        try {
          const synced = await assetsApi.getStatus({
            requestId: controller.requestId,
            assetId: controller.assetId,
            ...(request && typeof request === 'object' ? request : {})
          });
          if (synced && synced.ok !== false) controller._processSnapshot(synced);
        } catch {}
      });
    }

    return controller;
  }

  return {
    buildRuntimeAssetSummary,
    createRuntimeAssetError,
    startRuntimeAssetPrefetch
  };
});
