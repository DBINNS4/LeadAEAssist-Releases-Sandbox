// utils/cueSchema.js
// Phase 1: Canonical cue model + per-track overrides (608 + 708)
//
// Design goals:
//   - Keep the existing flattened cue shape working (cue.start/end/text etc.).
//   - Persist a reliable V2 schema: { canonical: {...}, overrides: {...} }.
//   - Overrides are nullable; null means "inherit".
//   - Track override staleness deterministically via a canonical-text fingerprint.
//
// NOTE:
// This module is dependency-free (no Electron/OpenAI). It can be used from:
//   - Node-side export/QC code
//   - CLI/test tooling

'use strict';

/**
 * Normalize text for fingerprinting.
 * We want stable results across platforms and reasonable tolerance for CRLF.
 */
function _normalizeTextForFingerprint(text) {
  return String(text ?? '')
    .replace(/\r\n?/g, '\n')
    .trim();
}

/**
 * Fast, deterministic 32-bit FNV-1a fingerprint.
 * Not cryptographic. Used only for "did canonical text change?" tracking.
 */
function fingerprintText(text) {
  const s = _normalizeTextForFingerprint(text);
  // FNV-1a 32-bit
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i += 1) {
    h ^= s.charCodeAt(i);
    // h *= 16777619 (with uint32 overflow)
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  return h.toString(16).padStart(8, '0');
}

function _canonicalTextForFingerprint(cue) {
  if (!cue || typeof cue !== 'object') return '';
  if (Array.isArray(cue.lines) && cue.lines.length) {
    return cue.lines.map(l => String(l || '')).join('\n');
  }
  if (typeof cue.text === 'string' && cue.text.length) return cue.text;
  if (Array.isArray(cue.runs) && cue.runs.length) {
    return cue.runs.map(r => String((r && typeof r === 'object') ? (r.text ?? '') : '')).join('');
  }
  const canon = (cue.canonical && typeof cue.canonical === 'object') ? cue.canonical : null;
  if (canon && typeof canon.text === 'string') return canon.text;
  return '';
}

const DEFAULT_OVERRIDES_608 = Object.freeze({
  start: null,
  end: null,
  text: null,
  breaks: null,
  // Phase B: per-line CEA-608 placement override (row/col).
  // NOTE: For SCC docs, canonical placement still lives in cue.sccPlacement.
  // This field is used primarily for MCC true708 workflows where 608 is a derived track.
  placement: null,
  note: null,
  // Phase 1.3 staleness tracking
  _baseCanonicalTextFp: null,
  overridePossiblyStale: false
});

const DEFAULT_OVERRIDES_708 = Object.freeze({
  window: null,
  style: null,
  text: null,
  // Phase 1.3 staleness tracking
  _baseCanonicalTextFp: null,
  overridePossiblyStale: false
});

function _cloneDefault(obj) {
  return { ...obj };
}

function isCueV2(cue) {
  return !!(
    cue &&
    typeof cue === 'object' &&
    cue.canonical &&
    typeof cue.canonical === 'object' &&
    cue.overrides &&
    typeof cue.overrides === 'object'
  );
}

function _getLegacy608OverrideText(cue) {
  if (!cue || typeof cue !== 'object') return null;
  const direct = cue.compat608Text ?? cue.compat608_override ?? cue.compat608OverrideText;
  if (typeof direct === 'string' && direct.trim()) return direct;
  const container = cue.compat608;
  if (container && typeof container === 'object') {
    if (typeof container.text === 'string' && container.text.trim()) return container.text;
    if (Array.isArray(container.lines) && container.lines.length) {
      const joined = container.lines.map(l => String(l || '')).join('\n');
      if (joined.trim()) return joined;
    }
  }
  if (Array.isArray(cue.compat608Lines) && cue.compat608Lines.length) {
    const joined = cue.compat608Lines.map(l => String(l || '')).join('\n');
    if (joined.trim()) return joined;
  }
  return null;
}

function _ensureTrackOverrideShape(existing, defaults) {
  const out = (existing && typeof existing === 'object') ? { ...existing } : {};
  for (const [k, v] of Object.entries(defaults)) {
    if (!(k in out)) out[k] = v;
  }
  return out;
}

/**
 * Ensure a cue has Phase-1 schema fields.
 *
 * This is intentionally tolerant:
 *   - preserves unknown fields
 *   - migrates legacy compat608Text/compat608 lines into overrides['608'].text
 *   - leaves flattened cue.start/end/text intact for current editor code
 */
function ensureCueSchema(cue) {
  if (!cue || typeof cue !== 'object') return cue;

  // Canonical: if missing, synthesize from the flattened cue fields.
  if (!cue.canonical || typeof cue.canonical !== 'object') {
    cue.canonical = {};
  }
  const canon = cue.canonical;
  if (canon.start == null && cue.start != null) canon.start = cue.start;
  if (canon.end == null && cue.end != null) canon.end = cue.end;
  if (canon.text == null && cue.text != null) canon.text = cue.text;

  // If flattened fields are missing (common in V2-only payloads), hydrate them from canonical.
  if (cue.start == null && canon.start != null) cue.start = canon.start;
  if (cue.end == null && canon.end != null) cue.end = canon.end;
  if (cue.text == null && canon.text != null) cue.text = canon.text;

  // Preserve common canonical fields when present on flattened cue.
  if (canon.speaker == null && cue.speaker != null) canon.speaker = cue.speaker;
  if (canon.lines == null && cue.lines != null) canon.lines = cue.lines;
  if (canon.runs == null && cue.runs != null) canon.runs = cue.runs;
  if (canon.sccPlacement == null && cue.sccPlacement != null) canon.sccPlacement = cue.sccPlacement;
  if (canon.cea708Placement == null && cue.cea708Placement != null) canon.cea708Placement = cue.cea708Placement;

  // Also hydrate flattened fields from canonical where needed.
  if (cue.speaker == null && canon.speaker != null) cue.speaker = canon.speaker;
  if (cue.lines == null && canon.lines != null) cue.lines = canon.lines;
  if (cue.runs == null && canon.runs != null) cue.runs = canon.runs;
  if (cue.sccPlacement == null && canon.sccPlacement != null) cue.sccPlacement = canon.sccPlacement;
  if (cue.cea708Placement == null && canon.cea708Placement != null) cue.cea708Placement = canon.cea708Placement;

  // Consistency: the editor still primarily mutates flattened fields (cue.start/end/text).
  // Keep canonical updated so downstream consumers that read cue.canonical don't see stale data.
  // (If canonical is the ONLY source and flattened was hydrated from it, these are no-ops.)
  if (cue.start != null && canon.start != null && cue.start !== canon.start) canon.start = cue.start;
  if (cue.end != null && canon.end != null && cue.end !== canon.end) canon.end = cue.end;
  if (cue.text != null && canon.text != null && cue.text !== canon.text) canon.text = cue.text;
  if (cue.speaker != null && canon.speaker != null && cue.speaker !== canon.speaker) canon.speaker = cue.speaker;
  if (cue.lines != null && canon.lines != null && cue.lines !== canon.lines) canon.lines = cue.lines;
  if (cue.runs != null && canon.runs != null && cue.runs !== canon.runs) canon.runs = cue.runs;
  if (cue.sccPlacement != null && canon.sccPlacement != null && cue.sccPlacement !== canon.sccPlacement) canon.sccPlacement = cue.sccPlacement;
  if (cue.cea708Placement != null && canon.cea708Placement != null && cue.cea708Placement !== canon.cea708Placement) canon.cea708Placement = cue.cea708Placement;

  // Overrides
  if (!cue.overrides || typeof cue.overrides !== 'object') {
    cue.overrides = {};
  }
  cue.overrides['608'] = _ensureTrackOverrideShape(cue.overrides['608'], DEFAULT_OVERRIDES_608);
  cue.overrides['708'] = _ensureTrackOverrideShape(cue.overrides['708'], DEFAULT_OVERRIDES_708);

  // Legacy migration for 608 override text.
  const o608 = cue.overrides['608'];
  if ((o608.text == null || o608.text === '') && (o608.breaks == null)) {
    const legacy = _getLegacy608OverrideText(cue);
    if (legacy && legacy.trim()) {
      o608.text = legacy;
    }
  }

  // If we have 608 override content but no baseline fingerprint, assume it was
  // derived from the current canonical (avoid spurious "stale" badges on load).
  if ((o608.text != null && String(o608.text).trim()) && !o608._baseCanonicalTextFp) {
    o608._baseCanonicalTextFp = fingerprintText(_canonicalTextForFingerprint(cue) || canon.text || '');
    o608.overridePossiblyStale = false;
  }

  const o708 = cue.overrides['708'];
  if ((o708.text != null && String(o708.text).trim()) && !o708._baseCanonicalTextFp) {
    o708._baseCanonicalTextFp = fingerprintText(_canonicalTextForFingerprint(cue) || canon.text || '');
    o708.overridePossiblyStale = false;
  }

  return cue;
}

/**
 * Sync cue.canonical from the flattened cue fields.
 * Call before serializing or when you need canonical to be authoritative.
 */
function syncCanonicalFromFlat(cue) {
  if (!cue || typeof cue !== 'object') return cue;
  ensureCueSchema(cue);
  const canon = cue.canonical;
  canon.start = cue.start;
  canon.end = cue.end;
  canon.text = cue.text;
  if (cue.speaker != null) canon.speaker = cue.speaker;
  if (cue.lines != null) canon.lines = cue.lines;
  if (cue.runs != null) canon.runs = cue.runs;
  if (cue.sccPlacement != null) canon.sccPlacement = cue.sccPlacement;
  if (cue.cea708Placement != null) canon.cea708Placement = cue.cea708Placement;
  return cue;
}

/**
 * Compute and (optionally) persist staleness flags.
 */
function computeOverridePossiblyStale(cue, track, { persist = false } = {}) {
  if (!cue || typeof cue !== 'object') return false;
  ensureCueSchema(cue);

  const t = String(track || '').trim();
  const ov = cue.overrides[t];
  if (!ov || typeof ov !== 'object') return false;

  const hasAnyOverride = Object.keys(ov).some((k) => {
    if (k.startsWith('_')) return false;
    if (k === 'overridePossiblyStale') return false;
    return ov[k] != null;
  });
  if (!hasAnyOverride) {
    if (persist) ov.overridePossiblyStale = false;
    return false;
  }

  const baseFp = ov._baseCanonicalTextFp;
  if (!baseFp) {
    if (persist) ov.overridePossiblyStale = false;
    return false;
  }
  const currentFp = fingerprintText(_canonicalTextForFingerprint(cue));
  const stale = baseFp !== currentFp;
  if (persist) ov.overridePossiblyStale = stale;
  return stale;
}

function setOverride608Text(cue, text) {
  if (!cue || typeof cue !== 'object') return cue;
  ensureCueSchema(cue);
  const o608 = cue.overrides['608'];
  const t = String(text ?? '').replace(/\r\n?/g, '\n');
  const trimmed = t.trim();
  o608.text = trimmed ? t : null;
  o608.breaks = null;
  o608._baseCanonicalTextFp = fingerprintText(_canonicalTextForFingerprint(cue));
  o608.overridePossiblyStale = false;

  // Keep legacy fields in sync for backward compatibility.
  cue.compat608Text = trimmed ? t : '';
  if (cue.compat608) delete cue.compat608;
  return cue;
}

function clearOverride608(cue) {
  if (!cue || typeof cue !== 'object') return cue;
  ensureCueSchema(cue);
  const o608 = cue.overrides['608'];
  o608.start = null;
  o608.end = null;
  o608.text = null;
  o608.breaks = null;
  o608.placement = null;
  o608.note = null;
  o608._baseCanonicalTextFp = null;
  o608.overridePossiblyStale = false;

  // Clear legacy mirrors.
  if (cue.compat608Text != null) delete cue.compat608Text;
  if (cue.compat608 != null) delete cue.compat608;
  if (cue.compat608Lines != null) delete cue.compat608Lines;
  return cue;
}

function setOverride708Text(cue, text) {
  if (!cue || typeof cue !== 'object') return cue;
  ensureCueSchema(cue);
  const o708 = cue.overrides['708'];
  const t = String(text ?? '').replace(/\r\n?/g, '\n');
  const trimmed = t.trim();
  o708.text = trimmed ? t : null;
  o708._baseCanonicalTextFp = fingerprintText(_canonicalTextForFingerprint(cue));
  o708.overridePossiblyStale = false;
  return cue;
}

function clearOverride708(cue) {
  if (!cue || typeof cue !== 'object') return cue;
  ensureCueSchema(cue);
  const o708 = cue.overrides['708'];
  o708.window = null;
  o708.style = null;
  o708.text = null;
  o708._baseCanonicalTextFp = null;
  o708.overridePossiblyStale = false;
  return cue;
}

/**
 * Extract an effective 608 override string from Phase-1 schema.
 * Returns null when no override is present.
 */
function getOverride608Text(cue) {
  if (!cue || typeof cue !== 'object') return null;
  // Prefer Phase-1 overrides.
  const o608 = cue?.overrides && typeof cue.overrides === 'object' ? cue.overrides['608'] : null;
  if (o608 && typeof o608 === 'object') {
    if (typeof o608.text === 'string' && o608.text.trim()) return o608.text;
    if (Array.isArray(o608.breaks) && o608.breaks.length) {
      const joined = o608.breaks.map((l) => String(l || '')).join('\n');
      if (joined.trim()) return joined;
    }
  }
  // Fallback to legacy.
  return _getLegacy608OverrideText(cue);
}

/**
 * Serialize a cue into a stable Phase-1 object.
 * - canonical is sourced from the flattened fields (authoritative)
 * - overrides are normalized (missing keys filled with nulls)
 * - staleness flags are recomputed and stored
 */
function serializeCueV2(cue) {
  if (!cue || typeof cue !== 'object') return cue;
  // Keep canonical authoritative.
  syncCanonicalFromFlat(cue);
  ensureCueSchema(cue);

  // Persist staleness flags.
  computeOverridePossiblyStale(cue, '608', { persist: true });
  computeOverridePossiblyStale(cue, '708', { persist: true });

  // Canonical: keep it compact and deterministic.
  const canonical = { ...cue.canonical };
  // Ensure required keys.
  canonical.start = cue.start;
  canonical.end = cue.end;
  canonical.text = cue.text;

  // Overrides: include both tracks with nullable keys.
  const overrides = {
    '608': _ensureTrackOverrideShape(cue.overrides['608'], DEFAULT_OVERRIDES_608),
    '708': _ensureTrackOverrideShape(cue.overrides['708'], DEFAULT_OVERRIDES_708)
  };

  return {
    id: cue.id,
    canonical,
    overrides
  };
}

function ensureDocCueSchema(doc) {
  if (!doc || typeof doc !== 'object') return doc;
  if (!Array.isArray(doc.cues)) return doc;
  for (const cue of doc.cues) ensureCueSchema(cue);
  return doc;
}

module.exports = {
  fingerprintText,
  _canonicalTextForFingerprint,
  isCueV2,
  ensureCueSchema,
  ensureDocCueSchema,
  syncCanonicalFromFlat,
  serializeCueV2,
  computeOverridePossiblyStale,
  setOverride608Text,
  clearOverride608,
  setOverride708Text,
  clearOverride708,
  getOverride608Text
};
