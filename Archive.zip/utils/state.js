// utils/state.js
const fs = require('fs');
const path = require('path');

const { ensureUserDataSubdir } = require('./appPaths');
const { renameReplaceSync, uniqueTempPath } = require('./fsSafe');
// Single source of truth for all preferences and license info

function getStatePath() {
  return path.join(ensureUserDataSubdir('config'), 'state.json');
}

function getStateBackupPath() {
  return `${getStatePath()}.bak`;
}

function readJsonFile(jsonPath) {
  const raw = fs.readFileSync(jsonPath, 'utf-8');
  if (!raw || !String(raw).trim()) return {};
  return JSON.parse(raw);
}

function readState() {
  const statePath = getStatePath();
  const backupPath = getStateBackupPath();

  try {
    return readJsonFile(statePath);
  } catch {
    try {
      const backupState = readJsonFile(backupPath);
      // Best-effort healing: restore primary file from backup atomically.
      writeState(backupState);
      return backupState;
    } catch {
      return {};
    }
  }
}

function writeAtomicallySync(filePath, payload, mode = 0o600) {
  const dir = path.dirname(filePath);

  // If the "dir" path exists but is a FILE, normalize to ENOTDIR.
  if (fs.existsSync(dir)) {
    const st = fs.statSync(dir);
    if (st && !st.isDirectory()) {
      const e = new Error(`ENOTDIR: not a directory, mkdir '${dir}'`);
      e.code = "ENOTDIR";
      e.path = dir;
      throw e;
    }
  }

  try {
    fs.mkdirSync(dir, { recursive: true });
  } catch (err) {
    // Some platforms throw EEXIST when the path is a file; normalize.
    if (err && err.code === "EEXIST") {
      const e = new Error(`ENOTDIR: not a directory, mkdir '${dir}'`);
      e.code = "ENOTDIR";
      e.path = dir;
      throw e;
    }
    throw err;
  }

  const tempPath = uniqueTempPath(filePath, '.tmp');
  fs.writeFileSync(tempPath, payload, { encoding: 'utf-8', mode });
  renameReplaceSync(tempPath, filePath);
  try {
    fs.chmodSync(filePath, mode);
  } catch {
    // Best-effort only (e.g. Windows)
  }
}

function persistStateWithBackup(statePath, serializedState) {
  writeAtomicallySync(statePath, serializedState);
  try {
    writeAtomicallySync(`${statePath}.bak`, serializedState);
  } catch {
    // Backup is best-effort only; primary write succeeded.
  }
}

function writeState(newState) {
  const statePath = getStatePath();
  try {
    const payload = JSON.stringify(newState || {}, null, 2);
    persistStateWithBackup(statePath, payload);
    return { ok: true };
} catch (error) {
  const err =
    (error instanceof Error)
      ? error
      : Object.assign(new Error(String(error?.message || error)), error && typeof error === "object" ? error : {});
  return { ok: false, error: err };
}
}

module.exports = { readState, writeState };
