'use strict';

// Centralized time/timecode math (DF/NDF) used across the app
// - parseTime(ts, fps, dropFrameHint) -> ms
// - formatTimecode(seconds, dropFrame, fps, style='colon', roundMode='floor') -> string
// - formatTimecodes(ms, fps, dropFrame) -> { ndf, df, ms, timecodeFF, timecodeff, timecodeMs, timecodeMsEnd }
// - msToTC(ms, fps, style='colon', dropFrame=false)
// - toFrame/toFrameStart/toFrameEnd/toMs/msToFrame/msToFrameStart/msToFrameEnd

// Drop-frame aware time math with exact 1000/1001 rational handling.
// Eliminates float rounding that was coercing 59.94 DF into 60.00 NDF.
const DF_RATES = [
  { fps: 29.97, num: 30000, den: 1001, base: 30, dropPerMinute: 2 },
  { fps: 59.94, num: 60000, den: 1001, base: 60, dropPerMinute: 4 },
  { fps: 119.88, num: 120000, den: 1001, base: 120, dropPerMinute: 8 }
];

function isDropFrameRate(fps = 0) {
  const f = Number(fps);
  return DF_RATES.some(r => Math.abs(f - r.fps) < 0.02);
}

function _rateMeta(fps) {
  const f = Number(fps);
  const df = DF_RATES.find(r => Math.abs(f - r.fps) < 0.02);
  if (df) return { ...df, df: true };
  const ndfCandidates = [
    { fps: 23.976, num: 24000, den: 1001, base: 24 },
    { fps: 24.000, num: 24,    den: 1,    base: 24 },
    { fps: 25.000, num: 25,    den: 1,    base: 25 },
    { fps: 29.970, num: 30000, den: 1001, base: 30 },
    { fps: 30.000, num: 30,    den: 1,    base: 30 },
    { fps: 50.000, num: 50,    den: 1,    base: 50 },
    { fps: 59.940, num: 60000, den: 1001, base: 60 },
    { fps: 60.000, num: 60,    den: 1,    base: 60 }
  ];
  let best = ndfCandidates[0];
  let err = Math.abs(f - best.fps);
  for (let i = 1; i < ndfCandidates.length; i++) {
    const e = Math.abs(f - ndfCandidates[i].fps);
    if (e < err) {
      err = e;
      best = ndfCandidates[i];
    }
  }
  return { ...best, df: false, dropPerMinute: 0 };
}

function _secondsToFramesRaw(seconds, fps) {
  const { num, den } = _rateMeta(fps);
  return (Number(seconds) * num) / den;
}


function nominalFrameBase(fps = 30) {
  const f = Number(fps);
  if (!Number.isFinite(f) || f <= 0) return 30;
  const meta = _rateMeta(f);
  if (Math.abs(f - meta.fps) <= 0.05) return meta.base;
  return Math.max(1, Math.round(f));
}

const _EPS = 1e-9;

function _roundFrames(value, mode = 'floor') {
  if (!Number.isFinite(value)) return 0;
  if (mode === 'nearest') return Math.round(value);
  if (mode === 'ceil') return Math.ceil(value - _EPS);
  return Math.floor(value + _EPS);
}

function secondsToFrames(seconds, fps, roundMode = 'floor') {
  const raw = _secondsToFramesRaw(seconds, fps);
  const frames = _roundFrames(raw, roundMode);
  return Math.max(0, frames);
}

function framesToSeconds(frames, fps) {
  const { num, den } = _rateMeta(fps);
  return (Number(frames) * den) / num;
}


function frameDurationMs(fps, roundMode = 'ceil') {
  const f = Number(fps);
  const meta = Number.isFinite(f) && f > 0 ? _rateMeta(f) : _rateMeta(30);
  const exact = (Number.isFinite(f) && f > 0 && Math.abs(f - meta.fps) > 0.05)
    ? (1000 / f)
    : ((1000 * meta.den) / meta.num);
  return Math.max(1, _roundFrames(exact, roundMode));
}

// Helpers used across the app (keep these centralized)
//
// IMPORTANT POLICY:
//   - Start times: floor (inclusive start)
//   - End times:   ceil  (exclusive end / coverage-safe)
//
function toFrameStart(timeSec, fps) {
  return secondsToFrames(timeSec, fps, 'floor');
}

function toFrameEnd(timeSec, fps) {
  return secondsToFrames(timeSec, fps, 'ceil');
}

// Back-compat alias: historically toFrame() meant "floor".
function toFrame(timeSec, fps) {
  return toFrameStart(timeSec, fps);
}

function toMs(timeSec) {
  const v = Number(timeSec);
  return Number.isFinite(v) ? Math.floor(v * 1000 + _EPS) : 0;
}

function msToFrame(ms, fps) {
  return toFrameStart(Number(ms) / 1000, fps);
}

function msToFrameStart(ms, fps) {
  return toFrameStart(Number(ms) / 1000, fps);
}

function msToFrameEnd(ms, fps) {
  return toFrameEnd(Number(ms) / 1000, fps);
}

function _componentsToFrames(h, m, s, f, isDfLabel, fps) {
  const meta = _rateMeta(fps);
  const base = meta.base;
  const frame = Math.max(0, Math.min(Number(f) || 0, base - 1));
  const total = base * (h * 3600 + m * 60 + s) + frame;
  if (isDfLabel && meta.df) {
    const dropPerMinute = meta.dropPerMinute;
    const minutes = h * 60 + m;
    const dropped = dropPerMinute * (minutes - Math.floor(minutes / 10));
    return total - dropped;
  }
  return total;
}

function framesFromTimecodeLabel(tc, fps, dropFrameHint = null) {
  const match = /^(\d{2}):(\d{2}):(\d{2})([:;])(\d{2})$/.exec(String(tc).trim());
  if (!match) return 0;
  const [, H, M, S, sep, F] = match;
  const h = Number(H) || 0;
  const m = Number(M) || 0;
  const s = Number(S) || 0;
  const frame = Number(F) || 0;
  const isDfLabel = sep === ';';
  // MCC commonly uses ':' even for DF; if the caller knows DF, honor it.
  const preferDf = (dropFrameHint === true) && sep === ':' && isDropFrameRate(fps);
  return _componentsToFrames(h, m, s, frame, (isDfLabel || preferDf), fps);
}

function timecodeComponentsFromFrames(totalFrames, dropFrame = false, fps = 29.97) {
  const meta = _rateMeta(fps);
  const useDf = dropFrame && meta.df;
  const base = meta.base;

  if (useDf) {
    // Drop-frame timecode math is weird (on purpose): we label time as if it were
    // running at a nominal integer base (30/60/120), but we *skip* a small number
    // of frame numbers at the top of most minutes to keep the labels aligned to
    // clock time.
    //
    // This function is the inverse of _componentsToFrames() for DF rates.
    // The old implementation was producing invalid labels at 00:00:00;00 and at
    // every 10-minute boundary (broadcast/QC poison), so we explicitly mirror the
    // well-known algorithm used by _formatDfFromFrames().

    const drop = meta.dropPerMinute; // 2 for 29.97, 4 for 59.94, 8 for 119.88
    const framesPerMinute = base * 60 - drop;
    const framesPer10Min = base * 600 - drop * 9;

    // SMPTE timecode is defined modulo 24 hours.
    const framesInDay = framesPer10Min * 6 * 24;
    let fr = Number(totalFrames) % framesInDay;
    if (fr < 0) fr += framesInDay;

    const tenChunks = Math.floor(fr / framesPer10Min);
    const rem = fr % framesPer10Min;

    // Within the current 10-minute chunk, there are 9 drop events (each minute
    // except the 10th). The first drop does *not* apply until after the first
    // `drop` frames, so we clamp at 0 to avoid negative results.
    const extraDrop = Math.floor(Math.max(0, rem - drop) / framesPerMinute) * drop;
    const dropped = tenChunks * 9 * drop + extraDrop;
    const t = fr + dropped;

    const framesPerHour = base * 3600;
    const framesPerMinuteBase = base * 60;
    const hours = Math.floor(t / framesPerHour);
    const minutes = Math.floor((t % framesPerHour) / framesPerMinuteBase);
    const seconds = Math.floor((t % framesPerMinuteBase) / base);
    const frames = t % base;
    return { hours, minutes, seconds, frames, sep: ';' };
  }

  const framesPerHour = base * 60 * 60;
  const framesPerMinute = base * 60;

  // SMPTE timecode is defined modulo 24 hours. For NDF, make sure we:
  // - clamp to an integer frame count
  // - wrap negative/overflow values into the 24h window
  const framesInDay = framesPerHour * 24;
  let fr = Number(totalFrames);
  if (!Number.isFinite(fr)) fr = 0;
  fr = Math.floor(fr) % framesInDay;
  if (fr < 0) fr += framesInDay;

  let t = fr;
  const hours = Math.floor(t / framesPerHour);
  t -= hours * framesPerHour;
  const minutes = Math.floor(t / framesPerMinute);
  t -= minutes * framesPerMinute;
  const seconds = Math.floor(t / base);
  const frames = t - seconds * base;
  return { hours, minutes, seconds, frames, sep: ':' };
}

function formatTimecodeFromFrames(totalFrames, dropFrame = false, fps = 29.97, style = 'colon') {
  // This module has historically been called in two incompatible ways:
  //   1) formatTimecodeFromFrames(frames, dropFrameBool, fpsNum, style)
  //   2) formatTimecodeFromFrames(frames, fpsNum, { dropFrame, style })   <-- common in scripts
  // To keep timecode math correct (and tests sane), normalize the args.
  if (typeof dropFrame === 'number') {
    const fpsArg = dropFrame;
    const opts = (fps && typeof fps === 'object') ? fps : null;
    dropFrame = Boolean(opts?.dropFrame);
    style = opts?.style ?? style;
    fps = fpsArg;
  } else if (dropFrame && typeof dropFrame === 'object') {
    const opts = dropFrame;
    dropFrame = Boolean(opts?.dropFrame);
    style = opts?.style ?? style;
    fps = (typeof opts?.fps === 'number') ? opts.fps : fps;
  }

  // style mirrors formatTimecode() as much as possible.
  if (style === 'ms') {
    const sec = framesToSeconds(totalFrames, fps);
    return formatTimecode(sec, dropFrame, fps, 'ms');
  }
  const { hours, minutes, seconds, frames, sep } = timecodeComponentsFromFrames(totalFrames, dropFrame, fps);
  const h = String(hours).padStart(2, '0');
  const m = String(minutes).padStart(2, '0');
  const s = String(seconds).padStart(2, '0');
  const f = String(frames).padStart(2, '0');
  if (style === 'dot') return `${h}:${m}:${s}.${f}`;
  return `${h}:${m}:${s}${sep}${f}`;
}

function isLegalDropFrameLabel(tc, fps) {
  // Accept both ";" (SMPTE drop-frame) and ":" (some formats still label DF with a colon).
  const m = /^(\d{2}):(\d{2}):(\d{2})([:;])(\d{2})$/.exec(String(tc).trim());
  if (!m) return false;
  const [, , M, S, , F] = m;
  const meta = _rateMeta(fps);
  if (!meta.df) return false;
  // If a colon label is provided for a DF rate, treat it as DF for legality checks.
  // (We still prefer emitting ';' via timecodeComponentsFromFrames.)
  const mm = Number(M) || 0;
  const ss = Number(S) || 0;
  const ff = Number(F) || 0;
  // Illegal at the start of non-tenth minutes: ;00 and ;01 for 29.97 (drop=2), ;00..;03 for 59.94 (drop=4)
  if ((mm % 10) !== 0 && ss === 0 && ff < meta.dropPerMinute) return false;
  return mm < 60 && ss < 60 && ff < meta.base;
}

function assertLegalDropFrameLabel(tc, fps) {
  if (!isLegalDropFrameLabel(tc, fps)) {
    throw new Error(`Illegal drop-frame timecode for ${fps}fps: "${tc}"`);
  }
}

function parseTime(ts, fps = 30, dropFrameHint = null) {
  if (typeof ts === 'number') return Math.round(ts);
  if (!ts) return 0;
  const clean = String(ts).trim().replace(',', '.');

  const dot = /^(\d{2}):(\d{2}):(\d{2})\.(\d{2})$/.exec(clean);
  if (dot) {
    const [, H, M, S, FF] = dot;
    const h = Number(H) || 0;
    const m = Number(M) || 0;
    const s = Number(S) || 0;
    const f = Number(FF) || 0;
    const meta = _rateMeta(fps);
    const frameCount = meta.base * (h * 3600 + m * 60 + s) + Math.min(Math.max(f, 0), meta.base - 1);
    const millis = (frameCount * meta.den * 1000) / meta.num;
    return Math.round(millis);
  }

  const label = /^(\d{2}):(\d{2}):(\d{2})([:;])(\d{2})$/.exec(clean);
  if (label) {
    const [, H, M, S, sep, FF] = label;
    const h = Number(H) || 0;
    const m = Number(M) || 0;
    const s = Number(S) || 0;
    const f = Number(FF) || 0;
    const preferDf = (dropFrameHint === true) && sep === ':' && isDropFrameRate(fps);
    const isDfLabel = sep === ';' || preferDf;
    const totalFrames = _componentsToFrames(h, m, s, f, isDfLabel, fps);
    const meta = _rateMeta(fps);
    const millis = (totalFrames * meta.den * 1000) / meta.num;
    return Math.round(millis);
  }

  const parts = clean.split(':');
  if (parts.length === 3) {
    const h = Number(parts[0]) || 0;
    const m = Number(parts[1]) || 0;
    const s = Number.parseFloat(parts[2]);
    if (!Number.isNaN(s)) {
      return Math.round((h * 3600 + m * 60 + s) * 1000);
    }
  }

  const asNumber = Number.parseFloat(clean);
  if (!Number.isNaN(asNumber)) {
    return Math.round(asNumber * 1000);
  }
  return 0;
}

function _formatNdfFromFrames(totalFrames, base, sep) {
  const framesPerHour = base * 3600;
  const framesPerMinute = base * 60;
  const hours = Math.floor(totalFrames / framesPerHour);
  const minutes = Math.floor((totalFrames % framesPerHour) / framesPerMinute);
  const seconds = Math.floor((totalFrames % framesPerMinute) / base);
  const frames = totalFrames % base;
  const pad2 = (v) => String(v).padStart(2, '0');
  return `${pad2(hours)}:${pad2(minutes)}:${pad2(seconds)}${sep}${pad2(frames)}`;
}

function _formatDfFromFrames(totalFrames, fps, sep) {
  const meta = _rateMeta(fps);
  const base = meta.base;                 // 30 for 29.97, 60 for 59.94
  const drop = meta.dropPerMinute;        // 2 for 29.97, 4 for 59.94
  const framesPerMinute = base * 60 - drop;
  const framesPer10Min = base * 600 - drop * 9;

  // Count how many labels were dropped before `totalFrames`,
  // then "add them back" so we can format as a contiguous 30/60-base counter.
  const tenChunks = Math.floor(totalFrames / framesPer10Min);
  const rem = totalFrames % framesPer10Min;
  const extraDrop = Math.floor(Math.max(0, rem - drop) / framesPerMinute) * drop;
  const dropped = tenChunks * 9 * drop + extraDrop;
  const t = totalFrames + dropped;

  const framesPerHour = base * 3600;
  const framesPerMinuteBase = base * 60;
  const hours = Math.floor(t / framesPerHour);
  const minutes = Math.floor((t % framesPerHour) / framesPerMinuteBase);
  const seconds = Math.floor((t % framesPerMinuteBase) / base);
  const frame = t % base;
  const pad2 = (v) => String(v).padStart(2, '0');
  return `${pad2(hours)}:${pad2(minutes)}:${pad2(seconds)}${sep}${pad2(frame)}`;
}

function formatTimecode(seconds, dropFrame = false, fps = 29.97, style = 'colon', roundMode = 'floor') {
  if (typeof seconds !== 'number' || Number.isNaN(seconds)) {
    return style === 'ms' ? '00:00:00,000' : (style === 'dot' ? '00:00:00.00' : '00:00:00:00');
  }

  const meta = _rateMeta(fps);
  const useDf = !!dropFrame && meta.df;

  if (style === 'ms') {
    const whole = Math.floor(seconds);
    let ms = Math.round((seconds - whole) * 1000);
    let sec = whole;
    if (ms === 1000) {
      sec += 1;
      ms = 0;
    }
    const pad2 = (v) => String(v).padStart(2, '0');
    const pad3 = (v) => String(v).padStart(3, '0');
    const hh = Math.floor(sec / 3600);
    const mm = Math.floor((sec % 3600) / 60);
    const ss = sec % 60;
    return `${pad2(hh)}:${pad2(mm)}:${pad2(ss)},${pad3(ms)}`;
  }

  const totalFrames = secondsToFrames(seconds, fps, roundMode);

  if (style === 'dot') {
    const base = meta.base;
    const framesPerHour = base * 3600;
    const framesPerMinute = base * 60;
    const hours = Math.floor(totalFrames / framesPerHour);
    const minutes = Math.floor((totalFrames % framesPerHour) / framesPerMinute);
    const secs = Math.floor((totalFrames % framesPerMinute) / base);
    const frames = totalFrames % base;
    const pad2 = (v) => String(v).padStart(2, '0');
    return `${pad2(hours)}:${pad2(minutes)}:${pad2(secs)}.${pad2(frames)}`;
  }

  const sep = useDf ? ';' : ':';
  if (useDf) {
    return _formatDfFromFrames(totalFrames, fps, sep);
  }
  return _formatNdfFromFrames(totalFrames, meta.base, sep);
}

function msToTC(ms, fps, style = 'colon', dropFrame = false) {
  return formatTimecode(ms / 1000, dropFrame, fps, style);
}

function formatTimecodes(ms, fps, dropFrame = false) {
  const secs = ms / 1000;
  const dfCapable = isDropFrameRate(fps) === true;
  const ndf = formatTimecode(secs, false, fps, 'colon');
  const df = dropFrame ? formatTimecode(secs, true, fps, 'colon') : ndf;
  const msString = formatTimecode(secs, false, fps, 'ms');
  const roundedMs = Math.round(ms);
  return {
    ndf: { start: ndf, end: ndf },
    df: { start: df, end: df, dfCapable },
    ms: { start: roundedMs, end: roundedMs },
    timecodeFF: ndf,
    timecodeff: df,
    timecodeMs: msString,
    timecodeMsEnd: msString
  };
}

module.exports = {
  // primitives
  toFrame, toFrameStart, toFrameEnd, toMs, msToFrame, msToFrameStart, msToFrameEnd, nominalFrameBase, frameDurationMs,
  // DF/NDF core
  isDropFrameRate, secondsToFrames, framesToSeconds, framesFromTimecodeLabel,
  timecodeComponentsFromFrames, formatTimecodeFromFrames,
  isLegalDropFrameLabel, assertLegalDropFrameLabel,
  parseTime, msToTC, formatTimecode, formatTimecodes, formateTimecodeFromFrames: formatTimecodeFromFrames
};
