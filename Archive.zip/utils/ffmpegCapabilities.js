/* 
 * utils/ffmpegCapabilities.js
 * One stop for: encoders (-encoders) and muxers (-muxers)
 * - Single parser for both lists
 * - In-process cache with TTL
 * - Binary paths configurable (defaults to utils/ffmpeg resolution)
 */
const { execFileSync } = require('child_process');

let ffmpegBin = null;
let ttlMs = 10 * 60 * 1000; // 10 minutes
let cache = { stamp: 0, encoders: [], muxers: [] };

function configure({ ffmpegPath, cacheTtlMs } = {}) {
  if (ffmpegPath) ffmpegBin = ffmpegPath;
  if (Number.isFinite(cacheTtlMs) && cacheTtlMs > 0) ttlMs = cacheTtlMs;
}

function ensureBin() {
  if (ffmpegBin) return ffmpegBin;
  // Fallback to shared resolver (keeps a single source of truth for bundle paths)
  try {
    const { ffmpegPath } = require('./ffmpeg');
    ffmpegBin = ffmpegPath;
    return ffmpegBin;
  } catch {
    throw new Error('FFmpeg binary path is not configured');
  }
}

function run(args) {
  const bin = ensureBin();
  return execFileSync(bin, args, { encoding: 'utf8' }).toString();
}

// ---- Parsers ---------------------------------------------------------------
function parseEncoders(raw) {
  // Lines look like:
  // " V..... h264_videotoolbox   VideoToolbox H.264 Encoder"
  // " A..... aac                 AAC (Advanced Audio Coding)"
  const out = [];
  for (const line of raw.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z.]{6})\s+([^\s]+)\s+(.*)$/i);
    if (!m) continue;
    const flags = m[1] || '';
    const name = m[2];
    const description = (m[3] || '').trim();
    const type = flags.includes('V') ? 'video'
               : flags.includes('A') ? 'audio'
               : flags.includes('S') ? 'subtitle'
               : 'other';
    const hw =
      /videotoolbox/i.test(name) ? 'videotoolbox' :
      /nvenc/i.test(name)       ? 'nvenc'       :
      /qsv/i.test(name)         ? 'qsv'         :
      /amf/i.test(name)         ? 'amf'         : null;
    out.push({ name, type, hwAccel: hw, description });
  }
  return out;
}

function parseMuxers(raw) {
  // Lines look like: " E matroska           Matroska"
  const out = [];
  for (const line of raw.split(/\r?\n/)) {
    const m = line.match(/^\s*E\s+([^\s]+)\s+(.*)$/);
    if (!m) continue;
    const name = m[1];
    const description = (m[2] || '').trim();
    out.push({ name, description });
  }
  return out;
}

// ---- Public API ------------------------------------------------------------
function isFresh() {
  return (Date.now() - cache.stamp) < ttlMs;
}

function getCapabilities() {
  if (isFresh()) return cache;
  try {
    const encRaw = run(['-encoders']);
    const muxRaw = run(['-muxers']);
    cache = {
      stamp: Date.now(),
      encoders: parseEncoders(encRaw),
      muxers: parseMuxers(muxRaw)
    };
  } catch {
    // On error, keep old cache (if any) and surface empty results otherwise
    if (!cache.encoders.length && !cache.muxers.length) {
      cache = { stamp: Date.now(), encoders: [], muxers: [] };
    }
  }
  return cache;
}

function listEncoders(filter = {}) {
  const { type, hwAccel } = filter || {};
  let list = getCapabilities().encoders.slice();
  if (type) list = list.filter(e => e.type === type);
  if (hwAccel) list = list.filter(e => e.hwAccel === hwAccel);
  return list;
}

function listMuxers(whitelist = null) {
  let list = getCapabilities().muxers.slice();
  if (Array.isArray(whitelist) && whitelist.length) {
    const set = new Set(whitelist);
    list = list.filter(m => set.has(m.name));
  }
  return list;
}

module.exports = {
  configure,
  getCapabilities,
  listEncoders,
  listMuxers
};