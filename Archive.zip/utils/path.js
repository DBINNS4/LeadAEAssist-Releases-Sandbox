const fs = require('fs');

function ensureFolder(dir) {
  if (fs.existsSync(dir)) {
    const lst = fs.lstatSync(dir);
    if (lst.isSymbolicLink()) {
      throw new Error(`Path exists as a symlink and is not allowed: ${dir}`);
    }
    const stat = fs.statSync(dir);
    if (!stat.isDirectory()) {
      throw new Error(`Path exists but is not a directory: ${dir}`);
    }
    return;
  }
  fs.mkdirSync(dir, { recursive: true });
}

module.exports = { ensureFolder };
