'use strict';

// utils/fsAccessControl.js
//
// Centralized renderer->main filesystem access control.
//
// Policy (practical + secure):
//   The renderer may only perform file operations inside:
//     1) the app's userData directory (for app state), and
//     2) user-approved roots returned by native dialogs (files/folders).
//
// Main process keeps an in-memory approved roots set per renderer
// (keyed by event.sender.id). Nothing is persisted to disk.

const fs = require('fs');
const path = require('path');

let secureStore = null;
try {
  secureStore = require('../modules/secureStore');
} catch {
  secureStore = null;
}

let cachedUserDataRoots = null;
let missingUserDataWarningLogged = false;

const USER_DATA_ALLOWED_SUBDIRS = [
  'presets',
  'logs',
  'previews',
  path.join('temp'),
  path.join('cache'),
  path.join('config'),
];

const USER_DATA_SENSITIVE_PATHS = [
  path.join('config', 'secrets.bin'),
  path.join('config', 'secrets.fallback.key'),
  path.join('bridge', 'bridge.json'),
  path.join('bridge', 'auth.json'),
  path.join('auth'),
  path.join('license'),
  path.join('tokens'),
  path.join('config', 'license-token.json'),
  path.join('config', 'licenseToken.json'),
];

function getUserDataRoots() {
  if (cachedUserDataRoots) return cachedUserDataRoots;

  const roots = new Set();

  // Prefer the app's canonical userData path resolver when present.
  if (secureStore && typeof secureStore.resolveUserDataPath === 'function') {
    try {
      roots.add(secureStore.resolveUserDataPath());
    } catch {
      // ignore
    }
  }

  // Also allow Electron's configured userData directory (can differ
  // across dev/prod builds and app name changes).
  try {
    const { app } = require('electron');
    roots.add(app.getPath('userData'));
  } catch {
    // ignore
  }

  if (roots.size === 0 && !missingUserDataWarningLogged) {
    missingUserDataWarningLogged = true;
    console.error('[fsAccessControl] No trusted userData root resolved; denying filesystem access unless explicitly approved by dialog.');
  }

  cachedUserDataRoots = Array.from(roots).filter(Boolean);
  return cachedUserDataRoots;
}

function getUserDataPath() {
  return getUserDataRoots()[0];
}

function normalizeForComparison(p) {
  if (typeof p !== 'string') return null;
  const trimmed = p.trim();
  if (!trimmed) return null;

  let absolute;
  try {
    absolute = path.resolve(trimmed);
  } catch {
    return null;
  }

  const remainder = [];
  let cursor = absolute;
  let resolved = null;

  while (true) {
    try {
      const real = fs.realpathSync.native ? fs.realpathSync.native(cursor) : fs.realpathSync(cursor);
      resolved = remainder.length ? path.join(real, ...remainder.reverse()) : real;
      break;
    } catch {
      const parent = path.dirname(cursor);
      if (parent === cursor) return null;
      remainder.push(path.basename(cursor));
      cursor = parent;
    }
  }

  if (!resolved) return null;

  // Windows paths are case-insensitive.
  if (process.platform === 'win32') resolved = resolved.toLowerCase();
  return resolved;
}

function isSubpath(root, target) {
  if (!root || !target) return false;
  const rel = path.relative(root, target);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function isInsideAllowedUserDataSubdirs(userDataRoot, targetPath) {
  for (const subdir of USER_DATA_ALLOWED_SUBDIRS) {
    const allowedRoot = normalizeForComparison(path.join(userDataRoot, subdir));
    if (allowedRoot && isSubpath(allowedRoot, targetPath)) return true;
  }
  return false;
}

function getSensitivePathMatch(userDataRoot, targetPath) {
  for (const relPath of USER_DATA_SENSITIVE_PATHS) {
    const sensitiveRoot = normalizeForComparison(path.join(userDataRoot, relPath));
    if (!sensitiveRoot) continue;
    if (targetPath === sensitiveRoot || isSubpath(sensitiveRoot, targetPath)) {
      return relPath;
    }
  }
  return null;
}

function evaluatePathAccess(senderId, p) {
  const target = normalizeForComparison(p);
  if (!target) return { allowed: false, reason: 'invalid_path' };

  for (const base of getUserDataRoots()) {
    const normalizedBase = normalizeForComparison(base);
    if (!normalizedBase || !isSubpath(normalizedBase, target)) continue;

    const sensitiveMatch = getSensitivePathMatch(normalizedBase, target);
    if (sensitiveMatch) {
      return { allowed: false, reason: 'sensitive_path_denied', sensitivePath: sensitiveMatch };
    }

    if (isInsideAllowedUserDataSubdirs(normalizedBase, target)) {
      return { allowed: true, reason: 'user_data_allowlisted_subdir' };
    }

    return { allowed: false, reason: 'user_data_subdir_not_allowlisted' };
  }

  const list = _getSenderList(senderId) || [];
  for (const root of list) {
    if (!root || !root.path) continue;
    if (root.kind === 'file') {
      if (target === root.path) return { allowed: true, reason: 'approved_file' };
      continue;
    }
    if (root.kind === 'dir' && isSubpath(root.path, target)) return { allowed: true, reason: 'approved_dir' };
  }

  return { allowed: false, reason: 'not_approved' };
}

const approvedBySender = new Map();
const MAX_ROOTS_PER_SENDER = 256;

function _getSenderList(senderId) {
  const id = Number(senderId);
  if (!Number.isFinite(id)) return null;
  if (!approvedBySender.has(id)) approvedBySender.set(id, []);
  return approvedBySender.get(id);
}

function approveRoot(senderId, p, kindHint) {
  const list = _getSenderList(senderId);
  if (!list) return null;

  const normalized = normalizeForComparison(p);
  if (!normalized) return null;

  let kind = kindHint;
  if (kind !== 'file' && kind !== 'dir') {
    try {
      const st = fs.statSync(p);
      kind = st.isDirectory() ? 'dir' : 'file';
    } catch {
      kind = 'file';
    }
  }

  // De-dupe
  if (list.some(r => r.path === normalized && r.kind === kind)) return { path: normalized, kind };

  list.push({ path: normalized, kind });
  if (list.length > MAX_ROOTS_PER_SENDER) list.shift();

  return { path: normalized, kind };
}

function approveMany(senderId, paths, kindHint) {
  if (!Array.isArray(paths)) {
    approveRoot(senderId, paths, kindHint);
    return;
  }
  for (const p of paths) approveRoot(senderId, p, kindHint);
}

function isPathAllowed(senderId, p) {
  return evaluatePathAccess(senderId, p).allowed;
}

function resetApproved(senderId) {
  const id = Number(senderId);
  if (!Number.isFinite(id)) return;
  approvedBySender.delete(id);
}

module.exports = {
  getUserDataPath,
  getUserDataRoots,
  approveRoot,
  approveMany,
  evaluatePathAccess,
  isPathAllowed,
  resetApproved,
};
