'use strict';

const fs = require('fs');
const path = require('path');

function normalizeDir(value) {
  return (typeof value === 'string' && value.trim()) ? value.trim() : null;
}

function normalizeFile(value) {
  return (typeof value === 'string' && value.trim())
    ? path.resolve(value.trim())
    : null;
}

/**
 * Resolve candidate locations for the packaged runtime assets manifest.
 *
 * In packaged builds we intentionally support two layouts:
 *   1) extraResources/config/runtime.assets.manifest.json
 *   2) app.asar/config/runtime.assets.manifest.json
 *
 * The current packaging config includes the bundled config tree inside the app bundle, so the
 * app-relative path is the important fallback that keeps packaged builds working
 * even when the manifest is not duplicated into extraResources.
 */
function resolveManifestCandidatePaths(options = {}) {
  const isPackaged = !!options.isPackaged;
  const explicitManifestPath =
    normalizeFile(options.manifestPathOverride) ||
    normalizeFile(process.env.LEADAE_RUNTIME_ASSET_MANIFEST);
  const resourcesBase =
    normalizeDir(options.resourcesPathOverride) ||
    (
      typeof process.resourcesPath === 'string' && process.resourcesPath.trim()
        ? process.resourcesPath.trim()
        : null
    );
  const appBase =
    normalizeDir(options.appRootOverride) ||
    path.resolve(normalizeDir(options.moduleDirOverride) || __dirname, '..');
  const cwdBase = normalizeDir(options.cwdOverride) || process.cwd();

  const candidates = [];

  if (explicitManifestPath) {
    candidates.push(explicitManifestPath);
  }

  if (isPackaged && resourcesBase) {
    candidates.push(path.join(resourcesBase, 'config', 'runtime.assets.manifest.json'));
    candidates.push(path.join(resourcesBase, 'runtime.assets.manifest.json'));
  }

  if (appBase) {
    candidates.push(path.join(appBase, 'config', 'runtime.assets.manifest.json'));
  }

  if (cwdBase) {
    candidates.push(path.join(cwdBase, 'config', 'runtime.assets.manifest.json'));
  }

  return Array.from(new Set(candidates.filter(Boolean)));
}

/**
 * Load the packaged runtime assets manifest.
 *
 * This manifest is intentionally non-secret and ships inside the desktop app.
 * It will be used to version-lock externalized dependencies (e.g. Chrome-for-Testing,
 * whisper.cpp model binaries) to a specific app release (Option A).
 */
function loadRuntimeAssetsManifest(options = {}) {
  const candidates = resolveManifestCandidatePaths(options);

  for (const p of candidates) {
    try {
      if (!fs.existsSync(p)) continue;
      const j = JSON.parse(fs.readFileSync(p, 'utf8'));
      if (!j || typeof j !== 'object') continue;
      const schemaVersion = Number(j.schemaVersion || 0);
      const assets = (j.assets && typeof j.assets === 'object') ? j.assets : {};
      if (!Number.isFinite(schemaVersion) || schemaVersion <= 0) continue;
      return { schemaVersion, assets };
    } catch {
      // ignore bad JSON or unreadable file
    }
  }

  return { schemaVersion: 1, assets: {} };
}

module.exports = {
  loadRuntimeAssetsManifest,
  resolveManifestCandidatePaths
};
