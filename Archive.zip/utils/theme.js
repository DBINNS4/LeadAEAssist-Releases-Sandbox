// utils/theme.js
// Apply persisted theme (light/dark) without relying on inline scripts.

(() => {
  function applyStoredTheme() {
    try {
      const storedTheme = localStorage.getItem('theme');
      if (storedTheme) {
        document.body?.classList.toggle('dark-mode', storedTheme === 'dark');
      }
    } catch (_) {
      // Ignore storage errors.
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyStoredTheme, { once: true });
  } else {
    applyStoredTheme();
  }
})();
