'use strict';

const FALLBACK_WARN_THROTTLE_MS = Number(process.env.FALLBACK_WARN_THROTTLE_MS || 60 * 1000);

function createThrottledWarnLogger(defaultWindowMs = FALLBACK_WARN_THROTTLE_MS) {
  const lastByKey = new Map();
  return (key, detail, { windowMs = defaultWindowMs } = {}) => {
    const now = Date.now();
    const last = lastByKey.get(key) || 0;
    if ((now - last) < windowMs) return;
    lastByKey.set(key, now);
    console.warn(`[fallback:${key}]`, detail);
  };
}

const warnFallback = createThrottledWarnLogger();

function toError(value) {
  if (value instanceof Error) return value;
  if (typeof value === 'string') return new Error(value);
  return new Error('Unknown process-level error');
}

function safeMessage(err) {
  const raw = String(err?.message || err || 'Unknown error');
  const firstLine = raw.split('\n')[0].trim();
  return firstLine || 'Unknown error';
}

function isLikelyFatalError(err) {
  const code = String(err?.code || '');
  if (code === 'ERR_OUT_OF_MEMORY') return true;

  const msg = safeMessage(err).toLowerCase();
  return msg.includes('heap out of memory') || msg.includes('allocation failed - javascript heap out of memory');
}

function isExpectedUpdaterApplyError(err) {
  const msg = safeMessage(err);
  return /ditto:|shipit|could not lstat|could not read update request|could not locate update bundle/i.test(msg);
}

function registerGlobalErrorHandlers({
  telemetry,
  sendStatus,
  sendLog,
  onFatal,
  processRef = process
} = {}) {
  if (!processRef || typeof processRef.on !== 'function') return;
  if (processRef.__leadGlobalErrorHandlersInstalled) return;
  processRef.__leadGlobalErrorHandlersInstalled = true;

  const report = (kind, value, origin = null) => {
    const err = toError(value);
    const message = safeMessage(err);
    const updaterApplyError = kind === 'unhandledRejection' && isExpectedUpdaterApplyError(err);
    const fatal = !updaterApplyError && isLikelyFatalError(err);

    try {
      if (!updaterApplyError) {
        const scopeMeta = {
          tags: { scope: 'process', kind, severity: fatal ? 'fatal' : 'degraded' },
          extra: { origin: origin || undefined, fatal }
        };
        if (fatal) {
          telemetry?.captureException?.(err, scopeMeta);
        } else {
          telemetry?.captureMessage?.(message, {
            level: 'warning',
            ...scopeMeta,
            contexts: {
              process: {
                handler: kind,
                origin: origin || null
              }
            },
            dedupeKey: `runtime:${kind}:${message}`,
            dedupeWindowMs: 60 * 1000
          });
        }
      }
    } catch (err) {
      warnFallback('runtime.handler.telemetry-report-failed', err?.message || err);
    }

    try {
      sendLog?.({
        level: fatal ? 'error' : 'warn',
        kind: updaterApplyError ? 'autoUpdate' : kind,
        fatal,
        message,
        error: err
      });
    } catch (err) {
      warnFallback('runtime.handler.send-log-failed', err?.message || err);
    }

    try {
      sendStatus?.({
        status: updaterApplyError ? 'error' : (fatal ? 'fatal' : 'degraded'),
        kind: updaterApplyError ? 'autoUpdate' : kind,
        message: updaterApplyError
          ? 'A downloaded update could not be applied. Install the latest build manually.'
          : fatal
            ? 'A critical runtime error occurred. The app needs to close.'
            : 'A runtime issue occurred. You can continue, but some features may be unstable.'
      });
    } catch (err) {
      warnFallback('runtime.handler.send-status-failed', err?.message || err);
    }

    if (fatal) {
      try {
        onFatal?.(err, { kind, origin, message });
      } catch (fatalErr) {
        warnFallback('runtime.handler.on-fatal-callback-failed', fatalErr?.message || fatalErr);
      }
    }
  };

  processRef.on('unhandledRejection', (reason, promise) => {
    const origin = promise && typeof promise === 'object' ? 'promise' : null;
    report('unhandledRejection', reason, origin);
  });

  processRef.on('uncaughtException', (error, origin) => {
    report('uncaughtException', error, origin || null);
  });
}

module.exports = {
  registerGlobalErrorHandlers,
  isLikelyFatalError,
  safeMessage
};
