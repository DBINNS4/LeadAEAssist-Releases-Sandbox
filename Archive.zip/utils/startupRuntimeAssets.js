(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
    return;
  }

  const api = factory();
  root.startupRuntimeAssets = api;
  try {
    if (!root.runtimeAssetBootstrap) {
      root.runtimeAssetBootstrap = api.installStartupRuntimeAssetBootstrap();
    }
  } catch {
    // Best-effort only. Renderers can still create the bootstrap manually.
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const DEFAULT_BOOTSTRAP_PLAN = Object.freeze([
    Object.freeze({
      key: 'chromium',
      featureName: 'chromium',
      kind: 'chromium',
      request: Object.freeze({ feature: 'chromium' }),
      language: null,
      languageLabel: null
    }),
    Object.freeze({
      key: 'whisper-en',
      featureName: 'whisper',
      kind: 'whisper',
      request: Object.freeze({ feature: 'whisper', language: 'en' }),
      language: 'en',
      languageLabel: 'English (EN)'
    }),
    Object.freeze({
      key: 'whisper-multi',
      featureName: 'whisper',
      kind: 'whisper',
      request: Object.freeze({ feature: 'whisper', language: 'es' }),
      language: 'multi',
      languageLabel: 'All non-English languages'
    })
  ]);

  function _copyRequest(request) {
    return request && typeof request === 'object' ? { ...request } : {};
  }

  function _translate(options, key, fallback) {
    try {
      if (typeof options?.translate === 'function') {
        const value = options.translate(key, fallback);
        if (typeof value === 'string' && value) return value;
      }
    } catch {}
    return fallback != null ? String(fallback) : String(key || '');
  }

  function _translateTemplate(options, key, fallback, replacements) {
    try {
      if (typeof options?.translateTemplate === 'function') {
        const value = options.translateTemplate(key, fallback, replacements || {});
        if (typeof value === 'string' && value) return value;
      }
    } catch {}

    let template = _translate(options, key, fallback);
    for (const [token, value] of Object.entries(replacements || {})) {
      const pattern = new RegExp(`{{${token}}}`, 'g');
      template = template.replace(pattern, () => String(value ?? ''));
    }
    return template;
  }

  function _defaultTranslate(key, fallback) {
    try {
      const t = globalThis?.i18n?.t;
      if (typeof t === 'function') {
        const value = t(key, { defaultValue: fallback });
        if (typeof value === 'string' && value) return value;
      }
    } catch {}
    return fallback != null ? String(fallback) : String(key || '');
  }

  function _defaultTranslateTemplate(key, fallback, replacements) {
    let template = _defaultTranslate(key, fallback);
    for (const [token, value] of Object.entries(replacements || {})) {
      const pattern = new RegExp(`{{${token}}}`, 'g');
      template = template.replace(pattern, () => String(value ?? ''));
    }
    return template;
  }

  function _sanitizeError(error) {
    if (!error) return null;
    return {
      code: String(error.code || error.snapshot?.error?.code || 'ASSET_PREFETCH_FAILED').trim() || 'ASSET_PREFETCH_FAILED',
      message: String(error.message || error.snapshot?.error?.message || error).trim() || 'Runtime asset request failed'
    };
  }

  function _snapshotClone(snapshot) {
    if (!snapshot || typeof snapshot !== 'object') return snapshot || null;
    const clonedProgress = snapshot.progress && typeof snapshot.progress === 'object'
      ? { ...snapshot.progress }
      : null;
    const clonedError = snapshot.error && typeof snapshot.error === 'object'
      ? { ...snapshot.error }
      : snapshot.error || null;
    const clonedDescriptor = snapshot.descriptor && typeof snapshot.descriptor === 'object'
      ? { ...snapshot.descriptor }
      : {};

    return {
      ...snapshot,
      descriptor: clonedDescriptor,
      progress: clonedProgress,
      error: clonedError
    };
  }

  function _normalizePlanEntry(entry, options) {
    const normalizedEntry = entry && typeof entry === 'object' ? entry : {};
    const request = _copyRequest(normalizedEntry.request);
    const featureName = String(normalizedEntry.featureName || request.feature || normalizedEntry.kind || '').trim().toLowerCase();
    const key = String(normalizedEntry.key || featureName || `asset-${Date.now()}`).trim() || `asset-${Date.now()}`;
    const kind = String(normalizedEntry.kind || featureName || 'asset').trim().toLowerCase() || 'asset';
    const language = normalizedEntry.language == null ? null : String(normalizedEntry.language).trim().toLowerCase() || null;
    let languageLabel = normalizedEntry.languageLabel == null ? null : String(normalizedEntry.languageLabel).trim() || null;

    if (!languageLabel && featureName === 'whisper' && language === 'en') {
      languageLabel = _translate(options, 'languageEnglish', 'English (EN)');
    }
    if (!languageLabel && featureName === 'whisper' && language === 'multi') {
      languageLabel = _translate(options, 'runtimeAssetLanguageMulti', 'All non-English languages');
    }

    return {
      key,
      featureName,
      kind,
      request,
      language,
      languageLabel
    };
  }

  function _createAssetState(entry) {
    return {
      key: entry.key,
      featureName: entry.featureName,
      kind: entry.kind,
      request: _copyRequest(entry.request),
      language: entry.language,
      languageLabel: entry.languageLabel,
      started: false,
      finished: false,
      active: false,
      ready: false,
      immediate: false,
      error: null,
      snapshot: null,
      lastSnapshot: null,
      lastProgressRatio: null,
      startedAt: null,
      completedAt: null,
      updatedAt: Date.now()
    };
  }

  function _createFeatureState(featureName, total, enabled) {
    return {
      name: featureName,
      total,
      completed: 0,
      ready: false,
      pending: !!enabled,
      active: false,
      error: null,
      currentKey: null,
      currentSnapshot: null,
      lastSnapshot: null,
      lastProgressRatio: null,
      language: null,
      languageLabel: null,
      updatedAt: Date.now()
    };
  }

  function createStartupRuntimeAssetBootstrap(options = {}) {
    const normalizedOptions = options && typeof options === 'object' ? options : {};
    const win = normalizedOptions.windowObj || (typeof window !== 'undefined' ? window : null);
    const electron = normalizedOptions.electron || win?.electron || null;
    const assetsApi = normalizedOptions.assetsApi || electron?.assets || null;
    const assetUi = normalizedOptions.assetUi || win?.runtimeAssetUi || null;
    const enabled = typeof normalizedOptions.enabled === 'boolean'
      ? normalizedOptions.enabled
      : !!(electron?.isPackaged && assetsApi && typeof assetsApi.prefetch === 'function' && assetUi && typeof assetUi.startRuntimeAssetPrefetch === 'function');

    const plan = Object.freeze(
      (Array.isArray(normalizedOptions.plan) && normalizedOptions.plan.length ? normalizedOptions.plan : DEFAULT_BOOTSTRAP_PLAN)
        .map(entry => _normalizePlanEntry(entry, {
          translate: normalizedOptions.translate || _defaultTranslate,
          translateTemplate: normalizedOptions.translateTemplate || _defaultTranslateTemplate
        }))
    );

    const assetStateByKey = new Map();
    const featureEntriesByName = new Map();
    const featureStateByName = new Map();
    const listeners = new Set();

    for (const entry of plan) {
      assetStateByKey.set(entry.key, _createAssetState(entry));
      const list = featureEntriesByName.get(entry.featureName) || [];
      list.push(entry.key);
      featureEntriesByName.set(entry.featureName, list);
    }

    for (const [featureName, keys] of featureEntriesByName.entries()) {
      featureStateByName.set(featureName, _createFeatureState(featureName, keys.length, enabled));
    }

    const state = {
      enabled,
      started: false,
      active: false,
      finished: !enabled,
      successful: !enabled,
      startCount: 0,
      currentKey: null,
      startedAt: null,
      completedAt: null,
      errorCount: 0,
      fatalError: null,
      overall: {
        total: plan.length,
        completed: 0,
        ready: !enabled,
        pending: !!enabled,
        updatedAt: Date.now()
      }
    };

    let startPromise = null;

    function _resolveEntryKeyForSnapshot(snapshot) {
      const feature = String(snapshot?.feature || snapshot?.kind || '').trim().toLowerCase();
      if (!feature) return null;
      if (feature.includes('chrom')) return assetStateByKey.has('chromium') ? 'chromium' : null;
      if (!feature.includes('whisper')) return null;

      const language = String(snapshot?.language || '').trim().toLowerCase();
      if (language === 'en' && assetStateByKey.has('whisper-en')) return 'whisper-en';
      if (language && language !== 'en' && assetStateByKey.has('whisper-multi')) return 'whisper-multi';
      return null;
    }

    function _dispatch(snapshot) {
      if (!win || typeof win.dispatchEvent !== 'function' || typeof CustomEvent !== 'function') return;
      try {
        win.dispatchEvent(new CustomEvent('lae:runtime-assets-bootstrap', { detail: snapshot }));
      } catch {
        // Ignore DOM dispatch failures.
      }
    }

    function _summarizeFeature(featureName) {
      const keys = featureEntriesByName.get(featureName) || [];
      const entries = keys.map(key => assetStateByKey.get(key)).filter(Boolean);
      const featureState = featureStateByName.get(featureName);
      if (!featureState) return;

      const ready = entries.length > 0 && entries.every(entry => entry.ready);
      const active = entries.some(entry => entry.active);
      const completed = entries.filter(entry => entry.finished).length;
      const latest = [...entries].reverse().find(entry => entry.snapshot || entry.lastSnapshot) || null;
      const errorEntry = entries.find(entry => entry.error && !entry.ready) || null;

      featureState.completed = completed;
      featureState.ready = ready;
      featureState.active = active;
      featureState.pending = !!enabled && !ready && (state.active || completed < featureState.total);
      featureState.error = errorEntry ? { ...errorEntry.error } : null;
      featureState.currentKey = latest?.key || null;
      featureState.currentSnapshot = latest?.snapshot ? _snapshotClone(latest.snapshot) : null;
      featureState.lastSnapshot = latest?.lastSnapshot ? _snapshotClone(latest.lastSnapshot) : null;
      featureState.lastProgressRatio = latest?.lastProgressRatio ?? null;
      featureState.language = latest?.language || null;
      featureState.languageLabel = latest?.languageLabel || null;
      featureState.updatedAt = Date.now();
    }

    function _summarizeOverall() {
      const entries = [...assetStateByKey.values()];
      state.errorCount = entries.filter(entry => entry.error && !entry.ready).length;
      state.overall.completed = entries.filter(entry => entry.finished).length;
      state.overall.ready = entries.length > 0 && entries.every(entry => entry.ready);
      state.overall.pending = !!enabled && !state.overall.ready && (state.active || state.overall.completed < state.overall.total);
      state.overall.updatedAt = Date.now();
    }

    function _snapshot() {
      const assets = {};
      for (const [key, entry] of assetStateByKey.entries()) {
        assets[key] = {
          ...entry,
          request: _copyRequest(entry.request),
          error: entry.error ? { ...entry.error } : null,
          snapshot: entry.snapshot ? _snapshotClone(entry.snapshot) : null,
          lastSnapshot: entry.lastSnapshot ? _snapshotClone(entry.lastSnapshot) : null
        };
      }

      const features = {};
      for (const [featureName, featureState] of featureStateByName.entries()) {
        features[featureName] = {
          ...featureState,
          error: featureState.error ? { ...featureState.error } : null,
          currentSnapshot: featureState.currentSnapshot ? _snapshotClone(featureState.currentSnapshot) : null,
          lastSnapshot: featureState.lastSnapshot ? _snapshotClone(featureState.lastSnapshot) : null
        };
      }

      return {
        enabled: state.enabled,
        started: state.started,
        active: state.active,
        finished: state.finished,
        successful: state.successful,
        startCount: state.startCount,
        currentKey: state.currentKey,
        startedAt: state.startedAt,
        completedAt: state.completedAt,
        errorCount: state.errorCount,
        fatalError: state.fatalError ? { ...state.fatalError } : null,
        overall: { ...state.overall },
        assets,
        features
      };
    }

    function _emit() {
      for (const featureName of featureStateByName.keys()) {
        _summarizeFeature(featureName);
      }
      _summarizeOverall();
      const nextSnapshot = _snapshot();
      for (const listener of [...listeners]) {
        try {
          listener(nextSnapshot);
        } catch {
          // Listener errors should not break bootstrap updates.
        }
      }
      _dispatch(nextSnapshot);
      return nextSnapshot;
    }

    function _updateAssetState(entryKey, snapshot, controller, options = {}) {
      const entry = assetStateByKey.get(entryKey);
      if (!entry) return null;

      const snapshotClone = _snapshotClone(snapshot || {});
      const terminalState = String(snapshotClone?.state || '').trim().toLowerCase();
      const isInstalled = terminalState === 'installed';
      const isTerminal = isInstalled || terminalState === 'error' || terminalState === 'cancelled';

      entry.started = true;
      entry.finished = isTerminal;
      entry.active = !!snapshotClone?.active && !isTerminal;
      entry.ready = isInstalled;
      entry.immediate = options.immediate === true || entry.immediate;
      entry.error = terminalState === 'error'
        ? _sanitizeError(snapshotClone?.error || snapshotClone)
        : (terminalState === 'cancelled'
          ? _sanitizeError({ code: 'ABORT_ERR', message: String(snapshotClone?.error?.message || 'Runtime asset download cancelled.') })
          : null);
      entry.snapshot = entry.active ? snapshotClone : null;
      entry.lastSnapshot = snapshotClone;
      entry.lastProgressRatio = controller && Number.isFinite(Number(controller.lastProgressRatio))
        ? Number(controller.lastProgressRatio)
        : entry.lastProgressRatio;
      if (!entry.startedAt) entry.startedAt = Date.now();
      if (entry.finished && !entry.completedAt) entry.completedAt = Date.now();
      entry.updatedAt = Date.now();
      return snapshotClone;
    }

    if (assetsApi && typeof assetsApi.onProgress === 'function') {
      try {
        assetsApi.onProgress((snapshot) => {
          const entryKey = _resolveEntryKeyForSnapshot(snapshot);
          const stateLabel = String(snapshot?.state || '').trim().toLowerCase();
          if (!entryKey || stateLabel !== 'installed') return;
          _updateAssetState(entryKey, snapshot, {
            lastProgressRatio: Number.isFinite(Number(snapshot?.progress?.progress))
              ? Number(snapshot.progress.progress)
              : null
          }, {
            immediate: false
          });
          _emit();
        });
      } catch {
        // Ignore renderer subscription failures; the startup bootstrap still works.
      }
    }

    async function _runEntry(entry) {
      const assetState = assetStateByKey.get(entry.key);
      if (!assetState) return;

      state.currentKey = entry.key;
      if (!assetState.startedAt) assetState.startedAt = Date.now();
      assetState.started = true;
      assetState.active = true;
      assetState.updatedAt = Date.now();
      _emit();

      try {
        const controller = await assetUi.startRuntimeAssetPrefetch(
          assetsApi,
          _copyRequest(entry.request),
          {
            kind: entry.kind,
            languageLabel: entry.languageLabel,
            translate: normalizedOptions.translate || _defaultTranslate,
            translateTemplate: normalizedOptions.translateTemplate || _defaultTranslateTemplate,
            onSnapshot: (snapshot, currentController) => {
              _updateAssetState(entry.key, snapshot, currentController);
              _emit();
            }
          }
        );

        if (controller.immediate) {
          _updateAssetState(entry.key, controller.snapshot || { state: 'installed', installed: true, ready: true }, controller, {
            immediate: true
          });
          _emit();
          return;
        }

        try {
          const result = await controller.promise;
          _updateAssetState(entry.key, result, controller);
          _emit();
        } catch (error) {
          const snapshot = error?.snapshot || {
            feature: entry.featureName,
            kind: entry.kind,
            language: entry.language,
            state: 'error',
            error: _sanitizeError(error)
          };
          _updateAssetState(entry.key, snapshot, controller);
          _emit();
        }
      } catch (error) {
        const snapshot = error?.snapshot || {
          feature: entry.featureName,
          kind: entry.kind,
          language: entry.language,
          state: 'error',
          error: _sanitizeError(error)
        };
        _updateAssetState(entry.key, snapshot, null);
        _emit();
      }
    }

    async function start() {
      if (startPromise) return startPromise;

      if (!enabled) {
        state.started = true;
        state.active = false;
        state.finished = true;
        state.successful = true;
        state.startCount += 1;
        state.startedAt = state.startedAt || Date.now();
        state.completedAt = Date.now();
        return _emit();
      }

      state.started = true;
      state.active = true;
      state.finished = false;
      state.successful = false;
      state.startCount += 1;
      state.startedAt = state.startedAt || Date.now();
      _emit();

      startPromise = (async () => {
        try {
          for (const entry of plan) {
            await _runEntry(entry);
          }
        } catch (error) {
          state.fatalError = _sanitizeError(error);
        } finally {
          state.active = false;
          state.finished = true;
          state.currentKey = null;
          state.completedAt = Date.now();
          state.successful = [...assetStateByKey.values()].every(entry => entry.ready);
        }
        return _emit();
      })();

      return startPromise;
    }

    function autoStart() {
      return start();
    }

    function getState() {
      return _snapshot();
    }

    function getFeatureState(featureName) {
      const key = String(featureName || '').trim().toLowerCase();
      const snapshot = _snapshot();
      return snapshot.features[key] || null;
    }

    function shouldBlockFeature(featureName) {
      return !!getFeatureState(featureName)?.pending;
    }

    function isFeatureReady(featureName) {
      return !!getFeatureState(featureName)?.ready;
    }

    function onChange(listener) {
      if (typeof listener !== 'function') return () => {};
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    }

    return {
      start,
      autoStart,
      getState,
      getFeatureState,
      shouldBlockFeature,
      isFeatureReady,
      onChange
    };
  }

  function installStartupRuntimeAssetBootstrap(options = {}) {
    const normalizedOptions = options && typeof options === 'object' ? options : {};
    const win = normalizedOptions.windowObj || (typeof window !== 'undefined' ? window : null);
    const doc = normalizedOptions.documentObj || win?.document || null;

    if (!win) {
      return createStartupRuntimeAssetBootstrap(normalizedOptions);
    }

    if (win.runtimeAssetBootstrap && typeof win.runtimeAssetBootstrap.getState === 'function') {
      return win.runtimeAssetBootstrap;
    }

    let enabled = normalizedOptions.enabled;
    if (typeof enabled !== 'boolean') {
      let isSubtitleEditorWindow = false;
      try {
        const search = String(win.location?.search || '');
        isSubtitleEditorWindow = new URLSearchParams(search).get('win') === 'subtitle-editor';
      } catch {}
      if (isSubtitleEditorWindow) enabled = false;
    }

    const bootstrap = createStartupRuntimeAssetBootstrap({
      ...normalizedOptions,
      enabled,
      windowObj: win
    });
    win.runtimeAssetBootstrap = bootstrap;

    const bootstrapEnabled = (() => {
      try {
        return !!bootstrap.getState?.().enabled;
      } catch {
        return !!enabled;
      }
    })();

    if (normalizedOptions.autoStart !== false && bootstrapEnabled) {
      const startBootstrap = () => {
        try {
          if (!bootstrap.getState?.().started) {
            void bootstrap.start();
          }
        } catch {
          void bootstrap.start();
        }
      };

      if (doc && doc.readyState === 'loading') {
        doc.addEventListener('DOMContentLoaded', startBootstrap, { once: true });
      } else {
        startBootstrap();
      }
    }

    return bootstrap;
  }

  return {
    DEFAULT_BOOTSTRAP_PLAN,
    createStartupRuntimeAssetBootstrap,
    installStartupRuntimeAssetBootstrap
  };
});
