const path = require('path');
const fs = require('fs');

const { ensureUserDataSubdir } = require('./appPaths');
const { renameReplaceSync, safeReadJson, uniqueTempPath } = require('./fsSafe');

// Persist hash cache in userData/config/cache so it remains writable in
// packaged builds without polluting config root.
const hashCachePath = path.join(ensureUserDataSubdir('config', 'cache'), 'hash-cache.json');
const hashCacheBackupPath = `${hashCachePath}.bak`;

const legacyHashCachePath = path.join(ensureUserDataSubdir('logs'), 'hash-cache.json');
const legacyHashCacheBackupPath = `${legacyHashCachePath}.bak`;
const CACHE_FILE_MODE = 0o600;
const DEFAULT_MAX_ENTRIES = 5000;
const DEFAULT_MAX_AGE_DAYS = 30;

function getPruneOptions() {
  const maxEntriesEnv = Number.parseInt(process.env.HASH_CACHE_MAX_ENTRIES, 10);
  const maxAgeDaysEnv = Number.parseInt(process.env.HASH_CACHE_MAX_AGE_DAYS, 10);
  const maxEntries = Number.isFinite(maxEntriesEnv) && maxEntriesEnv > 0
    ? maxEntriesEnv
    : DEFAULT_MAX_ENTRIES;
  const maxAgeDays = Number.isFinite(maxAgeDaysEnv) && maxAgeDaysEnv > 0
    ? maxAgeDaysEnv
    : DEFAULT_MAX_AGE_DAYS;
  return {
    maxEntries,
    maxAgeMs: maxAgeDays * 24 * 60 * 60 * 1000
  };
}

function pruneCache(cache, options = {}) {
  if (!cache || typeof cache !== 'object') return {};
  const { maxEntries, maxAgeMs } = options;
  const now = Date.now();
  let entries = Object.entries(cache).filter(([, value]) => value && typeof value === 'object');

  if (Number.isFinite(maxAgeMs) && maxAgeMs > 0) {
    entries = entries.filter(([, value]) => {
      const timestamp = Number(value.timestamp);
      if (!Number.isFinite(timestamp) || timestamp <= 0) return false;
      return now - timestamp <= maxAgeMs;
    });
  }

  if (Number.isFinite(maxEntries) && maxEntries > 0 && entries.length > maxEntries) {
    entries.sort(([, a], [, b]) => {
      const aTime = Number(a.timestamp) || 0;
      const bTime = Number(b.timestamp) || 0;
      return bTime - aTime;
    });
    entries = entries.slice(0, maxEntries);
  }

  return Object.fromEntries(entries);
}

function applyPrunedCache(targetCache, prunedCache) {
  for (const key of Object.keys(targetCache)) {
    if (!(key in prunedCache)) {
      delete targetCache[key];
    }
  }
  for (const [key, value] of Object.entries(prunedCache)) {
    targetCache[key] = value;
  }
}


function writeJsonAtomicallySync(filePath, payload, mode = 0o600) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tempPath = uniqueTempPath(filePath, '.tmp');
  fs.writeFileSync(tempPath, payload, { encoding: 'utf-8', mode });
  renameReplaceSync(tempPath, filePath);
  try {
    fs.chmodSync(filePath, mode);
  } catch {
    // Best-effort only (e.g. Windows)
  }
}


function migrateLegacyCacheIfNeeded() {
  try {
    if (fs.existsSync(hashCachePath)) return;
    fs.mkdirSync(path.dirname(hashCachePath), { recursive: true });

    if (fs.existsSync(legacyHashCachePath)) {
      try {
        renameReplaceSync(legacyHashCachePath, hashCachePath);
      } catch {
        const legacy = safeReadJson(legacyHashCachePath, null);
        if (legacy && typeof legacy === 'object') {
          writeJsonAtomicallySync(hashCachePath, JSON.stringify(legacy, null, 2), CACHE_FILE_MODE);
          try { fs.unlinkSync(legacyHashCachePath); } catch {}
        }
      }
    }

    if (fs.existsSync(legacyHashCacheBackupPath) && !fs.existsSync(hashCacheBackupPath)) {
      try {
        renameReplaceSync(legacyHashCacheBackupPath, hashCacheBackupPath);
      } catch {
        const legacyBak = safeReadJson(legacyHashCacheBackupPath, null);
        if (legacyBak && typeof legacyBak === 'object') {
          writeJsonAtomicallySync(hashCacheBackupPath, JSON.stringify(legacyBak, null, 2), CACHE_FILE_MODE);
          try { fs.unlinkSync(legacyHashCacheBackupPath); } catch {}
        }
      }
    }
  } catch {
    // best-effort migration only.
  }
}

function readCacheFile(cachePath) {
  const cache = safeReadJson(cachePath, null);
  return (cache && typeof cache === 'object') ? cache : null;
}

// Load cache from disk
function loadCache() {
  migrateLegacyCacheIfNeeded();
  const pruneOptions = getPruneOptions();
  const primaryCache = readCacheFile(hashCachePath);
  if (primaryCache) {
    return pruneCache(primaryCache, pruneOptions);
  }

  const backupCache = readCacheFile(hashCacheBackupPath);
  if (backupCache) {
    const prunedBackup = pruneCache(backupCache, pruneOptions);
    // Best-effort healing: restore canonical cache file from backup.
    saveCache(prunedBackup);
    return prunedBackup;
  }

  // Recreate defaults silently when cache is missing/corrupt.
  saveCache({});
  return {};
}

// Save cache to disk
function saveCache(cache) {
  try {
    const pruned = pruneCache(cache, getPruneOptions());
    fs.mkdirSync(path.dirname(hashCachePath), { recursive: true });

    // Keep in-memory object aligned with persisted/pruned form.
    if (cache && typeof cache === 'object') {
      applyPrunedCache(cache, pruned);
    }

    const payload = JSON.stringify(pruned, null, 2);
    writeJsonAtomicallySync(hashCachePath, payload, CACHE_FILE_MODE);
    try {
      writeJsonAtomicallySync(hashCacheBackupPath, payload, CACHE_FILE_MODE);
    } catch {
      // Backup persistence is best-effort only.
    }
  } catch {
    // Noisy logging intentionally avoided for recoverable cache writes.
  }
}

// Add a new entry
function updateCacheEntry(cache, hash, relPath) {
  cache[hash] = {
    file: relPath,
    timestamp: Date.now()
  };
  const prunedCache = pruneCache(cache, getPruneOptions());
  applyPrunedCache(cache, prunedCache);
}

// Check if file is already processed
function isDuplicate(cache, hash) {
  return !!cache[hash];
}

module.exports = {
  loadCache,
  saveCache,
  updateCacheEntry,
  isDuplicate
};
