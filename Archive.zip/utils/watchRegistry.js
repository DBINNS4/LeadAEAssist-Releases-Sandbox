// utils/watchRegistry.js
//
// Watch-mode processed tracking.
//
// Key design goal: **never** write marker files back into source media folders.
// Instead we track processed files in a small registry under userData/cache,
// so it works on read-only volumes (camera cards, protected network shares)
// and avoids mutating source directories.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const { ensureUserDataSubdir } = require('./appPaths');
const { atomicWriteJson, safeReadJson } = require('./fsSafe');

const REGISTRY_PATH = path.join(ensureUserDataSubdir('cache', 'watch'), 'processed.json');

// Tunables (env overrides are useful for heavy facilities).
const DEFAULT_MAX_ENTRIES = Number(process.env.WATCH_REGISTRY_MAX_ENTRIES || 50000);
const DEFAULT_MAX_AGE_DAYS = Number(process.env.WATCH_REGISTRY_MAX_AGE_DAYS || 90);
const DEFAULT_SAVE_DEBOUNCE_MS = Number(process.env.WATCH_REGISTRY_SAVE_DEBOUNCE_MS || 1000);

function nowMs() {
  return Date.now();
}

function normalizeRootKey(rootPath) {
  if (!rootPath) return '';
  const str = String(rootPath);
  try {
    const real = fs.realpathSync(str);
    return process.platform === 'win32' || process.platform === 'darwin'
      ? real.toLowerCase()
      : real;
  } catch {
    try {
      const resolved = path.resolve(str);
      return process.platform === 'win32' || process.platform === 'darwin'
        ? resolved.toLowerCase()
        : resolved;
    } catch {
      return str;
    }
  }
}

/**
 * Create a stable session key.
 *
 * Session keys are scoped by:
 *   - panel (ingest/transcode/etc)
 *   - watchRootKey (the watched folder)
 *   - optional variantKey (e.g., ingest destination/preset)
 */
function createSessionKey(panel, watchRootKey, variantKey = '') {
  const p = String(panel || 'unknown').trim().toLowerCase();
  const root = normalizeRootKey(watchRootKey);
  const v = String(variantKey || '').trim();
  return v ? `${p}::${root}::${v}` : `${p}::${root}`;
}

// Normalize path separators + trim.
function normalizeRelPath(p) {
  return String(p || '')
    .replace(/\\/g, '/')
    .replace(/^\/+/, '')
    .replace(/\/+$/, '')
    .trim();
}

/**
 * A file signature is based on:
 *   - relative path from watch root (normalized)
 *   - size (bytes)
 *   - mtime (ms)
 *   - ctime (ms) when available
 *   - inode/volume identifiers when available
 *   - small-file content hash when provided
 *
 * If a file is replaced/rewritten, the signature should change even when size/mtime are preserved.
 */
function createFileSignature(watchRoot, filePath, sizeBytes, mtimeMs, opts = {}) {
  const rel = normalizeRelPath(path.relative(watchRoot, filePath));
  const ctimeMs = Number.isFinite(opts?.ctimeMs) ? opts.ctimeMs : 0;
  const inode = opts?.inode ? String(opts.inode) : '';
  const contentHash = opts?.contentHash ? String(opts.contentHash) : '';
  return `${rel}|${Number(sizeBytes) || 0}|${Number(mtimeMs) || 0}|${ctimeMs}|${inode}|${contentHash}`;
}

function createEntryId(sessionKey, fileSignature) {
  return crypto
    .createHash('sha1')
    .update(`${sessionKey}::${fileSignature}`)
    .digest('hex');
}

function isProcessed(registry, sessionKey, fileSignature) {
  if (!registry || !sessionKey || !fileSignature) return false;
  const id = createEntryId(sessionKey, fileSignature);
  return !!registry[id];
}

/**
 * Mark a signature as processed (in-memory).
 * Returns true if updated.
 */
function markProcessed(registry, sessionKey, fileSignature, meta = {}) {
  if (!registry || !sessionKey || !fileSignature) return false;
  const id = createEntryId(sessionKey, fileSignature);
  registry[id] = {
    session: String(sessionKey),
    file: String(meta.file || ''),
    sizeBytes: Number(meta.sizeBytes) || 0,
    mtimeMs: Number(meta.mtimeMs) || 0,
    timestamp: nowMs()
  };
  return true;
}

function pruneRegistry(registry, opts = {}) {
  const maxEntries = Number.isFinite(opts.maxEntries) ? opts.maxEntries : DEFAULT_MAX_ENTRIES;
  const maxAgeDays = Number.isFinite(opts.maxAgeDays) ? opts.maxAgeDays : DEFAULT_MAX_AGE_DAYS;

  const cutoffMs = nowMs() - maxAgeDays * 24 * 60 * 60 * 1000;
  const entries = Object.entries(registry || {});

  // Drop too-old entries
  const fresh = entries.filter(([, v]) => (v?.timestamp || 0) >= cutoffMs);
  fresh.sort((a, b) => (b[1]?.timestamp || 0) - (a[1]?.timestamp || 0));

  const trimmed = maxEntries > 0 ? fresh.slice(0, maxEntries) : fresh;
  return Object.fromEntries(trimmed);
}

function loadWatchRegistry() {
  const data = safeReadJson(REGISTRY_PATH, {});
  const pruned = pruneRegistry(data);
  // Keep pruned in memory; next save will persist.
  return pruned;
}

async function saveWatchRegistry(registry) {
  try {
    const pruned = pruneRegistry(registry);

    // Mutate the caller's object so in-memory state matches what we persist.
    // This prevents unbounded growth during long watch sessions.
    if (registry && typeof registry === 'object') {
      for (const k of Object.keys(registry)) delete registry[k];
      Object.assign(registry, pruned);
    }

    await atomicWriteJson(REGISTRY_PATH, pruned);
    return { ok: true, path: REGISTRY_PATH };
  } catch (err) {
    return { ok: false, error: err?.message || String(err) };
  }
}

// ---------------------------------------------------------------------------
// Shared (singleton) registry helpers
// ---------------------------------------------------------------------------

let sharedRegistry = null;
let sharedDirty = false;
let sharedSaveTimer = null;
let sharedSavingPromise = null;

function getSharedWatchRegistry() {
  if (sharedRegistry) return sharedRegistry;
  sharedRegistry = loadWatchRegistry();
  return sharedRegistry;
}

function markProcessedShared(sessionKey, fileSignature, meta = {}) {
  const registry = getSharedWatchRegistry();
  const updated = markProcessed(registry, sessionKey, fileSignature, meta);
  if (updated) queueSharedWatchRegistrySave();
  return updated;
}

function queueSharedWatchRegistrySave(delayMs = DEFAULT_SAVE_DEBOUNCE_MS) {
  sharedDirty = true;
  if (sharedSaveTimer) return;
  sharedSaveTimer = setTimeout(() => {
    sharedSaveTimer = null;
    void saveSharedNow();
  }, Math.max(0, delayMs));
}

async function saveSharedNow() {
  if (!sharedDirty) return { ok: true, skipped: true };
  if (sharedSavingPromise) return sharedSavingPromise;

  sharedDirty = false;
  const registry = getSharedWatchRegistry();

  sharedSavingPromise = (async () => {
    const res = await saveWatchRegistry(registry);
    if (!res?.ok) {
      // Retry later.
      sharedDirty = true;
    }
    return res;
  })()
    .catch(err => {
      sharedDirty = true;
      return { ok: false, error: err?.message || String(err) };
    })
    .finally(() => {
      sharedSavingPromise = null;
      // If more writes came in while saving, schedule another.
      if (sharedDirty && !sharedSaveTimer) {
        queueSharedWatchRegistrySave(DEFAULT_SAVE_DEBOUNCE_MS);
      }
    });

  return sharedSavingPromise;
}

async function flushSharedWatchRegistrySave() {
  if (sharedSaveTimer) {
    clearTimeout(sharedSaveTimer);
    sharedSaveTimer = null;
  }
  return saveSharedNow();
}

// ---------------------------------------------------------------------------
// Ingest-specific: variant key
// ---------------------------------------------------------------------------

/**
 * Compute a stable, short key representing the ingest configuration variant.
 * This prevents surprising "already processed" skips when the user changes
 * destinations/presets.
 */
function createIngestVariantKey(cfg = {}) {
  try {
    const destination = cfg?.destination ? normalizeRootKey(cfg.destination) : '';
    const flattenStructure = !!cfg?.flattenStructure;
    const autoFolder = !!cfg?.autoFolder;
    const verificationCfg = cfg?.verification || {};
    const verification = {
      method: typeof verificationCfg.method === 'string'
        ? verificationCfg.method.trim().toLowerCase()
        : '',
      useChecksum: !!verificationCfg.useChecksum,
      compareByte: !!verificationCfg.compareByte,
      skipDuplicates: !!verificationCfg.skipDuplicates,
      useSha256: !!verificationCfg.useSha256,
      useMd5: !!verificationCfg.useMd5,
      useBlake3: !!verificationCfg.useBlake3,
      useXxhash64: !!verificationCfg.useXxhash64
    };

    const payload = {
      destination,
      flattenStructure,
      autoFolder,
      verification
    };

    const hash = crypto.createHash('sha1').update(JSON.stringify(payload)).digest('hex');
    return hash.slice(0, 12);
  } catch {
    return '';
  }
}

module.exports = {
  REGISTRY_PATH,

  // Core helpers
  createSessionKey,
  createFileSignature,
  isProcessed,
  markProcessed,
  loadWatchRegistry,
  saveWatchRegistry,

  // Shared registry helpers
  getSharedWatchRegistry,
  markProcessedShared,
  queueSharedWatchRegistrySave,
  flushSharedWatchRegistrySave,

  // Panel variants
  createIngestVariantKey
};
