// utils/trustedIpcSender.js
// Harden sensitive IPC endpoints by ensuring they can only be called from
// a trusted, local renderer context (our app's own files, or localhost in dev).

const { app } = require('electron');
const path = require('path');
const { fileURLToPath } = require('url');

function isSubpath(childPath, parentPath) {
  const rel = path.relative(parentPath, childPath);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function isFileUrlWithinApp(urlString) {
  if (typeof urlString !== 'string' || !urlString.startsWith('file:')) return false;
  try {
    const targetPath = path.resolve(fileURLToPath(urlString));
    const appRoot = path.resolve(app.getAppPath());
    return isSubpath(targetPath, appRoot);
  } catch {
    return false;
  }
}

function isDevLocalhost(urlString) {
  if (typeof urlString !== 'string') return false;
  if (app.isPackaged) return false;
  try {
    const parsed = new URL(urlString);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false;
    return (
      parsed.hostname === 'localhost' ||
      parsed.hostname === '127.0.0.1' ||
      parsed.hostname === '::1' ||
      parsed.hostname === '[::1]'
    );
  } catch {
    return false;
  }
}

function getSenderUrl(event) {
  // Prefer frame URL if available (more precise), fall back to top-level.
  const frameUrl = event?.senderFrame?.url;
  if (typeof frameUrl === 'string' && frameUrl) return frameUrl;
  const wc = event?.sender;
  if (wc && typeof wc.getURL === 'function') {
    try {
      const url = wc.getURL();
      if (typeof url === 'string') return url;
    } catch {
      // ignore
    }
  }
  return '';
}

function isTrustedIpcSender(event) {
  const url = getSenderUrl(event);
  return isFileUrlWithinApp(url) || isDevLocalhost(url);
}

function assertTrustedIpcSender(event, actionName = 'IPC') {
  if (isTrustedIpcSender(event)) return;
  const url = getSenderUrl(event);
  const err = new Error(`Blocked ${actionName} from untrusted origin: ${url || '(unknown)'}`);
  err.code = 'ERR_UNTRUSTED_ORIGIN';
  throw err;
}

module.exports = {
  isTrustedIpcSender,
  assertTrustedIpcSender,
  getSenderUrl,
};
