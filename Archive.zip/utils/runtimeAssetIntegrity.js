'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function compareNames(a, b) {
  const left = String(a?.name || a || '');
  const right = String(b?.name || b || '');
  if (left < right) return -1;
  if (left > right) return 1;
  return 0;
}

function updateHashWithFileContents(hash, filePath) {
  const fd = fs.openSync(filePath, 'r');
  const buffer = Buffer.allocUnsafe(1024 * 1024);
  try {
    while (true) {
      const bytesRead = fs.readSync(fd, buffer, 0, buffer.length, null);
      if (!bytesRead) break;
      hash.update(buffer.subarray(0, bytesRead));
    }
  } finally {
    fs.closeSync(fd);
  }
}

function sha256FileHex(filePath) {
  const hash = crypto.createHash('sha256');
  updateHashWithFileContents(hash, filePath);
  return hash.digest('hex');
}

function sha256DirectoryTreeHex(rootDir, options = {}) {
  const resolvedRoot = path.resolve(String(rootDir || ''));
  const rootStats = fs.lstatSync(resolvedRoot);
  if (!rootStats.isDirectory()) {
    throw new Error(`Directory digest requires a directory: ${resolvedRoot}`);
  }

  const hash = crypto.createHash('sha256');
  hash.update('runtime-asset-directory-sha256-v1\0');

  const rootName = String(options.rootName || '').trim().replace(/^\/+|\/+$/g, '');
  if (rootName) {
    hash.update(`dir\0${rootName}\0`);
  }

  function walk(absDir, relDir) {
    const entries = fs.readdirSync(absDir, { withFileTypes: true }).sort(compareNames);
    for (const entry of entries) {
      const absPath = path.join(absDir, entry.name);
      const relPath = relDir ? `${relDir}/${entry.name}` : entry.name;
      const stats = fs.lstatSync(absPath);

      if (stats.isSymbolicLink()) {
        hash.update(`symlink\0${relPath}\0${fs.readlinkSync(absPath)}\0`);
        continue;
      }

      if (stats.isDirectory()) {
        hash.update(`dir\0${relPath}\0`);
        walk(absPath, relPath);
        continue;
      }

      if (stats.isFile()) {
        hash.update(`file\0${relPath}\0${stats.size}\0`);
        updateHashWithFileContents(hash, absPath);
        hash.update('\0');
        continue;
      }

      hash.update(`other\0${relPath}\0${stats.mode & 0o170000}\0`);
    }
  }

  walk(resolvedRoot, rootName);
  return hash.digest('hex');
}

module.exports = {
  sha256FileHex,
  sha256DirectoryTreeHex
};
