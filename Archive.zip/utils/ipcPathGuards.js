'use strict';

// utils/ipcPathGuards.js
//
// Shared helpers for enforcing renderer->main path safety at IPC boundaries.
//
// Core policy:
//   - Only allow filesystem access inside:
//       1) app userData roots, and
//       2) user-approved roots (via native dialogs)
//   - Reject non-file URI schemes when a value is expected to be a file path
//   - Require absolute paths by default (prevents cwd-dependent escape)
//
// NOTE:
//   This is intentionally conservative. If an IPC handler receives a value that
//   is supposed to be a file path, it must pass these checks before touching
//   the filesystem.

const path = require('path');
const { fileURLToPath } = require('url');
const { isPathAllowed } = require('./fsAccessControl');

function _isWindowsDrivePath(s) {
  return typeof s === 'string' && /^[a-zA-Z]:[\\/]/.test(s);
}

function _isWindowsUncPath(s) {
  // e.g. \\server\share\file
  return typeof s === 'string' && s.startsWith('\\\\');
}

function toLocalPathIfFileUrl(p) {
  if (typeof p !== 'string') return p;
  const s = p.trim();
  if (!s) return s;
  if (s.startsWith('file:')) {
    try {
      return fileURLToPath(s);
    } catch {
      return s;
    }
  }
  return s;
}

function _looksLikeUriScheme(s) {
  if (typeof s !== 'string') return false;
  if (_isWindowsDrivePath(s)) return false;
  if (_isWindowsUncPath(s)) return false;
  // Matches: "scheme:" at the beginning (e.g., http:, https:, rtmp:, pipe:)
  return /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(s);
}

function _isDisallowedScheme(s) {
  if (!_looksLikeUriScheme(s)) return false;
  const scheme = String(s).split(':', 1)[0].toLowerCase();
  // Allow file: URLs only. Everything else is blocked in path contexts.
  return scheme !== 'file';
}

function assertNoNetworkSchemes(strings) {
  const list = Array.isArray(strings) ? strings : [strings];
  for (const item of list) {
    const s0 = String(item ?? '').trim();
    if (!s0) continue;
    // Reject explicit URI schemes unless it's file:
    if (_isDisallowedScheme(s0)) {
      throw new Error(`❌ Path rejected: URI/protocol not allowed (${s0})`);
    }
    // Also catch common URL forms that may not match the simple scheme regex above.
    if (/(^|\s)(https?:\/\/|rtsp:\/\/|rtmp:\/\/|srt:\/\/)/i.test(s0)) {
      throw new Error(`❌ Path rejected: network URL not allowed (${s0})`);
    }
  }
}

function assertApprovedPath(senderId, p, opts = {}) {
  const id = Number(senderId);
  // Fail closed when sender context is missing.
  if (!Number.isFinite(id)) {
    throw new Error('❌ Path rejected: missing sender context');
  }

  const requireAbsolute = opts?.requireAbsolute !== false;

  const raw = typeof p === 'string' ? p.trim() : String(p ?? '').trim();
  if (!raw) return null;

  const local = toLocalPathIfFileUrl(raw);

  // If it looks like a URI scheme (other than file: which we convert), reject.
  if (_isDisallowedScheme(local)) {
    throw new Error(`❌ Path rejected: URI/protocol not allowed (${local})`);
  }

  // Require absolute paths to avoid cwd-dependent escape.
  if (requireAbsolute) {
    const abs = _isWindowsDrivePath(local) || _isWindowsUncPath(local) || path.isAbsolute(local);
    if (!abs) {
      throw new Error(`❌ Path rejected: path must be absolute (${local})`);
    }
  }

  if (!isPathAllowed(id, local)) {
    throw new Error(`❌ Path rejected: path not approved (${local})`);
  }

  return local;
}

function assertApprovedPaths(senderId, paths, opts = {}) {
  const list = Array.isArray(paths) ? paths : [paths];
  const out = [];
  for (const p of list) {
    const validated = assertApprovedPath(senderId, p, opts);
    if (validated) out.push(validated);
  }
  return out;
}

function extractAbsolutePathsFromObject(payload) {
  const out = new Set();
  const seen = new Set();

  const isAbsoluteLike = (s) => {
    if (typeof s !== 'string') return false;
    const t = s.trim();
    if (!t) return false;
    if (t.startsWith('file:')) return true;
    if (_isWindowsDrivePath(t)) return true;
    if (_isWindowsUncPath(t)) return true;
    try {
      return path.isAbsolute(t);
    } catch {
      return false;
    }
  };

  const walk = (value) => {
    if (typeof value === 'string') {
      if (isAbsoluteLike(value)) out.add(value.trim());
      return;
    }
    if (!value || typeof value !== 'object') return;
    if (Buffer.isBuffer(value)) return;
    if (seen.has(value)) return;
    seen.add(value);

    if (Array.isArray(value)) {
      for (const item of value) walk(item);
      return;
    }

    for (const k of Object.keys(value)) {
      try {
        walk(value[k]);
      } catch {
        // ignore unwalkable getters
      }
    }
  };

  walk(payload);
  return Array.from(out);
}

module.exports = {
  toLocalPathIfFileUrl,
  assertNoNetworkSchemes,
  assertApprovedPath,
  assertApprovedPaths,
  extractAbsolutePathsFromObject,
};
