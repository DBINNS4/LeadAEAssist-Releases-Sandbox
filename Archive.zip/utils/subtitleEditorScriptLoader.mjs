// utils/subtitleEditorScriptLoader.mjs
// CSP-safe subtitle editor script loader.
//
// Why this exists:
// - subtitle-editor.html is a separate window with a strict CSP (no inline scripts, no unsafe-eval).
// - Packaged builds prefer the obfuscated renderer bundle.
// - Dev builds should be able to use the plain sources without having to re-run obfuscation.
//
// Ordering note:
// This module uses top-level await so DOMContentLoaded won't fire until the renderer script is loaded.

function loadScript(src, { id } = {}) {
  return new Promise((resolve, reject) => {
    try {
      if (id) {
        const existing = document.getElementById(id);
        if (existing) existing.remove();
      }

      const s = document.createElement('script');
      if (id) s.id = id;
      s.src = src;
      s.async = false;

      s.onload = () => resolve({ src });
      s.onerror = () => reject(new Error(`Failed to load script: ${src}`));

      document.head.appendChild(s);
    } catch (err) {
      reject(err);
    }
  });
}

async function loadWithFallback(primary, fallback, opts = {}) {
  try {
    return await loadScript(primary, opts);
  } catch (err) {
    console.warn(`[subtitle-editor-script-loader] ${err.message} \u2192 falling back to ${fallback}`);
    return await loadScript(fallback, opts);
  }
}

const isPackaged = !!window.electron?.isPackaged;

// Packaged builds: prefer obfuscated
// Dev builds: prefer plain
const primary = isPackaged
  ? './dist-obfuscated/renderer.subtitleEditor.js'
  : './renderer.subtitleEditor.js';

const fallback = isPackaged
  ? './renderer.subtitleEditor.js'
  : './dist-obfuscated/renderer.subtitleEditor.js';

await loadWithFallback(primary, fallback, { id: 'subtitle-editor-script' });
