// utils/externalNavigationGuards.js
// Centralized hardening against remote navigation / window opens in privileged Electron windows.
//
// Goals:
//  - Deny all in-app popups (window.open / target="_blank") so remote content never inherits preload privileges.
//  - Prevent in-place navigation away from trusted origins.
//  - Open safe external URLs (http/https/mailto) in the user's default browser instead.

const path = require('path');
const { app, shell } = require('electron');
const { fileURLToPath } = require('url');

// Allowed navigations *inside* the Electron window.
// - 127.0.0.1 is your local bridge server
// - file: is allowed only for files within the app directory (see DEFAULT_ALLOWED_FILE_ROOTS)
const DEFAULT_ALLOWED_PREFIXES = [
  'http://127.0.0.1',
  'https://127.0.0.1',
  'ws://127.0.0.1',
  'wss://127.0.0.1'
];

function normalizeAllowedOrigin(candidate) {
  if (!candidate || typeof candidate !== 'object') return null;
  if (candidate.protocol === 'file:') return null;
  if (candidate.username || candidate.password) return null;

  const protocol = typeof candidate.protocol === 'string' ? candidate.protocol.toLowerCase() : '';
  const hostname = typeof candidate.hostname === 'string' ? candidate.hostname.toLowerCase() : '';
  const port = typeof candidate.port === 'string' ? candidate.port : '';

  if (!protocol || !hostname) return null;
  return { protocol, hostname, port };
}

function buildAllowedOrigins(allowedPrefixes, allowedOrigins) {
  if (Array.isArray(allowedOrigins) && allowedOrigins.length) {
    return allowedOrigins.map(normalizeAllowedOrigin).filter(Boolean);
  }

  return (Array.isArray(allowedPrefixes) ? allowedPrefixes : [])
    .map(prefix => {
      try {
        const parsed = new URL(prefix);
        return normalizeAllowedOrigin(parsed);
      } catch {
        return null;
      }
    })
    .filter(Boolean);
}

function defaultAllowedFileRoots() {
  // In production this is typically: .../resources/app.asar
  // In dev this is typically your project root.
  try {
    const appPath = app?.getAppPath?.();
    return appPath ? [appPath] : [];
  } catch {
    return [];
  }
}

function normalizeForCompare(p) {
  const resolved = path.resolve(String(p));
  return process.platform === 'win32' ? resolved.toLowerCase() : resolved;
}

function isPathInsideOrEqual(childPath, rootPath) {
  const child = normalizeForCompare(childPath);
  const root = normalizeForCompare(rootPath);
  if (child === root) return true;
  const rel = path.relative(root, child);
  return rel && !rel.startsWith('..') && !path.isAbsolute(rel);
}

function isAllowedFileUrl(url, allowedFileRoots) {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== 'file:') return false;
    const p = fileURLToPath(parsed);
    return (allowedFileRoots || []).some(root => isPathInsideOrEqual(p, root));
  } catch {
    return false;
  }
}

function isAllowedInAppUrl(url, opts = {}) {
  if (!url || typeof url !== 'string') return false;

  // Back-compat: if an array is passed, treat it as allowedPrefixes.
  // (Older call sites used: isAllowedInAppUrl(url, allowedPrefixes))
  const allowedPrefixes = Array.isArray(opts)
    ? opts
    : Array.isArray(opts.allowedPrefixes) && opts.allowedPrefixes.length
      ? opts.allowedPrefixes
      : DEFAULT_ALLOWED_PREFIXES;

  const allowedFileRoots = Array.isArray(opts)
    ? defaultAllowedFileRoots()
    : Array.isArray(opts.allowedFileRoots) && opts.allowedFileRoots.length
      ? opts.allowedFileRoots
      : defaultAllowedFileRoots();

  const allowedOrigins = Array.isArray(opts)
    ? buildAllowedOrigins(allowedPrefixes)
    : buildAllowedOrigins(allowedPrefixes, opts.allowedOrigins);

  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return false;
  }

  if (parsed.protocol === 'file:') {
    // Optional hardening: only allow file:// URLs that resolve into the app directory.
    return isAllowedFileUrl(url, allowedFileRoots);
  }

  if (parsed.username || parsed.password) return false;

  const protocol = parsed.protocol.toLowerCase();
  const hostname = parsed.hostname.toLowerCase();
  const port = parsed.port || '';

  return allowedOrigins.some(allowed => (
    allowed.protocol === protocol &&
    allowed.hostname === hostname &&
    allowed.port === port
  ));
}

function isLocalhostHostname(hostname) {
  const h = String(hostname || '').trim().toLowerCase();
  if (!h) return false;
  return h === 'localhost' || h === '127.0.0.1' || h === '::1';
}

function openExternalIfSafe(url, opts = {}) {
  if (!url || typeof url !== 'string') return;
  try {
    const parsed = new URL(url);

    const offlineFn = (opts && typeof opts.isOfflineModeEnabled === 'function')
      ? opts.isOfflineModeEnabled
      : null;
    const offline = !!(offlineFn && offlineFn());

    if (offline) {
      // Offline Mode: block all non-localhost external URLs.
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        const hostname = String(parsed.hostname || '').trim().toLowerCase();
        if (!isLocalhostHostname(hostname)) return;
      } else {
        // mailto and other schemes count as “outside” actions while offline.
        return;
      }
    }

    // Restrict to protocols that are expected to be opened by the OS/browser.
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:' || parsed.protocol === 'mailto:') {
      void shell.openExternal(url).catch(() => {
        // Best effort only: never let an OS-level open failure bubble into navigation handlers.
      });
    }
  } catch {
    // Ignore invalid/unsupported URLs (e.g., "about:blank").
  }
}

function installExternalNavigationGuards(webContents, opts = {}) {
  if (!webContents) return;

  // Idempotency: avoid double-registering handlers if called twice.
  if (webContents.__externalNavGuardsInstalled) return;
  webContents.__externalNavGuardsInstalled = true;

  const allowedPrefixes =
    Array.isArray(opts.allowedPrefixes) && opts.allowedPrefixes.length
      ? opts.allowedPrefixes
      : DEFAULT_ALLOWED_PREFIXES;

  const allowedFileRoots =
    Array.isArray(opts.allowedFileRoots) && opts.allowedFileRoots.length
      ? opts.allowedFileRoots
      : defaultAllowedFileRoots();

  const isOfflineModeEnabled = (opts && typeof opts.isOfflineModeEnabled === 'function')
    ? opts.isOfflineModeEnabled
    : null;

  // Block creation of new BrowserWindows via window.open / target="_blank".
  webContents.setWindowOpenHandler(({ url }) => {
    openExternalIfSafe(url, { isOfflineModeEnabled });
    return { action: 'deny' };
  });

  const handleNavigate = (event, url) => {
    if (isAllowedInAppUrl(url, { allowedPrefixes, allowedFileRoots })) return;
    event.preventDefault();
    openExternalIfSafe(url, { isOfflineModeEnabled });
  };

  // In-window navigations.
  webContents.on('will-navigate', handleNavigate);
  // Redirects can otherwise escape an allowlisted URL.
  webContents.on('will-redirect', handleNavigate);
}

module.exports = {
  DEFAULT_ALLOWED_PREFIXES,
  isAllowedInAppUrl,
  openExternalIfSafe,
  installExternalNavigationGuards
};
