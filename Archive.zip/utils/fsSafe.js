// IMPORTANT: use Electron's unpatched fs when available so file operations on
// user paths don't get confused by Electron's ASAR virtualization.
const { fs, fsp } = require('./nativeFs');
const path = require('path');

function isWindowsReplaceRenameError(err) {
  // On Windows, rename can fail if destination exists or is momentarily busy.
  return !!(err && (err.code === 'EEXIST' || err.code === 'EPERM' || err.code === 'EBUSY' || err.code === 'EACCES'));
}

/**
 * Rename src -> dest, replacing dest if needed (Windows-safe).
 * Intended for FILE paths (not directories).
 */
async function renameReplace(src, dest) {
  try {
    await fsp.rename(src, dest);
  } catch (err) {
    if (isWindowsReplaceRenameError(err)) {
      try { await fsp.unlink(dest); } catch {}
      await fsp.rename(src, dest);
      return;
    }
    throw err;
  }
}

/**
 * Sync version of renameReplace.
 */
function renameReplaceSync(src, dest) {
  try {
    fs.renameSync(src, dest);
  } catch (err) {
    if (isWindowsReplaceRenameError(err)) {
      try { fs.unlinkSync(dest); } catch {}
      fs.renameSync(src, dest);
      return;
    }
    throw err;
  }
}

/**
 * Move src -> dest with replacement semantics, with EXDEV (cross-device) fallback.
 * Intended for FILE paths (not directories).
 */
async function moveReplace(src, dest) {
  try {
    await renameReplace(src, dest);
  } catch (err) {
    if (err && err.code === 'EXDEV') {
      await fsp.copyFile(src, dest);
      await fsp.unlink(src);
      return;
    }
    throw err;
  }
}

function uniqueTempPath(finalPath, suffix = '.tmp') {
  const rand = Math.random().toString(16).slice(2);
  const stamp = Date.now();
  return `${finalPath}${suffix}.${process.pid}.${stamp}.${rand}`;
}

function isIgnorableDirSyncError(err) {
  // Directory fsync support is platform/filesystem dependent. On Windows and
  // some network filesystems this is expected to fail; treat as best-effort.
  return !!(err && (
    err.code === 'EINVAL' ||
    err.code === 'ENOTSUP' ||
    err.code === 'EOPNOTSUPP' ||
    err.code === 'EPERM' ||
    err.code === 'EACCES' ||
    err.code === 'EBADF' ||
    err.code === 'UNKNOWN'
  ));
}

async function syncDirectoryEntryAsync(filePath) {
  const dirPath = path.dirname(filePath);
  let dirHandle;
  try {
    dirHandle = await fsp.open(dirPath, 'r');
    await dirHandle.sync();
  } catch (err) {
    if (!isIgnorableDirSyncError(err)) throw err;
  } finally {
    try { await dirHandle?.close(); } catch {}
  }
}

function syncDirectoryEntrySync(filePath) {
  const dirPath = path.dirname(filePath);
  let dirFd;
  try {
    dirFd = fs.openSync(dirPath, 'r');
    fs.fsyncSync(dirFd);
  } catch (err) {
    if (!isIgnorableDirSyncError(err)) throw err;
  } finally {
    try {
      if (typeof dirFd === 'number') fs.closeSync(dirFd);
    } catch {}
  }
}

/**
 * Write a file atomically and durability-hardened by:
 * 1) writing to a unique temp file in the same directory,
 * 2) fsync/datasync-ing the temp file,
 * 3) renaming into place,
 * 4) fsync-ing the parent directory (best-effort where unsupported).
 */
async function atomicWriteFile(destPath, data, options = {}) {
  const { mode = 0o600, encoding = 'utf-8' } = options;

  await fsp.mkdir(path.dirname(destPath), { recursive: true });

  const tmpPath = uniqueTempPath(destPath, '.tmp');
  let tmpHandle;
  try {
    tmpHandle = await fsp.open(tmpPath, 'w', mode);
    await tmpHandle.writeFile(data, { encoding });
    if (typeof tmpHandle.datasync === 'function') {
      await tmpHandle.datasync();
    } else {
      await tmpHandle.sync();
    }
    await tmpHandle.close();
    tmpHandle = null;

    await renameReplace(tmpPath, destPath);
    await syncDirectoryEntryAsync(destPath);
    try { await fsp.chmod(destPath, mode); } catch {}
  } catch (err) {
    try { await tmpHandle?.close(); } catch {}
    try { await fsp.unlink(tmpPath); } catch {}
    throw err;
  }
}

/**
 * Sync equivalent of atomicWriteFile with durability hardening.
 */
function atomicWriteFileSync(destPath, data, options = {}) {
  const { mode = 0o600, encoding = 'utf-8' } = options;

  fs.mkdirSync(path.dirname(destPath), { recursive: true });

  const tmpPath = uniqueTempPath(destPath, '.tmp');
  let tmpFd;
  try {
    tmpFd = fs.openSync(tmpPath, 'w', mode);
    fs.writeFileSync(tmpFd, data, { encoding });
    if (typeof fs.fdatasyncSync === 'function') {
      fs.fdatasyncSync(tmpFd);
    } else {
      fs.fsyncSync(tmpFd);
    }
    fs.closeSync(tmpFd);
    tmpFd = undefined;

    renameReplaceSync(tmpPath, destPath);
    syncDirectoryEntrySync(destPath);
    try { fs.chmodSync(destPath, mode); } catch {}
  } catch (err) {
    try {
      if (typeof tmpFd === 'number') fs.closeSync(tmpFd);
    } catch {}
    try { fs.unlinkSync(tmpPath); } catch {}
    throw err;
  }
}

async function atomicWriteJson(destPath, obj, options = {}) {
  const { mode = 0o600 } = options;
  const data = JSON.stringify(obj, null, 2);
  return atomicWriteFile(destPath, data, { mode, encoding: 'utf-8' });
}

function atomicWriteJsonSync(destPath, obj, options = {}) {
  const { mode = 0o600 } = options;
  const data = JSON.stringify(obj, null, 2);
  return atomicWriteFileSync(destPath, data, { mode, encoding: 'utf-8' });
}

/**
 * Read JSON safely (sync).
 * Returns `fallback` if the file doesn't exist or JSON is invalid.
 */
function safeReadJson(filePath, fallback = null) {
  try {
    if (!filePath) return fallback;
    if (!fs.existsSync(filePath)) return fallback;
    const raw = fs.readFileSync(filePath, 'utf-8');
    if (!raw || !String(raw).trim()) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

module.exports = {
  renameReplace,
  renameReplaceSync,
  moveReplace,
  uniqueTempPath,
  atomicWriteFile,
  atomicWriteFileSync,
  atomicWriteJson,
  atomicWriteJsonSync,
  safeReadJson
};
