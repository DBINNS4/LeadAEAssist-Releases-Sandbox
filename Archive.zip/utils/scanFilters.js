// utils/scanFilters.js
//
// Centralized scan/traversal filtering for ingest/clone/preview.
//
// Goals:
// - Keep user-facing copy operations predictable (copy bytes, don't interpret).
// - Make hidden/system handling configurable.
// - Provide a sane *optional* ignore list for dev/cache folders (performance + noise).
//
// NOTE: This module intentionally has zero Electron dependencies.

/**
 * Default ignore names. These are intentionally conservative.
 *
 * They target extremely common *development* / *metadata* folders and files that
 * users almost never want in post-production ingest workflows, but might exist
 * if someone points ingest at a codebase.
 *
 * IMPORTANT: This list is only applied when `useDefaultIgnorePatterns` is enabled.
 */
const DEFAULT_IGNORE_ENTRY_NAMES = Object.freeze([
  // Dev dependency trees
  'node_modules',
  'bower_components',

  // VCS metadata
  '.git',
  '.svn',
  '.hg',

  // Editor/IDE metadata
  '.idea',
  '.vscode',

  // macOS archive metadata folder
  '__macosx',

  // Windows metadata
  'thumbs.db',
  'desktop.ini'
]);

const ALWAYS_SKIP_FILE_NAMES = Object.freeze([
  '.ds_store',
  'thumbs.db'
]);

const ALWAYS_SKIP_FILE_PREFIXES = Object.freeze([
  '._'
]);

const ALWAYS_SKIP_FILE_SUFFIXES = Object.freeze([
  '.done',
  '.doneflag'
]);

function normalizeName(name) {
  return String(name || '').trim().toLowerCase();
}

function buildNameSet(names) {
  const set = new Set();
  for (const n of Array.isArray(names) ? names : []) {
    const norm = normalizeName(n);
    if (norm) set.add(norm);
  }
  return set;
}

function shouldAlwaysSkipFile(name) {
  const lower = normalizeName(name);
  if (!lower) return false;
  if (ALWAYS_SKIP_FILE_NAMES.includes(lower)) return true;
  if (ALWAYS_SKIP_FILE_PREFIXES.some(prefix => lower.startsWith(prefix))) return true;
  if (ALWAYS_SKIP_FILE_SUFFIXES.some(suffix => lower.endsWith(suffix))) return true;
  return false;
}

/**
 * Build a fast predicate for deciding whether to skip a directory entry.
 *
 * @param {object} options
 * @param {boolean} [options.includeHidden=false] - When false, skip dotfiles/dirs.
 * @param {boolean} [options.useDefaultIgnorePatterns=false] - When true, apply DEFAULT_IGNORE_ENTRY_NAMES.
 * @param {string[]} [options.ignoreNames=[]] - Additional exact entry-name ignores (case-insensitive).
 * @returns {{
 *   includeHidden: boolean,
 *   useDefaultIgnorePatterns: boolean,
 *   ignoredNames: string[],
 *   shouldSkipEntry: (name: string, isDirectory: boolean) => boolean,
 *   shouldSkipFile: (name: string) => boolean,
 *   shouldSkipDir: (name: string) => boolean,
 * }}
 */
function buildScanFilter(options = {}) {
  const includeHidden = !!options.includeHidden;
  const useDefaultIgnorePatterns = !!options.useDefaultIgnorePatterns;

  const ignoreSet = new Set();
  if (useDefaultIgnorePatterns) {
    for (const n of DEFAULT_IGNORE_ENTRY_NAMES) {
      ignoreSet.add(normalizeName(n));
    }
  }

  const extra = buildNameSet(options.ignoreNames);
  for (const n of extra) ignoreSet.add(n);

  const shouldSkipEntry = (name, isDirectory) => {
    const n = String(name || '');
    if (!n) return true;

    const lower = n.toLowerCase();

    // Hidden/system handling (optional)
    if (!includeHidden && lower.startsWith('.')) return true;

    // Conservative ignore list (optional)
    if (ignoreSet.has(lower)) return true;

    // For directories, also skip well-known macOS system folders when hidden is excluded.
    // (When includeHidden=true, user explicitly asked for an exhaustive copy.)
    if (!includeHidden && isDirectory) {
      if (lower === '.spotlight-v100') return true;
      if (lower === '.fseventsd') return true;
      if (lower === '.trashes') return true;
    }

    return false;
  };

  return {
    includeHidden,
    useDefaultIgnorePatterns,
    ignoredNames: Array.from(ignoreSet),
    shouldSkipEntry,
    shouldSkipFile: (name) => shouldSkipEntry(name, false),
    shouldSkipDir: (name) => shouldSkipEntry(name, true)
  };
}

module.exports = {
  ALWAYS_SKIP_FILE_NAMES,
  DEFAULT_IGNORE_ENTRY_NAMES,
  buildScanFilter,
  shouldAlwaysSkipFile
};
