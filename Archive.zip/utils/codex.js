const fs = require('fs');
const path = require('path');
const electron = require('electron');

const app = electron.app || null;

let __specCache = null;
let __specPath = null;
let __packagedSpecPath = null;
let __userSpecPath = null;

function existing(p) {
  try { return p && fs.existsSync(p); } catch { return false; }
}

function locateSpecPaths() {
  if (__packagedSpecPath && __userSpecPath) {
    return { packaged: __packagedSpecPath, user: __userSpecPath };
  }
  const userData = app ? app.getPath('userData') : null;
  const userCfg = userData && path.join(userData, 'config', 'codex_format_spec.json');
  // When packaged, config is inside app.getAppPath() (typically …/Resources/app.asar).
  const base = (app && typeof app.getAppPath === 'function')
    ? app.getAppPath()
    : path.join(__dirname, '..');
  const packaged = path.join(base, 'config', 'codex_format_spec.json');

  __userSpecPath = userCfg || '';
  __packagedSpecPath = packaged;
  return { packaged, user: userCfg };
}

function tryParseJsonFile(p) {
  if (!p || !existing(p)) return null;
  try {
    const raw = fs.readFileSync(p, 'utf8');
    return JSON.parse(raw) || {};
  } catch (err) {
    console.error(`❌ Failed to load codex_format_spec.json at ${p}:`, err?.message || err);
    return null;
  }
}

function loadSpec() {
  if (__specCache) return __specCache;
  const { user, packaged } = locateSpecPaths();

  // Prefer a user override if it exists, but never let a bad override break the panel.
  // If user JSON is invalid, fall back to the packaged spec.
  const fromUser = tryParseJsonFile(user);
  if (fromUser) {
    __specCache = fromUser;
    __specPath = user;
  } else {
    const fromPackaged = tryParseJsonFile(packaged);
    __specCache = fromPackaged || { formats: {}, audio: {} };
    __specPath = packaged;
  }

  // basic shape guarantees
  __specCache.formats ||= {};
  __specCache.audio ||= {};
  return __specCache;
}

function uniq(arr) {
  return Array.from(new Set((arr || []).filter(Boolean)));
}

function mergeFormatEntries(entries) {
  const out = {
    containers: [],
    resolutions: [],
    frameRates: [],
    pixelFormats: [],
    audio: [],
    // defaults (prefer last defined)
    defaultContainer: '',
    defaultResolution: '',
    defaultFrameRate: '',
    defaultPixelFormat: '',
    defaultColorRange: '',
    defaultFieldOrder: '',
    defaultAudio: '',
    defaultChannels: '',
    defaultSampleRate: '',
    defaultAudioBitrate: ''
  };
  for (const e of entries) {
    if (!e || typeof e !== 'object') continue;
    out.containers = uniq(out.containers.concat(e.containers || []));
    out.resolutions = uniq(out.resolutions.concat(e.resolutions || []));
    out.frameRates = uniq(out.frameRates.concat(e.frameRates || []));
    out.pixelFormats = uniq(out.pixelFormats.concat(e.pixelFormats || []));
    out.audio = uniq(out.audio.concat(e.audio || []));
    // defaults: last one wins (spec should keep them consistent)
    for (const k of Object.keys(out)) {
      if (k.startsWith('default') && e[k]) out[k] = e[k];
    }
  }
  return out;
}

function getFormatSpec(format) {
  const spec = loadSpec();
  if (!format) return null;

  const key = String(format).trim();
  if (!key) return null;
  const lower = key.toLowerCase();

  // Family alias: treat prores_ks as “any prores_*”
  if (lower === 'prores_ks') {
    const keys = Object.keys(spec.formats).filter(k => k.startsWith('prores'));
    return mergeFormatEntries(keys.map(k => spec.formats[k]));
  }

  // DNx variants:
  // Treat variant entries (dnxhd_### / dnxhr_*) as first-class formats.
  // The compatibility spec already defines their allowed containers/resolutions/rates.
  //
  // IMPORTANT: Do *not* UNION them with the base "dnxhd" entry here.
  // Unioning makes the UI show options that the selected variant does not actually list.
  // If a variant ever ships with missing/empty arrays, the panel will fail-open and still
  // let the user select from the global dropdown options.
  if (lower.startsWith('dnxhd_') || lower.startsWith('dnxhr_')) {
    return spec.formats[key] || spec.formats[lower] || spec.formats['dnxhd'] || null;
  }

  return spec.formats[key] || spec.formats[lower] || null;
}

function listFormats() {
  return Object.keys(loadSpec().formats || {});
}

function listAudioCodecs() {
  return Object.keys(loadSpec().audio || {});
}

function getCompatibility(format) {
  const f = getFormatSpec(format) || {};
  return {
    format,
    containers: f.containers || [],
    resolutions: f.resolutions || [],
    frameRates: f.frameRates || [],
    pixelFormats: f.pixelFormats || [],
    colorRanges: (f.colorRanges || []).map(v => String(v).toLowerCase()),
    fieldOrders: f.fieldOrders || [],
    audioCodecs: f.audio || [],
    channelOptions: f.channelOptions || [],
    sampleRates: f.sampleRates || [],
    defaults: {
      container: f.defaultContainer || '',
      resolution: f.defaultResolution || '',
      frameRate: f.defaultFrameRate || '',
      pixelFormat: f.defaultPixelFormat || '',
      colorRange: (f.defaultColorRange || '').toLowerCase(),
      fieldOrder: f.defaultFieldOrder || '',
      audio: f.defaultAudio || '',
      channels: f.defaultChannels || '',
      sampleRate: f.defaultSampleRate || '',
      audioBitrate: f.defaultAudioBitrate || ''
    }
  };
}

function getAudioConstraints(codec) {
  const a = (loadSpec().audio || {})[codec] || {};
  return {
    codec,
    sampleRates: a.sampleRates || [],
    channels: a.channels || [],
    containers: a.containers || []
  };
}

function isAudioContainerValid(codec, container) {
  const a = (loadSpec().audio || {})[codec];
  return !!(a && Array.isArray(a.containers) && a.containers.includes(container));
}

module.exports = {
  loadSpec, // mostly for tests
  listFormats,
  listAudioCodecs,
  getCompatibility,
  getAudioConstraints,
  isAudioContainerValid
};
