// IMPORTANT: use Electron's unpatched fs when available so byte-compare works
// on `.asar` files in user folders.
const { fsp } = require('./nativeFs');

async function compareFilesByteByByte(file1, file2, options = {}) {
  const signal = (options && typeof options === 'object') ? options.signal : null;
  const stat1 = await fsp.stat(file1);
  const stat2 = await fsp.stat(file2);
  if (signal?.aborted) throw new Error('Compare canceled by user');
  if (stat1.size !== stat2.size) return false;

  const CHUNK_SIZE = 64 * 1024;
  const buffer1 = Buffer.alloc(CHUNK_SIZE);
  const buffer2 = Buffer.alloc(CHUNK_SIZE);

  const fd1 = await fsp.open(file1, 'r');
  const fd2 = await fsp.open(file2, 'r');

  try {
    let bytesRead = 0;
    while (bytesRead < stat1.size) {
      if (signal?.aborted) throw new Error('Compare canceled by user');
      const { bytesRead: read1 } = await fd1.read(buffer1, 0, CHUNK_SIZE, bytesRead);
      const { bytesRead: read2 } = await fd2.read(buffer2, 0, CHUNK_SIZE, bytesRead);

      if (signal?.aborted) throw new Error('Compare canceled by user');

      if (read1 !== read2 || !buffer1.slice(0, read1).equals(buffer2.slice(0, read2))) {
        return false;
      }

      bytesRead += read1;
    }

    return true;
  } finally {
    await fd1.close();
    await fd2.close();
  }
}

module.exports = { compareFilesByteByByte };
