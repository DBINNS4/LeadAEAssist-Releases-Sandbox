const { execFileSync } = require('child_process');
let electron;
try {
  electron = require('electron');
} catch {
  electron = null;
}

const app = electron?.app || null;
const isPackaged = app?.isPackaged ?? false;

const { getBinaryPaths } = require('./ffmpegBridge');

function resolveFfmpegBin() {
  return getBinaryPaths().ffmpegPath;
}

// Module-level cache to avoid spawning `ffmpeg -encoders` repeatedly.
// Format/encoder detection can be triggered often (e.g., UI changes), so this
// keeps the app responsive and reduces process churn.
const __encodersCache = {
  bin: null,
  text: null,
  set: null
};

function parseEncoderNames(encodersText) {
  const set = new Set();
  const text = String(encodersText || '');
  if (!text) return set;

  // `ffmpeg -encoders` output looks like:
  //  V..... h264_nvenc           NVIDIA NVENC H.264 encoder
  //  A..... aac                  AAC (Advanced Audio Coding)
  // We take the second whitespace-delimited token as the encoder name.
  for (const line of text.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    // Skip headers
    if (trimmed.startsWith('Encoders:')) continue;
    if (trimmed.startsWith('--')) continue;

    const parts = trimmed.split(/\s+/);
    if (parts.length < 2) continue;
    const name = parts[1];
    if (name && !name.includes('=')) set.add(name);
  }

  return set;
}

function getAvailableEncoders(ffmpegPath) {
  const bin = ffmpegPath || resolveFfmpegBin();

  if (__encodersCache.bin === bin && typeof __encodersCache.text === 'string') {
    return __encodersCache.text;
  }

  try {
    const args = ['-hide_banner', '-encoders'];
    if (isPackaged) {
      console.log('[DEBUG - packaged]', bin, args);
    }
    console.log('[LeadAE Transcode]', bin, args);

    const output = execFileSync(bin, args, {
      encoding: 'utf-8'
    });
    console.log('[FFmpeg exited]', 0);

    __encodersCache.bin = bin;
    __encodersCache.text = output;
    __encodersCache.set = parseEncoderNames(output);

    return output;
  } catch (err) {
    console.error('[FFmpeg Spawn Error]', err);
    console.warn('\u26A0\uFE0F Failed to fetch encoders', err);
    return '';
  }
}

function getAvailableEncoderSet(ffmpegPath) {
  const bin = ffmpegPath || resolveFfmpegBin();
  if (__encodersCache.bin !== bin || !__encodersCache.set) {
    // Populate cache
    getAvailableEncoders(bin);
  }
  return __encodersCache.set || new Set();
}

function detectBestGPUEncoder(baseCodec, ffmpegPath) {
  const encSet = getAvailableEncoderSet(ffmpegPath);

  const priorityList = {
    // Prefer hardware encoders first, then software fallbacks.
    // Keep this list permissive to support "legal" FFmpeg builds that may not
    // include libx264/libx265.
    h264: [
      'h264_videotoolbox',
      'h264_nvenc',
      'h264_qsv',
      'h264_vaapi',
      'h264_amf',
      'h264_v4l2m2m',
      'h264_omx',
      'h264_mediacodec',
      'libx264',
      'libopenh264'
    ],
    hevc: [
      'hevc_videotoolbox',
      'hevc_nvenc',
      'hevc_qsv',
      'hevc_vaapi',
      'hevc_amf',
      'hevc_v4l2m2m',
      'hevc_mediacodec',
      'libx265',
      'libkvazaar'
    ]
  };

  const preferred = priorityList[baseCodec] || [];

  for (const encoder of preferred) {
    if (encSet.has(encoder)) {
      if (process.env.DEBUG_GPU) {
        // GPU encoder selected
      }
      return encoder;
    }
  }

  // Nothing available.
  return null;
}

function detectAIComputeType() {
  const platform = process.platform;

  try {
    if (platform === 'darwin') {
      const brand = execFileSync('sysctl', ['-n', 'machdep.cpu.brand_string'], { encoding: 'utf-8' })
        .toString()
        .toLowerCase();
      if (brand.includes('apple m')) return 'metal';
    }

    if (platform === 'linux' || platform === 'win32') {
      const output = execFileSync(
        'nvidia-smi',
        ['--query-gpu=name', '--format=csv,noheader'],
        { encoding: 'utf-8' }
      )
        .toString();
      if (output && output.trim()) return 'cuda';
    }
  } catch {
    // ignore and fallback to CPU
  }

  return 'cpu';
}

function detectOptimalComputeType() {
  const platform = process.platform;
  const arch = process.arch;

  // Apple Silicon
  if (platform === 'darwin' && arch === 'arm64') {
    return 'int8';
  }

  // PC — assume NVIDIA or fallback
  if (platform === 'win32' || platform === 'linux') {
    try {
      const output = execFileSync('nvidia-smi', ['-L'], { encoding: 'utf-8' }).toString();
      if (output && output.trim()) return 'float16';
    } catch {
      // ignore, fallback to float16 assumption
    }
    return 'float16';
  }

  return 'float32';
}

module.exports = {
  detectBestGPUEncoder,
  getAvailableEncoders,
  getAvailableEncoderSet,
  detectAIComputeType,
  detectOptimalComputeType
};
