'use strict';

const os = require('os');
const path = require('path');
const { fsp } = require('./nativeFs');

const DEFAULT_TEMP_PREFIXES = [
  'leadAE_',
  'leadAE-',
  'lead_ae_',
  'lead_ae-'
];

const DEFAULT_LOG_RETENTION_DAYS = Number.parseInt(process.env.LEADAE_LOG_MAX_AGE_DAYS || '30', 10);
const DEFAULT_LOG_RETENTION_MAX_TOTAL_MB = Number.parseFloat(process.env.LEADAE_LOG_MAX_TOTAL_MB || '512');
const LOG_FILE_EXTENSIONS = new Set(['.txt', '.jsonl']);
const LOG_FILE_NAME_EXCLUSIONS = new Set(['hash-cache.json']);

function formatBytes(bytes) {
  const n = Number(bytes) || 0;
  if (n < 1024) return `${n} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let v = n;
  let u = -1;
  while (v >= 1024 && u < units.length - 1) {
    v /= 1024;
    u += 1;
  }
  return `${v.toFixed(v >= 10 ? 1 : 2)} ${units[u]}`;
}

function getMaintenanceConfig(overrides = {}) {
  const clearTempOnStartup = process.env.LEADAE_CLEAR_TEMP_ON_STARTUP === 'true';
  const clearCacheOnStartup = process.env.LEADAE_CLEAR_CACHE_ON_STARTUP === 'true';
  const tempFileMaxAgeDays = Number.parseInt(process.env.LEADAE_TEMP_MAX_AGE_DAYS || '7', 10);
  const tempFileMaxAgeMs = Number.isFinite(tempFileMaxAgeDays)
    ? tempFileMaxAgeDays * 24 * 60 * 60 * 1000
    : 7 * 24 * 60 * 60 * 1000;
  const logRetentionDays = Number.isFinite(DEFAULT_LOG_RETENTION_DAYS) ? DEFAULT_LOG_RETENTION_DAYS : 30;
  const logRetentionMaxAgeMs = Number.isFinite(logRetentionDays)
    ? logRetentionDays * 24 * 60 * 60 * 1000
    : 30 * 24 * 60 * 60 * 1000;
  const logRetentionMaxTotalMb = Number.isFinite(DEFAULT_LOG_RETENTION_MAX_TOTAL_MB)
    ? DEFAULT_LOG_RETENTION_MAX_TOTAL_MB
    : 512;
  const logRetentionMaxTotalBytes = Number.isFinite(logRetentionMaxTotalMb)
    ? logRetentionMaxTotalMb * 1024 * 1024
    : 512 * 1024 * 1024;

  return {
    clearTempOnStartup,
    clearCacheOnStartup,
    tempDir: os.tmpdir(),
    tempPrefixes: DEFAULT_TEMP_PREFIXES,
    tempFileMaxAgeMs,
    logRetentionMaxAgeMs,
    logRetentionMaxTotalBytes,
    ...overrides
  };
}

async function lstatSafe(target) {
  try {
    return await fsp.lstat(target);
  } catch {
    return null;
  }
}

async function rmSafe(target) {
  try {
    await fsp.rm(target, { recursive: true, force: true });
    return true;
  } catch {
    return false;
  }
}

async function getPathSize(target) {
  const st = await lstatSafe(target);
  if (!st) return 0;
  if (st.isFile()) return Number(st.size) || 0;
  if (!st.isDirectory()) return 0;

  let total = 0;
  const entries = await fsp.readdir(target, { withFileTypes: true });
  for (const entry of entries) {
    total += await getPathSize(path.join(target, entry.name));
  }
  return total;
}

async function clearDirectoryContents(dirPath) {
  let freedBytes = 0;
  let removedCount = 0;

  let entries = [];
  try {
    entries = await fsp.readdir(dirPath, { withFileTypes: true });
  } catch {
    return { freedBytes, removedCount };
  }

  for (const entry of entries) {
    const target = path.join(dirPath, entry.name);
    const bytes = await getPathSize(target);
    const ok = await rmSafe(target);
    if (ok) {
      freedBytes += bytes;
      removedCount += 1;
    }
  }

  return { freedBytes, removedCount };
}

async function clearTempFiles(options = {}) {
  const {
    tempDir = os.tmpdir(),
    tempPrefixes = DEFAULT_TEMP_PREFIXES,
    maxAgeMs,
    logger
  } = options;

  const log = (logger && typeof logger.info === 'function') ? logger : console;

  // tempPrefixes semantics:
  // - null  => no prefix filtering (clear everything inside tempDir)
  // - array => clear only entries starting with any prefix
  // - other => fall back to default prefixes
  const prefixes = (tempPrefixes === null)
    ? null
    : (Array.isArray(tempPrefixes) ? tempPrefixes : DEFAULT_TEMP_PREFIXES);

  let freedBytes = 0;
  let removed = 0;

  let entries = [];
  try {
    entries = await fsp.readdir(tempDir, { withFileTypes: true });
  } catch (err) {
    log.warn?.('⚠️ Temp cleanup failed to read temp dir:', err?.message || err);
    return { ok: false, freedBytes, freed: formatBytes(freedBytes), removedCount: removed };
  }

  for (const entry of entries) {
    if (prefixes !== null) {
      // Safety: empty prefix list => match nothing.
      if (!Array.isArray(prefixes) || prefixes.length === 0) continue;
      if (!prefixes.some(prefix => entry.name.startsWith(prefix))) continue;
    }
    const target = path.join(tempDir, entry.name);
    try {
      const st = await lstatSafe(target);
      if (!st) continue;

      if (Number.isFinite(maxAgeMs)) {
        const ageMs = Date.now() - (st.mtimeMs || 0);
        if (ageMs < maxAgeMs) continue;
      }

      const bytes = await getPathSize(target);
      const ok = await rmSafe(target);
      if (ok) {
        freedBytes += bytes;
        removed += 1;
      }
    } catch (err) {
      log.warn?.('⚠️ Failed to clear temp entry:', target, err?.message || err);
    }
  }

  return {
    ok: true,
    freedBytes,
    freed: formatBytes(freedBytes),
    removedCount: removed
  };
}

async function clearCacheFiles(options = {}) {
  const {
    app,
    session,
    userDataDir,
    logger
  } = options;

  // Clear legacy loose temp files directly under os.tmpdir.
  const log = (logger && typeof logger.info === 'function') ? logger : console;

  let freedBytes = 0;
  let removed = 0;

  // 1) Clear Chromium HTTP cache (best-effort).
  try {
    const s = session?.defaultSession;
    if (s && typeof s.clearCache === 'function') {
      await s.clearCache();
    }
    // Clear CacheStorage + Service Workers (these can hold large caches in Chromium).
    if (s && typeof s.clearStorageData === 'function') {
      await s.clearStorageData({ storages: ['cachestorage', 'serviceworkers'] });
    }
  } catch (err) {
    log.warn?.('⚠️ Chromium cache clear failed (continuing):', err?.message || err);
  }

  // 2) Remove on-disk cache folders + app cache files (best-effort).
  const targets = new Set();

  if (app && typeof app.getPath === 'function') {
    try {
      const cachePath = app.getPath('cache');
      if (cachePath) targets.add(cachePath);
    } catch {
      // ignore
    }
  }

  if (userDataDir && typeof userDataDir === 'string') {
    targets.add(path.join(userDataDir, 'Cache'));
    targets.add(path.join(userDataDir, 'Code Cache'));
    targets.add(path.join(userDataDir, 'GPUCache'));
    targets.add(path.join(userDataDir, 'DawnCache'));
    targets.add(path.join(userDataDir, 'ShaderCache'));
    targets.add(path.join(userDataDir, 'cache'));

    // Hash cache (app-level) - delete unconditionally on explicit clear.
    targets.add(path.join(userDataDir, 'logs', 'hash-cache.json'));
  }

  for (const target of targets) {
    try {
      const st = await lstatSafe(target);
      if (!st) continue;

      if (st.isDirectory()) {
        const res = await clearDirectoryContents(target);
        freedBytes += res.freedBytes;
        removed += res.removedCount;
        continue;
      }

      if (st.isFile()) {
        const bytes = Number(st.size) || 0;
        const ok = await rmSafe(target);
        if (ok) {
          freedBytes += bytes;
          removed += 1;
        }
      }
    } catch (err) {
      log.warn?.('⚠️ Failed clearing cache target:', target, err?.message || err);
    }
  }

  return {
    ok: true,
    freedBytes,
    freed: formatBytes(freedBytes),
    removedCount: removed
  };
}

async function collectLogFiles(dirPath) {
  const files = [];
  const dirs = [];
  const rootStat = await lstatSafe(dirPath);
  if (!rootStat || !rootStat.isDirectory()) {
    return { files, dirs };
  }

  const stack = [dirPath];
  while (stack.length) {
    const current = stack.pop();
    if (!current) continue;
    dirs.push(current);
    let entries = [];
    try {
      entries = await fsp.readdir(current, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const entry of entries) {
      const target = path.join(current, entry.name);
      if (entry.isDirectory()) {
        stack.push(target);
        continue;
      }
      if (!entry.isFile()) continue;
      if (LOG_FILE_NAME_EXCLUSIONS.has(entry.name)) continue;
      const ext = path.extname(entry.name).toLowerCase();
      if (!LOG_FILE_EXTENSIONS.has(ext)) continue;
      const st = await lstatSafe(target);
      if (!st || !st.isFile()) continue;
      files.push({
        path: target,
        size: Number(st.size) || 0,
        mtimeMs: Number(st.mtimeMs) || 0
      });
    }
  }
  return { files, dirs };
}

async function pruneEmptyDirs(dirs, rootDir) {
  const ordered = Array.isArray(dirs)
    ? dirs.slice().sort((a, b) => b.length - a.length)
    : [];
  for (const dir of ordered) {
    if (!dir || dir === rootDir) continue;
    try {
      const entries = await fsp.readdir(dir);
      if (entries.length === 0) {
        await rmSafe(dir);
      }
    } catch {
      // ignore
    }
  }
}

async function clearLogFiles(options = {}) {
  const {
    logsDir,
    maxAgeMs,
    maxTotalBytes,
    logger
  } = options;

  const log = (logger && typeof logger.info === 'function') ? logger : console;
  let freedBytes = 0;
  let removed = 0;
  let scanned = 0;

  if (!logsDir) {
    return { ok: false, error: 'Missing logs directory', freedBytes, freed: formatBytes(freedBytes), removedCount: removed };
  }

  const { files, dirs } = await collectLogFiles(logsDir);
  scanned = files.length;

  let remaining = files.slice();
  if (Number.isFinite(maxAgeMs)) {
    const cutoff = Date.now() - maxAgeMs;
    const kept = [];
    for (const file of remaining) {
      if (file.mtimeMs >= cutoff) {
        kept.push(file);
        continue;
      }
      const ok = await rmSafe(file.path);
      if (ok) {
        freedBytes += file.size;
        removed += 1;
      }
    }
    remaining = kept;
  }

  if (Number.isFinite(maxTotalBytes)) {
    const ordered = remaining.slice().sort((a, b) => a.mtimeMs - b.mtimeMs);
    let total = ordered.reduce((sum, file) => sum + (file.size || 0), 0);
    for (const file of ordered) {
      if (total <= maxTotalBytes) break;
      const ok = await rmSafe(file.path);
      if (ok) {
        total -= file.size || 0;
        freedBytes += file.size || 0;
        removed += 1;
      }
    }
  }

  try {
    await pruneEmptyDirs(dirs, logsDir);
  } catch (err) {
    log.warn?.('⚠️ Failed pruning empty log folders:', err?.message || err);
  }

  return {
    ok: true,
    freedBytes,
    freed: formatBytes(freedBytes),
    removedCount: removed,
    scannedCount: scanned
  };
}

async function runStartupMaintenance(options = {}) {
  const {
    app,
    session,
    userDataDir,
    logger,
    config
  } = options;

  const resolvedConfig = getMaintenanceConfig(config);
  const result = {
    ok: true,
    temp: null,
    cache: null,
    logs: null
  };

  if (resolvedConfig.clearTempOnStartup) {
    result.temp = await clearTempFiles({
      tempDir: resolvedConfig.tempDir,
      tempPrefixes: resolvedConfig.tempPrefixes,
      maxAgeMs: resolvedConfig.tempFileMaxAgeMs,
      logger
    });
  }

  if (resolvedConfig.clearCacheOnStartup) {
    result.cache = await clearCacheFiles({ app, session, userDataDir, logger });
  }

  const hasLogAgeLimit = Number.isFinite(resolvedConfig.logRetentionMaxAgeMs);
  const hasLogSizeLimit = Number.isFinite(resolvedConfig.logRetentionMaxTotalBytes);
  if (hasLogAgeLimit || hasLogSizeLimit) {
    const logsDir = userDataDir
      ? path.join(userDataDir, 'logs')
      : null;
    if (logsDir) {
      result.logs = await clearLogFiles({
        logsDir,
        maxAgeMs: hasLogAgeLimit ? resolvedConfig.logRetentionMaxAgeMs : undefined,
        maxTotalBytes: hasLogSizeLimit ? resolvedConfig.logRetentionMaxTotalBytes : undefined,
        logger
      });
    }
  }

  return result;
}

module.exports = {
  getMaintenanceConfig,
  formatBytes,
  runStartupMaintenance,
  clearTempFiles,
  clearCacheFiles,
  clearLogFiles
};
