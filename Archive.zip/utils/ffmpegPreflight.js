/*
  utils/ffmpegPreflight.js

  macOS-specific fixups for bundled FFmpeg/FFprobe.

  Why this exists:
  - When FFmpeg binaries arrive via a downloaded ZIP, macOS frequently applies
    the com.apple.quarantine attribute. Gatekeeper then blocks execution and the
    process often appears to Node as SIGKILL with empty stdout/stderr.
  - In dev workflows this is common and it makes startup checks (like
    ffmpeg -version / -encoders) fail in a confusing way.

  Policy:
  - In packaged builds: do NOT automatically remove quarantine (that would be a
    security bypass). Packaged releases should be properly codesigned and
    notarized instead.
  - In dev builds: best-effort chmod + dequarantine so the developer isn't
    soft-bricked by Gatekeeper after unzipping repo assets.
*/

const fs = require('fs');
const { execFileSync } = require('child_process');

function isMac() {
  return process.platform === 'darwin';
}

function exists(p) {
  try {
    return fs.existsSync(p);
  } catch {
    return false;
  }
}

function chmodIfPossible(p, mode = 0o755) {
  try {
    if (!exists(p)) return false;
    fs.chmodSync(p, mode);
    return true;
  } catch {
    return false;
  }
}

function hasQuarantineAttribute(p) {
  if (!isMac()) return false;
  if (!exists(p)) return false;
  try {
    // If attribute exists, xattr exits 0.
    execFileSync('/usr/bin/xattr', ['-p', 'com.apple.quarantine', p], {
      stdio: ['ignore', 'ignore', 'ignore']
    });
    return true;
  } catch {
    return false;
  }
}

function clearQuarantineAttribute(p) {
  if (!isMac()) return false;
  if (!exists(p)) return false;
  try {
    // Remove only the quarantine attribute.
    execFileSync('/usr/bin/xattr', ['-d', 'com.apple.quarantine', p], {
      stdio: ['ignore', 'ignore', 'ignore']
    });
    return true;
  } catch {
    // Fallback: clear all extended attributes (still best-effort).
    try {
      execFileSync('/usr/bin/xattr', ['-c', p], {
        stdio: ['ignore', 'ignore', 'ignore']
      });
      return true;
    } catch {
      return false;
    }
  }
}

/**
 * Best-effort preflight for ffmpeg/ffprobe.
 *
 * @param {Object} opts
 * @param {string} opts.ffmpegPath
 * @param {string} opts.ffprobePath
 * @param {boolean} opts.isPackaged
 * @returns {{ chmod: string[], dequarantine: string[] }}
 */
function preflightFfmpegBinaries({ ffmpegPath, ffprobePath, isPackaged }) {
  const chmod = [];
  const dequarantine = [];

  // Always attempt chmod (harmless in both dev + packaged; will typically be a no-op).
  for (const p of [ffmpegPath, ffprobePath].filter(Boolean)) {
    if (chmodIfPossible(p)) chmod.push(p);
  }

  // Only auto-dequarantine in dev builds.
  if (isMac() && !isPackaged) {
    for (const p of [ffmpegPath, ffprobePath].filter(Boolean)) {
      if (hasQuarantineAttribute(p)) {
        if (clearQuarantineAttribute(p)) dequarantine.push(p);
      }
    }
  }

  return { chmod, dequarantine };
}

function looksLikeGatekeeperKill(err) {
  if (!err || typeof err !== 'object') return false;
  // Typical execFileSync shape when macOS kills a quarantined binary:
  // { status: null, signal: 'SIGKILL', stdout: '', stderr: '', output: [null,'',''] }
  const signal = err.signal;
  const status = err.status;
  const out = err.stdout ?? (Array.isArray(err.output) ? err.output[1] : '');
  const errOut = err.stderr ?? (Array.isArray(err.output) ? err.output[2] : '');
  return signal === 'SIGKILL' && status == null && String(out || '') === '' && String(errOut || '') === '';
}

module.exports = {
  preflightFfmpegBinaries,
  looksLikeGatekeeperKill
};
