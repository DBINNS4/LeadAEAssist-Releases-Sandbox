'use strict';

// utils/telemetrySelfTest.js
//
// Purpose: deterministic smoke test for Sentry integration.
//
// Activated by env var:
//   LEAD_TELEMETRY_SELFTEST=true
//
// What it does (best-effort):
//  1) Sends a main-process test exception via telemetryService.captureException (does NOT crash the app).
//  2) Triggers an uncaught renderer exception from inside renderer.js (for sourcemap validation).
//  3) Spawns a subtitle-editor window and triggers an uncaught renderer exception there too.
//
// Notes:
// - This file is intentionally conservative: if anything fails, it logs and exits.
// - This is test-only behavior and should be gated by the env var above.

const path = require('path');
const { BrowserWindow } = require('electron');
const telemetryService = require('../services/telemetryService');

let _ran = false;

function _log(...args) {
  try {
     
    console.log('[telemetry-selftest]', ...args);
  } catch {
    // ignore
  }
}

async function _triggerRendererThrow(win, globalFnName, fallbackMessage) {
  if (!win || win.isDestroyed?.()) return;
  try {
    // IMPORTANT: We want the throw to originate *inside* the renderer bundle files
    // (renderer.js / renderer.subtitleEditor.js) so sourcemaps can symbolicate.
    // We therefore call a pre-defined global function when available.
    await win.webContents.executeJavaScript(
      `(() => {
        try {
          const fn = window[${JSON.stringify(globalFnName)}];
          if (typeof fn === 'function') {
            fn();
            return;
          }
        } catch (e) {
          setTimeout(() => { throw e; }, 0);
          return;
        }
        // Fallback: still produce an uncaught error (but it may not symbolicate).
        setTimeout(() => { throw new Error(${JSON.stringify(fallbackMessage)}); }, 0);
      })();`
    );
  } catch (err) {
    _log('executeJavaScript failed:', err?.message || String(err));
  }
}

async function runTelemetrySelfTest({ mainWindow, appRootDir } = {}) {
  try {
    if (_ran) return;
    if (process.env.LEAD_TELEMETRY_SELFTEST !== 'true') return;
    _ran = true;

    const root = (typeof appRootDir === 'string' && appRootDir.trim())
      ? appRootDir.trim()
      : path.join(__dirname, '..');

    // 1) Main-process test event
    const state = telemetryService.getState?.() || {};
    _log('telemetry state:', state);

    telemetryService.captureException(
      new Error('LEAD_SENTRY_SELFTEST_MAIN_CAPTURE'),
      { tags: { selftest: 'true', origin: 'main' } }
    );

    // 2) Main window renderer test (renderer.js)
    if (mainWindow && !mainWindow.isDestroyed?.()) {
      _log('triggering main-window renderer throw...');
      await _triggerRendererThrow(
        mainWindow,
        '__LEAD_SENTRY_SELFTEST_THROW_RENDERER',
        'LEAD_SENTRY_SELFTEST_RENDERER_MAIN_FALLBACK'
      );
    } else {
      _log('mainWindow not available; skipping main-window renderer throw');
    }

    // 3) Subtitle editor window renderer test
    _log('spawning subtitle-editor selftest window...');
    const subtitleWin = new BrowserWindow({
      width: 900,
      height: 600,
      show: false,
      webPreferences: {
        preload: path.join(root, 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: true,
        webviewTag: false,
        nodeIntegrationInSubFrames: false,
        enableRemoteModule: false,
        webSecurity: true,
        nativeWindowOpen: true
      }
    });

    // Load from app bundle root (same as production window)
    await subtitleWin.loadFile(path.join(root, 'subtitle-editor.html'), {
      query: { win: 'subtitle-editor' }
    });

    // Trigger after load so renderer.subtitleEditor.js has executed.
    _log('triggering subtitle-editor renderer throw...');
    await _triggerRendererThrow(
      subtitleWin,
      '__LEAD_SENTRY_SELFTEST_THROW_SUBTITLE_EDITOR',
      'LEAD_SENTRY_SELFTEST_RENDERER_SUBTITLE_FALLBACK'
    );

    // Give Sentry a moment to ship the event, then close the window.
    setTimeout(() => {
      try { subtitleWin.close(); } catch {}
    }, 2500);

    // Show it if devtools are enabled, otherwise keep hidden.
    try {
      const allowDevTools = process.env.DEBUG_UI === 'true' || process.env.NODE_ENV !== 'production';
      if (allowDevTools) subtitleWin.show();
    } catch {
      // ignore
    }
  } catch (err) {
    _log('selftest failed:', err?.message || String(err));
  }
}

module.exports = {
  runTelemetrySelfTest,
};
