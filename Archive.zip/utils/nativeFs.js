// utils/nativeFs.js
//
// Electron patches Node's `fs` to treat `.asar` archives like virtual directories.
// That behavior is great for loading the app, but it's *wrong* for user-facing
// file operations (ingest / clone / backup):
//
// - A real `.asar` that exists in the user's filesystem should be copied as a
//   single opaque file.
// - The patched `fs` may report `.asar` as a directory and allow `readdir()`
//   into it, which causes our recursive walkers to "enter" the archive and then
//   later explode with "Invalid package ... .asar" errors.
//
// Electron provides `original-fs` which bypasses that ASAR virtualization.
// In non-Electron contexts (tests/CLI), `original-fs` won't exist.

let fs;
try {
  // Electron only.
  fs = require('original-fs');
} catch {
  fs = require('fs');
}

// Prefer the promises API from the same fs implementation.
// (Avoid `require('fs/promises')` here because in Electron it may still be patched.)
const fsp = fs.promises || require('fs').promises;

module.exports = { fs, fsp };
