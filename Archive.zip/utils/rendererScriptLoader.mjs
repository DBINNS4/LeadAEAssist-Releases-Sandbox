// utils/rendererScriptLoader.mjs
// CSP-safe script loader that prefers obfuscated bundles when present,
// with a fallback to the plain (non-obfuscated) sources.
//
// Why this exists:
//  - We removed inline "onerror" handlers and unsafe-inline from CSP.
//  - We also removed unsafe-eval from CSP.
//  - Some builds include ./dist-obfuscated/* and some (dev) do not.
//
// This module uses top-level await so that DOMContentLoaded will not fire
// until the renderer scripts are loaded and executed. This avoids the class
// of bugs where renderer.js attaches DOMContentLoaded listeners too late.

function loadScript(src, { id } = {}) {
  return new Promise((resolve, reject) => {
    try {
      if (id) {
        const existing = document.getElementById(id);
        if (existing) existing.remove();
      }

      const s = document.createElement('script');
      if (id) s.id = id;
      s.src = src;
      // Dynamically-inserted scripts are async by default; we enforce order by awaiting.
      s.async = false;

      s.onload = () => resolve({ src });
      s.onerror = () => reject(new Error(`Failed to load script: ${src}`));

      document.head.appendChild(s);
    } catch (err) {
      reject(err);
    }
  });
}

async function loadWithFallback(primary, fallback, opts = {}) {
  const verify = typeof opts.verify === 'function' ? opts.verify : null;
  const loadOpts = { ...(opts || {}) };
  delete loadOpts.verify;

  try {
    const res = await loadScript(primary, loadOpts);
    if (verify && !verify()) {
      throw new Error(`Verification failed after loading: ${primary}`);
    }
    return res;
  } catch (err) {
    console.warn(`[script-loader] ${err.message} → falling back to ${fallback}`);
    const res = await loadScript(fallback, loadOpts);
    if (verify && !verify()) {
      throw new Error(`Verification failed after loading: ${fallback}`);
    }
    return res;
  }
}

// Keep the same ordering as the original HTML:
//   1) speed-test panel code
//   2) main renderer (tab switching + panel logic)


// Sentry renderer SDK (Route B) is loaded via a normal <script> tag in index.html and subtitle-editor.html
await loadWithFallback(
  './dist-obfuscated/renderer.speed-test.js',
  './renderer.speed-test.js',
  { id: 'panel-script-speed-test' }
);

await loadWithFallback(
  './dist-obfuscated/renderer.js',
  './renderer.js',
  {
    id: 'panel-script-main',
    // renderer.js is expected to initialize the shared ipc alias.
    // If it fails early (e.g., CSP blocks unsafe-eval in an older obfuscated build),
    // fall back to the plain script.
    verify: () => !!window.ipc
  }
);
