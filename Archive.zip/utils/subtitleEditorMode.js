// utils/subtitleEditorMode.js
//
// Pure helpers for deciding which subtitle editor "mode" to use.
//
// IMPORTANT:
// - This module is intentionally DOM-free and side-effect free so it can be
//   unit-tested in Node/Jest.
// - It is NOT allowed to change how captions are parsed/written. It only
//   classifies a doc object for editor UI routing.

function _lower(v) {
  return String(v ?? '').trim().toLowerCase();
}

function _docIdentityString(doc) {
  if (!doc) return '';
  return _lower(doc.sourcePath || doc.displayName || '');
}

function isSccDoc(doc) {
  if (!doc) return false;
  const kind = _lower(doc.kind || doc.format);
  if (kind === 'scc' || kind === 'cea608' || kind === '608') return true;
  return _docIdentityString(doc).endsWith('.scc');
}

function isMccDoc(doc) {
  if (!doc) return false;
  const kind = _lower(doc.kind || doc.format);
  if (kind === 'mcc') return true;
  return _docIdentityString(doc).endsWith('.mcc');
}

function isSrtDoc(doc) {
  if (!doc) return false;
  const kind = _lower(doc.kind || doc.format);
  if (kind === 'srt') return true;
  return _docIdentityString(doc).endsWith('.srt');
}

function isVttDoc(doc) {
  if (!doc) return false;
  const kind = _lower(doc.kind || doc.format);
  if (kind === 'vtt' || kind === 'webvtt') return true;
  return _docIdentityString(doc).endsWith('.vtt');
}

function isWebCaptionDoc(doc) {
  return isSrtDoc(doc) || isVttDoc(doc);
}

// Coarse-grained editor mode routing.
// - 'web'      => SRT/VTT authoring and preview rules
// - 'broadcast' => SCC/MCC authoring and preview rules
function resolveSubtitleEditorMode(doc) {
  return isWebCaptionDoc(doc) ? 'web' : 'broadcast';
}

module.exports = {
  resolveSubtitleEditorMode,
  isWebCaptionDoc,
  isSccDoc,
  isMccDoc,
  isSrtDoc,
  isVttDoc,
};
