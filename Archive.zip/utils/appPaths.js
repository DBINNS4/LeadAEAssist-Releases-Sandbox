'use strict';

const fs = require('fs');
const path = require('path');
const platformPaths = require('../platform/paths');

// utils/appPaths.js
// -----------------------------------------------------------------------------
// Canonical app storage paths.
//
// IMPORTANT:
//   Do NOT rely on Electron's default app.getPath('userData') derivation.
//   This app changes app.setName() for branding, and Electron derives the default
//   userData directory from the app name. We need a stable directory name so that
//   desktop + CEP bridge + test/CLI contexts all agree.
//
// Canonical root on macOS:
//   ~/Library/Application Support/LeadAEAssist
// -----------------------------------------------------------------------------

const CANONICAL_APP_DIR = 'LeadAEAssist';
const LEGACY_APP_DIR_VARIANTS = [
  'LeadAEAssist',
  'Lead AE Assist'
  // NOTE: Intentionally *not* including "LEAD AE – ASSIST" here.
  // That folder is treated as a legacy/bug artifact and should be migrated.
];

function _mkdirBestEffort(dir) {
  try { fs.mkdirSync(dir, { recursive: true }); } catch { /* best-effort */ }
  return dir;
}

function resolveUserDataPath() {
  const env = process.env.USER_DATA_PATH;
  if (typeof env === 'string' && env.trim()) {
    return _mkdirBestEffort(env);
  }

  // Use a stable folder name under the platform app data base.
  const base = platformPaths.getAppDataBase();

  // If a legacy variant exists, prefer it to avoid "orphaning" user data.
  // (We still migrate individual bug-artifacts from other names elsewhere.)
  for (const v of LEGACY_APP_DIR_VARIANTS) {
    const candidate = path.join(base, v);
    try {
      if (fs.existsSync(candidate)) return candidate;
    } catch {
      // ignore
    }
  }

  // Default to canonical.
  return _mkdirBestEffort(path.join(base, CANONICAL_APP_DIR));
}

function getUserDataPath() {
  return resolveUserDataPath();
}

function ensureUserDataSubdir(...parts) {
  const dir = path.join(getUserDataPath(), ...parts);
  return _mkdirBestEffort(dir);
}

function ensureTempSubdir(...parts) {
  return ensureUserDataSubdir('temp', ...parts);
}

function ensureCacheSubdir(...parts) {
  return ensureUserDataSubdir('cache', ...parts);
}

function ensurePreviewsDir() {
  return ensureUserDataSubdir('previews');
}

module.exports = {
  CANONICAL_APP_DIR,
  getUserDataPath,
  ensureUserDataSubdir,
  ensureTempSubdir,
  ensureCacheSubdir,
  ensurePreviewsDir
};
