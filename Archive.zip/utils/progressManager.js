const { EventEmitter } = require('events');
const path = require('path');

class ProgressManager extends EventEmitter {
  constructor(totalBytes = 0, throttleIntervalMs = 250, mode = 'files') {
    super();
    this.totalBytes = totalBytes;
    this.completedBytes = 0;
    this.totalFiles = 0;
    this.completedFiles = 0;
    this.active = new Map();
    this.startTime = Date.now();
    this._lastOverallEmit = 0;
    this._throttleInterval = throttleIntervalMs;
    this._mode = mode;
    this._isComplete = false;
    this._lastJobId = null;

    // 🕒 Emit progress every interval, even if no new data
    this._ticker = setInterval(() => {
      this._forceTick();
    }, this._throttleInterval);
  }

  setTotalFiles(count) {
    this.totalFiles = count;
  }

  startFile(streamId, filePath, size) {
    const entry = { file: path.basename(filePath), copied: 0, size };
    this.active.set(streamId, entry);
    this.emit('stream-progress', this._payload(streamId, entry));
  }

  updateStream(streamId, chunkSize) {
    const entry = this.active.get(streamId);
    if (!entry) return;
    // IMPORTANT (v1 performance hardening): do not emit per-chunk progress.
    // Large, fast copies can generate thousands of chunk callbacks per second
    // which will flood IPC/UI updates and make the app appear frozen.
    // The interval ticker (_forceTick) is the single source of progress emissions.
    const inc = (Number(chunkSize) || 0);
    const prevCopied = entry.copied;
    const nextCopied = prevCopied + inc;
    entry.copied = entry.size > 0 ? Math.min(entry.size, nextCopied) : nextCopied;

    // Only count the delta that actually advanced (guards against overshoot).
    const advanced = Math.max(0, entry.copied - prevCopied);
    this.completedBytes += advanced;
  }

  finishFile(streamId, statusMap = null) {
    const entry = this.active.get(streamId);
    if (!entry) return;
    entry.copied = entry.size;
    this.completedFiles++;
    
    this.emit('stream-progress', this._payload(streamId, entry));
    this.emit('file-complete', {
      streamId: String(streamId),
      file: entry.file,
      completedFiles: this.completedFiles,
      totalFiles: this.totalFiles
    });
    if (statusMap) {
      this.emit('file-status', {
        streamId: String(streamId),
        statusMap,
        file: entry.file
      });
    }
    this.active.delete(streamId);

    this.emit('overall-progress', {
      overall: this._overall(),
      eta: this._eta(),
      completedFiles: this.completedFiles,
      totalFiles: this.totalFiles
    });

    // ✅ Safety net: auto-complete when we’re truly done.
    // We don’t pass jobId here (unknown at this layer); upstream can still call complete(jobId).
    if (
      !this._isComplete &&
      this.totalFiles > 0 &&
      this.completedFiles >= this.totalFiles &&
      this.active.size === 0
    ) {
      try { this.complete(); } catch {}
    }
  }

  adjustTotal(delta) {
    this.totalBytes += delta;
  }

  _overall() {
    switch (this._mode) {
      case 'time': {
        return this.totalBytes > 0
          ? Math.min(100, (this.completedBytes / this.totalBytes) * 100)
          : 0;
      }
      case 'files': {
        return this.totalFiles > 0
          ? Math.min(100, (this.completedFiles / this.totalFiles) * 100)
          : 0;
      }
      case 'bytes':
      default: {
        return this.totalBytes > 0
          ? Math.min(100, (this.completedBytes / this.totalBytes) * 100)
          : 0;
      }
    }
  }

  _estimatedTotalTime() {
    const elapsed = Date.now() - this.startTime;

    switch (this._mode) {
      case 'time': {
        const progress = this.completedBytes / this.totalBytes;
        return progress > 0 ? elapsed / progress : elapsed;
      }
      case 'files': {
        const rate = this.completedFiles / elapsed;
        const remaining = this.totalFiles - this.completedFiles;
        return rate > 0 ? elapsed + remaining / rate : elapsed;
      }
      default: {
        const rate = this.completedBytes / elapsed;
        const remaining = this.totalBytes - this.completedBytes;
        return rate > 0 ? elapsed + remaining / rate : elapsed;
      }
    }
  }

  _eta() {
    const estimatedMs = this._estimatedTotalTime() - (Date.now() - this.startTime);
    return `${Math.max(0, Math.floor(estimatedMs / 1000))}s`;
  }

  _percent(current, total) {
    return total > 0 ? Math.min(100, (current / total) * 100) : 0;
  }

    _payload(streamId, entry) {
    if (!entry) {
      return {
        streamId,
        file: 'unknown',
        percent: 0,
        eta: this._eta(),
        overall: this._overall(),
        completedFiles: this.completedFiles,
        totalFiles: this.totalFiles
      };
    }

    return {
      streamId,
      file: entry.file,
      percent: this._percent(entry.copied, entry.size),
      eta: this._eta(),
      overall: this._overall(),
      completedFiles: this.completedFiles,
      totalFiles: this.totalFiles
    };
  }

  update(streamId, chunkSize) {
    this.updateStream(streamId, chunkSize);
    const entry = this.active.get(streamId);
    return this._payload(streamId, entry);
  }

  _forceTick() {
    for (const [streamId, entry] of this.active.entries()) {
      this.emit('stream-progress', this._payload(streamId, entry));
    }

    this.emit('overall-progress', {
      overall: this._overall(),
      eta: this._eta(),
      completedFiles: this.completedFiles,
      totalFiles: this.totalFiles
    });
  }

  complete(jobId = null) {
    if (this._isComplete) {
      if (jobId != null && jobId !== this._lastJobId) {
        this._lastJobId = jobId;
        this.emit('complete', {
          jobId,
          completedFiles: this.completedFiles,
          totalFiles: this.totalFiles
        });
      }
      return;
    }
    this._isComplete = true;
    this._lastJobId = jobId;
    this._forceTick();
    this.emit('complete', {
      jobId,
      completedFiles: this.completedFiles,
      totalFiles: this.totalFiles
    });
    this.dispose();
  }

  dispose() {
    clearInterval(this._ticker);
  }
}

module.exports = ProgressManager;
