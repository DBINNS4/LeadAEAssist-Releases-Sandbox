(() => {
  // NOTE: Do not capture the IPC bridge at module init time.
  // Some panels load scripts lazily and may set window.ipc after this file.
  const getIpc = () => window.ipc ?? window.electron ?? globalThis.ipc;

  // Preserve the button's internal markup (the UI skin relies on nested spans).
  // Falls back to plain text for simple buttons.
  function setButtonLabel(btn, label) {
    if (!btn) return;
    try {
      const textNode = btn.querySelector?.('.button_text');
      if (textNode) {
        textNode.textContent = String(label ?? '');
        return;
      }
    } catch {
      // ignore
    }
    btn.textContent = String(label ?? '');
  }

  function translateLabel(key, fallback) {
    const i18n = window.i18n;
    if (!i18n?.t) return fallback;
    try {
      return i18n.t(key, { defaultValue: fallback });
    } catch {
      return fallback;
    }
  }

  function inferPanelContext({ panel, checkboxId, startBtnId, cancelBtnId }) {
    if (panel) return panel;
    const ids = [checkboxId, startBtnId, cancelBtnId].map(v => String(v || '').toLowerCase());
    if (ids.some(v => v.includes('ingest'))) return 'ingest';
    if (ids.some(v => v.includes('transcode'))) return 'transcode';
    if (ids.some(v => v.includes('transcribe'))) return 'transcribe';
    return 'default';
  }

  function resolveLabelKeys(context) {
    const panelKeys = {
      ingest: {
        start: 'startIngest',
        cancel: 'cancelIngest',
        startWatching: 'ingestStartWatching',
        stopWatching: 'ingestStopWatching'
      },
      transcode: {
        start: 'startTranscode',
        cancel: 'cancelTranscode',
        startWatching: 'transcodeStartWatching',
        stopWatching: 'transcodeStopWatching'
      },
      transcribe: {
        start: 'startTranscribe',
        cancel: 'cancelTranscribe',
        startWatching: 'transcribeStartWatching',
        stopWatching: 'transcribeStopWatching'
      },
      default: {
        start: 'start',
        cancel: 'cancel',
        startWatching: 'startWatching',
        stopWatching: 'stopWatching'
      }
    };
    return panelKeys[context] || panelKeys.default;
  }

  function initWatchToggle({ checkboxId, startBtnId, cancelBtnId, panel, onToggle }) {
    const checkbox = document.getElementById(checkboxId);
    const startBtn = document.getElementById(startBtnId);
    const cancelBtn = document.getElementById(cancelBtnId);
    const context = inferPanelContext({ panel, checkboxId, startBtnId, cancelBtnId });
    const keys = resolveLabelKeys(context);

    const updateLabels = ({ notifyToggle = true } = {}) => {
      const isWatch = checkbox?.checked;
      setButtonLabel(
        startBtn,
        isWatch
          ? translateLabel(keys.startWatching, 'Start Watching')
          : translateLabel(keys.start, 'Start')
      );
      setButtonLabel(
        cancelBtn,
        isWatch
          ? translateLabel(keys.stopWatching, 'Stop Watching')
          : translateLabel(keys.cancel, 'Cancel')
      );
      if (notifyToggle && typeof onToggle === 'function') {
        try { onToggle(isWatch); }
        catch (e) { console.warn('[watch-mode] onToggle failed:', e); }
      }
    };

    checkbox?.addEventListener('change', updateLabels);
    if (window.i18n?.on) {
      window.i18n.on('languageChanged', () => {
        updateLabels({ notifyToggle: false });
      });
    }
    updateLabels();

    return { checkbox, startBtn, cancelBtn };
  }

  async function startWatch(panel, cfg) {
    const i = getIpc();
    if (!i?.invoke) {
      throw new Error('IPC bridge not available (window.electron.invoke missing).');
    }

    if (window.watchConfigs) window.watchConfigs[panel] = cfg;

    // Avoid mutating caller-owned config objects.
    const baseCfg = (cfg && typeof cfg === 'object') ? { ...cfg } : {};
    baseCfg.logActions = true;

    // Derive watcher hidden handling from panel config when possible.
    // Ingest/clone panels use `includeHiddenFiles`; other panels may use
    // `includeHidden`. The watcher expects `ignoreHidden`.
    const includeHidden =
      (typeof baseCfg.includeHiddenFiles === 'boolean')
        ? baseCfg.includeHiddenFiles
        : ((typeof baseCfg.includeHidden === 'boolean') ? baseCfg.includeHidden : false);
    if (typeof baseCfg.ignoreHidden !== 'boolean') {
      baseCfg.ignoreHidden = !includeHidden;
    }

    // Prefer an explicit watchFolder. For backward compatibility, tolerate a few
    // older panel configs. Avoid using outputPath for transcribe watch mode,
    // because outputPath is the *destination* and watching it can self-trigger.
    const folder =
      baseCfg?.watchFolder ||
      baseCfg?.folder ||
      baseCfg?.source ||
      baseCfg?.outputFolder ||
      (panel === 'transcribe' ? null : (baseCfg?.outputPath || null));

    if (!folder) {
      throw new Error('No valid folder path provided for Watch Mode.');
    }

    const result = await i.invoke('start-watch-folder', {
      ...baseCfg,
      panel,
      folder,
      panelConfig: baseCfg,
      customExtensions: baseCfg.customExtensions || []
    });

    // Important: the backend can *return* failure (success:false) without throwing.
    // Normalize that into an exception so panels can handle it consistently.
    const ok = !!result && (result.success === true || result.ok === true);
    if (result && !ok) {
      const errorValue = result?.error;
      const detail =
        typeof result === 'string'
          ? result
          : (errorValue && typeof errorValue === 'object')
            ? (errorValue.message || result?.message || 'Watch mode could not be started.')
            : errorValue || result?.message || 'Watch mode could not be started.';
      throw new Error(detail);
    }

    return result;
  }

  async function stopWatch(panel) {
    const i = getIpc();
    if (!i?.invoke) {
      throw new Error('IPC bridge not available (window.electron.invoke missing).');
    }
    return i.invoke('stop-watch-folder', panel);
  }

  const api = { initWatchToggle, startWatch, stopWatch };

  if (typeof module !== 'undefined') {
    module.exports = api;
  }

  window.watchUtils = api;

  // Signal that watch utilities are ready. Some panels may load before this
  // script (depending on bundling/load order) and can re-initialize once
  // watchUtils becomes available.
  try {
    window.dispatchEvent(new Event('watch-utils-ready'));
  } catch {
    // ignore
  }
})();
