// utils/qcDeliveryPrefs.js
// Centralized QC & Delivery preference logic shared across panels.
//
// Goals (Phase 1):
//  - Single source of truth for export policy normalization (warn | gate_write | gate_block)
//  - One place to read QC thresholds + delivery knobs from localStorage
//  - Idempotent migrations for legacy keys
//  - Reusable MCC 708 window placement normalization
//
// This module is written to work in BOTH:
//  - Electron renderer (window + localStorage)
//  - Node (CommonJS require)
//
// In the renderer, it attaches to: window.qcDeliveryPrefs

'use strict';

(function attach(root, factory) {
  const api = factory();
  // CommonJS (Node / Electron main)
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  }
  // Browser / renderer global
  // (Avoid polluting Node globals in tests / main process.)
  const hasDom = !!(root && typeof root === 'object' && root.document && typeof root.document === 'object');
  if (hasDom) root.qcDeliveryPrefs = api;
})(typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : this), function factory() {
  // ─────────────────────────────────────────────────────────────
  // Defaults (must match the Transcribe panel “fresh install” behavior)
  // ─────────────────────────────────────────────────────────────
  const DEFAULTS = Object.freeze({
    scc: {
      exportPolicy: 'warn',
      allowNdf: false,
      strictCharacterEncoding: false,
      padEven: false,
      repeatControlCodes: true,
      repeatPreambleCodes: true,
      stripLeadingDashes: false,
      channel: 1,
      safeMargins: { left: 0, right: 0 },
      // Transcribe panel: SCC placement is always user-driven via the Visual placement grid.
      placementMode: 'custom',
      placementBottomRow: 15,
      // Default "lower center" for a 28-col window in a 32-col grid = left edge at col 2.
      placementLeftCol: 2,
      shaping: {
        enabled: false,
        mode: 'conservative',
        microCueSec: 0.40,
        microGapSec: 0.12,
        maxShiftSec: 0.25,
        fixStartTcClamp: true
      }
    },
    mcc: {
      exportPolicy: 'warn',
      include608Compatibility: true,
      telestreamCompression: false,
      includeCdpTimecode: false,
      includeCcsSvcInfo: true,
      authoringModel: 'true708',
      alignment: 'left',
      pingPongWindows: true,
      maxCharsPerLine: 42,
      maxLinesPerBlock: 2,
      maxDurationSeconds: 6.0,
      serviceNumber: 1,
      language: 'eng',
      timecodeOffsetPolicy: 'clamp',
      mcc708Window: { rel: true, anchorId: 7, anchorV: 90, anchorH: 50 },
      padEven: false,
      repeatControlCodes: false,
      repeatPreambleCodes: true,
      strictCharacterEncoding: false,
      safeMargins: { left: 0, right: 0 },
      shaping: {
        enabled: false,
        mode: 'conservative',
        microCueSec: 0.40,
        microGapSec: 0.12,
        maxShiftSec: 0.25
      }
    },
    vtt: {
      qc: {
        maxCps: 20,
        minDurationSeconds: 1.0,
        minSplitDurationSeconds: 0.5
      }
    }
  });

  // ─────────────────────────────────────────────────────────────
  // Canonical key list for QC & Delivery prefs persistence
  // ─────────────────────────────────────────────────────────────
  // NOTE: These are localStorage keys. Phase 3 uses this list to sync to state.json.
  const STORAGE_KEYS = Object.freeze([
    // SCC
    'scc-export-policy',
    'scc-qc-gate',
    'scc-draft-salvage',
    'scc-qc-max-cps',
    'scc-qc-max-wpm',
    'scc-qc-min-duration',
    'scc-qc-min-gap',
    'scc-qc-max-late-eoc',
    'scc-qc-max-late-eoc-count',
    'scc-safe-left',
    'scc-safe-right',
    'scc-placement-mode',
    'scc-placement-bottom-row',
    'scc-placement-left-col',
    'scc-channel',
    'scc-allow-ndf',
    'scc-strict-encoding',
    'scc-shape-enable',
    'scc-shape-mode',
    'scc-shape-micro-dur',
    'scc-shape-micro-gap',
    'scc-shape-max-shift',
    'scc-shape-fix-starttc',
    'scc-prestart-roll',
    'scc-time-source',
    'scc-start-reset-at',
    'scc-start-reset-op',
    'scc-pad-even',
    'scc-prefix-words',
    'scc-repeat-control',
    'scc-repeat-preamble',
    'scc-strip-leading-dashes',

    // MCC
    'mcc-export-policy',
    'mcc-qc-max-cps',
    'mcc-qc-max-wpm',
    'mcc-qc-min-duration',
    'mcc-qc-min-gap',
    'mcc-include-608',
    'mcc-telestream-compress',
    'mcc-embed-cdp-timecode',
    'mcc-include-ccsvc-info',
    'mcc-alignment',
    'mcc-pingpong-windows',
    'mcc-max-chars',
    'mcc-max-lines',
    'mcc-max-duration',
    'mcc-service-number',
    'mcc-language',
    'mcc-tc-start',
    'mcc-timecode-offset',
    'mcc-timecode-offset-policy',
    'mcc-window-rel',
    'mcc-window-anchor-id',
    'mcc-window-anchor-v',
    'mcc-window-anchor-h',
    'mcc-window-anchor-migrated-v1',
    'mcc-window-anchor-migrated-v2',
    'mcc-pad-even',
    'mcc-repeat-control',
    'mcc-repeat-preamble',
    'mcc-strict-encoding',
    'mcc-safe-left',
    'mcc-safe-right',
    'mcc-overflow-policy',
    'mcc-shape-enable',
    'mcc-shape-mode',
    'mcc-shape-micro-dur',
    'mcc-shape-micro-gap',
    'mcc-shape-max-shift',

    // SRT
    'srt-prevent-overlaps',
    'srt-allow-extension',
    'srt-max-end-extension',
    'srt-max-chars',
    'srt-max-lines',
    'srt-max-duration',
    'srt-qc-max-cps',
    'srt-qc-min-duration',
    'srt-qc-min-split-duration',
    'srt-utf8-bom',
    'srt-line-ending',

    // VTT
    'vtt-include-style',
    'vtt-prevent-overlaps',
    'vtt-allow-extension',
    'vtt-max-end-extension',
    'vtt-max-chars',
    'vtt-max-lines',
    'vtt-max-duration',
    'vtt-qc-max-cps',
    'vtt-qc-min-duration',
    'vtt-qc-min-split-duration'
  ]);

  function getStorageKeys() {
    return Array.from(STORAGE_KEYS);
  }

  // Snapshot localStorage (or compatible storage) values for the canonical keys.
  // Missing keys are omitted from the output.
  function snapshotStorage(storage, keys = STORAGE_KEYS) {
    const st = _resolveStorage(storage);
    const out = {};
    if (!st) return out;
    const list = Array.isArray(keys) ? keys : STORAGE_KEYS;
    for (const k of list) {
      try {
        const v = st.getItem(k);
        if (v != null) out[String(k)] = String(v);
      } catch {
        // ignore
      }
    }
    return out;
  }

  // Apply a snapshot back into storage.
  // By default, removes any canonical keys that are not present in the snapshot.
  function applyStorageSnapshot(storage, snapshot, opts = {}) {
    const st = _resolveStorage(storage);
    if (!st) return;
    const snap = (snapshot && typeof snapshot === 'object') ? snapshot : {};
    const keys = Array.isArray(opts.keys) ? opts.keys : STORAGE_KEYS;
    const removeMissing = (opts.removeMissing !== false);

    for (const k of keys) {
      const key = String(k);
      if (Object.prototype.hasOwnProperty.call(snap, key)) {
        const v = snap[key];
        try {
          if (v == null) st.removeItem(key);
          else st.setItem(key, String(v));
        } catch {
          // ignore
        }
      } else if (removeMissing) {
        try { st.removeItem(key); } catch {}
      }
    }
  }


  // ─────────────────────────────────────────────────────────────
  // Storage helpers
  // ─────────────────────────────────────────────────────────────
  function _resolveStorage(storage) {
    if (storage && typeof storage.getItem === 'function') return storage;
    if (typeof localStorage !== 'undefined' && localStorage && typeof localStorage.getItem === 'function') return localStorage;
    return null;
  }

  function _getStr(storage, key, defVal = '') {
    const st = _resolveStorage(storage);
    if (!st) return String(defVal ?? '');
    try {
      const v = st.getItem(key);
      return (v == null) ? String(defVal ?? '') : String(v);
    } catch {
      return String(defVal ?? '');
    }
  }

  function _setStr(storage, key, value) {
    const st = _resolveStorage(storage);
    if (!st) return;
    try { st.setItem(key, String(value)); } catch {}
  }

  function _remove(storage, key) {
    const st = _resolveStorage(storage);
    if (!st) return;
    try { st.removeItem(key); } catch {}
  }

  function _getBool(storage, key, defVal = false) {
    const raw = _getStr(storage, key, null);
    if (raw == null) return !!defVal;
    const s = String(raw).trim().toLowerCase();
    if (s === 'true') return true;
    if (s === 'false') return false;
    return !!defVal;
  }

  function _getInt(storage, key, defVal = 0, min = null, max = null) {
    const raw = parseInt(_getStr(storage, key, ''), 10);
    let out = Number.isFinite(raw) ? raw : defVal;
    if (typeof min === 'number') out = Math.max(min, out);
    if (typeof max === 'number') out = Math.min(max, out);
    return out;
  }

  // IMPORTANT: Number('') === 0.
  // For prefs/QC thresholds, a blank input means “unset”, not 0.
  function _getNumOpt(storage, key) {
    const s = String(_getStr(storage, key, '') ?? '').trim();
    if (!s) return undefined;
    const n = Number(s);
    return Number.isFinite(n) ? n : undefined;
  }

  function _getNum(storage, key, defVal = null) {
    const n = _getNumOpt(storage, key);
    return (n == null) ? defVal : n;
  }

  // ─────────────────────────────────────────────────────────────
  // Export policy normalization + legacy migration
  // ─────────────────────────────────────────────────────────────
  function normalizeExportPolicy(raw, fallback = '') {
    const v = String(raw || '').trim().toLowerCase();
    if (v === 'gate_block' || v === 'block' || v === 'strict') return 'gate_block';
    if (v === 'gate_write' || v === 'gate') return 'gate_write';
    if (v === 'warn' || v === 'draft' || v === 'normal' || v === 'off') return 'warn';
    return String(fallback || '').trim();
  }

  function _deriveExportPolicyFromLegacy({ legacyGateRaw, legacyDraftRaw, defaultPolicy }) {
    const hasLegacy = (legacyGateRaw != null) || (legacyDraftRaw != null);
    const legacyGate = legacyGateRaw === 'true';
    const legacyDraft = (legacyDraftRaw == null) ? true : (legacyDraftRaw !== 'false');
    return !hasLegacy
      ? defaultPolicy
      : (legacyGate ? (legacyDraft ? 'gate_write' : 'gate_block') : 'warn');
  }

  function _syncLegacySccKeys(storage, exportPolicy) {
    const policy = normalizeExportPolicy(exportPolicy, DEFAULTS.scc.exportPolicy);
    const gate = (policy === 'gate_write' || policy === 'gate_block');
    const draft = (policy !== 'gate_block');
    _setStr(storage, 'scc-export-policy', policy);
    _setStr(storage, 'scc-qc-gate', gate ? 'true' : 'false');
    _setStr(storage, 'scc-draft-salvage', draft ? 'true' : 'false');
    return policy;
  }

  // Public helper: keep SCC export policy + legacy keys in sync.
  // This is used by UI code when the dropdown changes, so behavior stays consistent
  // across Transcribe, Subtitle Editor, and any future panels.
  function syncSccExportPolicy(storage, exportPolicy) {
    return _syncLegacySccKeys(storage, exportPolicy);
  }

  function _deriveMccExportPolicyFromProfile(storage) {
    const prof = String(_getStr(storage, 'mcc-delivery-profile', '') || '').trim().toLowerCase();
    if (prof === 'broadcast') return 'gate_write';
    if (prof === 'strict') return 'gate_write';
    if (prof === 'nle') return 'warn';
    return '';
  }

  // One-time migration for the classic broken 708 window state:
  // rel=false but anchor numbers are still in 0..99 (% space) or V got clamped to 74.
  function migrateMccWindowAnchors(storage) {
    const st = _resolveStorage(storage);
    if (!st) return;
    try {
      const didMigrate = String(st.getItem('mcc-window-anchor-migrated-v1') || '').trim() === '1';
      if (didMigrate) return;

      const relRaw = String(st.getItem('mcc-window-rel') || '').trim().toLowerCase();
      if (relRaw !== 'false') return;

      const hRaw = String(st.getItem('mcc-window-anchor-h') || '').trim();
      const vRaw = String(st.getItem('mcc-window-anchor-v') || '').trim();
      const anchorIdRaw = parseInt(String(st.getItem('mcc-window-anchor-id') || '7'), 10);
      const anchorId = Number.isFinite(anchorIdRaw) ? Math.max(0, Math.min(8, anchorIdRaw)) : 7;

      const hNum = parseInt(hRaw, 10);
      const vNum = parseInt(vRaw, 10);

      // Strong signal: V in 75..99 can ONLY be relative (absolute max is 74)
      const vLooksRelative = Number.isFinite(vNum) && vNum > 74 && vNum <= 99;
      const hLooksRelative = Number.isFinite(hNum) && hNum >= 0 && hNum <= 99;

      // Default-ish broken state (Lower Center) where V got clamped.
      const classicClampedDefault =
        (anchorId === 7) &&
        (hRaw === '50') &&
        (vRaw === '74' || vLooksRelative || vRaw === '90' || vRaw === '');

      if (vLooksRelative && hLooksRelative) {
        const hAbs = Math.round((hNum / 99) * 209);
        const vAbs = Math.round((vNum / 99) * 74);
        st.setItem('mcc-window-anchor-h', String(Math.max(0, Math.min(209, hAbs))));
        st.setItem('mcc-window-anchor-v', String(Math.max(0, Math.min(74, vAbs))));
        st.setItem('mcc-window-anchor-migrated-v1', '1');
        return;
      }

      if (classicClampedDefault) {
        const hAbs = Math.round((50 / 99) * 209);
        const vAbs = Math.round((90 / 99) * 74);
        st.setItem('mcc-window-anchor-h', String(Math.max(0, Math.min(209, hAbs))));
        st.setItem('mcc-window-anchor-v', String(Math.max(0, Math.min(74, vAbs))));
        st.setItem('mcc-window-anchor-migrated-v1', '1');
      }
    } catch {
      // Migration must never block UI.
    }
  }

  function migrateLegacyPrefs(storage) {
    // SCC export policy migration
    const existingScc = normalizeExportPolicy(_getStr(storage, 'scc-export-policy', ''), '');
    if (!existingScc) {
      const legacyGateRaw = _getStr(storage, 'scc-qc-gate', null);
      const legacyDraftRaw = _getStr(storage, 'scc-draft-salvage', null);
      const derived = _deriveExportPolicyFromLegacy({
        legacyGateRaw,
        legacyDraftRaw,
        defaultPolicy: DEFAULTS.scc.exportPolicy
      });
      _syncLegacySccKeys(storage, derived);
    } else {
      _syncLegacySccKeys(storage, existingScc);
    }
    // MCC export policy: 2-state UI (Draft/Delivery). Collapse any legacy "gate_block" into Delivery.
    let existingMcc = normalizeExportPolicy(_getStr(storage, 'mcc-export-policy', ''), '');
    if (!existingMcc) {
      const fromProfile = _deriveMccExportPolicyFromProfile(storage);
      existingMcc = normalizeExportPolicy(fromProfile, DEFAULTS.mcc.exportPolicy);
    }
    if (existingMcc === 'gate_block') existingMcc = 'gate_write';
    _setStr(storage, 'mcc-export-policy', existingMcc || DEFAULTS.mcc.exportPolicy);

    // MCC delivery profile + compatibility mode were removed from the UI.
    try { _remove(storage, 'mcc-delivery-profile'); } catch {}
    try { _remove(storage, 'mcc-compat-mode'); } catch {}


    // MCC 708 window migration
    migrateMccWindowAnchors(storage);

    // VTT delivery profiles were removed (professional UI: no training wheels).
    // Clean up the legacy key so state sync/storage doesn't retain dead settings.
    try { _remove(storage, 'vtt-profile'); } catch {}
  }

  // ─────────────────────────────────────────────────────────────
  // MCC 708 window placement normalization (rel/abs repair)
  // ─────────────────────────────────────────────────────────────
  function normalizeMcc708WindowPlacement(wIn) {
    const w = (wIn && typeof wIn === 'object') ? { ...wIn } : {};
    const rel = (w.rel !== false); // default true

    const anchorIdRaw = Number.isFinite(Number(w.anchorId)) ? Math.trunc(Number(w.anchorId)) : 7;
    const anchorId = Math.max(0, Math.min(8, anchorIdRaw));

    let anchorV = Number.isFinite(Number(w.anchorV)) ? Math.trunc(Number(w.anchorV)) : (rel ? 90 : 67);
    let anchorH = Number.isFinite(Number(w.anchorH)) ? Math.trunc(Number(w.anchorH)) : (rel ? 50 : 105);

    if (rel) {
      // If Relative is ON but H is > 99, the anchors are almost certainly still in absolute space.
      // Convert instead of clamping (clamping pins the window to the far right).
      if (Number.isFinite(anchorH) && anchorH > 99) {
        const hAbs = Math.max(0, Math.min(209, anchorH));
        anchorH = Math.round((hAbs / 209) * 99);

        // Convert V only if it also looks like absolute (<=74).
        if (Number.isFinite(anchorV) && anchorV >= 0 && anchorV <= 74) {
          const vAbs = Math.max(0, Math.min(74, anchorV));
          anchorV = Math.round((vAbs / 74) * 99);
        }
      }

      anchorV = Math.max(0, Math.min(99, anchorV));
      anchorH = Math.max(0, Math.min(99, anchorH));
    } else {
      // Absolute mode: V is 0..74, H is 0..209.
      const vLooksRelative = (anchorV > 74 && anchorV <= 99);
      const classicClampedDefault = (anchorId === 7 && anchorH === 50 && anchorV === 74);

      if (vLooksRelative) {
        // Treat both anchors as relative percentages and convert to absolute.
        anchorH = Math.round((Math.max(0, Math.min(99, anchorH)) / 99) * 209);
        anchorV = Math.round((Math.max(0, Math.min(99, anchorV)) / 99) * 74);
      } else if (classicClampedDefault) {
        // The user likely intended the default 90% vertical placement, but it got clamped to 74.
        anchorH = Math.round((50 / 99) * 209);
        anchorV = Math.round((90 / 99) * 74);
      }

      anchorV = Math.max(0, Math.min(74, anchorV));
      anchorH = Math.max(0, Math.min(209, anchorH));
    }

    return { rel, anchorId, anchorV, anchorH };
  }

  // ─────────────────────────────────────────────────────────────
  // Read per-format preferences
  // ─────────────────────────────────────────────────────────────
  function readSccPrefs(storage) {
    migrateLegacyPrefs(storage);

    const prefs = {};

    prefs.safeMargins = {
      left: _getInt(storage, 'scc-safe-left', DEFAULTS.scc.safeMargins.left, 0, 15),
      right: _getInt(storage, 'scc-safe-right', DEFAULTS.scc.safeMargins.right, 0, 15)
    };

    // Default placement for SCC (CEA-608) when cues do not carry explicit {row}/{col} tags
    prefs.placementMode = (() => {
      const raw = String(_getStr(storage, 'scc-placement-mode', DEFAULTS.scc.placementMode) || '').trim().toLowerCase();
      return (raw === 'custom' || raw === 'manual' || raw === 'fixed') ? 'custom' : 'auto';
    })();

    prefs.placementBottomRow = _getInt(storage, 'scc-placement-bottom-row', DEFAULTS.scc.placementBottomRow, 1, 15);
    prefs.placementLeftCol = _getInt(storage, 'scc-placement-left-col', DEFAULTS.scc.placementLeftCol, 0, 31);

    // Caption service (CC1–CC4). Stored as '1'..'4' (or occasionally 'CC1' strings).
    prefs.channel = (() => {
      const raw = String(_getStr(storage, 'scc-channel', String(DEFAULTS.scc.channel)) || '').trim().toUpperCase();
      const m = raw.match(/^CC\s*([1-4])$/);
      const n = m ? parseInt(m[1], 10) : parseInt(raw, 10);
      return Number.isFinite(n) ? Math.max(1, Math.min(4, n)) : DEFAULTS.scc.channel;
    })();

    prefs.allowNdf = _getBool(storage, 'scc-allow-ndf', DEFAULTS.scc.allowNdf);
    prefs.strictCharacterEncoding = _getBool(storage, 'scc-strict-encoding', DEFAULTS.scc.strictCharacterEncoding);

    const exportPolicy = normalizeExportPolicy(_getStr(storage, 'scc-export-policy', DEFAULTS.scc.exportPolicy), DEFAULTS.scc.exportPolicy);
    prefs.exportPolicy = exportPolicy;
    prefs.draft = (exportPolicy !== 'gate_block');
    _syncLegacySccKeys(storage, exportPolicy);

    prefs.shaping = {
      enabled: _getBool(storage, 'scc-shape-enable', DEFAULTS.scc.shaping.enabled),
      mode: String(_getStr(storage, 'scc-shape-mode', DEFAULTS.scc.shaping.mode)).trim() || DEFAULTS.scc.shaping.mode,
      microCueSec: _getNum(storage, 'scc-shape-micro-dur', DEFAULTS.scc.shaping.microCueSec),
      microGapSec: _getNum(storage, 'scc-shape-micro-gap', DEFAULTS.scc.shaping.microGapSec),
      maxShiftSec: _getNum(storage, 'scc-shape-max-shift', DEFAULTS.scc.shaping.maxShiftSec),
      fixStartTcClamp: _getBool(storage, 'scc-shape-fix-starttc', DEFAULTS.scc.shaping.fixStartTcClamp)
    };

    prefs.preStartTransmitSec = (() => {
      const v = _getNumOpt(storage, 'scc-prestart-roll');
      return Number.isFinite(v) && v > 0 ? v : 0;
    })();

    const ts = String(_getStr(storage, 'scc-time-source', '')).trim();
    if (ts) prefs.timeSource = ts;

    const sra = String(_getStr(storage, 'scc-start-reset-at', 'auto')).trim();
    if (sra) prefs.startResetAt = sra;

    const sro = String(_getStr(storage, 'scc-start-reset-op', 'edm')).trim();
    if (sro) prefs.startResetOp = sro;

    prefs.padEven = _getBool(storage, 'scc-pad-even', DEFAULTS.scc.padEven);

    const pw = String(_getStr(storage, 'scc-prefix-words', '')).trim();
    if (pw) prefs.prefixWords = pw.split(/[,\s]+/).map(t => t.trim()).filter(Boolean);

    // Default true unless explicitly disabled
    prefs.repeatControlCodes = _getStr(storage, 'scc-repeat-control', '') !== 'false';
    prefs.repeatPreambleCodes = _getStr(storage, 'scc-repeat-preamble', '') !== 'false';
    prefs.stripLeadingDashes = _getBool(storage, 'scc-strip-leading-dashes', DEFAULTS.scc.stripLeadingDashes);

    prefs.qc = {
      // Derived from SCC export policy (single source of truth)
      gate: (exportPolicy !== 'warn'),
      maxCps: _getNumOpt(storage, 'scc-qc-max-cps'),
      maxWpm: _getNumOpt(storage, 'scc-qc-max-wpm'),
      minDurationSec: _getNumOpt(storage, 'scc-qc-min-duration'),
      minGapSec: _getNumOpt(storage, 'scc-qc-min-gap'),
      maxLateEocSec: _getNumOpt(storage, 'scc-qc-max-late-eoc'),
      maxLateEocCount: (() => {
        const v = parseInt(_getStr(storage, 'scc-qc-max-late-eoc-count', ''), 10);
        return Number.isFinite(v) ? v : undefined;
      })()
    };

    return prefs;
  }

  function readMccPrefs(storage) {
    migrateLegacyPrefs(storage);

    const prefs = {};

    const include608 = _getBool(storage, 'mcc-include-608', DEFAULTS.mcc.include608Compatibility);
    prefs.include608Compatibility = include608;

    prefs.telestreamCompression = _getBool(storage, 'mcc-telestream-compress', DEFAULTS.mcc.telestreamCompression);

    const embedTc = _getBool(storage, 'mcc-embed-cdp-timecode', DEFAULTS.mcc.includeCdpTimecode);
    // Backend supports both names; keep them in sync.
    prefs.includeCdpTimecode = embedTc;
    prefs.embedCdpTimecode = embedTc;

    prefs.includeCcsSvcInfo = _getBool(storage, 'mcc-include-ccsvc-info', DEFAULTS.mcc.includeCcsSvcInfo);

    // MCC authoring model: always True 708 (broadcast is the only final truth).
    prefs.authoringModel = 'true708';
    prefs.alignment = (() => {
      const v = String(_getStr(storage, 'mcc-alignment', DEFAULTS.mcc.alignment)).trim().toLowerCase();
      return (v === 'left' || v === 'center' || v === 'right') ? v : DEFAULTS.mcc.alignment;
    })();

    prefs.pingPongWindows = _getBool(storage, 'mcc-pingpong-windows', DEFAULTS.mcc.pingPongWindows);

    prefs.maxCharsPerLine = (() => {
      const raw = parseInt(_getStr(storage, 'mcc-max-chars', ''), 10);
      const n = Number.isFinite(raw) ? raw : DEFAULTS.mcc.maxCharsPerLine;
      return Math.max(1, Math.min(42, n));
    })();

    prefs.maxLinesPerBlock = (() => {
      const raw = parseInt(_getStr(storage, 'mcc-max-lines', ''), 10);
      const n = Number.isFinite(raw) ? raw : DEFAULTS.mcc.maxLinesPerBlock;
      // Lead AE policy: never allow more than 3 lines per subtitle block.
      return Math.max(1, Math.min(3, n));
    })();

    prefs.maxDurationSeconds = (() => {
      const v = _getNum(storage, 'mcc-max-duration', DEFAULTS.mcc.maxDurationSeconds);
      return Number.isFinite(v) ? Math.max(0.1, v) : DEFAULTS.mcc.maxDurationSeconds;
    })();

    prefs.serviceNumber = (() => {
      const raw = parseInt(_getStr(storage, 'mcc-service-number', String(DEFAULTS.mcc.serviceNumber)), 10);
      return Number.isFinite(raw) ? Math.max(1, Math.min(63, raw)) : DEFAULTS.mcc.serviceNumber;
    })();

    const lang = String(_getStr(storage, 'mcc-language', '')).trim();
    if (lang) prefs.language = lang;

    const tcStart = String(_getStr(storage, 'mcc-tc-start', '')).trim();
    if (tcStart) {
      prefs.startTc = tcStart;
      prefs.startTC = tcStart;
    }

    const tcOffset = String(_getStr(storage, 'mcc-timecode-offset', '')).trim();
    if (tcOffset) prefs.timecodeOffset = tcOffset;

    prefs.timecodeOffsetPolicy = (() => {
      const v = String(_getStr(storage, 'mcc-timecode-offset-policy', DEFAULTS.mcc.timecodeOffsetPolicy)).trim().toLowerCase();
      return (v === 'error') ? 'error' : 'clamp';
    })();

    // 708 window placement
    prefs.mcc708Window = (() => {
      const rel = _getBool(storage, 'mcc-window-rel', DEFAULTS.mcc.mcc708Window.rel);
      const anchorId = _getInt(storage, 'mcc-window-anchor-id', DEFAULTS.mcc.mcc708Window.anchorId, 0, 8);

      const anchorVRaw = parseInt(_getStr(storage, 'mcc-window-anchor-v', rel ? String(DEFAULTS.mcc.mcc708Window.anchorV) : '67'), 10);
      const anchorHRaw = parseInt(_getStr(storage, 'mcc-window-anchor-h', rel ? String(DEFAULTS.mcc.mcc708Window.anchorH) : '105'), 10);

      return normalizeMcc708WindowPlacement({
        rel,
        anchorId,
        anchorV: Number.isFinite(anchorVRaw) ? anchorVRaw : (rel ? DEFAULTS.mcc.mcc708Window.anchorV : 67),
        anchorH: Number.isFinite(anchorHRaw) ? anchorHRaw : (rel ? DEFAULTS.mcc.mcc708Window.anchorH : 105)
      });
    })();

    prefs.padEven = _getBool(storage, 'mcc-pad-even', DEFAULTS.mcc.padEven);
    // Default false unless explicitly enabled
    prefs.repeatControlCodes = _getStr(storage, 'mcc-repeat-control', 'false') !== 'false';
    // Default true unless explicitly disabled
    prefs.repeatPreambleCodes = _getStr(storage, 'mcc-repeat-preamble', '') !== 'false';

    prefs.strictCharacterEncoding = _getBool(storage, 'mcc-strict-encoding', DEFAULTS.mcc.strictCharacterEncoding);

    prefs.safeMargins = (() => {
      const lRaw = parseInt(_getStr(storage, 'mcc-safe-left', String(DEFAULTS.mcc.safeMargins.left)), 10);
      const rRaw = parseInt(_getStr(storage, 'mcc-safe-right', String(DEFAULTS.mcc.safeMargins.right)), 10);
      const left = Number.isFinite(lRaw) ? Math.max(0, Math.min(15, lRaw)) : DEFAULTS.mcc.safeMargins.left;
      const right = Number.isFinite(rRaw) ? Math.max(0, Math.min(15, rRaw)) : DEFAULTS.mcc.safeMargins.right;
      return { left, right };
    })();

    prefs.overflowPolicy = (() => {
      const v = String(_getStr(storage, 'mcc-overflow-policy', '')).trim().toLowerCase();
      if (v === 'error' || v === 'truncate') return v;
      return '';
    })();

    prefs.shaping = {
      enabled: _getBool(storage, 'mcc-shape-enable', DEFAULTS.mcc.shaping.enabled),
      mode: String(_getStr(storage, 'mcc-shape-mode', DEFAULTS.mcc.shaping.mode)).trim() || DEFAULTS.mcc.shaping.mode,
      microCueSec: _getNum(storage, 'mcc-shape-micro-dur', DEFAULTS.mcc.shaping.microCueSec),
      microGapSec: _getNum(storage, 'mcc-shape-micro-gap', DEFAULTS.mcc.shaping.microGapSec),
      maxShiftSec: _getNum(storage, 'mcc-shape-max-shift', DEFAULTS.mcc.shaping.maxShiftSec)
    };
    let exportPolicy = normalizeExportPolicy(_getStr(storage, 'mcc-export-policy', DEFAULTS.mcc.exportPolicy), DEFAULTS.mcc.exportPolicy);
    // MCC UI is 2-state (Draft/Delivery). Collapse any legacy "gate_block" into Delivery.
    if (exportPolicy === 'gate_block') exportPolicy = 'gate_write';
    prefs.exportPolicy = exportPolicy;
    _setStr(storage, 'mcc-export-policy', exportPolicy);

    prefs.qc = {
      gate: (exportPolicy !== 'warn'),
      maxCps: _getNumOpt(storage, 'mcc-qc-max-cps'),
      maxWpm: _getNumOpt(storage, 'mcc-qc-max-wpm'),
      minDurationSec: _getNumOpt(storage, 'mcc-qc-min-duration'),
      minGapSec: _getNumOpt(storage, 'mcc-qc-min-gap')
    };

    return prefs;
  }

  function readSrtPrefs(storage) {
    const prefs = {};
    prefs.preventOverlaps = _getBool(storage, 'srt-prevent-overlaps', true);
    prefs.allowTimeExtension = _getBool(storage, 'srt-allow-extension', true);
    prefs.maxEndExtensionSeconds = _getNum(storage, 'srt-max-end-extension', 1.5);
    prefs.maxCharsPerLine = _getInt(storage, 'srt-max-chars', 42, 1, 100);
    prefs.maxLinesPerBlock = _getInt(storage, 'srt-max-lines', 2, 1, 10);
    prefs.maxDurationSeconds = _getNum(storage, 'srt-max-duration', 6.0);
    prefs.utf8Bom = _getBool(storage, 'srt-utf8-bom', false);
    prefs.lineEnding = String(_getStr(storage, 'srt-line-ending', 'lf')).trim() || 'lf';
    prefs.qc = {
      maxCps: _getNum(storage, 'srt-qc-max-cps', 20),
      minDurationSeconds: _getNum(storage, 'srt-qc-min-duration', 1.0),
      minSplitDurationSeconds: _getNum(storage, 'srt-qc-min-split-duration', 0.5)
    };
    return prefs;
  }

  function readVttPrefs(storage) {
    const prefs = {};
    prefs.includeStyleMetadata = _getBool(storage, 'vtt-include-style', false);
    prefs.preventOverlaps = _getBool(storage, 'vtt-prevent-overlaps', false);
    prefs.allowTimeExtension = _getBool(storage, 'vtt-allow-extension', true);
    prefs.maxEndExtensionSeconds = _getNum(storage, 'vtt-max-end-extension', 1.5);
    prefs.maxCharsPerLine = _getInt(storage, 'vtt-max-chars', 42, 1, 100);
    prefs.maxLinesPerBlock = _getInt(storage, 'vtt-max-lines', 2, 1, 10);
    prefs.maxDurationSeconds = _getNum(storage, 'vtt-max-duration', 6.0);
    prefs.qc = {
      maxCps: _getNum(storage, 'vtt-qc-max-cps', DEFAULTS.vtt.qc.maxCps),
      minDurationSeconds: _getNum(storage, 'vtt-qc-min-duration', DEFAULTS.vtt.qc.minDurationSeconds),
      minSplitDurationSeconds: _getNum(storage, 'vtt-qc-min-split-duration', DEFAULTS.vtt.qc.minSplitDurationSeconds)
    };
    return prefs;
  }

  function readAll(storage) {
    return {
      scc: readSccPrefs(storage),
      mcc: readMccPrefs(storage),
      srt: readSrtPrefs(storage),
      vtt: readVttPrefs(storage)
    };
  }

  // ─────────────────────────────────────────────────────────────
  // Builders (used by later phases; kept pure and override-friendly)
  // ─────────────────────────────────────────────────────────────
  function buildSccOptions(prefs, overrides = {}) {
    const p = (prefs && typeof prefs === 'object') ? prefs : {};
    const safeMargins = { ...(p.safeMargins || {}), ...(overrides.safeMargins || {}) };
    const shaping = { ...(p.shaping || {}), ...(overrides.shaping || {}) };
    const qc = { ...(p.qc || {}), ...(overrides.qc || {}) };
    const exportPolicy = normalizeExportPolicy(overrides.exportPolicy ?? p.exportPolicy, DEFAULTS.scc.exportPolicy);

    // Single source of truth: exportPolicy controls whether QC is gated.
    // Keep qc.gate consistent so UI + export paths don't drift.
    qc.gate = (exportPolicy !== 'warn');

    return {
      ...p,
      ...overrides,
      exportPolicy,
      draft: (exportPolicy !== 'gate_block'),
      safeMargins,
      shaping,
      qc
    };
  }

  function buildMccOptions(prefs, overrides = {}) {
    const p = (prefs && typeof prefs === 'object') ? prefs : {};
    const safeMargins = { ...(p.safeMargins || {}), ...(overrides.safeMargins || {}) };
    const qc = { ...(p.qc || {}), ...(overrides.qc || {}) };
    const shaping = { ...(p.shaping || {}), ...(overrides.shaping || {}) };
    let exportPolicy = normalizeExportPolicy(overrides.exportPolicy ?? p.exportPolicy, DEFAULTS.mcc.exportPolicy);
    // MCC UI is 2-state (Draft/Delivery). Collapse any legacy "gate_block" into Delivery.
    if (exportPolicy === 'gate_block') exportPolicy = 'gate_write';

    // Single source of truth: exportPolicy controls whether QC is gated.
    // Keep qc.gate consistent so UI + export paths don't drift.
    qc.gate = (exportPolicy !== 'warn');

    const merged708 = normalizeMcc708WindowPlacement({
      ...(p.mcc708Window || {}),
      ...(overrides.mcc708Window || {})
    });

    // Canonicalize common synonyms so downstream export paths don't drift.
    const coerceBool = (v) => {
      if (typeof v === 'boolean') return v;
      if (typeof v === 'string') {
        const s = v.trim().toLowerCase();
        if (s === 'true') return true;
        if (s === 'false') return false;
      }
      return undefined;
    };

    // CDP timecode: backend supports both names; keep them in sync.
    const tcOverride = coerceBool(overrides.includeCdpTimecode ?? overrides.embedCdpTimecode ?? overrides.cdpTimecode);
    const tcPref = coerceBool(p.includeCdpTimecode ?? p.embedCdpTimecode ?? p.cdpTimecode);
    const includeCdpTimecode = (tcOverride !== undefined)
      ? tcOverride
      : ((tcPref !== undefined) ? tcPref : DEFAULTS.mcc.includeCdpTimecode);

    // Start TC: keep both spellings in sync for round-trip workflows.
    const startTcRaw = (overrides.startTC ?? overrides.startTc ?? p.startTC ?? p.startTc);
    const startTc = (typeof startTcRaw === 'string' && startTcRaw.trim()) ? startTcRaw.trim() : startTcRaw;
    const hasStartTc = (typeof startTc === 'string' && startTc.trim());

    const out = {
      ...p,
      ...overrides,
      authoringModel: 'true708',
      exportPolicy,
      safeMargins,
      qc,
      shaping,
      mcc708Window: merged708,
      includeCdpTimecode,
      embedCdpTimecode: includeCdpTimecode
    };

    // UI removed MCC delivery profile + compatibility mode presets.
    // Ensure no hidden preset can override explicit checkboxes.
    try { delete out.compatibilityMode; } catch {}
    try { delete out.compatMode; } catch {}
    try { delete out.deliveryProfile; } catch {}
    try { delete out.profile; } catch {}



    if (hasStartTc) {
      out.startTc = String(startTc).trim();
      out.startTC = String(startTc).trim();
    }

    return out;
  }

  function buildVttOptions(prefs, overrides = {}) {
    const p = (prefs && typeof prefs === 'object') ? prefs : {};
    const qc = { ...(p.qc || {}), ...(overrides.qc || {}) };
    return { ...p, ...overrides, qc };
  }

  // Helper used by the Subtitle Editor: merge global prefs into a doc, doc wins.
  function mergeDocOptionsForExport(doc, prefsAll) {
    const d = (doc && typeof doc === 'object') ? doc : {};
    const all = (prefsAll && typeof prefsAll === 'object') ? prefsAll : readAll();

    const out = { ...d };

    // SCC
    try {
      const p = all.scc || {};
      const existing = (d.sccOptions && typeof d.sccOptions === 'object') ? d.sccOptions : {};
      out.sccOptions = buildSccOptions(p, existing);
    } catch {}

    // MCC
    try {
      const p = all.mcc || {};
      const existing = (d.mccOptions && typeof d.mccOptions === 'object') ? d.mccOptions : {};
      out.mccOptions = buildMccOptions(p, existing);
    } catch {}

    return out;
  }

  return {
    DEFAULTS,
    // storage sync (Phase 3)
    STORAGE_KEYS,
    getStorageKeys,
    snapshotStorage,
    applyStorageSnapshot,
    // utils
    normalizeExportPolicy,
    syncSccExportPolicy,
    normalizeMcc708WindowPlacement,
    // migration
    migrateLegacyPrefs,
    migrateMccWindowAnchors,
    // readers
    readSccPrefs,
    readMccPrefs,
    readSrtPrefs,
    readVttPrefs,
    readAll,
    // builders
    buildSccOptions,
    buildMccOptions,
    buildVttOptions,
    mergeDocOptionsForExport,
    // (internal helpers exposed for tests/debugging)
    _getStr,
    _getBool,
    _getNumOpt,
    _setStr,
    _remove
  };
});
