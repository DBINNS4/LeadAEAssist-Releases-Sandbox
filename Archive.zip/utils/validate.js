const { generateChecksum } = require('./hash');
const fs = require('fs');

function validateTranscodeConfig(config) {
  const errors = [];

  if (!config.outputFormat) errors.push('❌ Missing output format.');
  if (!config.container) errors.push('❌ Missing container.');
  if (!config.outputFolder || !fs.existsSync(config.outputFolder)) errors.push('❌ Invalid output folder.');
  if (!config.inputPath || !fs.existsSync(config.inputPath)) errors.push('❌ Input file not found.');

  return errors;
}

async function isDuplicate(src, dest, method = 'sha256') {
  if (!fs.existsSync(dest)) return false;

  const [srcHash, destHash] = await Promise.all([
    generateChecksum(src, method),
    generateChecksum(dest, method)
  ]);

  return srcHash === destHash;
}

function suggestEncoder(format, log = []) {
  const f = String(format || '').toLowerCase();

  if (f.includes('prores')) return 'prores_ks';
  if (f.includes('h.265') || f.includes('h265') || f.includes('hevc')) return 'libx265';
  if (f.includes('h.264') || f.includes('h264')) return 'libx264';
  if (f.includes('av1')) return 'libaom-av1';
  if (f.includes('vp9')) return 'libvpx-vp9';
  if (f.includes('ffv1')) return 'ffv1';
  if (f.includes('mjpeg') || f.includes('jpeg') || f.includes('jpg')) return 'mjpeg';
  if (f.includes('png')) return 'png';
  if (f.includes('tiff') || f.includes('tif')) return 'tiff';
  if (f.includes('exr')) return 'exr';

  log.push(`⚠️ Unknown format "${format}", defaulting to libx264.`);
  return 'libx264';
}

module.exports = {
  validateTranscodeConfig,
  isDuplicate,
  suggestEncoder
};
