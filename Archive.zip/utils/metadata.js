const { execFileSync } = require('child_process');
const { getBinaryPaths, parseAvgFrameRate } = require('./ffmpegBridge');

function getSourceMetadata(filePath) {
  const { ffprobePath } = getBinaryPaths();

  try {
    const result = execFileSync(
      ffprobePath,
      [
        '-v', 'error',
        // Match Source must use the same full-stream probe shape as the source
        // grid. Reduced -show_entries queries are brittle here because MOV/MXF
        // timecode frequently lives on tmcd/data streams, and ffprobe only emits
        // tag objects reliably when the corresponding *_tags sections are
        // requested (or when the full stream/format sections are shown).
        '-show_format',
        '-show_streams',
        '-of', 'json',
        filePath
      ],
      {
        encoding: 'utf-8',
        maxBuffer: 20 * 1024 * 1024,
        // execFileSync writes child stderr straight to the parent stderr by
        // default. DNxHD/FFprobe can emit non-fatal decoder complaints while
        // still returning usable JSON, which makes Match Source look broken in
        // Terminal even when metadata parsing succeeds. Pipe stderr so those
        // messages stay contained unless the probe actually throws.
        stdio: ['ignore', 'pipe', 'pipe']
      }
    );
    const parsed = JSON.parse(result);
    const streams = Array.isArray(parsed?.streams) ? parsed.streams : [];
    const stream = streams.find(s => s?.codec_type === 'video');
    if (!stream) return null;
    const {
      index,
      codec_type,
      width,
      height,
      avg_frame_rate,
      r_frame_rate,
      field_order,
      pix_fmt
    } = stream;
    return {
      index,
      codec_type,
      width,
      height,
      avg_frame_rate,
      r_frame_rate,
      field_order,
      pix_fmt,
      videoStream: stream,
      // Keep the Match Source metadata shape aligned with the raw ffprobe JSON
      // used by the source grid. Do NOT lift stream.tags/timecode to the root:
      // if the video stream carries a colon-delimited label while a tmcd/data
      // stream carries the authoritative semicolon-delimited tag, flattening
      // the video stream upward makes Match Source incorrectly read the file as
      // NDF.
      format: parsed?.format || null,
      streams
    };
  } catch (err) {
    console.error('\u274C Error parsing FFprobe metadata:', err);
    return null;
  }
}

function validateInputAgainstCodex(metadata, codexEntry) {
  if (!metadata || !codexEntry) return true;
  const probe = (metadata.videoStream && typeof metadata.videoStream === 'object')
    ? metadata.videoStream
    : (Array.isArray(metadata.streams)
      ? (metadata.streams.find(stream => stream?.codec_type === 'video') || metadata)
      : metadata);
  const { width, height, pix_fmt, r_frame_rate, avg_frame_rate } = probe;
  const rules = codexEntry.inputRequirements;
  if (!rules) return true;

  const fps = parseAvgFrameRate(r_frame_rate) ?? parseAvgFrameRate(avg_frame_rate) ?? 0;

  const resolutionOK = !rules.allowedResolutions ||
    rules.allowedResolutions.some(([w, h]) => w === width && h === height);
  const pixelOK = !rules.requiredPixelFormat || rules.requiredPixelFormat === pix_fmt;
  const frameRateOK = (!rules.minFrameRate || fps >= rules.minFrameRate) &&
    (!rules.maxFrameRate || fps <= rules.maxFrameRate);

  return resolutionOK && pixelOK && frameRateOK;
}

module.exports = { getSourceMetadata, validateInputAgainstCodex };
