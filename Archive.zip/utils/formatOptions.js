// utils/formatOptions.js
// Format-scope logic for Transcribe output mini-panels.
// (Moved from inline script to satisfy a strict CSP.)

(() => {
  function getSelectedFormat() {
    const hidden = document.getElementById('transcribe-output-formats');
    if (!hidden) return '';
    return String(hidden.value || '').trim();
  }

  function show(el, on) {
    if (!el) return;
    el.classList.toggle('hidden', !on);
  }

  function updateFormatPanels() {
    const format = getSelectedFormat().replace(/^\./, '');
    const txtSelected = format === 'txt' || format === 'plain_text';
    const scriptedSelected = format === 'script';
    const sccSelected = format === 'scc';
    const mccSelected = format === 'mcc';

    // Show/hide the TXT-specific mini-panel
    show(document.getElementById('fmt-txt'), txtSelected);

    // Show/hide the VTT-specific mini-panel
    const vttSelected = format === 'vtt';
    show(document.getElementById('fmt-vtt'), vttSelected);

    // Show/hide the SRT-specific mini-panel
    const srtSelected = format === 'srt';
    show(document.getElementById('fmt-srt'), srtSelected);

    // QC & Delivery is intentionally always visible so users can set defaults
    // (for Transcribe exports and Subtitle Editor exports) without selecting
    // an output format first.

    // Show/hide the SCC-specific mini-panel
    show(document.getElementById('fmt-scc'), sccSelected);
    show(document.getElementById('fmt-mcc'), mccSelected);
    // Show/hide the Scripted-specific mini-panel
    show(document.getElementById('fmt-script'), scriptedSelected);
  }

  function wire() {
    const hidden = document.getElementById('transcribe-output-formats');
    if (!hidden) return;
    ['change', 'input', 'dropdown:change'].forEach(ev => hidden.addEventListener(ev, updateFormatPanels));
    updateFormatPanels();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', wire, { once: true });
  } else {
    wire();
  }
})();
