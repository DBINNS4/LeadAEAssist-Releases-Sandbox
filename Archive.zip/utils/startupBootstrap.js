function buildStartupHealth() {
  return {
    queueReady: false,
    ingestReady: false,
    transcodeReady: false,
    transcribeReady: false,
    loggingReady: false,
    optionalFailures: [],
    criticalFailures: []
  };
}

function addFailure(bucket, error, key) {
  const message = error?.message || String(error);
  bucket.push({ key, message });
}

async function loadStartupDependencies({ requireFn, importFn, cloneCore }) {
  const health = buildStartupHealth();
  const deps = {};

  const criticalLoaders = [
    {
      key: 'fileUtils',
      run: () => {
        const { waitForStableFile, getAllFilesRecursively } = requireFn('./modules/fileUtils');
        deps.waitForStableFile = waitForStableFile;
        deps.getAllFilesRecursively = getAllFilesRecursively;
      }
    },
    {
      key: 'ingest',
      run: () => {
        const { runIngest, cancelIngest, validateIngestConfig } = requireFn('./modules/ingest');
        deps.runIngest = runIngest;
        deps.cancelIngest = cancelIngest;
        deps.validateIngestConfig = validateIngestConfig;
        health.ingestReady = true;
      }
    },
    {
      key: 'transcode',
      run: () => {
        const { runTranscode, cancelTranscode } = requireFn('./modules/transcode');
        deps.runTranscode = runTranscode;
        deps.cancelTranscode = cancelTranscode;
        health.transcodeReady = true;
      }
    },
    {
      key: 'transcribe',
      run: () => {
        const { runTranscribe, cancelTranscribe } = requireFn('./modules/transcribe');
        deps.runTranscribe = runTranscribe;
        deps.cancelTranscribe = cancelTranscribe;
        health.transcribeReady = true;
      }
    },
    {
      key: 'logging',
      run: () => {
        const { archivePanelSessionLog } = requireFn('./modules/logUtils');
        deps.archivePanelSessionLog = archivePanelSessionLog;
        health.loggingReady = true;
      }
    },
    {
      key: 'queue',
      run: async () => {
        const { default: PQueue } = await importFn('p-queue');
        deps.PQueue = PQueue;
        health.queueReady = true;
      }
    },
    {
      key: 'clone',
      run: () => {
        const { cancelClone } = cloneCore;
        deps.cancelClone = cancelClone;
      }
    }
  ];

  const optionalLoaders = [
    {
      key: 'gpuEncoder',
      run: () => {
        const { detectBestGPUEncoder } = requireFn('./utils/gpuEncoder');
        deps.detectBestGPUEncoder = detectBestGPUEncoder;
      }
    },
    {
      key: 'chokidar',
      run: () => {
        deps.chokidar = requireFn('chokidar');
      }
    },
    {
      key: 'adobeUtilities',
      run: () => {
        const { runAdobeUtilities, cancelAdobeUtilities, validateAdobeConfig } = requireFn('./modules/adobe-utilities');
        deps.runAdobeUtilities = runAdobeUtilities;
        deps.cancelAdobeUtilities = cancelAdobeUtilities;
        deps.validateAdobeConfig = validateAdobeConfig;
      }
    }
  ];

  for (const loader of criticalLoaders) {
    try {
      await loader.run();
    } catch (err) {
      addFailure(health.criticalFailures, err, loader.key);
    }
  }

  for (const loader of optionalLoaders) {
    try {
      await loader.run();
    } catch (err) {
      addFailure(health.optionalFailures, err, loader.key);
    }
  }

  health.ok = health.criticalFailures.length === 0;
  return { health, deps };
}

module.exports = {
  buildStartupHealth,
  loadStartupDependencies
};
