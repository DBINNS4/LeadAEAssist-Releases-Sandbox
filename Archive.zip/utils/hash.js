const fs = require('fs');
const crypto = require('crypto');

async function generateChecksum(file, method = 'sha256') {
  return new Promise((resolve, reject) => {
    try {
      const hash = crypto.createHash(method);
      const stream = fs.createReadStream(file);
      stream.on('data', (chunk) => hash.update(chunk));
      stream.on('end', () => resolve(hash.digest('hex')));
      stream.on('error', reject);
    } catch (err) {
      reject(err);
    }
  });
}

module.exports = { generateChecksum };
