global.TextEncoder = require('util').TextEncoder;
global.TextDecoder = require('util').TextDecoder;

global.ipc = {
  on: jest.fn(),
  send: jest.fn(),
  invoke: jest.fn(),
};

// Default behavior for new validation IPCs
global.ipc.invoke.mockImplementation(async (channel, arg) => {
  if (channel === 'path-exists') return true;          // pretend everything exists by default
  if (channel === 'normalize-path') return String(arg ?? '').trim();
  if (channel === 'log-viewer:read-log-files') return window.electron.readLogFiles(arg);
  if (channel === 'app:get-version') return '0.0.0-test';
  if (channel === 'secure-store:has-ai-api-key') return false;
  return undefined;
});

global.watchConfigs = {};

global.window = global.window || {};
global.window.electron = {
  resolvePath: (...parts) => `/mocked/path/${parts.join('/')}`,
  readTextFile: () => '{}',
  joinPath: (...parts) => parts.join('/'),
  writeTextFile: jest.fn(),
  mkdir: jest.fn(),
  readdir: jest.fn(() => []),
  basename: (p) => p.split('/').pop(),
  fileExists: () => true,
  readLogFiles: jest.fn(() => Promise.resolve([
    { name: 'log1.txt', content: 'Old log entry\nnew\n' }
  ])),
  secrets: {
    hasAiApiKey: jest.fn(async () => false),
    setAiApiKey: jest.fn(async () => ({ ok: true })),
    deleteAiApiKey: jest.fn(async () => ({ ok: true })),
  },
  isMediaComposerRunning: jest.fn(() => false),
  // appDir removed from preload as part of security hardening
};

global.window.watchUtils = require('./utils/watch-mode');

// Silence verbose logging during tests to avoid "Cannot log after tests" errors
jest.spyOn(console, 'log').mockImplementation(() => {});

// Stub styled dropdown helpers used by renderer modules
global.setupStyledDropdown = (id, options = []) => {
  const select = document.getElementById(id);
  if (!select) return;
  select.innerHTML = '<option value="" data-i18n="presetsPlaceholder"></option>';
  options.forEach(opt => {
    const option = document.createElement('option');
    option.value = opt.value;
    option.textContent = opt.label;
    select.appendChild(option);
  });
};
global.setupStyledDropdownMulti = jest.fn();
global.setDropdownValue = (id, value) => {
  const select = document.getElementById(id);
  if (select) select.value = value;
};

// Provide setImmediate for environments where it is missing (jsdom)
if (typeof setImmediate === 'undefined') {
  global.setImmediate = (fn, ...args) => setTimeout(fn, 0, ...args);
}
