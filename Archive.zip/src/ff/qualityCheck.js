// src/ff/qualityCheck.js
// Canonical, retime-aware, MD5-only (no null/framemd5), two-pass SSIM/PSNR checker.

const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

// ---- helpers ---------------------------------------------------------------

function escapeForFilter(p) {
  // Use forward slashes and quote with single-quotes in filter args.
  // Escape single quotes inside the path.
  return p.replace(/\\/g, '/').replace(/'/g, "\\'");
}

function makeTempDirNear(targetPath) {
  const baseDir = path.dirname(targetPath);
  try {
    fs.accessSync(baseDir, fs.constants.W_OK);
    return fs.mkdtempSync(path.join(baseDir, 'qa-'));
  } catch {}

  const userDataRoot = process.env.USER_DATA_PATH;
  if (userDataRoot) {
    const cacheDir = path.join(userDataRoot, 'cache');
    try {
      fs.mkdirSync(cacheDir, { recursive: true });
      return fs.mkdtempSync(path.join(cacheDir, 'qa-'));
    } catch {}
  }

  return fs.mkdtempSync(path.join(os.tmpdir(), 'qa-'));
}

function tmpFile(dir, prefix, ext) {
  return path.join(dir, `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`);
}

function parseRational(x) {
  if (!x) return NaN;
  if (/^\d+\/\d+$/.test(x)) {
    const [a,b] = x.split('/').map(Number);
    return b ? (a/b) : NaN;
  }
  const n = Number(x);
  return Number.isFinite(n) ? n : NaN;
}

function ffprobeStr(ffprobePath, file, key) {
  // Read a single value (nk/nw suppresses key names and wrappers).
  // e.g. key = stream=r_frame_rate
  return new Promise((resolve) => {
    const args = [
      '-v','error',
      '-select_streams','v:0',
      '-show_entries', key,
      '-of','default=nk=1:nw=1',
      file
    ];
    const p = spawn(ffprobePath, args, { stdio: ['ignore','pipe','pipe'] });
    let out = '';
    p.stdout.on('data', d => out += d.toString());
    p.on('exit', () => resolve(out.trim()));
  });
}

async function ffprobeNum(ffprobePath, file, key) {
  const s = await ffprobeStr(ffprobePath, file, key);
  const val = parseRational(s);
  return Number.isFinite(val) ? val : NaN;
}

function runFFmpeg(ffmpegPath, args, { timeoutMs = 180000 } = {}) {
  return new Promise((resolve, reject) => {
    const p = spawn(ffmpegPath, args, { stdio: ['ignore','ignore','pipe'] });
    let stderr = '';
    const to = setTimeout(() => {
      try { p.kill('SIGKILL'); } catch {}
      reject(new Error('ffmpeg timeout'));
    }, timeoutMs);

    p.stderr.on('data', d => { stderr += d.toString(); });

    p.on('exit', (code) => {
      clearTimeout(to);
      if (code === 0) resolve();
      else reject(new Error(stderr.trim() || `ffmpeg exited ${code}`));
    });
  });
}

function parseSsimLog(filePath) {
  // Look for the last "All:<val>"
  try {
    const txt = fs.readFileSync(filePath, 'utf8');
    let last = null;
    for (const line of txt.trim().split(/\r?\n/)) {
      const m = line.match(/\bAll:([0-9]*\.?[0-9]+)/);
      if (m) last = Number(m[1]);
    }
    return Number.isFinite(last) ? last : null;
  } catch {
    return null;
  }
}

function parsePsnrLog(filePath) {
  // Look for the last "psnr_avg: <val>"
  try {
    const txt = fs.readFileSync(filePath, 'utf8');
    let last = null;
    for (const line of txt.trim().split(/\r?\n/)) {
      const m = line.match(/\bpsnr_avg:\s*([0-9]*\.?[0-9]+)/i);
      if (m) last = Number(m[1]);
    }
    return Number.isFinite(last) ? last : null;
  } catch {
    return null;
  }
}

// ---- main -----------------------------------------------------------------

/**
 * Run SSIM/PSNR verification in two compliant passes.
 * - never uses null/framemd5
 * - sinks to -f md5 FILE
 * - optionally retimes BOTH sides to target fps (for 29.97 -> 23.976, etc)
 *
 * @param {Object} opts
 * @param {string} opts.ffmpegPath
 * @param {string} opts.ffprobePath
 * @param {string} opts.src       original
 * @param {string} opts.out       transcoded
 * @param {number} [opts.timeoutMs=180000]
 * @param {number} [opts.retimeFps] - if provided, we retime both to this fps; if absent, we’ll try output fps
 * @returns {Promise<{status:'ok'|'skipped'|'error', ssim?:number, psnr?:number, reason?:string}>}
 */
async function runSsimPsNrCheck(opts) {
  const {
    ffmpegPath, ffprobePath, src, out,
    timeoutMs = 180000,
    retimeFps
  } = opts || {};

  if (!ffmpegPath || !ffprobePath || !src || !out) {
    return { status: 'error', reason: { key: 'transcodeQualityReasonMissingRequiredParameters' } };
  }
  if (!fs.existsSync(src) || !fs.existsSync(out)) {
    return { status: 'error', reason: { key: 'transcodeQualityReasonInputOutputNotFound' } };
  }

  // Decide which fps to align to.
  let targetFps = Number(retimeFps);
  if (!Number.isFinite(targetFps)) {
    const outFps = await ffprobeNum(ffprobePath, out, 'stream=r_frame_rate');
    targetFps = Number.isFinite(outFps) ? outFps : NaN;
  }
  const doRetime = Number.isFinite(targetFps);

  let tempRoot;
  try {
    tempRoot = makeTempDirNear(out);

    const ssimLog = tmpFile(tempRoot, 'ssim', 'log');
    const psnrLog = tmpFile(tempRoot, 'psnr', 'log');
    const sinkSsim = tmpFile(tempRoot, 'sink_ssim', 'md5');
    const sinkPsnr = tmpFile(tempRoot, 'sink_psnr', 'md5');

    const even = 'scale=w=trunc(iw/2)*2:h=trunc(ih/2)*2';
    const fpsA = doRetime ? `,fps=${targetFps}` : '';
    const fpsB = doRetime ? `,fps=${targetFps}` : '';

    // --- pass 1: SSIM ---
    {
      const fc = [
        `[0:v]${even}${fpsA}[a]`,
        `[1:v]${even}${fpsB}[b]`,
        `[a][b]ssim=stats_file='${escapeForFilter(ssimLog)}'[v]`,
      ].join(';');

      const args = [
        '-nostdin', '-y', '-v', 'error',
        '-i', src, '-i', out,
        '-filter_complex', fc,
        '-map', '[v]',
        '-f', 'md5', sinkSsim
      ];
      await runFFmpeg(ffmpegPath, args, { timeoutMs });
    }

    // --- pass 2: PSNR ---
    {
      const fc = [
        `[0:v]${even}${fpsA}[a]`,
        `[1:v]${even}${fpsB}[b]`,
        `[a][b]psnr=stats_file='${escapeForFilter(psnrLog)}'[v]`,
      ].join(';');

      const args = [
        '-nostdin', '-y', '-v', 'error',
        '-i', src, '-i', out,
        '-filter_complex', fc,
        '-map', '[v]',
        '-f', 'md5', sinkPsnr
      ];
      await runFFmpeg(ffmpegPath, args, { timeoutMs });
    }

    const ssim = parseSsimLog(ssimLog);
    const psnr = parsePsnrLog(psnrLog);

    const haveAny = (typeof ssim === 'number' && Number.isFinite(ssim))
                 || (typeof psnr === 'number' && Number.isFinite(psnr));
    if (!haveAny) {
      return { status: 'error', reason: { key: 'transcodeQualityReasonNoMetricsProduced' } };
    }
    return { status: 'ok', ssim, psnr };
  } catch (err) {
    return { status: 'error', reason: { key: 'transcodeQualityReasonQcError', params: { message: err?.message || 'quality check failed' } } };
  } finally {
    if (tempRoot) {
      try { fs.rmSync(tempRoot, { recursive: true, force: true }); } catch {}
    }
  }
}

module.exports = { runSsimPsNrCheck };
