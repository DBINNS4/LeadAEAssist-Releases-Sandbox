// ipc/index.js
// Central IPC registry for Lead AE Assist.
// This file wires domain-specific handler registrars into Electron's ipcMain.

const registerCodexHandlers = require('./codex.handlers');
const registerFfmpegHandlers = require('./ffmpeg.handlers');
const registerTranscodeHandlers = require('./transcode.handlers');
const registerTranscribeHandlers = require('./transcribe.handlers');
const registerIngestHandlers = require('./ingest.handlers');
const registerSubtitleEditorHandlers = require('./subtitleEditor.handlers');
const registerLicenseHandlers = require('./license.handlers');
const registerBillingHandlers = require('./billing.handlers');
const registerQueueHandlers = require('./queue.handlers');
const registerMiscHandlers = require('./misc.handlers');
const registerBackupHandlers = require('./backup.handlers');
const registerBridgeHandlers = require('./bridge.handlers');
const registerPrefsHandlers = require('./prefs.handlers');
const registerFsAccessHandlers = require('./fsAccess.handlers');
const registerTelemetryHandlers = require('./telemetry.handlers');
const registerCepInstallerHandlers = require('./cepInstaller.handlers');
const registerAssetHandlers = require('./assets.handlers');

function registerIpcHandlers(ipcMain, context = {}) {
  // Order is not critical, but keep it stable for sanity.
  registerCodexHandlers(ipcMain, context);
  registerFfmpegHandlers(ipcMain, context);
  registerTranscodeHandlers(ipcMain, context);
  registerTranscribeHandlers(ipcMain, context);
  registerIngestHandlers(ipcMain, context);
  registerSubtitleEditorHandlers(ipcMain, context);
  registerLicenseHandlers(ipcMain, context);
  registerBillingHandlers(ipcMain, context);
  registerQueueHandlers(ipcMain, context);
  registerFsAccessHandlers(ipcMain, context);
  registerTelemetryHandlers(ipcMain, context);
  registerAssetHandlers(ipcMain, context);

  // CEP panel installer/repair (Premiere panel)
  if (typeof registerCepInstallerHandlers === 'function') {
    registerCepInstallerHandlers(ipcMain);
  }

  // Backup IPC handlers (standalone backup queue)
  registerBackupHandlers(ipcMain, context);
  registerMiscHandlers(ipcMain, context);
  registerPrefsHandlers(ipcMain, context);
  if (typeof registerBridgeHandlers === 'function') registerBridgeHandlers(ipcMain, context);
}

module.exports = {
  registerIpcHandlers,
};
