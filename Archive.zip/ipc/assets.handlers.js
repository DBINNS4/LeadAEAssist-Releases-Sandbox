'use strict';

const { app } = require('electron');

const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const runtimeAssetRequestService = require('../services/runtimeAssetRequestService');

const activeOperationsByAssetId = new Map();
const activeOperationsByRequestId = new Map();
const latestSnapshotsByAssetId = new Map();
const senderSubscriptions = new Map();
const senderCleanupBound = new Set();
let requestSequence = 0;

function isAbortError(error) {
  const name = String(error?.name || '').trim().toLowerCase();
  const code = String(error?.code || '').trim().toLowerCase();
  return name === 'aborterror' || code === 'abort_err' || code === 'aborted';
}

function sanitizeError(error) {
  if (!error) return null;
  return {
    code: String(error.code || (isAbortError(error) ? 'ABORT_ERR' : 'ASSET_PREFETCH_FAILED')).trim(),
    message: String(error.message || error).trim() || 'Unknown runtime asset error'
  };
}

function nextRequestId(assetId) {
  requestSequence += 1;
  const safeAssetId = String(assetId || 'asset')
    .replace(/[^a-zA-Z0-9_.-]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'asset';
  return `asset-${requestSequence}-${safeAssetId}`;
}

function getSenderId(sender) {
  return Number.isFinite(Number(sender?.id)) ? Number(sender.id) : null;
}

function safeSend(sender, channel, payload) {
  if (!sender || typeof sender.send !== 'function') return false;
  try {
    if (typeof sender.isDestroyed === 'function' && sender.isDestroyed()) return false;
  } catch {
    return false;
  }

  try {
    sender.send(channel, payload);
    return true;
  } catch {
    return false;
  }
}

function addSenderSubscription(senderId, requestId) {
  if (senderId == null || !requestId) return;
  let set = senderSubscriptions.get(senderId);
  if (!set) {
    set = new Set();
    senderSubscriptions.set(senderId, set);
  }
  set.add(requestId);
}

function removeSenderSubscription(senderId, requestId) {
  if (senderId == null || !requestId) return;
  const set = senderSubscriptions.get(senderId);
  if (!set) return;
  set.delete(requestId);
  if (!set.size) senderSubscriptions.delete(senderId);
}

function bindSenderCleanup(sender) {
  const senderId = getSenderId(sender);
  if (senderId == null) return;
  if (senderCleanupBound.has(senderId)) return;
  if (!sender || typeof sender.once !== 'function') return;

  senderCleanupBound.add(senderId);
  sender.once('destroyed', () => {
    senderCleanupBound.delete(senderId);
    detachSenderFromAllOperations(senderId, { reason: 'sender-destroyed' });
  });
}

function buildSnapshot(entry, overrides = {}) {
  const baseProgress = entry.lastProgress
    ? {
        phase: entry.lastProgress.phase || null,
        status: entry.lastProgress.status || null,
        progress: Number.isFinite(Number(entry.lastProgress.progress))
          ? Number(entry.lastProgress.progress)
          : null,
        bytesReceived: Number.isFinite(Number(entry.lastProgress.bytesReceived))
          ? Number(entry.lastProgress.bytesReceived)
          : null,
        bytesTotal: Number.isFinite(Number(entry.lastProgress.bytesTotal))
          ? Number(entry.lastProgress.bytesTotal)
          : null,
        source: entry.lastProgress.source || null,
        mode: entry.lastProgress.mode || null,
        timestamp: entry.lastProgress.timestamp || null,
        url: entry.lastProgress.url || null
      }
    : null;

  const snapshot = {
    ok: true,
    requestId: entry.requestId || null,
    assetId: entry.assetId,
    kind: entry.kind || null,
    feature: entry.feature || null,
    language: entry.language || null,
    modelFile: entry.modelFile || null,
    platform: entry.platform || null,
    arch: entry.arch || null,
    state: entry.state,
    active: !!entry.active,
    installed: !!entry.installed,
    ready: !!entry.ready,
    path: entry.path || null,
    expectedPath: entry.expectedPath || null,
    executablePath: entry.executablePath || null,
    modelPath: entry.modelPath || null,
    source: entry.source || null,
    offline: !!entry.offline,
    descriptor: entry.descriptor || {},
    progress: baseProgress,
    error: entry.error || null,
    subscriberCount: entry.subscribers ? entry.subscribers.size : 0,
    updatedAt: Date.now()
  };

  return { ...snapshot, ...overrides };
}

function cacheSnapshot(entry, overrides = {}) {
  const snapshot = buildSnapshot(entry, overrides);
  latestSnapshotsByAssetId.set(entry.assetId, snapshot);
  return snapshot;
}

function emitSnapshot(entry, overrides = {}) {
  const snapshot = cacheSnapshot(entry, overrides);
  entry.lastSnapshot = snapshot;

  for (const subscriber of [...entry.subscribers.values()]) {
    safeSend(subscriber.sender, 'assets:progress', snapshot);
  }

  return snapshot;
}

function attachSenderToOperation(entry, sender, options = {}) {
  const senderId = getSenderId(sender);
  if (senderId == null) return;
  bindSenderCleanup(sender);
  entry.subscribers.set(senderId, {
    sender,
    senderId,
    attachedAt: Date.now()
  });
  addSenderSubscription(senderId, entry.requestId);

  if (options.replay && entry.lastSnapshot) {
    safeSend(sender, 'assets:progress', entry.lastSnapshot);
  }
}

function detachSenderFromOperation(entry, senderId, options = {}) {
  if (!entry || senderId == null) return { detached: false, aborted: false };
  if (!entry.subscribers.has(senderId)) return { detached: false, aborted: false };

  entry.subscribers.delete(senderId);
  removeSenderSubscription(senderId, entry.requestId);

  let aborted = false;
  if (!entry.subscribers.size && entry.active && !entry.controller.signal.aborted) {
    aborted = true;
    try { entry.controller.abort(); } catch {}
    entry.state = 'cancelling';
    emitSnapshot(entry, {
      state: 'cancelling',
      active: true,
      cancelled: true,
      reason: options.reason || 'cancelled'
    });
  }

  return { detached: true, aborted };
}

function detachSenderFromAllOperations(senderId, options = {}) {
  const requestIds = senderSubscriptions.get(senderId);
  if (!requestIds || !requestIds.size) return;

  for (const requestId of [...requestIds]) {
    const entry = activeOperationsByRequestId.get(requestId);
    if (!entry) {
      removeSenderSubscription(senderId, requestId);
      continue;
    }
    detachSenderFromOperation(entry, senderId, options);
  }
}

function makeIdleSnapshot(resolved, options = {}) {
  const installed = runtimeAssetRequestService.resolveInstalledRuntimeAssetSnapshot(resolved, options);
  const latest = latestSnapshotsByAssetId.get(resolved.assetId) || null;
  let state = installed.installed
    ? (installed.ready ? 'installed' : 'broken')
    : 'missing';
  let error = null;
  let requestId = null;
  let source = installed.installed ? 'installed' : null;
  let updatedAt = Date.now();

  if (!installed.installed && latest && !latest.active && (latest.state === 'error' || latest.state === 'cancelled')) {
    state = latest.state;
    error = latest.error || null;
    requestId = latest.requestId || null;
    updatedAt = latest.updatedAt || updatedAt;
    source = latest.source || source;
  }

  return {
    ok: true,
    requestId,
    assetId: resolved.assetId,
    kind: resolved.kind,
    feature: resolved.feature,
    language: resolved.language || null,
    modelFile: resolved.modelFile || null,
    platform: resolved.platform || null,
    arch: resolved.arch || null,
    state,
    active: false,
    installed: installed.installed,
    ready: installed.ready,
    path: installed.path,
    expectedPath: installed.expectedPath,
    executablePath: installed.executablePath,
    modelPath: installed.modelPath,
    source,
    offline: installed.offline,
    descriptor: installed.descriptor || {},
    progress: latest && !latest.active ? latest.progress || null : null,
    error,
    subscriberCount: 0,
    updatedAt
  };
}

function resolveActiveEntryForRequest(request = {}, options = {}) {
  const normalized = runtimeAssetRequestService.normalizeAssetRequest(request);
  if (normalized.requestId && activeOperationsByRequestId.has(normalized.requestId)) {
    return activeOperationsByRequestId.get(normalized.requestId);
  }

  if (normalized.assetId && activeOperationsByAssetId.has(normalized.assetId)) {
    return activeOperationsByAssetId.get(normalized.assetId);
  }

  let resolved;
  try {
    resolved = runtimeAssetRequestService.resolveRuntimeAssetRequest(normalized, options);
  } catch {
    return null;
  }

  return activeOperationsByAssetId.get(resolved.assetId) || null;
}

function createOperation(resolved, options = {}) {
  const installed = runtimeAssetRequestService.resolveInstalledRuntimeAssetSnapshot(resolved, options);
  const entry = {
    requestId: nextRequestId(resolved.assetId),
    assetId: resolved.assetId,
    kind: resolved.kind,
    feature: resolved.feature,
    language: resolved.language || null,
    modelFile: resolved.modelFile || null,
    platform: resolved.platform || null,
    arch: resolved.arch || null,
    descriptor: resolved.descriptorSummary || {},
    expectedPath: installed.expectedPath || null,
    controller: new AbortController(),
    subscribers: new Map(),
    active: true,
    installed: installed.installed,
    ready: installed.ready,
    state: 'running',
    path: installed.path || null,
    executablePath: installed.executablePath || null,
    modelPath: installed.modelPath || null,
    source: installed.installed ? 'installed' : null,
    offline: installed.offline,
    error: null,
    lastProgress: {
      phase: 'queue',
      status: 'start',
      timestamp: Date.now()
    },
    lastSnapshot: null,
    resolved,
    promise: null
  };

  return entry;
}

function startOperation(entry, options = {}) {
  activeOperationsByAssetId.set(entry.assetId, entry);
  activeOperationsByRequestId.set(entry.requestId, entry);
  cacheSnapshot(entry);

  entry.promise = (async () => {
    try {
      const result = await runtimeAssetRequestService.ensureResolvedRuntimeAsset(entry.resolved, {
        ...options,
        signal: entry.controller.signal,
        onProgress: (progress) => {
          entry.lastProgress = {
            ...progress,
            timestamp: Number.isFinite(Number(progress?.timestamp)) ? Number(progress.timestamp) : Date.now()
          };
          entry.state = 'running';
          entry.active = true;
          emitSnapshot(entry);
        }
      });

      entry.active = false;
      entry.error = null;
      entry.offline = typeof result?.offline === 'boolean' ? result.offline : entry.offline;
      entry.source = result?.source || entry.source || 'installed';
      entry.path = result?.assetRoot || result?.modelPath || result?.path || entry.path || entry.expectedPath || null;
      entry.executablePath = result?.executablePath || entry.executablePath || null;
      entry.modelPath = result?.modelPath || entry.modelPath || null;
      entry.installed = true;
      entry.ready = true;
      entry.state = 'installed';

      emitSnapshot(entry, {
        state: 'installed',
        active: false,
        installed: true,
        ready: true,
        path: entry.path,
        executablePath: entry.executablePath,
        modelPath: entry.modelPath,
        source: entry.source
      });

      return buildSnapshot(entry);
    } catch (error) {
      entry.active = false;
      entry.error = sanitizeError(error);
      entry.state = isAbortError(error) ? 'cancelled' : 'error';
      emitSnapshot(entry, {
        state: entry.state,
        active: false,
        error: entry.error
      });
      throw error;
    } finally {
      activeOperationsByAssetId.delete(entry.assetId);
      activeOperationsByRequestId.delete(entry.requestId);
      for (const senderId of [...entry.subscribers.keys()]) {
        removeSenderSubscription(senderId, entry.requestId);
      }
      entry.subscribers.clear();
    }
  })();
  entry.promise.catch(() => {});

  return entry;
}

function _failure(code, message, extra = {}) {
  return {
    ok: false,
    code,
    error: message,
    ...extra
  };
}

function registerAssetHandlers(ipcMain) {
  ipcMain.handle('assets:getStatus', async (event, request = {}) => {
    try {
      assertTrustedIpcSender(event, 'assets:getStatus');
    } catch (error) {
      return _failure('IPC_UNTRUSTED', error?.message || 'Runtime asset status request blocked');
    }

    try {
      const options = { isPackaged: !!app.isPackaged };
      const activeEntry = resolveActiveEntryForRequest(request, options);
      if (activeEntry) return buildSnapshot(activeEntry);

      const resolved = runtimeAssetRequestService.resolveRuntimeAssetRequest(request, options);
      return makeIdleSnapshot(resolved, options);
    } catch (error) {
      return _failure(String(error?.code || 'ASSET_STATUS_FAILED'), error?.message || String(error));
    }
  });

  ipcMain.handle('assets:prefetch', async (event, request = {}, requestOptions = {}) => {
    try {
      assertTrustedIpcSender(event, 'assets:prefetch');
    } catch (error) {
      return _failure('IPC_UNTRUSTED', error?.message || 'Runtime asset prefetch blocked');
    }

    try {
      const sender = event?.sender || null;
      const options = {
        isPackaged: !!app.isPackaged,
        ...(requestOptions && typeof requestOptions === 'object' ? requestOptions : {})
      };
      const resolved = runtimeAssetRequestService.resolveRuntimeAssetRequest(request, options);
      const installed = makeIdleSnapshot(resolved, options);
      if (installed.installed && installed.ready) {
        return {
          ...installed,
          started: false,
          joined: false,
          reused: true
        };
      }

      let entry = activeOperationsByAssetId.get(resolved.assetId) || null;
      if (entry) {
        attachSenderToOperation(entry, sender, { replay: true });
        return {
          ...buildSnapshot(entry),
          started: false,
          joined: true,
          reused: false
        };
      }

      entry = createOperation(resolved, options);
      attachSenderToOperation(entry, sender, { replay: false });
      startOperation(entry, options);

      return {
        ...buildSnapshot(entry),
        started: true,
        joined: false,
        reused: false
      };
    } catch (error) {
      return _failure(String(error?.code || 'ASSET_PREFETCH_FAILED'), error?.message || String(error));
    }
  });

  ipcMain.handle('assets:cancel', async (event, request = {}) => {
    try {
      assertTrustedIpcSender(event, 'assets:cancel');
    } catch (error) {
      return _failure('IPC_UNTRUSTED', error?.message || 'Runtime asset cancel blocked');
    }

    const senderId = getSenderId(event?.sender);
    const options = { isPackaged: !!app.isPackaged };
    let entry = resolveActiveEntryForRequest(request, options);

    if (!entry && typeof request === 'string' && activeOperationsByAssetId.has(request)) {
      entry = activeOperationsByAssetId.get(request);
    }

    if (!entry) {
      try {
        const resolved = runtimeAssetRequestService.resolveRuntimeAssetRequest(request, options);
        return {
          ...makeIdleSnapshot(resolved, options),
          cancelled: false,
          detached: false
        };
      } catch (error) {
        return _failure(String(error?.code || 'ASSET_CANCEL_FAILED'), error?.message || String(error));
      }
    }

    const { detached, aborted } = detachSenderFromOperation(entry, senderId, { reason: 'cancelled' });
    return {
      ...buildSnapshot(entry),
      cancelled: detached,
      detached,
      abortRequested: aborted
    };
  });
}

function _resetForTests() {
  activeOperationsByAssetId.clear();
  activeOperationsByRequestId.clear();
  latestSnapshotsByAssetId.clear();
  senderSubscriptions.clear();
  senderCleanupBound.clear();
  requestSequence = 0;
}

module.exports = registerAssetHandlers;
module.exports.__private = {
  resetForTests: _resetForTests,
  getActiveOperationCount: () => activeOperationsByAssetId.size,
  getLatestSnapshot: (assetId) => latestSnapshotsByAssetId.get(assetId) || null
};
