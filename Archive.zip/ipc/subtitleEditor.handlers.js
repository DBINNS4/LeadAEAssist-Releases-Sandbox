// ipc/subtitleEditor.handlers.js
// Subtitle editor IPC: open, export, export-scc, burnin, find-latest.

const path = require('path');
const { BrowserWindow, screen } = require('electron');
const { installExternalNavigationGuards } = require('../utils/externalNavigationGuards');
const licenseService = require('../services/licenseService');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const {
  assertApprovedPaths,
  extractAbsolutePathsFromObject
} = require('../utils/ipcPathGuards');
const {
  openSubtitleDocument,
  exportCorrectedSubtitles,
  exportSccFromEditor,
  exportMccFromEditor,
  previewMccFromEditor,
  burnInCorrectedSubtitles,
  findLatestSubtitleSource,
  getSccGlyphs
} = require('../modules/transcribe');

let subtitleEditorWin = null;
const preloadPath = path.join(__dirname, '../preload.js');

// Keep the last init payload around so the renderer can pull it reliably.
// This prevents a first-open race where the init event is emitted before the
// renderer has attached listeners.
let pendingInitPayload = null;

async function openSubtitleEditorWindow(payload = {}) {
  // Always update the pending payload first so a just-opened renderer can fetch it.
  pendingInitPayload = payload || {};

  if (subtitleEditorWin && !subtitleEditorWin.isDestroyed()) {
    subtitleEditorWin.focus();
    subtitleEditorWin.webContents.send('subtitleEditor:init', payload);
    return { ok: true };
  }
  const MIN_WIDTH = 900;
  const BASE_HEIGHT = 800;
  const { height: maxH } = screen.getPrimaryDisplay().workAreaSize;
  const openHeight = Math.min(maxH, Math.round(BASE_HEIGHT * 2 * 0.75));

  subtitleEditorWin = new BrowserWindow({
    width: MIN_WIDTH,
    height: openHeight,
    minWidth: MIN_WIDTH,
    minHeight: 600,
    show: false,
    title: 'Subtitle Editor',
    webPreferences: {
      preload: preloadPath,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webviewTag: false,
      nodeIntegrationInSubFrames: false,
      enableRemoteModule: false,
      webSecurity: true,
      nativeWindowOpen: true
    }
  });

  // Security: prevent remote pages from opening inside an Electron window that
  // has preload privileges. External URLs open in the user's default browser.
  installExternalNavigationGuards(subtitleEditorWin.webContents);

  // Hygiene: clear approved-roots state for this renderer when the window is torn down.
  try {
    const { resetApproved } = require('../utils/fsAccessControl');
    const senderId = subtitleEditorWin.webContents.id;
    subtitleEditorWin.webContents.on('destroyed', () => {
      try { resetApproved(senderId); } catch {}
    });
  } catch {
    // best-effort
  }
  subtitleEditorWin.on('closed', () => (subtitleEditorWin = null));

  subtitleEditorWin.once('ready-to-show', () => subtitleEditorWin.show());

  // Option B: the subtitle editor is a true window with its own HTML root.
  // (No shared app chrome, no #window-content, no overlay semantics.)
  // Load from the app's own directory (absolute path) so navigation guards can
  // safely restrict file:// navigations to the app bundle only.
  await subtitleEditorWin.loadFile(path.join(__dirname, '..', 'subtitle-editor.html'), {
    query: { win: 'subtitle-editor' }
  });
  if (!subtitleEditorWin.isVisible()) subtitleEditorWin.show();
  subtitleEditorWin.webContents.on('did-finish-load', () => {
    subtitleEditorWin?.webContents.send('subtitleEditor:init', payload || {});
  });
  return { ok: true };
}

function registerSubtitleEditorHandlers(ipcMain) {
  // IMPORTANT:
  // Do NOT register generic dialog channels (select-folder, open-file-dialog, save-file-dialog, select-files)
  // here. Those are shared across the app and are already registered in ipc/misc.handlers.js.
  // Registering them twice will crash Electron with:
  // "Attempted to register a second handler for 'select-folder'".

  ipcMain.handle('subtitle-editor:open', (_e, payload) => {
    assertTrustedIpcSender(_e, 'subtitle-editor:open');
    if (!licenseService.isFeatureEnabled('subtitle-editor')) {
      return { ok: false, error: 'License required for subtitle-editor' };
    }
    return openSubtitleEditorWindow(payload);
  });

  // Renderer bootstrap reliability: allow the subtitle-editor renderer to pull the
  // most recent init payload on demand.
  ipcMain.handle('subtitle-editor-get-pending-init', async (event) => {
    // Safe to expose to trusted app renderers only: payload can include source/media paths.
    assertTrustedIpcSender(event, 'subtitle-editor-get-pending-init');
    return pendingInitPayload || {};
  });

  ipcMain.handle('subtitle-editor-open', async (event, payload) => {
    assertTrustedIpcSender(event, 'subtitle-editor-open');
    try {
      if (!licenseService.isFeatureEnabled('subtitle-editor')) {
        return { error: 'License required for subtitle-editor' };
      }
      const senderId = event?.sender?.id;
      const knownPaths = [];
      if (payload?.sourcePath) knownPaths.push(payload.sourcePath);
      if (payload?.mediaPath) knownPaths.push(payload.mediaPath);
      const nested = extractAbsolutePathsFromObject(payload || {});
      assertApprovedPaths(senderId, [...knownPaths, ...nested]);
      return await openSubtitleDocument(payload || {});
    } catch (err) {
      return { error: err.message || String(err) };
    }
  });

  ipcMain.handle('subtitle-editor-export', async (event, payload) => {
    assertTrustedIpcSender(event, 'subtitle-editor-export');
    try {
      if (!licenseService.isFeatureEnabled('subtitle-editor')) {
        return { error: 'License required for subtitle-editor export' };
      }
      const senderId = event?.sender?.id;
      const knownPaths = [];
      const doc = payload?.doc;
      if (doc?.sourcePath) knownPaths.push(doc.sourcePath);
      if (doc?.mediaPath) knownPaths.push(doc.mediaPath);
      if (doc?.outputDir) knownPaths.push(doc.outputDir);
      const nested = extractAbsolutePathsFromObject(payload || {});
      assertApprovedPaths(senderId, [...knownPaths, ...nested]);
      return await exportCorrectedSubtitles(payload || {});
    } catch (err) {
      return { error: err.message || String(err) };
    }
  });

  ipcMain.handle('subtitle-editor-export-scc', async (event, payload) => {
    assertTrustedIpcSender(event, 'subtitle-editor-export-scc');
    try {
      if (!licenseService.isFeatureEnabled('subtitle-editor')) {
        return { error: 'License required for subtitle-editor export' };
      }
      const senderId = event?.sender?.id;
      const knownPaths = [];
      const doc = payload?.doc;
      if (doc?.sourcePath) knownPaths.push(doc.sourcePath);
      if (doc?.mediaPath) knownPaths.push(doc.mediaPath);
      if (doc?.outputDir) knownPaths.push(doc.outputDir);
      const nested = extractAbsolutePathsFromObject(payload || {});
      assertApprovedPaths(senderId, [...knownPaths, ...nested]);
      return await exportSccFromEditor(payload || {});
    } catch (err) {
      return { error: err.message || String(err) };
    }
  });

  ipcMain.handle('subtitle-editor-export-mcc', async (event, payload) => {
    assertTrustedIpcSender(event, 'subtitle-editor-export-mcc');
    try {
      if (!licenseService.isFeatureEnabled('subtitle-editor')) {
        return { error: 'License required for subtitle-editor export' };
      }
      const senderId = event?.sender?.id;
      const knownPaths = [];
      const doc = payload?.doc;
      if (doc?.sourcePath) knownPaths.push(doc.sourcePath);
      if (doc?.mediaPath) knownPaths.push(doc.mediaPath);
      if (doc?.outputDir) knownPaths.push(doc.outputDir);
      const nested = extractAbsolutePathsFromObject(payload || {});
      assertApprovedPaths(senderId, [...knownPaths, ...nested]);
      return await exportMccFromEditor(payload || {});
    } catch (err) {
      return { error: err.message || String(err) };
    }
  });

  // Milestone 5: Dual preview panes (encode MCC in memory and decode both
  // 708 and forced-608 compatibility tracks).
  ipcMain.handle('subtitle-editor-preview-mcc', async (event, payload) => {
    assertTrustedIpcSender(event, 'subtitle-editor-preview-mcc');
    try {
      if (!licenseService.isFeatureEnabled('subtitle-editor')) {
        return { error: 'License required for subtitle-editor preview' };
      }
      const senderId = event?.sender?.id;
      const knownPaths = [];
      const doc = payload?.doc;
      if (doc?.sourcePath) knownPaths.push(doc.sourcePath);
      if (doc?.mediaPath) knownPaths.push(doc.mediaPath);
      if (doc?.outputDir) knownPaths.push(doc.outputDir);
      const nested = extractAbsolutePathsFromObject(payload || {});
      assertApprovedPaths(senderId, [...knownPaths, ...nested]);
      return await previewMccFromEditor(payload || {});
    } catch (err) {
      return { error: err.message || String(err) };
    }
  });

  ipcMain.handle('subtitle-editor-burnin', async (event, payload) => {
    assertTrustedIpcSender(event, 'subtitle-editor-burnin');
    try {
      if (!licenseService.isFeatureEnabled('subtitle-editor')) {
        return { error: 'License required for subtitle-editor burn-in' };
      }
      const senderId = event?.sender?.id;
      const knownPaths = [];
      const doc = payload?.doc;
      if (doc?.sourcePath) knownPaths.push(doc.sourcePath);
      if (doc?.mediaPath) knownPaths.push(doc.mediaPath);
      if (doc?.outputDir) knownPaths.push(doc.outputDir);
      const nested = extractAbsolutePathsFromObject(payload || {});
      assertApprovedPaths(senderId, [...knownPaths, ...nested]);
      return await burnInCorrectedSubtitles(payload || {});
    } catch (err) {
      return { error: err.message || String(err) };
    }
  });

  ipcMain.handle('subtitle-editor-find-latest', async (event, payload) => {
    assertTrustedIpcSender(event, 'subtitle-editor-find-latest');
    try {
      if (!licenseService.isFeatureEnabled('subtitle-editor')) {
        return null;
      }
      const senderId = event?.sender?.id;
      const knownPaths = [];
      if (typeof payload?.outputPath === 'string' && payload.outputPath.trim()) {
        knownPaths.push(payload.outputPath);
      }
      const nested = extractAbsolutePathsFromObject(payload || {});
      assertApprovedPaths(senderId, [...knownPaths, ...nested]);
      return await findLatestSubtitleSource(payload);
    } catch {
      return null;
    }
  });

  ipcMain.handle('subtitle-editor-get-scc-glyphs', async (event) => {
    assertTrustedIpcSender(event, 'subtitle-editor-get-scc-glyphs');
    return getSccGlyphs();
  });
}

module.exports = registerSubtitleEditorHandlers;
