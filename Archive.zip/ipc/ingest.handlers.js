// ipc/ingest.handlers.js
// Ingest/clone/folder tree IPC: calculate-ingest-bytes, calculate-clone-bytes, get-folder-tree, cep-run-ingest.

const path = require('path');
const { constants: fsConstants } = require('fs');
// IMPORTANT: use Electron's unpatched fs when available so `.asar` files in user
// folders are treated as regular files (not virtual directories).
const { fsp } = require('../utils/nativeFs');
const { buildScanFilter, shouldAlwaysSkipFile } = require('../utils/scanFilters');
const cloneCore = require('../modules/clone');
const licenseService = require('../services/licenseService');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const {
  assertApprovedPaths,
  extractAbsolutePathsFromObject,
  toLocalPathIfFileUrl
} = require('../utils/ipcPathGuards');

const _DEBUG_LOGS = process.env.DEBUG_LOGS === 'true';
// Bridge broadcast helper to talk to the CEP panel over WebSocket
function _broadcastToAdobePanel(_msg) {
  if (global.cepBridge && typeof global.cepBridge.broadcast === 'function') {
    global.cepBridge.broadcast(_msg);
  } else {
    throw new Error('CEP bridge is not available');
  }
}
let ingestModule;
const ingestBytesCache = new Map();
const INGEST_BYTES_CACHE_LIMIT = 25;
const INGEST_PREVIEW_FILE_CAP = 5000;
const INGEST_PREVIEW_TIME_BUDGET_MS = 1500;
const ingestPreviewRequests = new Map();
const ingestPreviewCleanupRegistered = new Set();
const INGEST_PREVIEW_REQUESTS_LIMIT = 50;

// Folder file-count cache (used by Clone Mode "Show File Count")
// Keyed by: root path + scan/filter settings.
const folderFileCountsCache = new Map();
const FOLDER_FILE_COUNTS_CACHE_LIMIT = 5;

function getFolderFileCountsCache(key) {
  if (!key) return null;
  const cached = folderFileCountsCache.get(key);
  if (!cached) return null;
  // simple LRU: refresh key
  folderFileCountsCache.delete(key);
  folderFileCountsCache.set(key, cached);
  return cached;
}

function setFolderFileCountsCache(key, value) {
  if (!key) return;
  folderFileCountsCache.delete(key);
  folderFileCountsCache.set(key, value);
  if (folderFileCountsCache.size > FOLDER_FILE_COUNTS_CACHE_LIMIT) {
    const oldestKey = folderFileCountsCache.keys().next().value;
    folderFileCountsCache.delete(oldestKey);
  }
}

const INGEST_PATH_FIELDS = ['source', 'destination', 'backupPath', 'watchFolder'];
const INGEST_PATH_CONTAINER_FIELDS = ['sourceFiles', 'selectedFolders', 'retryFiles'];
const PATH_VALIDATION_CODES = {
  NOT_ABSOLUTE: 'PATH_NOT_ABSOLUTE',
  NOT_WRITABLE: 'PATH_NOT_WRITABLE',
  NOT_FOUND: 'PATH_NOT_FOUND'
};
const INGEST_I18N_ERROR_KEYS = Object.freeze({
  PATH_REQUIRED: 'ingest.error.pathRequired',
  REQUESTED_PATH_OUTSIDE_APPROVED_ROOT: 'ingest.error.requestedPathOutsideApprovedRoot'
});
const INGEST_I18N_MESSAGE_KEYS = Object.freeze({
  INGEST_CANCEL_REQUESTED: 'ingest.status.cancelRequested',
  CLONE_CANCEL_REQUESTED: 'clone.status.cancelRequested',
  CLONE_LICENSE_REQUIRED: 'clone.error.licenseRequired',
  CLONE_RUN_FAILED: 'clone.error.runFailed'
});

function createIngestI18nError(key, params = {}) {
  const err = new Error(key);
  err.i18n = { key, params };
  return err;
}

function getIpcErrorPayload(err) {
  if (err?.i18n && typeof err.i18n === 'object' && typeof err.i18n.key === 'string') {
    return err.i18n;
  }
  if (typeof err?.message === 'string' && err.message.trim()) return err.message;
  return String(err);
}

function getIngestBytesCache(key) {
  if (!key) return null;
  const cached = ingestBytesCache.get(key);
  if (!cached) return null;
  ingestBytesCache.delete(key);
  ingestBytesCache.set(key, cached);
  return cached;
}

function setIngestBytesCache(key, value) {
  if (!key) return;
  ingestBytesCache.delete(key);
  ingestBytesCache.set(key, value);
  if (ingestBytesCache.size > INGEST_BYTES_CACHE_LIMIT) {
    const oldestKey = ingestBytesCache.keys().next().value;
    ingestBytesCache.delete(oldestKey);
  }
}

function registerIngestPreviewCleanup(sender) {
  if (!sender || typeof sender.once !== 'function') return;
  const senderId = sender.id;
  if (typeof senderId !== 'number' || ingestPreviewCleanupRegistered.has(senderId)) return;

  ingestPreviewCleanupRegistered.add(senderId);
  sender.once('destroyed', () => {
    ingestPreviewCleanupRegistered.delete(senderId);
    ingestPreviewRequests.delete(senderId);
  });
}

function setIngestPreviewRequest(senderId, previewRequestId) {
  if (typeof senderId !== 'number') return;
  ingestPreviewRequests.delete(senderId);
  ingestPreviewRequests.set(senderId, previewRequestId);
  if (ingestPreviewRequests.size > INGEST_PREVIEW_REQUESTS_LIMIT) {
    const oldestKey = ingestPreviewRequests.keys().next().value;
    ingestPreviewRequests.delete(oldestKey);
  }
}

function getIngestModule() {
  if (!ingestModule) {
    ingestModule = require('../modules/ingest');
  }
  return ingestModule;
}

function collectIngestConfigPaths(config) {
  const paths = [];
  if (!config || typeof config !== 'object') return paths;

  for (const field of INGEST_PATH_FIELDS) {
    const value = config[field];
    if (typeof value === 'string' && value.trim()) {
      paths.push({
        path: value,
        allowMissing: field === 'destination'
      });
    }
  }

  for (const field of INGEST_PATH_CONTAINER_FIELDS) {
    const value = config[field];
    if (!value) continue;
    if (Array.isArray(value)) {
      for (const entry of value) {
        if (typeof entry === 'string' && entry.trim()) {
          paths.push({ path: entry.trim(), allowMissing: false });
        }
      }
      continue;
    }
    paths.push(...extractAbsolutePathsFromObject(value).map(p => ({ path: p, allowMissing: false })));
  }

  return paths;
}

async function validatePathCandidate(senderId, rawPath, {
  allowMissing = false,
  requireCanonicalForExisting = true
} = {}) {
  const normalized = toLocalPathIfFileUrl(String(rawPath || '').trim());
  if (!normalized) return null;

  const normalizedPath = String(normalized || '').trim();
  if (!normalizedPath) return null;

  if (!path.isAbsolute(normalizedPath)) {
    throw new Error(`❌ Path rejected: path must be absolute (${normalizedPath})`);
  }

  const resolvedPath = path.resolve(normalizedPath);
  assertApprovedPaths(senderId, [normalizedPath]);
  assertApprovedPaths(senderId, [resolvedPath]);

  let canonicalPath = null;
  try {
    canonicalPath = await fsp.realpath(resolvedPath);
    assertApprovedPaths(senderId, [canonicalPath]);
  } catch (error) {
    const isMissingPathError = error && (error.code === 'ENOENT' || error.code === 'ENOTDIR');
    if (!isMissingPathError) {
      throw error;
    }

    if (allowMissing) {
      return { normalizedPath, resolvedPath, canonicalPath: null };
    }

    if (requireCanonicalForExisting) {
      try {
        await fsp.lstat(resolvedPath);
        throw new Error(`❌ Path rejected: failed to canonicalize existing path (${resolvedPath})`);
      } catch (lstatError) {
        if (!lstatError || (lstatError.code !== 'ENOENT' && lstatError.code !== 'ENOTDIR')) {
          throw lstatError;
        }
      }
    }
  }

  return { normalizedPath, resolvedPath, canonicalPath };
}

async function normalizeAndValidateIngestPaths(senderId, config) {
  const rawPaths = collectIngestConfigPaths(config);
  const validated = await Promise.all(rawPaths.map(entry => (
    validatePathCandidate(senderId, entry.path, {
      allowMissing: !!entry.allowMissing,
      requireCanonicalForExisting: true
    })
  )));
  const filtered = validated.filter(Boolean);
  const normalizedPaths = filtered.map(entry => entry.normalizedPath);
  const resolvedPaths = filtered.map(entry => entry.resolvedPath);
  const canonicalPaths = filtered.map(entry => entry.canonicalPath).filter(Boolean);

  return { normalizedPaths, resolvedPaths, canonicalPaths };
}

async function normalizeAndValidateRootPath(senderId, rawPath, {
  allowMissing = false
} = {}) {
  const validated = await validatePathCandidate(senderId, rawPath, {
    allowMissing,
    requireCanonicalForExisting: true
  });

  if (!validated) {
    throw createIngestI18nError(INGEST_I18N_ERROR_KEYS.PATH_REQUIRED);
  }

  return validated;
}

function isPathInside(base, candidate) {
  if (!base || !candidate) return false;
  const relative = path.relative(base, candidate);
  if (!relative || relative === '.') return true;
  if (relative.startsWith('..')) return false;
  return !path.isAbsolute(relative);
}

async function normalizeSourceFiles(sourceFiles = [], { watchTriggered = false, senderId } = {}) {
  const entries = [];
  const seen = new Set();
  let duplicateCount = 0;

  for (const entry of sourceFiles) {
    const trimmed = typeof entry === 'string' ? entry.trim() : '';
    if (!trimmed) continue;
    const localPath = toLocalPathIfFileUrl(trimmed) || trimmed;
    const resolved = path.resolve(localPath);
    let isSymlink = false;
    try {
      const lst = await fsp.lstat(resolved);
      isSymlink = typeof lst.isSymbolicLink === 'function' && lst.isSymbolicLink();
    } catch {
      // ignore lstat errors; missing paths still flow to crawl
    }
    let realPath = resolved;
    try {
      realPath = await fsp.realpath(resolved);
    } catch {
      // keep resolved path if realpath fails
    }
    if (realPath && resolved && realPath !== resolved) {
      assertApprovedPaths(senderId, [realPath]);
    }
    const dedupeKey = realPath || resolved;
    if (seen.has(dedupeKey)) {
      duplicateCount += 1;
      continue;
    }
    seen.add(dedupeKey);
    let isDir = false;
    if (!isSymlink) {
      try {
        const stat = await fsp.stat(realPath);
        isDir = stat.isDirectory();
      } catch {
        // ignore stat errors; missing paths still flow to crawl
      }
    }
    entries.push({ fullPath: isSymlink ? resolved : realPath, isDir });
  }

  let normalizedEntries = entries;
  let descendantCount = 0;

  if (!watchTriggered) {
    const dirPaths = entries.filter(entry => entry.isDir).map(entry => entry.fullPath);
    if (dirPaths.length) {
      normalizedEntries = entries.filter(entry => (
        !dirPaths.some(dir => dir !== entry.fullPath && isPathInside(dir, entry.fullPath))
      ));
      descendantCount = entries.length - normalizedEntries.length;
    }
  }

  return {
    files: normalizedEntries.map(entry => entry.fullPath),
    duplicateCount,
    descendantCount
  };
}

const FOLDER_TREE_DEFAULT_DEPTH = 1;
const FOLDER_TREE_MAX_DEPTH = 5;
const FOLDER_TREE_ENTRY_CAP = 2000;
const FOLDER_TREE_DEFAULT_PAGE_SIZE = 200;

function clampNumber(value, min, max) {
  const parsed = Number(value);
  if (Number.isNaN(parsed)) return min;
  return Math.min(Math.max(parsed, min), max);
}

// --- Folder file-count scanning helpers ---
// Used by Clone Mode folder tree when "Show File Count" is enabled.
//
// Behavior:
// - direct: files directly inside a folder (no recursion)
// - total: direct + all descendant files
//
// Filters match clone/ingest selection semantics:
// - includeHiddenFiles
// - default ignore patterns (cache/dev folders) unless explicitly disabled
// - include/exclude extensions
// - excludePatterns (substring match)

function normalizeExtensions(input) {
  return String(input || '')
    .split(',')
    .map(x => x.trim().toLowerCase().replace(/^\*/, ''))
    .filter(Boolean)
    .map(x => (x.startsWith('.') ? x : `.${x}`));
}

function parseExtension(name) {
  const base = String(name || '');
  const idx = base.lastIndexOf('.');
  if (idx < 0) return '';
  return base.slice(idx).toLowerCase();
}

function normalizeExcludePatterns(input) {
  const arr = Array.isArray(input)
    ? input
    : String(input || '')
        .split(',')
        .map(x => x.trim())
        .filter(Boolean);
  return arr.map(x => String(x || '').toLowerCase()).filter(Boolean);
}

function buildFolderFileCountsCacheKey({
  rootPath,
  includeHiddenFiles,
  useDefaultIgnorePatterns,
  includeExts,
  excludeExts,
  excludePatterns
}) {
  return JSON.stringify({
    rootPath: path.resolve(String(rootPath || '')),
    includeHiddenFiles: !!includeHiddenFiles,
    useDefaultIgnorePatterns: !!useDefaultIgnorePatterns,
    includeExts: Array.from(includeExts || []).slice().sort(),
    excludeExts: Array.from(excludeExts || []).slice().sort(),
    excludePatterns: Array.from(excludePatterns || []).slice().sort()
  });
}

async function buildFolderFileCountsIndex({
  rootPath,
  includeHiddenFiles,
  useDefaultIgnorePatterns,
  includeExts,
  excludeExts,
  excludePatterns
}) {
  const scanFilter = buildScanFilter({
    includeHidden: !!includeHiddenFiles,
    useDefaultIgnorePatterns: !!useDefaultIgnorePatterns
  });

  const includeSet = new Set((includeExts || []).map(x => String(x || '').toLowerCase()));
  const excludeSet = new Set((excludeExts || []).map(x => String(x || '').toLowerCase()));
  const patterns = (excludePatterns || []).map(x => String(x || '').toLowerCase()).filter(Boolean);

  const shouldCountFile = (fileName) => {
    if (!fileName) return false;
    if (scanFilter.shouldSkipFile(fileName)) return false;
    const ext = parseExtension(fileName);
    if (includeSet.size && !includeSet.has(ext)) return false;
    if (excludeSet.has(ext)) return false;
    if (patterns.length) {
      const lower = String(fileName).toLowerCase();
      for (const p of patterns) {
        if (p && lower.includes(p)) return false;
      }
    }
    return true;
  };

  const countsByPath = new Map();
  let unreadableDirCount = 0;

  // DFS with explicit stack to avoid call-stack blowups.
  // stage 0: read entries + push children, stage 1: sum child totals and store.
  const stack = [{ dir: rootPath, stage: 0 }];

  while (stack.length) {
    const frame = stack.pop();
    if (!frame) break;

    if (frame.stage === 0) {
      let entries;
      try {
        entries = await fsp.readdir(frame.dir, { withFileTypes: true });
      } catch {
        unreadableDirCount += 1;
        countsByPath.set(frame.dir, { direct: 0, total: 0 });
        continue;
      }

      const childDirs = [];
      let direct = 0;

      for (const entry of entries) {
        const name = entry?.name;
        if (!name) continue;

        const isSymlink = typeof entry.isSymbolicLink === 'function' ? entry.isSymbolicLink() : false;
        const isDir = typeof entry.isDirectory === 'function' ? entry.isDirectory() : entry.isDirectory;

        if (isDir && !isSymlink) {
          if (scanFilter.shouldSkipDir(name)) continue;
          childDirs.push(path.join(frame.dir, name));
          continue;
        }

        // Treat everything non-directory as a file-ish entry.
        if (shouldCountFile(name)) {
          direct += 1;
        }
      }

      // push for post-order processing
      stack.push({ dir: frame.dir, stage: 1, childDirs, direct });

      // push children for processing
      for (let i = childDirs.length - 1; i >= 0; i -= 1) {
        stack.push({ dir: childDirs[i], stage: 0 });
      }
      continue;
    }

    // stage 1: children already processed
    let total = frame.direct || 0;
    for (const childDir of frame.childDirs || []) {
      const childCounts = countsByPath.get(childDir);
      if (childCounts && typeof childCounts.total === 'number') {
        total += childCounts.total;
      }
    }

    countsByPath.set(frame.dir, { direct: frame.direct || 0, total });
  }

  return {
    countsByPath,
    meta: {
      unreadableDirCount,
      folderCount: countsByPath.size,
      fileCount: countsByPath.get(rootPath)?.total ?? 0
    }
  };
}

function buildTreeNode(fullPath, base, type) {
  return {
    name: path.basename(fullPath),
    path: fullPath,
    relativePath: path.relative(base, fullPath),
    type
  };
}

async function readDirectoryEntries(dirPath, scanFilter, { throwOnError = false } = {}) {
  try {
    const entries = await fsp.readdir(dirPath, { withFileTypes: true });
    if (!scanFilter) return { entries, error: null };
    const filtered = entries.filter(entry => {
      const name = entry?.name;
      if (!name) return false;
      const isDir = typeof entry.isDirectory === 'function' ? entry.isDirectory() : entry.isDirectory;
      if (isDir) {
        return !scanFilter.shouldSkipDir(name);
      }
      if (shouldAlwaysSkipFile(name)) return false;
      return !scanFilter.shouldSkipFile(name);
    });
    return { entries: filtered, error: null };
  } catch (err) {
    if (throwOnError) {
      throw err;
    }
    return { entries: [], error: err };
  }
}

async function buildFolderTree({
  rootPath,
  parentPath,
  depthLimit,
  entryCap,
  offset,
  limit,
  includeHiddenFiles,
  useDefaultIgnorePatterns
}) {
  const basePath = rootPath;
  const startPath = parentPath || rootPath;
  const rootNode = buildTreeNode(startPath, basePath, 'directory');
  const scanFilter = buildScanFilter({
    includeHidden: !!includeHiddenFiles,
    useDefaultIgnorePatterns: !!useDefaultIgnorePatterns
  });

  const queue = [{
    node: rootNode,
    dir: startPath,
    depth: 0,
    paged: true,
    offset,
    limit
  }];

  let createdCount = 0;
  let truncated = false;
  let depthLimitReached = false;
  let unreadableDirCount = 0;

  while (queue.length) {
    const current = queue.shift();
    if (!current) break;
    if (current.depth >= depthLimit) {
      depthLimitReached = true;
      continue;
    }

    const { entries, error } = await readDirectoryEntries(current.dir, scanFilter, {
      throwOnError: current.dir === startPath
    });
    if (error) {
      unreadableDirCount += 1;
    }
    const totalEntries = entries.length;
    const startIndex = current.paged ? current.offset : 0;
    const pageSize = current.paged ? current.limit : totalEntries;
    const sliced = entries.slice(startIndex, startIndex + pageSize);
    const hasMore = startIndex + pageSize < totalEntries;

    current.node.children = [];
    current.node.totalChildren = totalEntries;
    current.node.hasMore = hasMore;
    current.node.nextOffset = hasMore ? startIndex + pageSize : null;
    current.node.hasChildren = entries.some(entry => entry.isDirectory());

    for (const entry of sliced) {
      if (createdCount >= entryCap) {
        truncated = true;
        break;
      }
      const fullPath = path.join(current.dir, entry.name);
      if (entry.isDirectory()) {
        const childNode = buildTreeNode(fullPath, basePath, 'directory');
        childNode.hasChildren = true;
        current.node.children.push(childNode);
        createdCount += 1;
        queue.push({
          node: childNode,
          dir: fullPath,
          depth: current.depth + 1,
          paged: false,
          offset: 0,
          limit: current.limit
        });
      } else {
        current.node.children.push(buildTreeNode(fullPath, basePath, 'file'));
        createdCount += 1;
      }
    }

    if (truncated) {
      break;
    }
  }

  return {
    tree: rootNode,
    meta: {
      truncated,
      depthLimitReached,
      entryCapReached: truncated,
      entryCap,
      depthLimit,
      unreadableDirCount
    }
  };
}

function registerIngestHandlers(ipcMain) {
  ipcMain.handle('ingest-validate-paths', async (event, inputPaths) => {
    assertTrustedIpcSender(event, 'ingest-validate-paths');
    try {
      const rawPaths = Array.isArray(inputPaths) ? inputPaths : [];
      const mapping = {};
      const normalized = [];

      for (const rawPath of rawPaths) {
        const original = String(rawPath || '').trim();
        if (!original) continue;
        const local = toLocalPathIfFileUrl(original) || original;
        const normalizedPath = String(local || '').trim();
        if (!normalizedPath) continue;
        mapping[original] = normalizedPath;
        mapping[normalizedPath] = normalizedPath;
        normalized.push(normalizedPath);
      }

      const invalidPaths = normalized.filter(p => !path.isAbsolute(p));
      const absolutePaths = normalized.filter(p => path.isAbsolute(p));
      const resolved = absolutePaths.map(p => path.resolve(p));

      const senderId = event?.sender?.id;
      assertApprovedPaths(senderId, absolutePaths);
      assertApprovedPaths(senderId, resolved);

      const results = {};
      for (const invalidPath of invalidPaths) {
        results[invalidPath] = {
          exists: false,
          isDirectory: false,
          isFile: false,
          invalid: true,
          error: PATH_VALIDATION_CODES.NOT_ABSOLUTE
        };
      }

      const normalizedResolvedPairs = absolutePaths.map((normalizedPath, index) => ({
        normalizedPath,
        resolvedPath: resolved[index]
      }));
      const unique = new Map();
      for (const pair of normalizedResolvedPairs) {
        if (!unique.has(pair.normalizedPath)) {
          unique.set(pair.normalizedPath, pair.resolvedPath);
        }
      }
      await Promise.all(Array.from(unique.entries()).map(async ([target, resolvedTarget]) => {
        try {
          const st = await fsp.stat(resolvedTarget);
          const isDirectory = typeof st.isDirectory === 'function' ? st.isDirectory() : st.isDirectory;
          let writable = null;
          let writeReason = '';
          if (isDirectory) {
            try {
              await fsp.access(resolvedTarget, fsConstants.W_OK);
              writable = true;
            } catch (error) {
              writable = false;
              writeReason = error?.message || PATH_VALIDATION_CODES.NOT_WRITABLE;
            }
          }
          results[target] = {
            exists: true,
            isDirectory,
            isFile: typeof st.isFile === 'function' ? st.isFile() : st.isFile,
            writable,
            writeReason
          };
        } catch {
          results[target] = {
            exists: false,
            isDirectory: false,
            isFile: false,
            writable: false,
            writeReason: PATH_VALIDATION_CODES.NOT_FOUND
          };
        }
      }));

      return { success: true, results, mapping };
    } catch (err) {
      return { success: false, error: getIpcErrorPayload(err) };
    }
  });


  ipcMain.handle('calculate-ingest-bytes', async (event, cfg) => {
    assertTrustedIpcSender(event, 'calculate-ingest-bytes');
    try {
      const senderId = event?.sender?.id;
      const previewRequestId = cfg?.previewRequestId;
      registerIngestPreviewCleanup(event?.sender);
      if (senderId && previewRequestId !== undefined) {
        setIngestPreviewRequest(senderId, previewRequestId);
      }

      // Enforce approved-roots policy before crawling the filesystem.
      await normalizeAndValidateIngestPaths(senderId, cfg);

      const cacheKey = cfg?.previewCacheKey || cfg?.cacheKey;
      const cached = getIngestBytesCache(cacheKey);
      if (cached) {
        return { success: true, ...cached };
      }

      const norm = s => (s || '')
        .split(',')
        .map(x => x.trim().toLowerCase().replace(/^\*/, ''))
        .filter(Boolean)
        .map(x => (x.startsWith('.') ? x : `.${x}`));
      const includeExts = norm(cfg.filters?.include || cfg.includeExtensions);
      const excludeExts = norm(cfg.filters?.exclude || cfg.excludeExtensions);

      let total = 0;
      let fileCount = 0;
      let folderCount = 0;
      let truncated = false;
      let cancelled = false;
      let unreadableCount = 0;
      const startedAt = Date.now();
      const fileCap = clampNumber(cfg?.previewFileCap ?? INGEST_PREVIEW_FILE_CAP, 1, INGEST_PREVIEW_FILE_CAP);
      const timeBudgetMs = clampNumber(cfg?.previewTimeBudgetMs ?? INGEST_PREVIEW_TIME_BUDGET_MS, 50, INGEST_PREVIEW_TIME_BUDGET_MS);

      const shouldAbort = () => {
        if (senderId && previewRequestId !== undefined) {
          const currentRequestId = ingestPreviewRequests.get(senderId);
          if (currentRequestId !== previewRequestId) {
            cancelled = true;
            truncated = true;
            return true;
          }
        }
        if (fileCount >= fileCap || Date.now() - startedAt >= timeBudgetMs) {
          truncated = true;
          return true;
        }
        return false;
      };

      const includeHiddenFiles = !!cfg?.includeHiddenFiles;
      const includeCache = typeof cfg?.includeCache === 'boolean' ? cfg.includeCache : undefined;
      // Default behavior: exclude caches/dev folders unless explicitly included.
      const useDefaultIgnorePatterns = typeof includeCache === 'boolean'
        ? !includeCache
        : (cfg?.useDefaultIgnorePatterns !== undefined ? !!cfg.useDefaultIgnorePatterns : true);
      const scanFilter = buildScanFilter({
        includeHidden: includeHiddenFiles,
        useDefaultIgnorePatterns
      });

      const shouldSkipIngestDir = (name) => scanFilter.shouldSkipDir(name);
      const shouldSkipIngestFile = (name, { bypassScanFilter = false } = {}) => {
        if (shouldAlwaysSkipFile(name)) return true;
        if (bypassScanFilter) return false;
        return scanFilter.shouldSkipFile(name);
      };
      const shouldSkipHiddenPath = (filePath) => {
        if (includeHiddenFiles) return false;
        const segments = String(filePath || '').split(/[\\/]+/).filter(Boolean);
        return segments.some(seg => seg !== '.' && seg !== '..' && seg.startsWith('.'));
      };

      async function crawl(p, { bypassRootScanFilter = false } = {}) {
        if (shouldAbort()) return;
        let st;
        try { st = await fsp.lstat(p); } catch {
          unreadableCount += 1;
          truncated = true;
          return;
        }
        // Policy: skip symlinks entirely to avoid cycles and out-of-root traversal.
        if (typeof st.isSymbolicLink === 'function' && st.isSymbolicLink()) return;
        const isDir = typeof st.isDirectory === 'function' ? st.isDirectory() : st.isDirectory;
        if (isDir) {
          folderCount++;
          let entries;
          try { entries = await fsp.readdir(p, { withFileTypes: true }); } catch {
            unreadableCount += 1;
            truncated = true;
            return;
          }
          for (const entry of entries) {
            if (shouldAbort()) return;
            const name = entry.name;
            const full = path.join(p, name);
            let entryStat;
            try {
              entryStat = await fsp.lstat(full);
            } catch {
              unreadableCount += 1;
              truncated = true;
              continue;
            }
            if (typeof entryStat.isSymbolicLink === 'function' && entryStat.isSymbolicLink()) {
              continue;
            }
            if (entryStat.isDirectory()) {
              if (shouldSkipIngestDir(name)) continue;
              await crawl(full);
              continue;
            }
            if (shouldSkipIngestFile(name)) continue;
            const ext = path.extname(full).toLowerCase();
            if (includeExts.length && !includeExts.includes(ext)) continue;
            if (excludeExts.includes(ext)) continue;
            try {
              total += entryStat.size;
              fileCount++;
              if (shouldAbort()) return;
            } catch {
              unreadableCount += 1;
              truncated = true;
            }
          }
        } else {
          if (shouldSkipHiddenPath(p)) return;
          if (shouldSkipIngestFile(path.basename(p), { bypassScanFilter: bypassRootScanFilter })) return;
          const ext = path.extname(p).toLowerCase();
          if (includeExts.length && !includeExts.includes(ext)) return;
          if (excludeExts.includes(ext)) return;
          total += st.size;
          fileCount++;
          if (shouldAbort()) return;
        }
      }

      if (Array.isArray(cfg.sourceFiles) && cfg.sourceFiles.length) {
        const { files } = await normalizeSourceFiles(cfg.sourceFiles, {
          watchTriggered: !!cfg?.watchTriggered,
          senderId
        });
        for (const fp of files) {
          await crawl(fp, { bypassRootScanFilter: true });
        }
      } else if (cfg.source) {
        await crawl(cfg.source);
      }
      const payload = { total, fileCount, folderCount, truncated, cancelled, unreadableCount };
      if (!truncated && !cancelled) {
        setIngestBytesCache(cacheKey, payload);
      }
      return { success: true, ...payload };
    } catch (err) {
      return { success: false, error: getIpcErrorPayload(err) };
    }
  });

  ipcMain.handle('get-folder-tree', async (event, payload) => {
    assertTrustedIpcSender(event, 'get-folder-tree');
    try {
      const options = typeof payload === 'string' ? { rootPath: payload } : (payload || {});
      const senderId = event?.sender?.id;
      const safeRoot = await normalizeAndValidateRootPath(senderId, options.rootPath);
      const requestedParent = await normalizeAndValidateRootPath(
        senderId,
        options.parentPath || safeRoot.normalizedPath
      );

      const resolvedRoot = safeRoot.canonicalPath || safeRoot.resolvedPath;
      const resolvedParent = requestedParent.canonicalPath || requestedParent.resolvedPath;
      const relative = path.relative(resolvedRoot, resolvedParent);
      if (relative.startsWith('..') || path.isAbsolute(relative)) {
        throw createIngestI18nError(INGEST_I18N_ERROR_KEYS.REQUESTED_PATH_OUTSIDE_APPROVED_ROOT);
      }

      const depthLimit = clampNumber(options.depth ?? FOLDER_TREE_DEFAULT_DEPTH, 1, FOLDER_TREE_MAX_DEPTH);
      const entryCap = clampNumber(options.entryCap ?? FOLDER_TREE_ENTRY_CAP, 1, FOLDER_TREE_ENTRY_CAP);
      const limit = clampNumber(options.limit ?? FOLDER_TREE_DEFAULT_PAGE_SIZE, 1, FOLDER_TREE_ENTRY_CAP);
      const offset = clampNumber(options.offset ?? 0, 0, Number.MAX_SAFE_INTEGER);
      const includeHiddenFiles = !!options.includeHiddenFiles;
      const includeCache = typeof options.includeCache === 'boolean' ? options.includeCache : undefined;
      const useDefaultIgnorePatterns = typeof includeCache === 'boolean'
        ? !includeCache
        : (options.useDefaultIgnorePatterns !== undefined ? !!options.useDefaultIgnorePatterns : true);

      const result = await buildFolderTree({
        rootPath: safeRoot.normalizedPath,
        parentPath: resolvedParent,
        depthLimit,
        entryCap,
        offset,
        limit,
        includeHiddenFiles,
        useDefaultIgnorePatterns
      });

      return { success: true, tree: result.tree, meta: result.meta };
    } catch (err) {
      return { success: false, error: getIpcErrorPayload(err) };
    }
  });

  ipcMain.handle('get-folder-file-counts', async (event, payload) => {
    assertTrustedIpcSender(event, 'get-folder-file-counts');
    try {
      const options = typeof payload === 'string' ? { rootPath: payload } : (payload || {});
      const senderId = event?.sender?.id;
      const safeRoot = await normalizeAndValidateRootPath(senderId, options.rootPath);
      const resolvedRoot = safeRoot.canonicalPath || safeRoot.resolvedPath;

      const includeCache = typeof options.includeCache === 'boolean' ? options.includeCache : undefined;
      const useDefaultIgnorePatterns = typeof includeCache === 'boolean'
        ? !includeCache
        : (options.useDefaultIgnorePatterns !== undefined ? !!options.useDefaultIgnorePatterns : true);

      const includeExts = Array.from(new Set(normalizeExtensions(options.includeExtensions || options.filters?.include || '')));
      const excludeExts = Array.from(new Set(normalizeExtensions(options.excludeExtensions || options.filters?.exclude || '')));
      const excludePatterns = normalizeExcludePatterns(options.excludePatterns);

      const cacheKey = buildFolderFileCountsCacheKey({
        rootPath: resolvedRoot,
        includeHiddenFiles: !!options.includeHiddenFiles,
        useDefaultIgnorePatterns,
        includeExts,
        excludeExts,
        excludePatterns
      });

      let cached = getFolderFileCountsCache(cacheKey);
      let cacheHit = true;
      if (!cached) {
        cacheHit = false;
        cached = await buildFolderFileCountsIndex({
          rootPath: resolvedRoot,
          includeHiddenFiles: !!options.includeHiddenFiles,
          useDefaultIgnorePatterns,
          includeExts,
          excludeExts,
          excludePatterns
        });
        setFolderFileCountsCache(cacheKey, cached);
      }

      const requestedPaths = Array.isArray(options.paths)
        ? options.paths.map(p => String(p || '').trim()).filter(Boolean)
        : [];

      // Validate requested paths are within the approved root.
      for (const p of requestedPaths) {
        const validated = await validatePathCandidate(senderId, p, {
          allowMissing: true,
          requireCanonicalForExisting: true
        });
        const resolved = validated.canonicalPath || validated.resolvedPath;
        const relative = path.relative(resolvedRoot, resolved);
        if (relative.startsWith('..') || path.isAbsolute(relative)) {
          throw createIngestI18nError(INGEST_I18N_ERROR_KEYS.REQUESTED_PATH_OUTSIDE_APPROVED_ROOT);
        }
      }

      const counts = {};
      if (requestedPaths.length) {
        for (const p of requestedPaths) {
          const validated = await validatePathCandidate(senderId, p, {
            allowMissing: true,
            requireCanonicalForExisting: true
          });
          const resolved = validated.canonicalPath || validated.resolvedPath;
          const c = cached.countsByPath.get(resolved);
          counts[p] = c ? { direct: c.direct || 0, total: c.total || 0 } : { direct: 0, total: 0 };
        }
      } else {
        const c = cached.countsByPath.get(resolvedRoot);
        counts[resolvedRoot] = c ? { direct: c.direct || 0, total: c.total || 0 } : { direct: 0, total: 0 };
      }

      return {
        success: true,
        cacheHit,
        rootPath: resolvedRoot,
        counts,
        meta: cached.meta || {}
      };
    } catch (err) {
      return { success: false, error: getIpcErrorPayload(err) };
    }
  });

  ipcMain.handle('calculate-clone-bytes', async (event, cfg) => {
    assertTrustedIpcSender(event, 'calculate-clone-bytes');
    try {
      const senderId = event?.sender?.id;
      await normalizeAndValidateIngestPaths(senderId, cfg);
      return await cloneCore.calculateCloneBytes(cfg);
    } catch (err) {
      console.error('calculate-clone-bytes error:', err);
      return { success: false, error: String(err) };
    }
  });

  ipcMain.handle('cancel-ingest', async (event) => {
    assertTrustedIpcSender(event, 'cancel-ingest');
    const { cancelIngest } = getIngestModule();
    cancelIngest();
    return { key: INGEST_I18N_MESSAGE_KEYS.INGEST_CANCEL_REQUESTED };
  });

  ipcMain.handle('run-clone', async (event, config) => {
    assertTrustedIpcSender(event, 'run-clone');
    try {
      if (!licenseService.isFeatureEnabled('clone')) {
        const msg = { key: INGEST_I18N_MESSAGE_KEYS.CLONE_LICENSE_REQUIRED };
        return { success: false, error: msg, log: [msg] };
      }

      const senderId = event?.sender?.id;
      await normalizeAndValidateIngestPaths(senderId, config);
      return await cloneCore.runClone(config);
    } catch (err) {
      const errorDetail = err?.message || String(err);
      const errorPayload = {
        key: INGEST_I18N_MESSAGE_KEYS.CLONE_RUN_FAILED,
        params: { error: errorDetail }
      };
      return { success: false, error: errorPayload, log: [errorPayload] };
    }
  });

  ipcMain.handle('cancel-clone', async (event) => {
    assertTrustedIpcSender(event, 'cancel-clone');
    cloneCore.cancelClone();
    return { key: INGEST_I18N_MESSAGE_KEYS.CLONE_CANCEL_REQUESTED };
  });
}

module.exports = registerIngestHandlers;
