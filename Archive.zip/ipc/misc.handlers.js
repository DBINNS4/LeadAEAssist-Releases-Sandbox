// ipc/misc.handlers.js
const path = require('path');
const os = require('os');
const fs = require('fs');
const fsp = fs.promises;
const { execFile } = require('child_process');
const { dialog, app, shell, session, BrowserWindow } = require('electron');
const platformPaths = require('../platform/paths');
const { performance } = require('perf_hooks');
const { v4: uuidv4 } = require('uuid');
const { runSequentialDriveTest, SEQUENTIAL_BENCHMARK_TEMP_FILE_COUNT } = require('../modules/diskBenchmark');
const { estimateDiskWriteSpeed } = require('../modules/speedUtils');
const checkDiskSpace = require('check-disk-space').default;
const { getSourceMetadata } = require('../utils/metadata');
const { createProjectStructure: _createProjectStructure } = require('../modules/project-organizer');
const { expandPaths } = require('../modules/pathExpander');
const secureStore = require('../modules/secureStore');
const licenseService = require('../services/licenseService');
const { readLogFiles, createJobLogger, writeJobLogToFile, writeJobTextToFile } = require('../modules/logUtils');
const { ensureUserDataSubdir } = require('../utils/appPaths');
const { approveRoot, approveMany } = require('../utils/fsAccessControl');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const { readState } = require('../utils/state');
const { clearTempFiles, clearCacheFiles, clearLogFiles } = require('../utils/maintenance');
const autoUpdateService = require('../services/autoUpdateService');
const chromiumAssetService = require('../services/chromiumAssetService');
const {
  assertNoNetworkSchemes,
  toLocalPathIfFileUrl,
  assertApprovedPath,
  assertApprovedPaths,
  extractAbsolutePathsFromObject
} = require('../utils/ipcPathGuards');


// ---- Sandbox-compat sync helpers ----
// With renderer sandbox enabled, preload scripts cannot require Node built-ins
// (fs/path/os) or local CommonJS modules. Instead, preload calls a small set of
// synchronous IPC endpoints for lightweight, deterministic operations.
//
// These endpoints are:
//  - strictly allowlisted (channels are hard-coded)
//  - sender-verified (assertTrustedIpcSender)
//  - side-effect free (except mkdir for userData path)

function _okSync(event, value) {
  event.returnValue = { ok: true, value };
}

function _denySync(event, message) {
  event.returnValue = { ok: false, error: String(message || 'error') };
}


function isOfflineModeEnabled() {
  try {
    const state = readState() || {};
    return !!state?.preferences?.offlineMode;
  } catch {
    return false;
  }
}

let __cachedUserDataPath = null;

function resolveCanonicalUserDataPath() {
  if (__cachedUserDataPath) return __cachedUserDataPath;

  const env = process.env.USER_DATA_PATH;
  if (env && typeof env === 'string') {
    try { fs.mkdirSync(env, { recursive: true }); } catch {}
    __cachedUserDataPath = env;
    return __cachedUserDataPath;
  }

  // NOTE: This intentionally does NOT use app.getPath('userData') because this
  // app changes app.setName() for branding, and Electron derives userData from
  // the app name. We need a stable directory for both the desktop app + CEP.
  const base = platformPaths.getAppDataBase();
  const variants = [
    'LeadAEAssist',         // canonical
    'Lead AE Assist'        // legacy casing
  ];

  for (const v of variants) {
    const p = path.join(base, v);
    try {
      if (fs.existsSync(p)) {
        __cachedUserDataPath = p;
        return __cachedUserDataPath;
      }
    } catch {}
  }

  const canonical = path.join(base, 'LeadAEAssist');
  try { fs.mkdirSync(canonical, { recursive: true }); } catch {}
  __cachedUserDataPath = canonical;
  return __cachedUserDataPath;
}

// Lazy-load the transcribe engine only if/when the UI asks for formatting helpers.
let __transcribeEngine = null;
function getTranscribeEngineOrThrow() {
  if (__transcribeEngine) return __transcribeEngine;
  try {
    __transcribeEngine = require('../ai/transcribeEngine');
    return __transcribeEngine;
  } catch (err) {
    const e = new Error(`Transcribe engine unavailable: ${err?.message || String(err)}`);
    e.code = 'ERR_TRANSCRIBE_ENGINE_UNAVAILABLE';
    throw e;
  }
}

const BYTES_PER_MIB = 1024 * 1024;
const SPEEDTEST_DIRNAME = '.lead-speedtest';
const SPEEDTEST_ACTIVE_PREFIX = '.__lead_speedtest_active_';
const SPEEDTEST_OS_JUNK = new Set(['.DS_Store', 'Thumbs.db', 'desktop.ini']);
const SPEEDTEST_STALE_MIN_AGE_MS = 45 * 60 * 1000;
const SPEEDTEST_MARKER_STALE_MAX_AGE_MS = 60 * 60 * 1000;
// A small headroom buffer to reduce ENOSPC risk and avoid destabilizing low-space volumes.
// We intentionally keep this conservative, but not so large that small test sizes become unusable.
const DISK_SPACE_SAFETY_MIN_BYTES = 256 * 1024 * 1024; // 256 MiB
const DISK_SPACE_SAFETY_FRACTION = 0.10; // +10% on top of peak temp usage

// Drive test cancellation is tracked per renderer/webContents.
// Key = sender.id (webContents id). Value = boolean.
const driveTestCancelBySender = new Map();
// Drive test active guard per renderer/webContents.
// Key = sender.id (webContents id). Value = boolean.
const driveTestRunningBySender = new Set();

// Network test cancellation is tracked per renderer/webContents.
// Key = sender.id (webContents id). Value = state for an in-flight fast-cli child.
// We only allow one running network test per sender.
const networkTestStateBySender = new Map();
const cleanupRegisteredSenders = new Set();
const logReadStateBySender = new Map();
const NETWORK_TEST_CANCEL_TIMEOUT_MS = 8000;
const PROCESS_LIST_TIMEOUT_MS = 5000;

function toIpcSafeError(err, fallback = 'Request failed') {
  const raw = String(err?.message || err || fallback);
  const line = raw.split('\n')[0].trim();
  return line || fallback;
}

function isChildProcessAlive(child) {
  const pid = child?.pid;
  if (!Number.isFinite(pid)) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

function attemptNetworkTestKill(state, reason) {
  const child = state?.child;
  if (!child || state?.done) return;
  const logger = state?.logger;

  try {
    if (!child.killed) child.kill();
  } catch (err) {
    if (logger?.warn) {
      logger.warn('Network speed test kill failed', { reason, error: err?.message || err });
    } else {
      console.warn('⚠️ Network speed test kill failed:', err?.message || err);
    }
  }

  if (process.platform === 'win32') return;

  setTimeout(() => {
    if (state?.done || !isChildProcessAlive(child)) return;
    try {
      child.kill('SIGKILL');
      if (logger?.warn) {
        logger.warn('Network speed test fallback kill issued', { reason, signal: 'SIGKILL' });
      } else {
        console.warn('⚠️ Network speed test fallback kill issued');
      }
    } catch (err) {
      if (logger?.warn) {
        logger.warn('Network speed test fallback kill failed', {
          reason,
          signal: 'SIGKILL',
          error: err?.message || err
        });
      } else {
        console.warn('⚠️ Network speed test fallback kill failed:', err?.message || err);
      }
    }
  }, 500);
}

function makeSpeedTestJobId(prefix = 'speed-test') {
  try {
    return `${prefix}-${uuidv4()}`;
  } catch {
    const rand = Math.random().toString(16).slice(2, 10);
    return `${prefix}-${Date.now()}-${rand}`;
  }
}

// ────────────────────────────────────────────────────────────────
// Speed Test: user-facing reporting helpers
// Goal: keep INFO logs human-useful, keep plumbing out of INFO.
// ────────────────────────────────────────────────────────────────
function _toFiniteNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function _fmtNum(n, { digits = 1, fallback = 'N/A' } = {}) {
  if (!Number.isFinite(n)) return fallback;
  return Number(n).toFixed(digits);
}

function _fmtInt(n, { fallback = 'N/A' } = {}) {
  if (!Number.isFinite(n)) return fallback;
  return String(Math.round(n));
}

function _formatDurationCompact(seconds) {
  const s = Math.max(0, Math.round(Number(seconds) || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${sec}s`;
  return `${sec}s`;
}

function _estimateSecondsFromMB(sizeMB, mbPerSec, efficiency = 0.8) {
  const rate = Number(mbPerSec);
  if (!Number.isFinite(rate) || rate <= 0) return null;
  const eff = Number(efficiency);
  const effective = rate * (Number.isFinite(eff) ? eff : 1);
  if (!(effective > 0)) return null;
  return (Number(sizeMB) || 0) / effective;
}

function _estimateSecondsFromMiB(sizeMiB, miBPerSec, efficiency = 0.85) {
  const rate = Number(miBPerSec);
  if (!Number.isFinite(rate) || rate <= 0) return null;
  const eff = Number(efficiency);
  const effective = rate * (Number.isFinite(eff) ? eff : 1);
  if (!(effective > 0)) return null;
  return (Number(sizeMiB) || 0) / effective;
}

function _buildNetworkReport(downloadRaw, uploadRaw, pingRaw, opts = {}) {
  const provider = String(opts.provider || 'fast.com');
  const efficiency = Number.isFinite(Number(opts.efficiency)) ? Number(opts.efficiency) : 0.8;
  const estimateSizeGB = Number.isFinite(Number(opts.estimateSizeGB)) ? Number(opts.estimateSizeGB) : 100;

  const dlMbps = _toFiniteNumber(downloadRaw);
  const ulMbps = _toFiniteNumber(uploadRaw);
  const pingMs = _toFiniteNumber(pingRaw);

  const dlMBps = Number.isFinite(dlMbps) ? (dlMbps / 8) : null;
  const ulMBps = Number.isFinite(ulMbps) ? (ulMbps / 8) : null;

  const summaryLine =
    `Result (${provider}): ` +
    `Download ${_fmtInt(dlMbps)} Mbps (${_fmtNum(dlMBps, { digits: 1 })} MB/s) • ` +
    `Upload ${_fmtInt(ulMbps)} Mbps (${_fmtNum(ulMBps, { digits: 1 })} MB/s) • ` +
    `Ping ${_fmtInt(pingMs)} ms`;

  // Use decimal GB/MB for network estimates (matches Mbps/MBps conventions).
  const sizeMB = estimateSizeGB * 1000;
  const estDownSec = _estimateSecondsFromMB(sizeMB, dlMBps, efficiency);
  const estUpSec = _estimateSecondsFromMB(sizeMB, ulMBps, efficiency);
  const estimateLine =
    `Estimated transfer time (${Math.round(efficiency * 100)}% efficiency): ` +
    `${estimateSizeGB} GB down ≈ ${estDownSec != null ? _formatDurationCompact(estDownSec) : 'N/A'} • ` +
    `${estimateSizeGB} GB up ≈ ${estUpSec != null ? _formatDurationCompact(estUpSec) : 'N/A'}`;

  const stats = {
    provider,
    download: `${_fmtInt(dlMbps)} Mbps (${_fmtNum(dlMBps, { digits: 1 })} MB/s)`,
    upload: `${_fmtInt(ulMbps)} Mbps (${_fmtNum(ulMBps, { digits: 1 })} MB/s)`,
    ping: `${_fmtInt(pingMs)} ms`,
    [`${estimateSizeGB}GB_download_estimate`]: estDownSec != null ? `≈ ${_formatDurationCompact(estDownSec)}` : 'N/A',
    [`${estimateSizeGB}GB_upload_estimate`]: estUpSec != null ? `≈ ${_formatDurationCompact(estUpSec)}` : 'N/A',
    estimateEfficiency: `${Math.round(efficiency * 100)}%`
  };

  const meta = {
    provider,
    downloadMbps: dlMbps,
    uploadMbps: ulMbps,
    pingMs,
    downloadMBps: dlMBps,
    uploadMBps: ulMBps,
    estimateSizeGB,
    estimateEfficiency: efficiency
  };

  return { summaryLine, estimateLine, stats, meta };
}

function _buildDriveReport(mode, payload = {}, opts = {}) {
  const m = String(mode || '').toLowerCase() || 'drive';
  const efficiency = Number.isFinite(Number(opts.efficiency)) ? Number(opts.efficiency) : 0.85;
  const estimateSizeTiB = Number.isFinite(Number(opts.estimateSizeTiB)) ? Number(opts.estimateSizeTiB) : 1;

  const write = _toFiniteNumber(payload.write);
  const writeMin = _toFiniteNumber(payload.writeMin);
  const writeMax = _toFiniteNumber(payload.writeMax);
  const read = _toFiniteNumber(payload.read);
  const readMin = _toFiniteNumber(payload.readMin);
  const readMax = _toFiniteNumber(payload.readMax);

  const label = (m === 'random') ? 'Random' : 'Sequential';
  const summaryLine =
    `Result (${label} Drive): ` +
    `Write ${_fmtNum(write, { digits: 1 })} MiB/s (min ${_fmtNum(writeMin, { digits: 1 })}, max ${_fmtNum(writeMax, { digits: 1 })}) • ` +
    `Read ${_fmtNum(read, { digits: 1 })} MiB/s (min ${_fmtNum(readMin, { digits: 1 })}, max ${_fmtNum(readMax, { digits: 1 })})`;

  // Use binary TiB/MiB for drive estimates (matches MiB/s).
  const sizeMiB = estimateSizeTiB * 1024 * 1024;
  const estWriteSec = _estimateSecondsFromMiB(sizeMiB, write, efficiency);
  const estReadSec = _estimateSecondsFromMiB(sizeMiB, read, efficiency);
  const estimateLine =
    `Estimated copy time (${Math.round(efficiency * 100)}% efficiency): ` +
    `${estimateSizeTiB} TiB to drive ≈ ${estWriteSec != null ? _formatDurationCompact(estWriteSec) : 'N/A'} • ` +
    `${estimateSizeTiB} TiB from drive ≈ ${estReadSec != null ? _formatDurationCompact(estReadSec) : 'N/A'}`;

  const stats = {
    mode: m,
    write: `${_fmtNum(write, { digits: 1 })} MiB/s (min ${_fmtNum(writeMin, { digits: 1 })}, max ${_fmtNum(writeMax, { digits: 1 })})`,
    read: `${_fmtNum(read, { digits: 1 })} MiB/s (min ${_fmtNum(readMin, { digits: 1 })}, max ${_fmtNum(readMax, { digits: 1 })})`,
    [`${estimateSizeTiB}TiB_write_estimate`]: estWriteSec != null ? `≈ ${_formatDurationCompact(estWriteSec)}` : 'N/A',
    [`${estimateSizeTiB}TiB_read_estimate`]: estReadSec != null ? `≈ ${_formatDurationCompact(estReadSec)}` : 'N/A',
    estimateEfficiency: `${Math.round(efficiency * 100)}%`
  };

  const meta = {
    mode: m,
    writeMiBps: write,
    writeMinMiBps: writeMin,
    writeMaxMiBps: writeMax,
    readMiBps: read,
    readMinMiBps: readMin,
    readMaxMiBps: readMax,
    estimateSizeTiB,
    estimateEfficiency: efficiency
  };

  return { summaryLine, estimateLine, stats, meta };
}

function _persistSpeedtestJobArtifacts({ jobLogger, jobId, senderId, inputs, settings, stats }) {
  let structuredLogPath = null;
  try {
    structuredLogPath = jobLogger.getStructuredLogPath?.() || null;
    if (!structuredLogPath) structuredLogPath = writeJobLogToFile('speed-test', jobId, jobLogger.getEntries());
  } catch (e) {
    console.warn('⚠️ Failed to persist speed-test JSONL log:', e?.message || e);
    structuredLogPath = null;
  }

  let archivePath = null;
  try {
    archivePath = writeJobTextToFile('speed-test', jobId, jobLogger.getEntries(), {
      structuredLogPath,
      inputs: {
        sourceCount: Number.isFinite(Number(inputs?.sampleCount)) ? Number(inputs.sampleCount) : '',
        sources: Array.isArray(inputs?.sampleFiles) ? inputs.sampleFiles : [],
        ...((inputs && typeof inputs === 'object') ? inputs : {})
      },
      settings: {
        mode: settings?.mode || 'benchmark',
        ...((settings && typeof settings === 'object') ? settings : {}),
        senderId: (typeof senderId !== 'undefined') ? senderId : ''
      },
      stats: stats || undefined
    });
  } catch (e) {
    console.warn('⚠️ Failed to persist speed-test TXT log:', e?.message || e);
    archivePath = null;
  }

  return { structuredLogPath, archivePath };
}

function getChromiumFallbackRoot() {
  return app.isPackaged
    ? path.join(process.resourcesPath, 'puppeteer')
    : path.join(app.getAppPath(), 'vendor', 'puppeteer');
}

function formatChromiumDependencyError(error) {
  const code = String(error?.code || '').trim();

  if (code === 'ASSET_OFFLINE_BLOCKED') {
    return 'Chromium browser dependency is not installed yet, and offline mode is enabled. Disable offline mode or pre-seed the browser asset, then retry.';
  }
  if (code === 'ASSET_CHECKSUM_MISMATCH') {
    return 'Chromium browser dependency failed checksum verification after download. Delete the staged browser asset and retry, or reinstall the app.';
  }
  if (code === 'ASSET_MISSING' || code === 'ASSET_UNKNOWN' || code === 'ASSET_MISSING_CHECKSUM' || code === 'ASSET_UNSUPPORTED_PLATFORM') {
    return 'Chromium browser dependency is not available for this build. Reinstall the app or publish the matching runtime asset, then retry.';
  }
  if (code === 'BROWSER_MISSING') {
    return 'Chromium browser executable was not found inside the installed runtime asset. Reinstall the app or refresh the browser asset and retry.';
  }

  return `Chromium browser dependency could not be prepared. ${error?.message || 'Unknown error.'}`;
}

async function findBundledChromium(cacheDir) {
  const chromeRoot = path.join(cacheDir, 'chrome');
  try {
    await fsp.access(chromeRoot, fs.constants.F_OK);
  } catch {
    return null;
  }

  const platform = os.platform();
  const targetNames = new Set(
    platform === 'win32'
      ? ['chrome.exe']
      : ['chrome', 'Chromium', 'Google Chrome for Testing']
  );
  const maxDepth = 4;

  const walk = async (dir, depth) => {
    if (depth < 0) return null;
    let entries;
    try {
      entries = await fsp.readdir(dir, { withFileTypes: true });
    } catch {
      return null;
    }

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isFile()) {
        if (targetNames.has(entry.name)) return fullPath;
        continue;
      }
      if (!entry.isDirectory()) continue;

      if (platform === 'darwin' && entry.name.endsWith('.app')) {
        const macOsDir = path.join(fullPath, 'Contents', 'MacOS');
        try {
          const macEntries = await fsp.readdir(macOsDir, { withFileTypes: true });
          for (const macEntry of macEntries) {
            if (macEntry.isFile()) return path.join(macOsDir, macEntry.name);
          }
        } catch {
          // ignore
        }
      }

      const found = await walk(fullPath, depth - 1);
      if (found) return found;
    }
    return null;
  };

  return walk(chromeRoot, maxDepth);
}

function registerSenderCleanup(sender) {
  if (!sender || typeof sender.once !== 'function') return;
  const senderId = sender.id;
  if (typeof senderId !== 'number' || cleanupRegisteredSenders.has(senderId)) return;

  cleanupRegisteredSenders.add(senderId);
  sender.once('destroyed', () => {
    cleanupRegisteredSenders.delete(senderId);

    const state = networkTestStateBySender.get(senderId);
    if (state && !state.done) {
      state.cancelled = true;
      try {
        if (state.child && !state.child.killed) state.child.kill();
      } catch {
        // ignore
      }
      try {
        if (state.timeoutId) clearTimeout(state.timeoutId);
      } catch {
        // ignore
      }
    }
    networkTestStateBySender.delete(senderId);

    setDriveTestCancelled(senderId, true);
    driveTestRunningBySender.delete(senderId);
    logReadStateBySender.delete(senderId);
  });
}

function clampInt(value, min, max) {
  const n = Math.floor(Number(value));
  if (!Number.isFinite(n)) return min;
  return Math.min(max, Math.max(min, n));
}

async function safeUnlink(filePath) {
  try {
    await fsp.unlink(filePath);
  } catch {
    // ignore
  }
}

async function ensureSpeedtestDir(basePath) {
  const dirPath = path.join(basePath, SPEEDTEST_DIRNAME);
  try {
    await fsp.mkdir(dirPath, { recursive: true });
  } catch {
    // ignore
  }
  return dirPath;
}

async function verifySpeedtestDirWritable(basePath) {
  const dirPath = await ensureSpeedtestDir(basePath);
  let activeMarkerPath = null;
  let runId;
  try {
    ({ markerPath: activeMarkerPath, runId } = await acquireSpeedtestMarker(dirPath, {
      tag: 'writecheck',
      pid: process.pid
    }));
  } catch (err) {
    if (err?.code === 'MARKER_CREATE_FAILED') {
      return {
        ok: false,
        code: 'MARKER_CREATE_FAILED',
        message: 'Unable to acquire speed-test lock marker.',
        error: err?.message || String(err)
      };
    }
    throw err;
  }

  const tmpName = `.__lead_speedtest_writecheck_${runId}.tmp`;
  const tmpPath = path.join(dirPath, tmpName);

  try {
    await fsp.writeFile(tmpPath, '1', { flag: 'wx' });
    return { ok: true };
  } catch (err) {
    return {
      ok: false,
      code: 'DRIVE_NOT_WRITABLE',
      message: 'Drive is read-only or lacks write permissions.',
      error: err?.message || String(err)
    };
  } finally {
    await safeUnlink(tmpPath);
    await releaseSpeedtestMarker(activeMarkerPath);
    await cleanupSpeedtestDirIfIdle(dirPath);
  }
}

function makeSpeedtestRunId(tag = '') {
  const safeTag = String(tag || '').replace(/[^a-z0-9_-]/gi, '').slice(0, 32);
  return `${process.pid}_${Date.now()}_${Math.random().toString(16).slice(2)}${safeTag ? `_${safeTag}` : ''}`;
}

function isSpeedtestTempFile(name) {
  return (
    name.startsWith('lead_speedtest_')
    || name.startsWith('.__lead_speedtest_writecheck_')
    || name.startsWith('.__lead_speedtest_random_')
    || name.startsWith('.__speedtest_')
  );
}

function isSpeedtestActiveMarker(name) {
  return name.startsWith(SPEEDTEST_ACTIVE_PREFIX);
}

function isProcessAlive(pid) {
  const n = Number(pid);
  if (!Number.isInteger(n) || n <= 0) return false;
  try {
    process.kill(n, 0);
    return true;
  } catch {
    return false;
  }
}

function classifyStaleMarker({ payload, stat, maxAgeMs }) {
  if (!payload || typeof payload !== 'object') return 'malformed_payload';

  const createdAtMs = Number(payload.createdAtMs || Date.parse(payload.createdAt || ''));
  if (!Number.isFinite(createdAtMs)) return 'malformed_created_at';
  if ((Date.now() - createdAtMs) > maxAgeMs) return 'marker_expired';

  if (payload.pid != null && !isProcessAlive(payload.pid)) return 'dead_pid';

  if (stat && Number.isFinite(stat.mtimeMs) && (Date.now() - stat.mtimeMs) > maxAgeMs) return 'marker_file_expired';
  return null;
}

async function pruneStaleSpeedtestActiveMarkers(dirPath, options = {}) {
  const maxAgeMs = options?.maxAgeMs ?? SPEEDTEST_MARKER_STALE_MAX_AGE_MS;
  const logger = options?.logger;

  try {
    const entries = await fsp.readdir(dirPath, { withFileTypes: true });
    let reclaimedCount = 0;
    await Promise.all(entries.map(async (entry) => {
      if (!entry.isFile() || !isSpeedtestActiveMarker(entry.name)) return;

      const markerPath = path.join(dirPath, entry.name);
      let stat = null;
      try {
        stat = await fsp.stat(markerPath);
      } catch {
        return;
      }

      let payload = null;
      try {
        const raw = await fsp.readFile(markerPath, 'utf8');
        payload = JSON.parse(raw);
      } catch {
        // leave payload null to classify malformed markers
      }

      const reason = classifyStaleMarker({ payload, stat, maxAgeMs });
      if (!reason) return;

      logger?.warn?.('Reclaimed stale speedtest marker', {
        reason,
        markerPath,
        runId: payload?.runId || null,
        senderTag: payload?.senderTag || null,
        senderId: payload?.senderId ?? null,
        jobId: payload?.jobId || null,
        pid: payload?.pid ?? null
      });

      await safeUnlink(markerPath);
      reclaimedCount += 1;
    }));

    if (reclaimedCount > 0) {
      logger?.info?.('Completed stale speedtest marker cleanup', { dirPath, reclaimedCount });
    }
  } catch {
    // ignore
  }
}

async function cleanupStaleSpeedtestFiles(dirPath, minAgeMs = SPEEDTEST_STALE_MIN_AGE_MS, options = {}) {
  try {
    await pruneStaleSpeedtestActiveMarkers(dirPath, options);
    const entries = await fsp.readdir(dirPath, { withFileTypes: true });
    if (entries.some(entry => entry.isFile() && isSpeedtestActiveMarker(entry.name))) return;
    const staleBeforeMs = Date.now() - Math.max(0, Number(minAgeMs) || 0);

    await Promise.all(entries.map(async entry => {
      if (!entry.isFile()) return;
      if (!isSpeedtestTempFile(entry.name)) return;

      const entryPath = path.join(dirPath, entry.name);
      let stat;
      try {
        stat = await fsp.stat(entryPath);
      } catch {
        return;
      }
      if (!stat?.isFile?.() || stat.mtimeMs > staleBeforeMs) return;
      await safeUnlink(entryPath);
    }));
  } catch {
    // ignore
  }
}

async function createSpeedtestActiveMarker(dirPath, metadata = {}) {
  const runId = metadata?.runId || makeSpeedtestRunId(metadata?.tag || '');
  const name = `${SPEEDTEST_ACTIVE_PREFIX}${runId}.lock`;
  const markerPath = path.join(dirPath, name);
  const payload = {
    runId,
    tag: metadata?.tag || '',
    senderTag: metadata?.senderTag || '',
    senderId: metadata?.senderId ?? null,
    jobId: metadata?.jobId || '',
    pid: process.pid,
    createdAtMs: Date.now(),
    createdAt: new Date().toISOString()
  };
  try {
    await fsp.writeFile(markerPath, JSON.stringify(payload), { flag: 'wx' });
  } catch (error) {
    const markerError = new Error(`Failed to create speedtest marker: ${error?.message || String(error)}`);
    markerError.code = 'MARKER_CREATE_FAILED';
    markerError.cause = error;
    markerError.markerPath = markerPath;
    markerError.runId = runId;
    throw markerError;
  }
  return { markerPath, runId };
}

const defaultSpeedtestLockStrategy = {
  acquireMarker: createSpeedtestActiveMarker,
  releaseMarker: async (markerPath) => {
    if (markerPath) await safeUnlink(markerPath);
  }
};

let speedtestLockStrategy = { ...defaultSpeedtestLockStrategy };

function acquireSpeedtestMarker(dirPath, metadata = {}) {
  return speedtestLockStrategy.acquireMarker(dirPath, metadata);
}

async function releaseSpeedtestMarker(markerPath) {
  await speedtestLockStrategy.releaseMarker(markerPath);
}

function setSpeedtestLockStrategyForTests(strategy = {}) {
  speedtestLockStrategy = {
    ...defaultSpeedtestLockStrategy,
    ...(strategy || {})
  };
}

function resetSpeedtestLockStrategyForTests() {
  speedtestLockStrategy = { ...defaultSpeedtestLockStrategy };
}

async function cleanupSpeedtestDirIfIdle(dirPath, options = {}) {
  try {
    await pruneStaleSpeedtestActiveMarkers(dirPath, options);
    let entries = await fsp.readdir(dirPath, { withFileTypes: true });

    // If another test is still active in this dir, don't touch it.
    if (entries.some(e => e.isFile() && isSpeedtestActiveMarker(e.name))) return;

    await Promise.all(entries.map(async entry => {
      if (!entry.isFile()) return;
      const name = entry.name;
      if (isSpeedtestTempFile(name) || SPEEDTEST_OS_JUNK.has(name)) {
        await safeUnlink(path.join(dirPath, name));
      }
    }));

    entries = await fsp.readdir(dirPath, { withFileTypes: true });
    if (entries.some(e => e.isFile() && isSpeedtestActiveMarker(e.name))) return;
    if (entries.length !== 0) return;

    await fsp.rmdir(dirPath);
    options?.logger?.info?.('Removed idle speedtest directory', { dirPath });
  } catch {
    // ignore
  }
}

function formatBytesBinary(bytes) {
  const n = Number(bytes);
  if (!Number.isFinite(n)) return String(bytes);
  const abs = Math.abs(n);
  const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB'];
  let unitIdx = 0;
  let value = abs;
  while (value >= 1024 && unitIdx < units.length - 1) {
    value /= 1024;
    unitIdx += 1;
  }
  const decimals = unitIdx >= 3 ? 1 : 0; // show 1 decimal for GiB+; integers for smaller
  return `${value.toFixed(decimals)} ${units[unitIdx]}`;
}

async function preflightDriveTestDiskSpace({ safeDrivePath, mode, testSizeMiB }) {
  const sizeMiB = clampInt(testSizeMiB, 1, 2048);
  const fileSizeBytes = sizeMiB * BYTES_PER_MIB;
  const sequentialPeakTempBytes = SEQUENTIAL_BENCHMARK_TEMP_FILE_COUNT * fileSizeBytes;
  const peakTempBytes = mode === 'sequential' ? sequentialPeakTempBytes : fileSizeBytes;
  const safetyBytes = Math.max(
    DISK_SPACE_SAFETY_MIN_BYTES,
    Math.ceil(peakTempBytes * DISK_SPACE_SAFETY_FRACTION)
  );
  const requiredBytes = peakTempBytes + safetyBytes;

  let warning = null;
  let freeBytes;
  let totalBytes;
  try {
    const { free, size } = await checkDiskSpace(safeDrivePath);
    freeBytes = free;
    totalBytes = size;
    if (typeof free === 'number' && free >= 0 && free < requiredBytes) {
      return {
        ok: false,
        code: 'INSUFFICIENT_DISK_SPACE',
        freeBytes: free,
        totalBytes: size,
        requiredBytes,
        peakTempBytes,
        safetyBytes,
        testSizeMiB: sizeMiB,
        mode
      };
    }
    warning = null;
  } catch (err) {
    warning = {
      code: 'DISK_SPACE_CHECK_FAILED',
      error: err?.message || String(err)
    };
  }

  const writeCheck = await verifySpeedtestDirWritable(safeDrivePath);
  if (!writeCheck.ok) {
    return writeCheck;
  }

  return {
    ok: true,
    freeBytes,
    totalBytes,
    requiredBytes,
    peakTempBytes,
    safetyBytes,
    warning: warning || undefined
  };
}

const defaultDriveTestPreflightStrategy = {
  run: preflightDriveTestDiskSpace
};

let driveTestPreflightStrategy = { ...defaultDriveTestPreflightStrategy };

async function runDriveTestPreflight(options) {
  return driveTestPreflightStrategy.run(options);
}

function setDriveTestPreflightStrategyForTests(strategy = {}) {
  driveTestPreflightStrategy = {
    ...defaultDriveTestPreflightStrategy,
    ...(strategy || {})
  };
}

function resetDriveTestPreflightStrategyForTests() {
  driveTestPreflightStrategy = { ...defaultDriveTestPreflightStrategy };
}

function setDriveTestCancelled(senderId, value) {
  if (typeof senderId !== 'number') return;
  driveTestCancelBySender.set(senderId, !!value);
}

function isDriveTestCancelled(senderId) {
  return driveTestCancelBySender.get(senderId) === true;
}

function getDriveTestHelpers(event) {
  registerSenderCleanup(event?.sender);
  const senderId = event?.sender?.id;

  const safeSend = (channel, payload) => {
    if (!event?.sender || event.sender.isDestroyed()) return false;
    try {
      event.sender.send(channel, payload);
      return true;
    } catch (err) {
      if (err?.message?.includes('Object has been destroyed')) return false;
      throw err;
    }
  };

  const throwIfCancelled = () => {
    if (isDriveTestCancelled(senderId)) {
      const err = new Error('Drive test cancelled');
      err.code = 'DRIVE_TEST_CANCELLED';
      throw err;
    }
  };

  const sendProgress = bytes => {
    if (isDriveTestCancelled(senderId)) return;
    safeSend('drive-test-progress', { bytes });
  };

  return { senderId, throwIfCancelled, sendProgress, safeSend };
}



function getDialogParentWindow(event) {
  try {
    const wc = event?.sender;
    if (!wc) return null;
    return BrowserWindow.fromWebContents(wc) || null;
  } catch {
    return null;
  }
}

function clampDialogIndex(value, fallback, maxIndex) {
  const parsed = Number(value);
  if (!Number.isInteger(parsed)) return fallback;
  if (parsed < 0 || parsed > maxIndex) return fallback;
  return parsed;
}

function sanitizeDialogText(value, fallback = '', maxLength = 4000) {
  if (value == null) return fallback;
  const normalized = String(value).trim();
  if (!normalized) return fallback;
  return normalized.slice(0, maxLength);
}

function sanitizeDialogButtons(buttons) {
  if (!Array.isArray(buttons)) return ['OK'];
  const normalized = buttons
    .map((label) => sanitizeDialogText(label, '', 80))
    .filter(Boolean)
    .slice(0, 5);
  return normalized.length ? normalized : ['OK'];
}

function normalizeMessageDialogOptions(input) {
  const raw = (input && typeof input === 'object' && !Array.isArray(input))
    ? input
    : { message: input };

  const buttons = sanitizeDialogButtons(raw.buttons);
  const maxIndex = Math.max(0, buttons.length - 1);
  const normalized = {
    type: ['none', 'info', 'error', 'question', 'warning'].includes(raw.type) ? raw.type : 'none',
    title: sanitizeDialogText(raw.title, 'LEAD AE - ASSIST', 160),
    message: sanitizeDialogText(raw.message, 'Notice'),
    detail: sanitizeDialogText(raw.detail, '', 8000),
    buttons,
    defaultId: clampDialogIndex(raw.defaultId, 0, maxIndex),
    cancelId: clampDialogIndex(raw.cancelId, 0, maxIndex),
    noLink: true
  };

  const checkboxLabel = sanitizeDialogText(raw.checkboxLabel, '', 200);
  if (checkboxLabel) normalized.checkboxLabel = checkboxLabel;
  return normalized;
}

async function showNativeMessageDialog(event, rawOptions) {
  const dialogOptions = normalizeMessageDialogOptions(rawOptions);
  const parentWindow = getDialogParentWindow(event);
  const result = parentWindow
    ? await dialog.showMessageBox(parentWindow, dialogOptions)
    : await dialog.showMessageBox(dialogOptions);

  return {
    response: clampDialogIndex(result?.response, dialogOptions.defaultId, dialogOptions.buttons.length - 1),
    checkboxChecked: !!result?.checkboxChecked
  };
}

function normalizeConfirmDialogInput(input) {
  if (input && typeof input === 'object' && !Array.isArray(input)) {
    return input;
  }
  return { message: input };
}

function normalizeConfirmDialogOptions(input) {
  const raw = normalizeConfirmDialogInput(input);
  const cancelLabel = sanitizeDialogText(raw.cancelLabel, 'Cancel', 80);
  const okLabel = sanitizeDialogText(raw.okLabel, 'Yes', 80);
  const buttons = raw.buttons && Array.isArray(raw.buttons)
    ? sanitizeDialogButtons(raw.buttons)
    : [cancelLabel, okLabel];
  const okButtonIndex = buttons.length > 1 ? buttons.length - 1 : 0;
  const fallbackTitle = raw.title
    ? sanitizeDialogText(raw.title, 'Confirm', 160)
    : 'Confirm';

  return {
    okButtonIndex,
    dialogOptions: normalizeMessageDialogOptions({
      type: ['warning', 'question', 'info', 'error', 'none'].includes(raw.type) ? raw.type : 'warning',
      title: fallbackTitle,
      message: sanitizeDialogText(raw.message, 'Are you sure?'),
      detail: sanitizeDialogText(raw.detail, '', 8000),
      buttons,
      defaultId: clampDialogIndex(raw.defaultId, okButtonIndex, buttons.length - 1),
      cancelId: clampDialogIndex(raw.cancelId, 0, buttons.length - 1),
      checkboxLabel: sanitizeDialogText(raw.checkboxLabel, '', 200)
    })
  };
}

function registerMiscHandlers(ipcMain, context = {}) {
  // ---- Sandbox-safe sync endpoints (used by preload) ----
  ipcMain.on('app:get-info-sync', (event) => {
    try {
      assertTrustedIpcSender(event, 'app:get-info-sync');
      _okSync(event, {
        isPackaged: !!app.isPackaged,
        debugUI: process.env.DEBUG_UI === 'true',
        platform: process.platform,
        pathSep: path.sep
      });
    } catch (err) {
      _denySync(event, err?.message || err);
    }
  });

  ipcMain.on('app:get-user-data-path-sync', (event) => {
    try {
      assertTrustedIpcSender(event, 'app:get-user-data-path-sync');
      _okSync(event, resolveCanonicalUserDataPath());
    } catch (err) {
      _denySync(event, err?.message || err);
    }
  });

  ipcMain.on('path:joinSync', (event, ...parts) => {
    try {
      assertTrustedIpcSender(event, 'path:joinSync');
      _okSync(event, path.join(...(parts || [])));
    } catch (err) {
      _denySync(event, err?.message || err);
    }
  });

  ipcMain.on('path:basenameSync', (event, targetPath, ext) => {
    try {
      assertTrustedIpcSender(event, 'path:basenameSync');
      _okSync(event, path.basename(String(targetPath || ''), ext));
    } catch (err) {
      _denySync(event, err?.message || err);
    }
  });

  ipcMain.on('path:resolveSync', (event, ...parts) => {
    try {
      assertTrustedIpcSender(event, 'path:resolveSync');
      _okSync(event, path.resolve(...(parts || [])));
    } catch (err) {
      _denySync(event, err?.message || err);
    }
  });

  ipcMain.on('path:extnameSync', (event, targetPath) => {
    try {
      assertTrustedIpcSender(event, 'path:extnameSync');
      _okSync(event, path.extname(String(targetPath || '')));
    } catch (err) {
      _denySync(event, err?.message || err);
    }
  });

  ipcMain.on('path:relativeSync', (event, fromPath, toPath) => {
    try {
      assertTrustedIpcSender(event, 'path:relativeSync');
      _okSync(event, path.relative(String(fromPath || ''), String(toPath || '')));
    } catch (err) {
      _denySync(event, err?.message || err);
    }
  });

  ipcMain.on('path:dirnameSync', (event, targetPath) => {
    try {
      assertTrustedIpcSender(event, 'path:dirnameSync');
      _okSync(event, path.dirname(String(targetPath || '')));
    } catch (err) {
      _denySync(event, err?.message || err);
    }
  });

  ipcMain.on('path:isAbsoluteSync', (event, targetPath) => {
    try {
      assertTrustedIpcSender(event, 'path:isAbsoluteSync');
      _okSync(event, path.isAbsolute(String(targetPath || '')));
    } catch (err) {
      _denySync(event, err?.message || err);
    }
  });

  // Async path handlers for renderer hot paths (avoid sendSync in loops).
  ipcMain.handle('path:join', async (event, ...parts) => {
    assertTrustedIpcSender(event, 'path:join');
    return { ok: true, value: path.join(...(parts || [])) };
  });

  ipcMain.handle('path:basename', async (event, targetPath, ext) => {
    assertTrustedIpcSender(event, 'path:basename');
    return { ok: true, value: path.basename(String(targetPath || ''), ext) };
  });

  ipcMain.handle('path:resolve', async (event, ...parts) => {
    assertTrustedIpcSender(event, 'path:resolve');
    return { ok: true, value: path.resolve(...(parts || [])) };
  });

  ipcMain.handle('path:extname', async (event, targetPath) => {
    assertTrustedIpcSender(event, 'path:extname');
    return { ok: true, value: path.extname(String(targetPath || '')) };
  });

  ipcMain.handle('path:relative', async (event, fromPath, toPath) => {
    assertTrustedIpcSender(event, 'path:relative');
    return { ok: true, value: path.relative(String(fromPath || ''), String(toPath || '')) };
  });

  ipcMain.handle('path:dirname', async (event, targetPath) => {
    assertTrustedIpcSender(event, 'path:dirname');
    return { ok: true, value: path.dirname(String(targetPath || '')) };
  });

  ipcMain.handle('path:isAbsolute', async (event, targetPath) => {
    assertTrustedIpcSender(event, 'path:isAbsolute');
    return { ok: true, value: path.isAbsolute(String(targetPath || '')) };
  });

  // Transcript/export helpers (sync) — deterministic, no IO, safe to run in main.
  const _registerTranscribeEngineSync = (channel, methodName) => {
    ipcMain.on(channel, (event, ...args) => {
      try {
        assertTrustedIpcSender(event, channel);
        const engine = getTranscribeEngineOrThrow();
        const fn = engine?.[methodName];
        if (typeof fn !== 'function') {
          throw new Error(`Missing transcribeEngine.${methodName}`);
        }
        _okSync(event, fn(...args));
      } catch (err) {
        _denySync(event, err?.message || err);
      }
    });
  };

  const _registerTranscribeEngineAsync = (channel, methodName) => {
    ipcMain.handle(channel, async (event, ...args) => {
      assertTrustedIpcSender(event, channel);
      const engine = getTranscribeEngineOrThrow();
      const fn = engine?.[methodName];
      if (typeof fn !== 'function') {
        throw new Error(`Missing transcribeEngine.${methodName}`);
      }
      return await Promise.resolve(fn(...args));
    });
  };

  _registerTranscribeEngineSync('transcribeEngine:generatePlainTextSync', 'generatePlainText');
  _registerTranscribeEngineSync('transcribeEngine:generateSRTSync', 'generateSRT');
  _registerTranscribeEngineSync('transcribeEngine:generateVTTSync', 'generateVTT');
  _registerTranscribeEngineSync('transcribeEngine:generateSyncableScriptCSVSync', 'generateSyncableScriptCSV');
  _registerTranscribeEngineSync('transcribeEngine:generateMarkersTXTSync', 'generateMarkersTXT');
  _registerTranscribeEngineSync('transcribeEngine:generateXMLSync', 'generateXML');
  _registerTranscribeEngineSync('transcribeEngine:generateSegmentTextWithTokenTimingSync', 'generateSegmentTextWithTokenTiming');

  _registerTranscribeEngineSync('transcribeEngine:parseTimeSync', 'parseTime');
  _registerTranscribeEngineSync('transcribeEngine:parseTimecodeSync', 'parseTimecode');
  _registerTranscribeEngineSync('transcribeEngine:msToTCSync', 'msToTC');
  _registerTranscribeEngineSync('transcribeEngine:formatTimecodesSync', 'formatTimecodes');
  _registerTranscribeEngineSync('transcribeEngine:formatTimecodeSync', 'formatTimecode');

  // Subtitle Editor helpers (optional, but keeping parity avoids regressions)
  _registerTranscribeEngineSync('transcribeEngine:generateSCCSync', 'generateSCC');
  _registerTranscribeEngineSync('transcribeEngine:wrap608Sync', 'wrap608');
  _registerTranscribeEngineSync('transcribeEngine:wrap608WithMetaSync', 'wrap608WithMeta');
  _registerTranscribeEngineSync('transcribeEngine:validateMccContentQcSync', 'validateMccContentQc');
  _registerTranscribeEngineSync('transcribeEngine:validateSccContentQcSync', 'validateSccContentQc');

  // Async parity channels for heavy transcript/subtitle payload workflows.
  _registerTranscribeEngineAsync('transcribeEngine:generateSRT', 'generateSRT');
  _registerTranscribeEngineAsync('transcribeEngine:generateVTT', 'generateVTT');
  _registerTranscribeEngineAsync('transcribeEngine:generateSCC', 'generateSCC');
  _registerTranscribeEngineAsync('transcribeEngine:generateSegmentTextWithTokenTiming', 'generateSegmentTextWithTokenTiming');
  _registerTranscribeEngineAsync('transcribeEngine:validateMccContentQc', 'validateMccContentQc');
  _registerTranscribeEngineAsync('transcribeEngine:validateSccContentQc', 'validateSccContentQc');
  ipcMain.handle('start-watch-folder', async (event, config) => {
    assertTrustedIpcSender(event, 'start-watch-folder');
    try {
      const senderId = event?.sender?.id;
      const panelConfig = (config?.panelConfig && typeof config.panelConfig === 'object')
        ? config.panelConfig
        : {};

      const normalizePaths = (paths) => paths
        .map(p => toLocalPathIfFileUrl(String(p ?? '').trim()))
        .filter(Boolean);

      const candidatePaths = [];
      const addCandidate = (value) => {
        if (typeof value === 'string' && value.trim()) {
          candidatePaths.push(value.trim());
        }
      };

      // Enforce approved-roots policy: watch folder must be inside userData or a user-approved root.
      const watchFolder =
        config?.folder ||
        config?.watchFolder ||
        panelConfig?.folder ||
        panelConfig?.watchFolder;
      if (watchFolder) {
        assertApprovedPath(senderId, toLocalPathIfFileUrl(String(watchFolder).trim()));
      }

      addCandidate(config?.folder);
      addCandidate(config?.watchFolder);
      addCandidate(config?.destination);
      addCandidate(config?.backupPath);
      addCandidate(config?.outputFolder);
      addCandidate(config?.outputPath);
      addCandidate(config?.source);
      addCandidate(panelConfig?.destination);
      addCandidate(panelConfig?.backupPath);
      addCandidate(panelConfig?.outputFolder);
      addCandidate(panelConfig?.outputPath);
      addCandidate(panelConfig?.source);

      // Deep scan panelConfig for any absolute paths (outputFolder, destination, LUT path, etc)
      // and enforce that they are inside approved roots.
      const nestedPaths = extractAbsolutePathsFromObject(config || {});
      const normalizedCandidates = normalizePaths(candidatePaths);
      const normalizedNested = normalizePaths(nestedPaths);
      assertApprovedPaths(senderId, [...normalizedCandidates, ...normalizedNested]);
    } catch (err) {
      const message = err?.message || String(err);
      return {
        success: false,
        error: {
          message,
          code: 'ERR_WATCH_PATH_VALIDATION'
        },
        message
      };
    }

    // Watch Mode performance: resolve Auto Threads once at watch start (cache-backed)
    // and inject the computed thread count into the stored watch config.
    // This avoids running a disk benchmark per watch-triggered ingest job.
    let patchedConfig = config;
    try {
      const panel = String(config?.panel || '').toLowerCase();
      const panelCfg = (config?.panelConfig && typeof config.panelConfig === 'object') ? config.panelConfig : null;

      const isWatch = !!(panelCfg?.watchMode || config?.watchMode);
      const wantsAutoThreads = !!(panelCfg?.enableThreads && panelCfg?.autoThreads);

      const rawMaxThreads = panelCfg?.maxThreads ?? config?.maxThreads;
      const parsedMaxThreads = Number(rawMaxThreads);
      const hasManualThreads = Number.isFinite(parsedMaxThreads) && parsedMaxThreads > 0;

      if (panel === 'ingest' && isWatch && wantsAutoThreads && !hasManualThreads) {
        const destFolder = String(panelCfg?.destination || config?.destination || '').trim();
        if (destFolder) {
          let speedMiBps = null;
          let autoSelected = 3;
          try {
            speedMiBps = await estimateDiskWriteSpeed(destFolder);
            if (!Number.isFinite(speedMiBps)) {
              throw new Error('Non-finite disk benchmark speed');
            }
            autoSelected =
              speedMiBps < 50  ? 2 :
              speedMiBps < 100 ? 3 :
              speedMiBps < 200 ? 4 :
                              5;
          } catch {
            // If benchmarking fails, fall back to a conservative default.
            speedMiBps = null;
            autoSelected = 3;
          }

          const watchThreads = Math.min(4, Math.max(1, parseInt(autoSelected, 10) || 1));

          // Avoid mutating the caller-owned config object; clone before patching.
          patchedConfig = { ...config };
          patchedConfig.panelConfig = { ...(panelCfg || {}) };

          // Preserve the semantic intent (autoThreads=true), but inject a concrete maxThreads
          // so downstream watch-triggered jobs don't auto-benchmark on every enqueue.
          patchedConfig.maxThreads = watchThreads;
          patchedConfig.panelConfig.maxThreads = watchThreads;
          patchedConfig.panelConfig.autoThreadsResolved = true;
          if (Number.isFinite(speedMiBps)) {
            patchedConfig.panelConfig.autoThreadsResolvedSpeedMiBps = speedMiBps;
          }
        }
      }
    } catch {
      // Never block watch start due to auto-thread resolution.
    }

    if (typeof context.startWatchFolder === 'function') {
      return context.startWatchFolder(patchedConfig);
    }
    return { success: false, error: 'Watch folder controls unavailable.' };
  });

  ipcMain.handle('stop-watch-folder', async (event, panel) => {
    assertTrustedIpcSender(event, 'stop-watch-folder');
    if (typeof context.stopWatchFolder === 'function') {
      return context.stopWatchFolder(panel);
    }
    return '🛑 Watcher unavailable.';
  });

  ipcMain.handle('updates:get-status', (event) => {
    assertTrustedIpcSender(event, 'updates:get-status');
    return autoUpdateService.getLastStatus();
  });

  ipcMain.handle('updates:check', async (event) => {
    assertTrustedIpcSender(event, 'updates:check');
    try {
      const result = await autoUpdateService.checkForUpdates();
      return { ...(result || {}), ok: !!result?.ok, error: result?.error || null };
    } catch (err) {
      return { ok: false, error: toIpcSafeError(err, 'Unable to check for updates') };
    }
  });

  ipcMain.handle('updates:download', async (event) => {
    assertTrustedIpcSender(event, 'updates:download');
    try {
      const result = await autoUpdateService.downloadUpdate();
      return { ...(result || {}), ok: !!result?.ok, error: result?.error || null };
    } catch (err) {
      return { ok: false, error: toIpcSafeError(err, 'Unable to download update') };
    }
  });

  ipcMain.handle('updates:quit-and-install', async (event) => {
    assertTrustedIpcSender(event, 'updates:quit-and-install');
    try {
      autoUpdateService.quitAndInstall();
      return { ok: true, error: null };
    } catch (err) {
      return { ok: false, error: toIpcSafeError(err, 'Unable to install update') };
    }
  });

  ipcMain.handle('select-folder', async (event, options) => {
    assertTrustedIpcSender(event, 'select-folder');
    const result = await dialog.showOpenDialog({
      ...(options || {}),
      properties: ['openDirectory']
    });
    const picked = result.canceled ? null : result.filePaths[0];
    if (picked) approveRoot(event?.sender?.id, picked, 'dir');
    return picked;
  });

  ipcMain.handle('select-files', async (event, options) => {
    assertTrustedIpcSender(event, 'select-files');
    const result = await dialog.showOpenDialog({
      ...(options || {}),
      properties: ['openFile', 'multiSelections']
    });
    const picked = result.canceled ? null : result.filePaths;
    if (Array.isArray(picked) && picked.length) approveMany(event?.sender?.id, picked, 'file');
    return picked;
  });

  ipcMain.handle('select-folder-or-files', async (event, options) => {
    assertTrustedIpcSender(event, 'select-folder-or-files');
    const result = await dialog.showOpenDialog({
      ...(options || {}),
      properties: ['openFile', 'openDirectory', 'multiSelections']
    });
    const picked = result.canceled ? null : result.filePaths;
    if (Array.isArray(picked) && picked.length) {
      for (const p of picked) {
        // Determine type best-effort (directories vs files).
        let kind = 'file';
        try {
          const st = fs.statSync(p);
          kind = st.isDirectory() ? 'dir' : 'file';
        } catch {
          kind = 'file';
        }
        approveRoot(event?.sender?.id, p, kind);
      }
    }
    return picked;
  });

  // Approve one or more absolute filesystem paths for this renderer/webContents.
  //
  // Why this exists:
  // - Some UI workflows (notably drag-and-drop) can surface absolute file paths
  //   in the renderer without going through a main-process dialog.
  // - Our queue ingestion rejects any config containing unapproved absolute paths
  //   (defense-in-depth against compromised renderer input).
  //
  // This IPC endpoint lets the renderer ask the main process to explicitly
  // approve paths for the current session. Keep it tight:
  // - Trusted sender only
  // - Absolute paths only
  // - Optional native confirmation prompt
  ipcMain.handle('approve-paths', async (event, paths, options = {}) => {
    assertTrustedIpcSender(event, 'approve-paths');

    const senderId = event?.sender?.id;
    const kindHint = options?.kindHint || options?.kind || 'file';
    const confirm = options?.confirm !== false; // default: confirm

    const list = Array.isArray(paths) ? paths : [paths];
    const cleaned = [];

    // Reject network schemes early (http:, https:, etc.). Allow file:.
    assertNoNetworkSchemes(list);

    for (const item of list) {
      const raw = typeof item === 'string' ? item.trim() : String(item ?? '').trim();
      if (!raw) continue;

      const local = toLocalPathIfFileUrl(raw);
      // Require absolute paths (prevents cwd-based traversal).
      try {
        if (!path.isAbsolute(local)) continue;
      } catch {
        continue;
      }

      cleaned.push(local);
    }

    if (!cleaned.length) return [];

    // Optional user confirmation: blocks silent approval from renderer code.
    if (confirm) {
      const previewMax = 12;
      const preview = cleaned
        .slice(0, previewMax)
        .map(p => `• ${p}`)
        .join('\n');
      const more = cleaned.length > previewMax
        ? `\n… and ${cleaned.length - previewMax} more.`
        : '';

      const { response } = await dialog.showMessageBox({
        type: 'warning',
        buttons: ['Cancel', 'Allow'],
        defaultId: 1,
        cancelId: 0,
        title: 'Allow File Access',
        message: `Allow Lead AE Assist to access ${cleaned.length} path(s) you selected?`,
        detail: `${preview}${more}`
      });

      if (response !== 1) return [];
    }

    // Approve each path.
    for (const p of cleaned) {
      try {
        // If kindHint is 'auto', determine file vs dir.
        if (kindHint === 'auto') {
          let kind = 'file';
          try {
            const st = fs.statSync(p);
            kind = st.isDirectory() ? 'dir' : 'file';
          } catch {
            kind = 'file';
          }
          approveRoot(senderId, p, kind);
        } else {
          approveRoot(senderId, p, kindHint);
        }
      } catch {
        // best-effort; don't fail the whole batch if one path is weird
      }
    }

    return cleaned;
  });

  ipcMain.handle('save-file-dialog', async (event, options) => {
    assertTrustedIpcSender(event, 'save-file-dialog');
    const fileDialogResult = await dialog.showSaveDialog(options || {});
    const picked = fileDialogResult.canceled ? null : fileDialogResult.filePath;
    if (picked) {
      // Save dialogs often lead to writing multiple sibling outputs (e.g., .srt + .vtt + .json)
      // and storing outputDir in session state. Approve the parent directory so subsequent
      // writes and IPC payloads that include outputDir don't get rejected.
      try { approveRoot(event?.sender?.id, path.dirname(picked), 'dir'); } catch {}
      approveRoot(event?.sender?.id, picked, 'file');
    }
    return picked;
  });

  ipcMain.handle('open-file-dialog', async (event, options) => {
    assertTrustedIpcSender(event, 'open-file-dialog');
    const opts = { ...(options || {}), properties: ['openFile'] };
    const fileDialogResult = await dialog.showOpenDialog(opts);
    const picked = fileDialogResult.canceled ? null : fileDialogResult.filePaths[0];
    if (picked) approveRoot(event?.sender?.id, picked, 'file');
    return picked;
  });

  ipcMain.handle('app:get-version', async (event) => {
    try {
      assertTrustedIpcSender(event, 'app:get-version');
      return app.getVersion();
    } catch {
      return '';
    }
  });


  // Extended version/specs endpoint used by Account ▸ Version & Build panel.
  // Keep this payload deterministic + safe to share in bug reports.
  ipcMain.handle('app:get-version-specs', async (event) => {
    try {
      assertTrustedIpcSender(event, 'app:get-version-specs');

      const appPath = (() => {
        try { return app.getAppPath(); } catch { return process.cwd(); }
      })();

      const readJson = (p) => {
        try {
          const raw = fs.readFileSync(p, 'utf8');
          return JSON.parse(raw);
        } catch {
          return null;
        }
      };

      const pkg = readJson(path.join(appPath, 'package.json')) || {};
      const declaredDeps = (pkg && typeof pkg.dependencies === 'object') ? pkg.dependencies : {};

      const findNearestPackageJson = (resolvedEntry) => {
        try {
          let dir = path.dirname(String(resolvedEntry || ''));
          let guard = 0;
          while (dir && guard < 25) {
            const candidate = path.join(dir, 'package.json');
            if (fs.existsSync(candidate)) return candidate;
            const parent = path.dirname(dir);
            if (!parent || parent === dir) break;
            dir = parent;
            guard += 1;
          }
        } catch {
          // ignore
        }
        return null;
      };

      const getInstalledVersion = (pkgName) => {
        const name = String(pkgName || '').trim();
        if (!name) return null;

        // Preferred: resolve entry, then walk up to package.json.
        try {
          const entry = require.resolve(name);
          const pkgPath = findNearestPackageJson(entry);
          if (pkgPath) {
            const data = readJson(pkgPath);
            if (data && typeof data.version === 'string' && data.version.trim()) {
              return data.version.trim();
            }
          }
        } catch {
          // ignore
        }

        // Fallback: direct require (may fail due to package "exports").
        try {
          const data = require(`${name}/package.json`);
          if (data && typeof data.version === 'string' && data.version.trim()) {
            return data.version.trim();
          }
        } catch {
          // ignore
        }

        return null;
      };

      // Keep this list short + high-signal.
      const keyDeps = [
        'openai',
        'electron-updater',
        '@sentry/electron',
        'i18next',
        'ws',
        'chokidar',
        'uuid',
        'xxhash-wasm',
        '@napi-rs/blake-hash',
        'dotenv',
        'p-queue',
        'electron-log',
        'check-disk-space'
      ];

      const deps = {};
      for (const depName of keyDeps) {
        const installed = getInstalledVersion(depName);
        const declared = declaredDeps ? declaredDeps[depName] : null;
        deps[depName] = installed || (typeof declared === 'string' ? declared : '') || '';
      }

      const specs = {
        productName: pkg.productName || app.getName(),
        appVersion: (() => { try { return app.getVersion(); } catch { return pkg.version || ''; } })(),
        isPackaged: !!app.isPackaged,
        nodeEnv: String(process.env.NODE_ENV || ''),
        debugUI: String(process.env.DEBUG_UI || '').trim() === 'true',
        platform: process.platform,
        arch: process.arch,
        osRelease: (() => { try { return os.release(); } catch { return ''; } })(),
        osVersion: (() => { try { return typeof os.version === 'function' ? os.version() : ''; } catch { return ''; } })(),
        runtime: {
          electron: process.versions?.electron || '',
          chrome: process.versions?.chrome || '',
          node: process.versions?.node || '',
          v8: process.versions?.v8 || ''
        },
        deps
      };

      return { ok: true, value: specs };
    } catch (err) {
      return { ok: false, error: toIpcSafeError(err, 'Unable to read version specs') };
    }
  });



// ---- Preferences ▸ Maintenance (App-owned temp/cache/logs) ----
// IMPORTANT: The Preferences panel must reflect the actual folders the app uses.
// This app stores its own temp artifacts inside userData/LeadAEAssist/temp (not os.tmpdir()).
const resolveAppTempDir = () => ensureUserDataSubdir('temp');

const formatBytes = (bytes) => {
  const n = Number(bytes) || 0;
  if (n < 1024) return `${n} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let v = n;
  let u = -1;
  while (v >= 1024 && u < units.length - 1) {
    v /= 1024;
    u += 1;
  }
  return `${v.toFixed(v >= 10 ? 1 : 2)} ${units[u]}`;
};

const LEGACY_SYSTEM_TEMP_PREFIXES = [
  'leadAE_',
  'leadAE-',
  'lead_ae_',
  'lead_ae-',
  'lead-aeassist-',
  'lead-aeassist_',
  'leadai_',
  'leadai-'
];

ipcMain.handle('maintenance:get-info', async (event) => {
  assertTrustedIpcSender(event, 'maintenance:get-info');
  return { ok: true, tempDir: resolveAppTempDir() };
});

ipcMain.handle('maintenance:open-temp-folder', async (event) => {
  assertTrustedIpcSender(event, 'maintenance:open-temp-folder');
  const tempDir = resolveAppTempDir();
  try {
    const res = await shell.openPath(tempDir);
    if (res) return { ok: false, error: res };
    return { ok: true, error: null };
  } catch (err) {
    return { ok: false, error: toIpcSafeError(err, 'Unable to open temp folder') };
  }
});

ipcMain.handle('maintenance:clear-temp', async (event, options = {}) => {
  assertTrustedIpcSender(event, 'maintenance:clear-temp');

  const rawDays = options?.maxAgeDays;
  const days = parseInt(rawDays, 10);
  const maxAgeMs = Number.isFinite(days) && days >= 0
    ? days * 24 * 60 * 60 * 1000
    : undefined;

  const appTempDir = resolveAppTempDir();

  try {
    // Primary cleanup: app-owned temp folder (recursive + prunes empty job dirs).
    const appRes = await clearTempFiles({
      tempDir: appTempDir,
      tempPrefixes: null,
      maxAgeMs,
      logger: console
    });

    // Best-effort cleanup: legacy system-temp artifacts created by older builds.
    // This MUST remain prefix-scoped so we never touch unrelated system temp data.
    let legacyRes = null;
    try {
      legacyRes = await clearTempFiles({
        tempDir: os.tmpdir(),
        tempPrefixes: LEGACY_SYSTEM_TEMP_PREFIXES,
        maxAgeMs,
        logger: console
      });
    } catch {
      legacyRes = null;
    }

    const totalFreedBytes = (appRes?.freedBytes || 0) + (legacyRes?.freedBytes || 0);
    const totalRemovedCount = (appRes?.removedCount || 0) + (legacyRes?.removedCount || 0);

    return {
      ok: !!appRes?.ok && (!legacyRes || legacyRes.ok),
      freedBytes: totalFreedBytes,
      freed: formatBytes(totalFreedBytes),
      removedCount: totalRemovedCount,
      details: {
        appTempDir,
        appRes,
        legacyTempDir: os.tmpdir(),
        legacyRes
      }
    };
  } catch (err) {
    return { ok: false, error: err?.message || String(err), freedBytes: 0, freed: '0 B', removedCount: 0 };
  }
});

ipcMain.handle('maintenance:clear-cache', async (event) => {
    assertTrustedIpcSender(event, 'maintenance:clear-cache');
    try {
      return await clearCacheFiles({
        app,
        session,
        userDataDir: app.getPath('userData'),
        logger: console
      });
    } catch (err) {
      return { ok: false, error: err?.message || String(err), freedBytes: 0, freed: '0 B', removedCount: 0 };
    }
  });

  ipcMain.handle('maintenance:clear-logs', async (event, options = {}) => {
    assertTrustedIpcSender(event, 'maintenance:clear-logs');
    const rawDays = options?.maxAgeDays;
    const rawMaxMb = options?.maxTotalMb ?? options?.maxTotalMB;
    const days = parseInt(rawDays, 10);
    const maxAgeMs = Number.isFinite(days) && days >= 0
      ? days * 24 * 60 * 60 * 1000
      : undefined;
    const maxTotalMb = parseFloat(rawMaxMb);
    const maxTotalBytes = Number.isFinite(maxTotalMb) && maxTotalMb >= 0
      ? maxTotalMb * 1024 * 1024
      : undefined;
    try {
      return await clearLogFiles({
        logsDir: ensureUserDataSubdir('logs'),
        maxAgeMs,
        maxTotalBytes,
        logger: console
      });
    } catch (err) {
      return { ok: false, error: err?.message || String(err), freedBytes: 0, freed: '0 B', removedCount: 0 };
    }
  });

  ipcMain.handle('path-exists', async (event, targetPath) => {
    try {
      assertTrustedIpcSender(event, 'path-exists');
      if (!targetPath || typeof targetPath !== 'string') return false;
      const safePath = assertApprovedPath(event?.sender?.id, targetPath);
      await fsp.access(safePath, fs.constants.F_OK);
      return true;
    } catch {
      return false;
    }
  });

  ipcMain.handle('normalize-path', async (event, targetPath) => {
    try {
      assertTrustedIpcSender(event, 'normalize-path');
      if (!targetPath || typeof targetPath !== 'string') return '';
      return path.normalize(targetPath.trim());
    } catch {
      return (targetPath + '').trim();
    }
  });

  ipcMain.handle('stat-path', async (event, targetPath) => {
    try {
      assertTrustedIpcSender(event, 'stat-path');
      if (!targetPath || typeof targetPath !== 'string') {
        return { ok: false, error: 'invalid_path' };
      }
      const safePath = assertApprovedPath(event?.sender?.id, targetPath);
      const st = await fsp.stat(safePath);
      return {
        ok: true,
        isDirectory: st.isDirectory(),
        size: Number(st.size) || 0,
        mtimeMs: Number(st.mtimeMs) || 0
      };
    } catch (err) {
      return {
        ok: false,
        error: err?.code || err?.message || String(err)
      };
    }
  });

  // P0-2: minimal stat helper for preview-proxy caching.
  // Returns only fields needed for stable cache keys (avoid sending huge stat objects over IPC).
  ipcMain.handle('path-stat', async (event, targetPath) => {
    try {
      assertTrustedIpcSender(event, 'path-stat');
      if (!targetPath || typeof targetPath !== 'string') {
        return { ok: false, error: 'invalid_path' };
      }
      const safePath = assertApprovedPath(event?.sender?.id, targetPath);
      const st = await fsp.stat(safePath);
      return {
        ok: true,
        size: Number(st.size) || 0,
        mtimeMs: Number(st.mtimeMs) || 0
      };
    } catch (err) {
      return {
        ok: false,
        error: err?.code || err?.message || String(err)
      };
    }
  });

  ipcMain.handle('expand-paths', async (event, paths, options) => {
    try {
      assertTrustedIpcSender(event, 'expand-paths');
      const senderId = event?.sender?.id;
      // Enforce approved-roots policy before any lstat/readdir traversal occurs.
      // This prevents the renderer from probing arbitrary filesystem locations.
      assertApprovedPaths(senderId, paths);
      const result = await expandPaths(paths, options);
      return { success: true, ...result };
    } catch (err) {
      return { success: false, error: err.message || String(err) };
    }
  });

  ipcMain.handle('log-viewer:open-log-folder', async (event, dir) => {
    assertTrustedIpcSender(event, 'log-viewer:open-log-folder');
    const senderId = event?.sender?.id;
    try {
      const logsRoot = ensureUserDataSubdir('logs');
      const requested = dir ? assertApprovedPath(senderId, dir) : logsRoot;
      const rel = path.relative(logsRoot, requested);
      if (rel.startsWith('..') || path.isAbsolute(rel)) {
        console.warn('⚠️ Log viewer rejected open-log-folder request outside logs root', {
          requested,
          logsRoot,
          senderId
        });
        return { ok: false, errorCode: 'LOG_VIEWER_DIR_OUTSIDE_LOGS' };
      }

      const openError = await shell.openPath(requested);
      if (openError) {
        console.warn('⚠️ Failed to open log folder path via shell.openPath', {
          requested,
          senderId,
          openError
        });
        return { ok: false, errorCode: 'LOG_VIEWER_OPEN_PATH_FAILED' };
      }
      return { ok: true, errorCode: null };
    } catch (err) {
      console.error('❌ Unexpected log-viewer:open-log-folder failure', {
        senderId,
        dir,
        error: err?.message || String(err)
      });
      return { ok: false, errorCode: 'LOG_VIEWER_OPEN_FOLDER_UNKNOWN' };
    }
  });

  ipcMain.handle('log-viewer:read-log-files', async (event, dir) => {
    try {
      assertTrustedIpcSender(event, 'log-viewer:read-log-files');
      const senderId = event?.sender?.id;
      registerSenderCleanup(event?.sender);
      const logsRoot = ensureUserDataSubdir('logs');

      // Default to the app's logs root if the renderer didn't specify a directory.
      const requested = dir ? assertApprovedPath(senderId, dir) : logsRoot;

      // Extra tightening: only allow reading logs from inside the app's logs directory.
      // (Approved-roots alone would also allow reading other userData subfolders.)
      const rel = path.relative(logsRoot, requested);
      if (rel.startsWith('..') || path.isAbsolute(rel)) {
        throw new Error('❌ Log viewer rejected: directory is outside the app logs folder');
      }

      if (typeof senderId === 'number') {
        const existing = logReadStateBySender.get(senderId);
        if (existing?.controller) {
          existing.controller.abort();
        }
        const controller = new AbortController();
        const readId = (existing?.readId || 0) + 1;
        logReadStateBySender.set(senderId, { controller, readId });

        let logs = [];
        try {
          await fsp.access(requested, fs.constants.F_OK);
          logs = await readLogFiles(requested, undefined, { signal: controller.signal });
        } catch {
          logs = [];
        }
        const current = logReadStateBySender.get(senderId);
        if (!current || current.readId !== readId) {
          return [];
        }
        logReadStateBySender.set(senderId, { readId });
        return logs;
      }

      try {
        await fsp.access(requested, fs.constants.F_OK);
        return readLogFiles(requested);
      } catch {
        return [];
      }
    } catch (err) {
      console.error('❌ Failed to read log files via IPC:', err);
      return [];
    }
  });

  // Cancel a running network test (per renderer).
  // This mirrors the drive-test cancellation pattern, but tracks the spawned child process.
  ipcMain.handle('cancel-network-test', (event) => {
    try {
      assertTrustedIpcSender(event, 'cancel-network-test');
    } catch (err) {
      return { success: false, error: err?.message || 'Network test cancel blocked' };
    }

    const senderId = event?.sender?.id;
    if (typeof senderId !== 'number') return true;

    const state = networkTestStateBySender.get(senderId);
    if (!state || state.done) return true;

    state.cancelled = true;
    attemptNetworkTestKill(state, 'cancel');
    if (!state.cancelTimeoutId) {
      state.cancelTimeoutId = setTimeout(() => {
        state.finish?.({
          success: false,
          cancelled: true,
          code: 'NETWORK_TEST_CANCELLED',
          error: 'Cancelled'
        });
      }, NETWORK_TEST_CANCEL_TIMEOUT_MS);
    }
    if (!state.child || state.child.killed) {
      state.finish?.({
        success: false,
        cancelled: true,
        code: 'NETWORK_TEST_CANCELLED',
        error: 'Cancelled'
      });
    }

    // We still prefer waiting for the child to exit, but ensure cancellation
    // resolves within a short window so the renderer leaves the busy state.
    return true;
  });

  ipcMain.handle('run-network-test', async (event) => {
    registerSenderCleanup(event?.sender);
    const senderId = event?.sender?.id;
    const debugUiEnabled = process.env.DEBUG_UI === 'true';
    if (typeof senderId === 'number') {
      const existing = networkTestStateBySender.get(senderId);
      if (existing && !existing.done) {
        return {
          success: false,
          code: 'ALREADY_RUNNING',
          error: 'Network speed test is already running.'
        };
      }
    }
    try {
      assertTrustedIpcSender(event, 'run-network-test');
      if (isOfflineModeEnabled()) {
        return {
          success: false,
          code: 'OFFLINE_MODE',
          error: 'Offline Mode is enabled. Network speed tests are unavailable while offline.'
        };
      }
      if (!licenseService.isFeatureEnabled('speed-test')) {
        return {
          success: false,
          code: 'LICENSE_REQUIRED',
          error: '🔒 License required for speed test'
        };
      }
    } catch (err) {
      return { success: false, error: err?.message || 'Network test blocked' };
    }

    const jobId = makeSpeedTestJobId('speed-test-network');
    const jobLogger = createJobLogger({ panel: 'speed-test', jobId, stage: 'network', streamToFile: true });
    const provider = 'fast.com';
    const NETWORK_TEST_TIMEOUT_MS = 60000;

    // These are persisted into the TXT Job Report header.
    const reportInputs = { type: 'network' };
    const reportSettings = {
      provider,
      tool: 'fast-cli',
      timeoutMs: NETWORK_TEST_TIMEOUT_MS,
      uploadEnabled: true,
      output: 'json'
    };

    const finalize = (payload) => {
      const success = payload?.success === true;
      const cancelled = payload?.cancelled === true;
      let reportStats = null;

      if (cancelled) {
        jobLogger.setStage('cancelled');
        jobLogger.warn('Network speed test cancelled', { code: payload.code || 'NETWORK_TEST_CANCELLED' });
      } else if (success) {
        jobLogger.setStage('complete');
        const rep = _buildNetworkReport(payload.download, payload.upload, payload.ping, {
          provider,
          efficiency: 0.8,
          estimateSizeGB: 100
        });
        reportStats = rep.stats;
        jobLogger.info(rep.summaryLine, rep.meta);
        jobLogger.info(rep.estimateLine, { ...rep.meta, kind: 'estimate' });
      } else {
        jobLogger.setStage('error');
        jobLogger.error('Network speed test failed', { code: payload.code, error: payload.error });
      }

      const { structuredLogPath, archivePath } = _persistSpeedtestJobArtifacts({
        jobLogger,
        jobId,
        senderId,
        inputs: reportInputs,
        settings: reportSettings,
        stats: reportStats
      });

      try { jobLogger.close?.(); } catch {}

      return {
        ...payload,
        jobId,
        structuredLogPath,
        archivePath
      };
    };


    jobLogger.info(`Starting network speed test (${provider})`, { senderId, provider });

    // Note: calling the .bin shim usually requires a system Node install (bad for packaged apps).
    // Instead, run fast-cli using Electron's bundled Node via ELECTRON_RUN_AS_NODE.
    const candidateEntries = [
      () => require.resolve('fast-cli/distribution/cli.js'),
      // Fallback for any future/alternate package layouts.
      () => require.resolve('fast-cli/dist/cli.js')
    ];

    let cliEntry = null;
    for (const getEntry of candidateEntries) {
      try {
        cliEntry = getEntry();
        break;
      } catch {
        // ignore and try next candidate
      }
    }

    if (!cliEntry) {
      // Last-ditch fallback when module resolution is weird (custom packagers, etc.)
      const fallback = path.join(app.getAppPath(), 'node_modules', 'fast-cli', 'distribution', 'cli.js');
      try {
        await fsp.access(fallback, fs.constants.F_OK);
        cliEntry = fallback;
      } catch {
        // ignore
      }
    }

    if (!cliEntry) {
      return finalize({
        success: false,
        code: 'DEPENDENCY_MISSING',
        error: 'Network test tool is missing. Please reinstall the app to restore the network test component.'
      });
    }
    if (debugUiEnabled) {
      jobLogger.debug('Resolved network test CLI entry', { entry: path.basename(cliEntry) });
    }

    let chromiumFallbackRoot = getChromiumFallbackRoot();
    let chromiumPath = null;
    let chromiumAsset = null;
    let chromiumAssetError = null;

    if (app.isPackaged) {
      try {
        chromiumAsset = await chromiumAssetService.ensureChromiumExecutablePath({
          isPackaged: true,
          offline: isOfflineModeEnabled()
        });
        chromiumFallbackRoot = chromiumAsset.assetRoot;
        chromiumPath = chromiumAsset.executablePath;
      } catch (e) {
        chromiumAssetError = e;
        if (debugUiEnabled) {
          try {
            jobLogger.warn('Failed to resolve Chromium runtime asset', {
              assetId: e?.assetId || chromiumAssetService.getChromiumAssetId(),
              code: e?.code || '',
              error: e?.message || String(e)
            });
          } catch {}
        }
      }
    } else {
      chromiumPath = await findBundledChromium(chromiumFallbackRoot);
    }

    if (!chromiumPath) {
      if (app.isPackaged) {
        return finalize({
          success: false,
          code: chromiumAssetError?.code || 'BROWSER_MISSING',
          error: formatChromiumDependencyError(chromiumAssetError)
        });
      }

      return finalize({
        success: false,
        code: 'BROWSER_MISSING',
        error:
          'Chromium browser binary was not found. The network test requires a staged local browser runtime asset. ' +
          'Stage Chromium under vendor/puppeteer or reinstall the app.'
      });
    }
    if (debugUiEnabled) {
      jobLogger.debug(app.isPackaged ? 'Runtime Chromium located' : 'Bundled Chromium located', {
        binary: path.basename(chromiumPath),
        ...(chromiumAsset ? { assetId: chromiumAsset.assetId, source: chromiumAsset.source } : {})
      });
    }
    const state = {
      child: null,
      logger: jobLogger,
      timeoutId: null,
      cancelTimeoutId: null,
      done: false,
      cancelled: false,
      finish: null
    };

    // If senderId is missing (shouldn't happen in normal flows), run without cancellability.
    const canTrack = typeof senderId === 'number';

    return await new Promise((resolve) => {
      state.finish = (payload) => {
        if (state.done) return;
        state.done = true;
        try {
          if (state.timeoutId) clearTimeout(state.timeoutId);
        } catch {
          // ignore
        }
        try {
          if (state.cancelTimeoutId) clearTimeout(state.cancelTimeoutId);
        } catch {
          // ignore
        }
        if (canTrack) networkTestStateBySender.delete(senderId);
        resolve(finalize(payload));
      };

      if (canTrack) networkTestStateBySender.set(senderId, state);

      state.timeoutId = setTimeout(() => {
        if (state.done) return;
        if (state.cancelled) {
          return state.finish({
            success: false,
            cancelled: true,
            code: 'NETWORK_TEST_CANCELLED',
            error: 'Cancelled'
          });
        }
        attemptNetworkTestKill(state, 'timeout');
        state.finish({
          success: false,
          code: 'TIMEOUT',
          error: `Network test timed out after ${NETWORK_TEST_TIMEOUT_MS / 1000} seconds.`
        });
      }, NETWORK_TEST_TIMEOUT_MS);

      try {
        const extractJsonObject = (text) => {
          const s = String(text || '').trim();
          if (!s) return null;
          const idx = s.indexOf('{');
          if (idx < 0) return null;
          // fast-cli sometimes prints non-JSON lines before the JSON payload.
          // Grab from the first '{' onward and try parsing.
          const candidate = s.slice(idx).trim();
          try {
            return JSON.parse(candidate);
          } catch {
            // If there are trailing non-JSON lines, try the last line that starts with '{'
            const lines = candidate.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
            for (let i = lines.length - 1; i >= 0; i--) {
              if (lines[i].startsWith('{')) {
                try { return JSON.parse(lines[i]); } catch {}
              }
            }
            return null;
          }
        };

        const summarizeOutput = (stdout, stderr) => {
          const out = String(stdout || '').trim();
          const err = String(stderr || '').trim();
          const combined = (err && out) ? `${err}\n${out}` : (err || out);
          const oneLine = combined.replace(/\s+/g, ' ').trim();
          return oneLine.length > 240 ? oneLine.slice(0, 240) + '…' : oneLine;
        };

        state.child = execFile(
          process.execPath,
          [cliEntry, '--upload', '--json'],
          {
            encoding: 'utf-8',
            windowsHide: true,
            maxBuffer: 2 * 1024 * 1024,
            env: {
              ...process.env,
              ELECTRON_RUN_AS_NODE: '1',
              PUPPETEER_CACHE_DIR: chromiumFallbackRoot,
              PUPPETEER_EXECUTABLE_PATH: chromiumPath
            }
          },
          (err, stdout, stderr) => {
            if (state.done) return;

            if (state.cancelled) {
              return state.finish({ success: false, cancelled: true, code: 'NETWORK_TEST_CANCELLED', error: 'Cancelled' });
            }

            if (err) {
              const detail = stderr?.trim() || stdout?.trim() || err.message;
              return state.finish({
                success: false,
                code: 'EXEC_ERROR',
                error: detail
              });
            }

            const result = extractJsonObject(stdout) || extractJsonObject(stderr);
            if (!result) {
              const hint = summarizeOutput(stdout, stderr);
              return state.finish({
                success: false,
                code: 'PARSE_ERROR',
                error:
                  'Network test service returned non-JSON output. ' +
                  'This often means fast.com is blocked by the network (VPN/captive portal/firewall/DNS filtering). ' +
                  (hint ? `Details: ${hint}` : '')
              });
            }

            return state.finish({
              success: true,
              download: Number.isFinite(result.downloadSpeed)
                ? result.downloadSpeed.toFixed(2)
                : 'N/A',
              upload: Number.isFinite(result.uploadSpeed)
                ? result.uploadSpeed.toFixed(2)
                : 'N/A',
              ping: Number.isFinite(result.latency)
                ? result.latency.toFixed(1)
                : 'N/A'
            });
          }
        );
      } catch (spawnErr) {
        state.finish({ success: false, code: 'SPAWN_ERROR', error: spawnErr?.message || String(spawnErr) });
      }
    });
  });

  // SECURITY: do NOT return secret values to the renderer.
  // Instead, expose only boolean state checks.
  // NOTE: secureStore.getAiApiKey() will also perform legacy migration from
  // config/state.json into secure storage, but we never return the key.
  ipcMain.handle('secure-store:has-ai-api-key', async (event) => {
    try {
      assertTrustedIpcSender(event, 'secure-store:has-ai-api-key');
      const key = await secureStore.getAiApiKey();
      return typeof key === 'string' && key.trim().length > 0;
    } catch (err) {
      console.warn('⚠️ Failed to check AI API key presence in secure store:', err?.message || err);
      return false;
    }
  });

  ipcMain.handle('secure-store:set-ai-api-key', async (event, value) => {
    try {
      assertTrustedIpcSender(event, 'secure-store:set-ai-api-key');
      const v = String(value ?? '').trim();
      if (!v) {
        secureStore.deleteSecret('aiApiKey');
        return { ok: true };
      }
      secureStore.saveSecret('aiApiKey', v);
      return { ok: true };
    } catch (err) {
      console.warn('⚠️ Failed to save AI API key to secure store:', err?.message || err);
      return { ok: false, error: err?.message || String(err) };
    }
  });

  ipcMain.handle('secure-store:delete-ai-api-key', async (event) => {
    try {
      assertTrustedIpcSender(event, 'secure-store:delete-ai-api-key');
      secureStore.deleteSecret('aiApiKey');
      return { ok: true };
    } catch (err) {
      console.warn('⚠️ Failed to delete AI API key from secure store:', err?.message || err);
      return { ok: false, error: err?.message || String(err) };
    }
  });

  ipcMain.handle('is-media-composer-running', async (event) => {
    try {
      assertTrustedIpcSender(event, 'is-media-composer-running');

      const run = (cmd, args) => new Promise((resolve, reject) => {
        execFile(
          cmd,
          args,
          { encoding: 'utf-8', timeout: PROCESS_LIST_TIMEOUT_MS, windowsHide: true },
          (err, stdout = '') => {
            if (err) return reject(err);
            return resolve(stdout);
          }
        );
      });

      // We only want to block destructive actions when the actual Media Composer app is running.
      // The previous implementation used /media\s*composer/i against the full process list, which can
      // produce false positives if any unrelated process includes that phrase in its args/path.
      if (process.platform === 'darwin') {
        // Use "comm" (executable name only) to avoid matching arguments/paths.
        const output = await run('ps', ['-A', '-o', 'comm=']);
        const cmds = String(output || '')
          .split(/\r?\n/)
          .map((l) => l.trim())
          .filter(Boolean)
          .map((l) => l.replace(/^.*\//, '')); // drop paths if present

        const patterns = [
          /^Avid\s+Media\s+Composer$/i,
          /^Media\s+Composer$/i,
          /^AvidMediaComposer$/i
        ];

        return cmds.some((cmd) => patterns.some((re) => re.test(cmd)));
      }

      if (process.platform === 'win32') {
        // CSV output keeps the image name as the first quoted field.
        const output = await run('tasklist', ['/FO', 'CSV', '/NH']);
        return /"Avid\s*Media\s*Composer[^"]*\.exe"/i.test(output)
          || /"Media\s*Composer[^"]*\.exe"/i.test(output);
      }

      // Linux/other: fall back to comm-only scan.
      const output = await run('ps', ['-A', '-o', 'comm=']);
      const cmds = String(output || '')
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter(Boolean)
        .map((l) => l.replace(/^.*\//, ''));

      const patterns = [
        /^Avid\s+Media\s+Composer$/i,
        /^Media\s+Composer$/i,
        /^AvidMediaComposer$/i
      ];

      return cmds.some((cmd) => patterns.some((re) => re.test(cmd)));
    } catch (err) {
      console.warn('⚠️ Failed to check running processes:', err?.message || err);
      return false;
    }
  });

  ipcMain.handle('show-message-dialog', async (event, options) => {
    try {
      assertTrustedIpcSender(event, 'show-message-dialog');
      return await showNativeMessageDialog(event, options);
    } catch {
      return { response: 0, checkboxChecked: false };
    }
  });

  ipcMain.handle('show-confirm-dialog', async (event, input) => {
    try {
      assertTrustedIpcSender(event, 'show-confirm-dialog');
      const { okButtonIndex, dialogOptions } = normalizeConfirmDialogOptions(input);
      const { response } = await showNativeMessageDialog(event, dialogOptions);
      return response === okButtonIndex;
    } catch {
      return false;
    }
  });

  ipcMain.on('ui:set-collapsed', (event, payload) => {
    assertTrustedIpcSender(event, 'ui:set-collapsed');

    const normalizedPayload = (payload && typeof payload === 'object')
      ? payload
      : { collapsed: payload };

    const collapsed = !!normalizedPayload.collapsed;
    const requestId = Number.isFinite(Number(normalizedPayload.requestId))
      ? Number(normalizedPayload.requestId)
      : null;

    const sendAck = () => {
      try {
        event.sender.send('ui:collapsed-applied', { collapsed, requestId });
      } catch {}
    };

    if (typeof context.handleUICollapse === 'function') {
      Promise.resolve(context.handleUICollapse(collapsed))
        .catch(() => {})
        .finally(sendAck);
      return;
    }

    sendAck();
  });

  __appendmiscHandlers(ipcMain);
  __appendStep5AMisc(ipcMain);
}

module.exports = registerMiscHandlers;
module.exports.setSpeedtestLockStrategyForTests = setSpeedtestLockStrategyForTests;
module.exports.resetSpeedtestLockStrategyForTests = resetSpeedtestLockStrategyForTests;
module.exports.setDriveTestPreflightStrategyForTests = setDriveTestPreflightStrategyForTests;
module.exports.resetDriveTestPreflightStrategyForTests = resetDriveTestPreflightStrategyForTests;

// Preset helpers
function getLeadAEPresetDir() {
  return path.join(os.homedir(), 'LeadAE', 'Presets');
}

function ensurePresetDir() {
  const dir = getLeadAEPresetDir();
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}

function _scanLeadAEPresets() {
  const dir = ensurePresetDir();
  return fs
    .readdirSync(dir)
    .filter(f => ['.epr', '.json'].includes(path.extname(f)))
    .map(f => ({
      name: path.basename(f, path.extname(f)),
      fullPath: path.join(dir, f)
    }));
}

const PANEL_PRESET_ALLOWLIST = new Set([
  'adobe-utilities',
  'ingest',
  'transcode',
  'transcribe',
  'nle-utilities',
  'project-organizer'
]);

function normalizePanelPresetNamespace(panel) {
  const raw = String(panel || '').trim();
  if (!raw) throw new Error('Invalid panel preset namespace');
  if (/[\\/]/.test(raw)) throw new Error('Panel preset namespace contains path separators');

  const normalized = raw.toLowerCase();
  if (!PANEL_PRESET_ALLOWLIST.has(normalized)) {
    throw new Error('Panel preset namespace not allowed');
  }

  return normalized;
}

function normalizePanelPresetName(presetName) {
  const raw = String(presetName || '').trim();
  if (!raw) return null;
  if (/[\\/]/.test(raw)) return null;

  const base = path.basename(raw);
  if (!base || base === '.' || base === '..') return null;
  if (base !== raw) return null;

  return base;
}

function getPanelPresetDir(panel) {
  const safePanel = normalizePanelPresetNamespace(panel);
  const userDataPath = app.getPath('userData');
  const defaultDir = path.join(userDataPath, 'config', 'presets', safePanel);

  // Handle all variants of the app name folder that might exist (legacy hyphen/en dash names)
  // Cross-platform base for app data (mac: ~/Library/Application Support, win: %APPDATA%)
  const supportBase = (() => {
    try { return app.getPath('appData'); } catch { return platformPaths.getAppDataBase(); }
  })();
  const variants = [
    'LeadAEAssist',
    'Lead AE Assist' // legacy default
  ];

  let chosenDir = defaultDir;
  for (const v of variants) {
    const alt = path.join(supportBase, v, 'config', 'presets', safePanel);
    if (fs.existsSync(alt)) {
      chosenDir = alt;
      break;
    }
  }

  fs.mkdirSync(chosenDir, { recursive: true });
  return chosenDir;
}

const PANEL_PRESET_EXTENSIONS = ['.json'];
const PANEL_DEFAULT_PRESET_BASENAME = 'Default';
const PANEL_DEFAULT_PRESET_FILE = `${PANEL_DEFAULT_PRESET_BASENAME}.json`;

function isDefaultPanelPresetFileName(value) {
  const normalized = String(value || '').trim().toLowerCase();
  return normalized === PANEL_DEFAULT_PRESET_FILE.toLowerCase()
    || normalized === PANEL_DEFAULT_PRESET_BASENAME.toLowerCase();
}

function canonicalizePanelPresetFileName(presetName) {
  const baseName = normalizePanelPresetName(presetName);
  if (!baseName) return null;
  const withExtension = baseName.toLowerCase().endsWith('.json') ? baseName : `${baseName}.json`;
  const safeName = path.basename(withExtension);
  if (isDefaultPanelPresetFileName(safeName)) {
    return PANEL_DEFAULT_PRESET_FILE;
  }
  return safeName;
}

function resolvePanelPresetPath(dir, presetName) {
  const baseName = normalizePanelPresetName(presetName);
  if (!baseName) return null;

  const candidates = [
    path.basename(baseName),
    path.basename(baseName.toLowerCase().endsWith('.json') ? baseName : `${baseName}.json`)
  ];

  for (const candidate of candidates) {
    const target = path.join(dir, candidate);
    if (fs.existsSync(target)) return target;
  }

  const lowered = new Set(candidates.map(candidate => String(candidate || '').toLowerCase()));
  const files = fs.readdirSync(dir);
  const match = files.find(file => lowered.has(String(file || '').toLowerCase()));
  return match ? path.join(dir, match) : null;
}

function comparePanelPresetEntries(a, b) {
  if (!!a.isDefault !== !!b.isDefault) {
    return a.isDefault ? -1 : 1;
  }
  return String(a.name || '').localeCompare(String(b.name || ''), undefined, {
    sensitivity: 'base',
    numeric: true
  });
}

function scanPanelPresets(panel) {
  const dir = getPanelPresetDir(panel);
  fs.mkdirSync(dir, { recursive: true }); // ensure folder
  return fs
    .readdirSync(dir)
    .filter(file =>
      PANEL_PRESET_EXTENSIONS.some(ext => file.toLowerCase().endsWith(ext))
    )
    .map(file => ({
      name: isDefaultPanelPresetFileName(file)
        ? PANEL_DEFAULT_PRESET_BASENAME
        : path.basename(file, path.extname(file)),
      file,
      isDefault: isDefaultPanelPresetFileName(file)
    }))
    .sort(comparePanelPresetEntries)
    .map(({ isDefault, ...entry }) => entry);
}

// ---- moved from main.js (presets/drive/disk/metadata) ----
function __appendmiscHandlers(ipcMain) {
  ipcMain.handle('list-panel-presets', (event, panel) => {
    try {
      assertTrustedIpcSender(event, 'list-panel-presets');
      return scanPanelPresets(panel);
    } catch {
      return [];
    }
  });

  ipcMain.handle('delete-panel-preset', (event, { panel, presetName }) => {
    try {
      assertTrustedIpcSender(event, 'delete-panel-preset');
      const dir = getPanelPresetDir(panel);
      fs.mkdirSync(dir, { recursive: true }); // ensure folder
      const target = resolvePanelPresetPath(dir, presetName);
      if (!target) return false;

      fs.unlinkSync(target);
      return true;
    } catch (err) {
      console.error('❌ Failed to delete preset:', err);
      return false;
    }
  });

  ipcMain.handle('write-panel-preset', async (event, { panel, presetName, contents }) => {
    try {
      assertTrustedIpcSender(event, 'write-panel-preset');
      const dir = getPanelPresetDir(panel);
      const safeName = canonicalizePanelPresetFileName(presetName);
      if (!safeName) return null;

      const target = path.join(dir, safeName);
      const data = typeof contents === 'string' ? contents : JSON.stringify(contents ?? {}, null, 2);

      await fsp.writeFile(target, data, 'utf8');
      return target;
    } catch (err) {
      console.error('❌ Failed to write preset:', err);
      return null;
    }
  });

  ipcMain.handle('read-panel-preset', async (event, { panel, presetName }) => {
    try {
      assertTrustedIpcSender(event, 'read-panel-preset');
      const dir = getPanelPresetDir(panel);
      const target = resolvePanelPresetPath(dir, presetName);
      if (!target) return null;

      return await fsp.readFile(target, 'utf8');
    } catch (err) {
      console.error('❌ Failed to read preset:', err);
      return null;
    }
  });

  // Drive test cancellation (per renderer)
  ipcMain.handle('reset-drive-test-cancel', (event) => {
    try {
      assertTrustedIpcSender(event, 'reset-drive-test-cancel');
    } catch (err) {
      return { success: false, error: err?.message || 'Drive test cancel reset blocked' };
    }
    setDriveTestCancelled(event?.sender?.id, false);
    return true;
  });

  ipcMain.handle('cancel-drive-test', (event) => {
    try {
      assertTrustedIpcSender(event, 'cancel-drive-test');
    } catch (err) {
      return { success: false, error: err?.message || 'Drive test cancel blocked' };
    }
    setDriveTestCancelled(event?.sender?.id, true);
    return true;
  });

  ipcMain.handle('run-drive-test', async (event, drivePath, testSizeMiB = 1024) => {
    try {
      assertTrustedIpcSender(event, 'run-drive-test');
      if (!licenseService.isFeatureEnabled('speed-test')) {
        return {
          success: false,
          code: 'LICENSE_REQUIRED',
          error: '🔒 License required for speed test'
        };
      }
    } catch (err) {
      return { success: false, error: err?.message || 'Drive test blocked' };
    }

    const { senderId, throwIfCancelled, sendProgress, safeSend } = getDriveTestHelpers(event);
    if (typeof senderId === 'number') {
      if (driveTestRunningBySender.has(senderId)) {
        return {
          success: false,
          code: 'ALREADY_RUNNING',
          error: 'Drive test already running.'
        };
      }
      driveTestRunningBySender.add(senderId);
    }

    const jobId = makeSpeedTestJobId('speed-test-drive-sequential');
    const jobLogger = createJobLogger({ panel: 'speed-test', jobId, stage: 'drive-sequential', streamToFile: true });
    const reportInputs = { type: 'drive-sequential' };
    const reportSettings = { mode: 'sequential', testSizeMiB, iterations: 5 };
    let reportStats = null;
    let resolvedDrivePath = null;

    let response;
    let warningDetails = null;

    try {
      // Ensure the renderer can only write test files inside approved roots.
      const safeDrivePath = assertApprovedPath(senderId, drivePath);
      resolvedDrivePath = safeDrivePath;
      reportInputs.drivePath = safeDrivePath;
      reportSettings.drivePath = safeDrivePath;

      jobLogger.info('Sequential drive test started', {
        senderId,
        drivePath: safeDrivePath,
        testSizeMiB
      });

      // Preflight: avoid ENOSPC and low-space instability (especially on system volumes).
      throwIfCancelled();
      const preflight = await runDriveTestPreflight({
        safeDrivePath,
        mode: 'sequential',
        testSizeMiB
      });
      throwIfCancelled();

      warningDetails = preflight?.warning?.code === 'DISK_SPACE_CHECK_FAILED'
        ? { ...preflight.warning }
        : null;
      if (warningDetails) {
        jobLogger.warn('Disk space check failed; proceeding at your own risk.', {
          code: warningDetails.code,
          error: warningDetails.error
        });
        safeSend('drive-test-warning', {
          code: warningDetails.code,
          error: warningDetails.error
        });
      }

      if (!preflight.ok) {
        if (preflight.code === 'INSUFFICIENT_DISK_SPACE') {
          const required = formatBytesBinary(preflight.requiredBytes);
          const available = formatBytesBinary(preflight.freeBytes);
          const peak = formatBytesBinary(preflight.peakTempBytes);
          const safety = formatBytesBinary(preflight.safetyBytes);
          response = {
            success: false,
            code: 'INSUFFICIENT_DISK_SPACE',
            freeBytes: preflight.freeBytes,
            requiredBytes: preflight.requiredBytes,
            peakTempBytes: preflight.peakTempBytes,
            safetyBytes: preflight.safetyBytes,
            testSizeMiB: preflight.testSizeMiB,
            mode: 'sequential',
            error: `Insufficient free space for sequential drive test. Required ~${required} (peak temp ${peak} + safety ${safety}); available ${available}. Reduce test size or free up space.`
          };
          jobLogger.setStage('error');
          jobLogger.error('Sequential drive test blocked: insufficient disk space', {
            code: response.code,
            freeBytes: response.freeBytes,
            requiredBytes: response.requiredBytes
          });
          return response;
        }

        if (preflight.code === 'DRIVE_NOT_WRITABLE' || preflight.code === 'MARKER_CREATE_FAILED') {
          response = {
            success: false,
            code: preflight.code,
            error: preflight.message || (preflight.code === 'MARKER_CREATE_FAILED'
              ? 'Unable to acquire speed-test lock marker.'
              : 'Drive is read-only or lacks write permissions.')
          };
          jobLogger.setStage('error');
          jobLogger.error(
            preflight.code === 'MARKER_CREATE_FAILED'
              ? 'Sequential drive test blocked: marker creation failed'
              : 'Sequential drive test blocked: drive not writable',
            { code: response.code, error: response.error }
          );
          return response;
        }

      response = {
        success: false,
        code: preflight.code || 'DISK_SPACE_CHECK_FAILED',
        error: preflight.error || ''
      };
        jobLogger.setStage('error');
        jobLogger.error('Sequential drive test blocked: disk space check failed', { code: response.code, error: response.error });
        return response;
      }

      const result = await runSequentialDriveTest({
        drivePath: safeDrivePath,
        testSizeMiB,
        iterations: 5,
        senderTag: String(senderId ?? 0),
        senderId,
        jobId,
        logger: jobLogger,
        onProgressBytes: sendProgress,
        throwIfCancelled
      });

      response = warningDetails ? { ...result, warning: warningDetails } : result;

      if (response?.success === true) {
        jobLogger.setStage('complete');
        const rep = _buildDriveReport('sequential', response, { efficiency: 0.85, estimateSizeTiB: 1 });
        reportStats = rep.stats;
        jobLogger.info(rep.summaryLine, { ...rep.meta, drivePath: resolvedDrivePath || '' });
        jobLogger.info(rep.estimateLine, { ...rep.meta, kind: 'estimate' });
      } else {
        jobLogger.setStage('error');
        jobLogger.error('Sequential drive test failed', {
          code: response?.code,
          error: response?.error
        });
      }

      return response;
    } catch (err) {
      if (err?.code === 'DRIVE_TEST_CANCELLED') {
        response = { success: false, cancelled: true, error: 'Cancelled' };
        jobLogger.setStage('cancelled');
        jobLogger.warn('Sequential drive test cancelled', { code: 'DRIVE_TEST_CANCELLED' });
        return response;
      }
      response = { success: false, error: err.message };
      jobLogger.setStage('error');
      jobLogger.error('Sequential drive test error', { error: err?.message || String(err) });
      return response;
    } finally {
      if (typeof senderId === 'number') {
        driveTestRunningBySender.delete(senderId);
        driveTestCancelBySender.delete(senderId);
      }
      try {
        const success = response?.success === true;
        const cancelled = response?.cancelled === true;
        jobLogger.setStage(cancelled ? 'cancelled' : success ? 'complete' : 'error');

        const { structuredLogPath, archivePath } = _persistSpeedtestJobArtifacts({
          jobLogger,
          jobId,
          senderId,
          inputs: reportInputs,
          settings: reportSettings,
          stats: reportStats
        });
        try { jobLogger.close?.(); } catch {}
        if (response && typeof response === 'object') {
          response.jobId = jobId;
          response.structuredLogPath = structuredLogPath;
          response.archivePath = archivePath;
        }
      } catch (e) {
        console.warn('⚠️ Failed to persist speed-test drive log:', e?.message || e);
        try { jobLogger.close?.(); } catch {}
        if (response && typeof response === 'object') {
          response.jobId = jobId;
          response.structuredLogPath = null;
          response.archivePath = null;
        }
      }
    }
  });

  const ignorableFlushCodes = new Set(['EINVAL', 'ENOTSUP', 'EOPNOTSUPP']);
  const isIgnorableFlushError = error => Boolean(error && ignorableFlushCodes.has(error.code));

  ipcMain.handle('run-drive-test-random', async (event, drivePath, testSizeMiB = 1024) => {
    // Throttled progress: small enough to feel continuous, large enough not to spam IPC.
    const PROGRESS_MIN_BYTES = 16 * 1024 * 1024; // 16 MiB
    try {
      assertTrustedIpcSender(event, 'run-drive-test-random');
      if (!licenseService.isFeatureEnabled('speed-test')) {
        return {
          success: false,
          code: 'LICENSE_REQUIRED',
          error: '🔒 License required for speed test'
        };
      }
    } catch (err) {
      return { success: false, error: err?.message || 'Drive test blocked' };
    }

    const { senderId, throwIfCancelled, sendProgress, safeSend } = getDriveTestHelpers(event);
    if (typeof senderId === 'number') {
      if (driveTestRunningBySender.has(senderId)) {
        return {
          success: false,
          code: 'ALREADY_RUNNING',
          error: 'Drive test already running.'
        };
      }
      driveTestRunningBySender.add(senderId);
    }

    const jobId = makeSpeedTestJobId('speed-test-drive-random');
    const jobLogger = createJobLogger({ panel: 'speed-test', jobId, stage: 'drive-random', streamToFile: true });
    const reportInputs = { type: 'drive-random' };
    const reportSettings = { mode: 'random', testSizeMiB, iterations: 5, blockSize: 4096 };
    let reportStats = null;
    let resolvedDrivePath = null;

    let response;
    let warningDetails = null;

    try {
      if (!drivePath) throw new Error('Missing drivePath');

      // Ensure the renderer can only write test files inside approved roots.
      const safeDrivePath = assertApprovedPath(senderId, drivePath);
      resolvedDrivePath = safeDrivePath;
      reportInputs.drivePath = safeDrivePath;
      reportSettings.drivePath = safeDrivePath;

      jobLogger.info('Random drive test started', {
        senderId,
        drivePath: safeDrivePath,
        testSizeMiB
      });

      // Preflight: random test uses a single temp file per iteration, but still can be large.
      throwIfCancelled();
      const preflight = await runDriveTestPreflight({
        safeDrivePath,
        mode: 'random',
        testSizeMiB
      });
      throwIfCancelled();

      warningDetails = preflight?.warning?.code === 'DISK_SPACE_CHECK_FAILED'
        ? { ...preflight.warning }
        : null;
      if (warningDetails) {
        jobLogger.warn('Disk space check failed; proceeding at your own risk.', {
          code: warningDetails.code,
          error: warningDetails.error
        });
        safeSend('drive-test-warning', {
          code: warningDetails.code,
          error: warningDetails.error
        });
      }

      if (!preflight.ok) {
        if (preflight.code === 'INSUFFICIENT_DISK_SPACE') {
          const required = formatBytesBinary(preflight.requiredBytes);
          const available = formatBytesBinary(preflight.freeBytes);
          const peak = formatBytesBinary(preflight.peakTempBytes);
          const safety = formatBytesBinary(preflight.safetyBytes);
          response = {
            success: false,
            code: 'INSUFFICIENT_DISK_SPACE',
            freeBytes: preflight.freeBytes,
            requiredBytes: preflight.requiredBytes,
            peakTempBytes: preflight.peakTempBytes,
            safetyBytes: preflight.safetyBytes,
            testSizeMiB: preflight.testSizeMiB,
            mode: 'random',
            error: `Insufficient free space for random drive test. Required ~${required} (peak temp ${peak} + safety ${safety}); available ${available}. Reduce test size or free up space.`
          };
          jobLogger.setStage('error');
          jobLogger.error('Random drive test blocked: insufficient disk space', {
            code: response.code,
            freeBytes: response.freeBytes,
            requiredBytes: response.requiredBytes
          });
          return response;
        }

        if (preflight.code === 'DRIVE_NOT_WRITABLE' || preflight.code === 'MARKER_CREATE_FAILED') {
          response = {
            success: false,
            code: preflight.code,
            error: preflight.message || (preflight.code === 'MARKER_CREATE_FAILED'
              ? 'Unable to acquire speed-test lock marker.'
              : 'Drive is read-only or lacks write permissions.')
          };
          jobLogger.setStage('error');
          jobLogger.error(
            preflight.code === 'MARKER_CREATE_FAILED'
              ? 'Random drive test blocked: marker creation failed'
              : 'Random drive test blocked: drive not writable',
            { code: response.code, error: response.error }
          );
          return response;
        }

      response = {
        success: false,
        code: preflight.code || 'DISK_SPACE_CHECK_FAILED',
        error: preflight.error || ''
      };
        jobLogger.setStage('error');
        jobLogger.error('Random drive test blocked: disk space check failed', { code: response.code, error: response.error });
        return response;
      }

      const ITERATIONS = 5;
      const BLOCK_SIZE = 4096; // 4K
      const sizeMiB = clampInt(testSizeMiB, 1, 2048);
      const fileSize = sizeMiB * 1024 * 1024;
      const speedtestDir = await ensureSpeedtestDir(safeDrivePath);
      let activeMarkerPath = null;
      let runId;
      try {
        ({ markerPath: activeMarkerPath, runId } = await acquireSpeedtestMarker(speedtestDir, {
          tag: 'random',
          senderTag: String(senderId ?? 0),
          senderId,
          jobId
        }));
      } catch (error) {
        if (error?.code === 'MARKER_CREATE_FAILED') {
          response = {
            success: false,
            code: 'MARKER_CREATE_FAILED',
            error: 'Unable to acquire speed-test lock marker. Aborting random drive test safely.'
          };
          jobLogger.setStage('error');
          jobLogger.error('Random drive test blocked: marker creation failed', {
            code: response.code,
            error: response.error,
            details: error?.message || String(error)
          });
          return response;
        }
        throw error;
      }
      await cleanupStaleSpeedtestFiles(speedtestDir, SPEEDTEST_STALE_MIN_AGE_MS, { logger: jobLogger });
      const tmpPrefix = `.__lead_speedtest_random_${String(senderId ?? 0)}_${runId}`;
      const tmpFiles = [
        path.join(speedtestDir, `${tmpPrefix}_a.tmp`),
        path.join(speedtestDir, `${tmpPrefix}_b.tmp`),
        path.join(speedtestDir, `${tmpPrefix}_c.tmp`)
      ];
      const writeSpeeds = [];
      const readSpeeds = [];
      const readLagIterations = Math.min(2, Math.max(1, tmpFiles.length - 1));
      const pendingReadQueue = [];
      const cacheMitigation = {
        attempted: true,
        platform: process.platform,
        strategy: 'expanded_working_set_with_lagged_random_reads',
        workingSetFiles: tmpFiles.length,
        readLagIterations,
        handleReopenBetweenPhases: true,
        details: 'Random mode cannot force a full OS cache drop; mitigation relies on lagged reads and file rotation.',
        fullyApplied: false
      };

      const makeProgressAccumulator = () => {
        let pending = 0;
        const maybeEmit = (force = false) => {
          if (pending <= 0) return;
          if (!force && pending < PROGRESS_MIN_BYTES) return;
          sendProgress(pending);
          pending = 0;
        };
        return {
          add(n) {
            const v = Number(n) || 0;
            if (v <= 0) return;
            pending += v;
          },
          tick() {
            maybeEmit(false);
          },
          flush() {
            maybeEmit(true);
          }
        };
      };

      const randomWritePhase = async (targetPath) => {
        let fh;
        const progress = makeProgressAccumulator();
        try {
          try {
            fh = await fsp.open(targetPath, 'wx+');
          } catch (err) {
            // Some network filesystems can be weird about O_EXCL; fall back to a normal create/truncate.
            if (err?.code === 'EINVAL' || err?.code === 'ENOTSUP' || err?.code === 'EOPNOTSUPP') {
              fh = await fsp.open(targetPath, 'w+');
            } else {
              throw err;
            }
          }
          await fh.truncate(fileSize);

          const ops = Math.floor(fileSize / BLOCK_SIZE);
          const blockIndices = Array.from({ length: ops }, (_, idx) => idx);
          for (let i = ops - 1; i > 0; i -= 1) {
            const j = Math.floor(Math.random() * (i + 1));
            [blockIndices[i], blockIndices[j]] = [blockIndices[j], blockIndices[i]];
          }

          const wbuf = Buffer.alloc(BLOCK_SIZE, 0xaa);
          const start = performance.now();
          for (let i = 0; i < ops; i++) {
            if ((i & 1023) === 0) {
              throwIfCancelled();
              progress.tick(); // emit occasionally (throttled)
            }
            const offset = blockIndices[i] * BLOCK_SIZE;
            let position = offset;
            let bytesRemaining = BLOCK_SIZE;

            while (bytesRemaining > 0) {
              const { bytesWritten } = await fh.write(wbuf, BLOCK_SIZE - bytesRemaining, bytesRemaining, position);
              if (!Number.isFinite(bytesWritten) || bytesWritten <= 0) {
                const shortWriteError = new Error(
                  `Short write at offset ${offset}: expected ${BLOCK_SIZE} bytes, wrote ${BLOCK_SIZE - bytesRemaining} bytes`
                );
                shortWriteError.code = 'SHORT_WRITE';
                shortWriteError.context = {
                  targetPath,
                  offset,
                  expectedBytes: BLOCK_SIZE,
                  bytesWritten: BLOCK_SIZE - bytesRemaining
                };
                throw shortWriteError;
              }

              bytesRemaining -= bytesWritten;
              position += bytesWritten;
              progress.add(bytesWritten);
            }
          }
          try {
            await fh.sync();
          } catch (error) {
            if (!isIgnorableFlushError(error)) throw error;
          }
          const end = performance.now();
          writeSpeeds.push((fileSize / ((end - start) / 1000)) / (1024 * 1024));
          // Only mark the write phase as complete once sync() is done.
          progress.flush();
          return blockIndices;
        } finally {
          try {
            await fh?.close();
          } catch {
            // ignore
          }
        }
      };

      const randomReadPhase = async (targetPath, blockIndices) => {
        let fh;
        const progress = makeProgressAccumulator();
        try {
          fh = await fsp.open(targetPath, 'r');
          const rbuf = Buffer.alloc(BLOCK_SIZE);
          const start = performance.now();
          for (let i = 0; i < blockIndices.length; i++) {
            if ((i & 1023) === 0) {
              throwIfCancelled();
              progress.tick();
            }
            const offset = blockIndices[i] * BLOCK_SIZE;
            const { bytesRead } = await fh.read(rbuf, 0, BLOCK_SIZE, offset);
            progress.add(bytesRead);
            if (bytesRead !== BLOCK_SIZE) {
              const shortReadError = new Error(
                `Short read at offset ${offset}: expected ${BLOCK_SIZE} bytes, read ${bytesRead}`
              );
              shortReadError.code = 'SHORT_READ';
              shortReadError.context = {
                targetPath,
                offset,
                expectedBytes: BLOCK_SIZE,
                bytesRead
              };
              throw shortReadError;
            }
          }
          const end = performance.now();
          readSpeeds.push((fileSize / ((end - start) / 1000)) / (1024 * 1024));
          progress.flush();
        } finally {
          try {
            await fh?.close();
          } catch {
            // ignore
          }
          await safeUnlink(targetPath);
        }
      };

      try {
        for (let run = 0; run < ITERATIONS; run++) {
          throwIfCancelled();
          const tmpFile = tmpFiles[run % tmpFiles.length];
          await safeUnlink(tmpFile);

          const blockIndices = await randomWritePhase(tmpFile);
          pendingReadQueue.push({ targetPath: tmpFile, blockIndices });

          if (pendingReadQueue.length > readLagIterations) {
            const target = pendingReadQueue.shift();
            throwIfCancelled();
            await randomReadPhase(target.targetPath, target.blockIndices);
          }
        }

        while (pendingReadQueue.length > 0) {
          const target = pendingReadQueue.shift();
          throwIfCancelled();
          await randomReadPhase(target.targetPath, target.blockIndices);
        }

      } finally {
        await Promise.all(tmpFiles.map(safeUnlink));
        await releaseSpeedtestMarker(activeMarkerPath);
        await cleanupSpeedtestDirIfIdle(speedtestDir, { logger: jobLogger });
      }

      writeSpeeds.shift();
      readSpeeds.shift();
      const avg = arr => arr.reduce((a, b) => a + b, 0) / arr.length;

      const result = {
        success: true,
        write: avg(writeSpeeds).toFixed(1),
        writeMin: Math.min(...writeSpeeds).toFixed(1),
        writeMax: Math.max(...writeSpeeds).toFixed(1),
        read: avg(readSpeeds).toFixed(1),
        readMin: Math.min(...readSpeeds).toFixed(1),
        readMax: Math.max(...readSpeeds).toFixed(1),
        cacheMitigation
      };

      response = warningDetails ? { ...result, warning: warningDetails } : result;

      if (response?.success === true) {
        jobLogger.setStage('complete');
        const rep = _buildDriveReport('random', response, { efficiency: 0.85, estimateSizeTiB: 1 });
        reportStats = rep.stats;
        jobLogger.info(rep.summaryLine, { ...rep.meta, drivePath: resolvedDrivePath || '' });
        jobLogger.info(rep.estimateLine, { ...rep.meta, kind: 'estimate' });
      } else {
        jobLogger.setStage('error');
        jobLogger.error('Random drive test failed', {
          code: response?.code,
          error: response?.error
        });
      }

      return response;
    } catch (err) {
      if (err?.code === 'DRIVE_TEST_CANCELLED') {
        response = { success: false, cancelled: true, error: 'Cancelled' };
        jobLogger.setStage('cancelled');
        jobLogger.warn('Random drive test cancelled', { code: 'DRIVE_TEST_CANCELLED' });
        return response;
      }
      response = {
        success: false,
        code: err?.code || 'RANDOM_DRIVE_TEST_FAILED',
        error: err?.message || 'Random drive test failed'
      };
      jobLogger.setStage('error');
      jobLogger.error('Random drive test error', {
        code: response.code,
        error: response.error,
        context: err?.context
      });
      return response;
    } finally {
      if (typeof senderId === 'number') {
        driveTestRunningBySender.delete(senderId);
        driveTestCancelBySender.delete(senderId);
      }
      try {
        const success = response?.success === true;
        const cancelled = response?.cancelled === true;
        jobLogger.setStage(cancelled ? 'cancelled' : success ? 'complete' : 'error');

        const { structuredLogPath, archivePath } = _persistSpeedtestJobArtifacts({
          jobLogger,
          jobId,
          senderId,
          inputs: reportInputs,
          settings: reportSettings,
          stats: reportStats
        });
        try { jobLogger.close?.(); } catch {}
        if (response && typeof response === 'object') {
          response.jobId = jobId;
          response.structuredLogPath = structuredLogPath;
          response.archivePath = archivePath;
        }
      } catch (e) {
        console.warn('⚠️ Failed to persist speed-test drive log:', e?.message || e);
        try { jobLogger.close?.(); } catch {}
        if (response && typeof response === 'object') {
          response.jobId = jobId;
          response.structuredLogPath = null;
          response.archivePath = null;
        }
      }
    }
  });

  ipcMain.handle('get-source-metadata', async (event, filePath) => {
    try {
      assertTrustedIpcSender(event, 'get-source-metadata');
      const safePath = assertApprovedPath(event?.sender?.id, filePath);
      return getSourceMetadata(safePath);
    } catch (err) {
      console.error('❌ getSourceMetadata failed:', err);
      return null;
    }
  });

}

// --- Step 5A services wiring ---
function __appendStep5AMisc(ipcMain) {
  const { presetsRoot, listPresets, readJson, deletePreset } = require('../services/presetService');

  ipcMain.handle('list-leadae-presets', async event => {
    try {
      assertTrustedIpcSender(event, 'list-leadae-presets');
      return { ok: true, presets: listPresets(presetsRoot()) };
    } catch (err) {
      return {
        ok: false,
        code: err?.code || 'PRESET_LIST_FAILED',
        message: err?.message || 'Failed to list presets.'
      };
    }
  });

  ipcMain.handle('delete-leadae-preset', async (event, file) => {
    try {
      assertTrustedIpcSender(event, 'delete-leadae-preset');
      await deletePreset(file);
      return { ok: true };
    } catch (err) {
      return {
        ok: false,
        code: err?.code || 'PRESET_DELETE_FAILED',
        message: err?.message || 'Failed to delete preset.'
      };
    }
  });

  ipcMain.handle('read-preset-json', async (event, file) => {
    try {
      assertTrustedIpcSender(event, 'read-preset-json');
      const preset = await readJson(file);
      return { ok: true, preset };
    } catch (err) {
      return {
        ok: false,
        code: err?.code || 'PRESET_READ_FAILED',
        message: err?.message || 'Failed to read preset.'
      };
    }
  });
}
