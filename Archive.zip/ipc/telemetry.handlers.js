// ipc/telemetry.handlers.js
// Minimal telemetry IPC so renderer processes can:
//  - Query whether crash reporting is enabled
//  - Toggle enable/disable
//
// IMPORTANT: We do NOT expose any secrets to the renderer.
//
// NOTE: Renderer crash/error capture is handled by the Sentry Electron renderer SDK
// (@sentry/electron/renderer). We intentionally do NOT accept forwarded renderer
// exceptions over a custom IPC channel anymore (Route A removed).

'use strict';

const telemetry = require('../services/telemetryService');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');

function coerceBool(v, defaultValue = false) {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'string') {
    const s = v.trim().toLowerCase();
    if (s === 'true' || s === '1' || s === 'yes' || s === 'on') return true;
    if (s === 'false' || s === '0' || s === 'no' || s === 'off') return false;
  }
  if (typeof v === 'number') return v !== 0;
  return defaultValue;
}

function registerTelemetryHandlers(ipcMain) {
  if (!ipcMain) return;

  ipcMain.handle('telemetry:get-state', async (event) => {
    assertTrustedIpcSender(event, 'telemetry:get-state');
    return telemetry.getState();
  });

  ipcMain.handle('telemetry:set-enabled', async (event, payload) => {
    assertTrustedIpcSender(event, 'telemetry:set-enabled');
    const enabled = coerceBool(payload?.enabled ?? payload, true);
    const persist = coerceBool(payload?.persist, true);
    const res = telemetry.setEnabled(enabled, { persist });
    return res;
  });
}

module.exports = registerTelemetryHandlers;
