// ipc/cepInstaller.handlers.js
// Install / repair / remove the bundled Adobe CEP extension (Premiere panel)
// into the standard CEP extension locations.
//
// SECURITY:
// - Only callable from trusted renderer origins (our packaged app files, or localhost in dev).
// - The renderer cannot provide arbitrary paths; we only copy from the bundled extension.

'use strict';

const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const { app, shell } = require('electron');
const { execFileSync } = require('child_process');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');

const EXTENSION_ID = 'com.leadae.panel';
const i18nMessage = (key, params = {}) => ({ key, params });

const CEP_ERROR_CODES = Object.freeze({
  STATUS_READ_FAILED: 'CEP_STATUS_READ_FAILED',
  SYSTEM_INSTALL_MAC_ONLY: 'CEP_SYSTEM_INSTALL_MAC_ONLY',
  SYSTEM_INSTALL_NOT_RECOMMENDED: 'CEP_SYSTEM_INSTALL_NOT_RECOMMENDED',
  SIGNED_ZXP_NOT_FOUND: 'CEP_SIGNED_ZXP_NOT_FOUND',
  SIGNED_ZXP_INVALID: 'CEP_SIGNED_ZXP_INVALID',
  INSTALL_FAILED: 'CEP_INSTALL_FAILED',
  SYSTEM_UNINSTALL_MAC_ONLY: 'CEP_SYSTEM_UNINSTALL_MAC_ONLY',
  UNINSTALL_FAILED: 'CEP_UNINSTALL_FAILED',
  OPEN_FOLDER_FAILED: 'CEP_OPEN_FOLDER_FAILED'
});

function cepError(code, params = {}) {
  const keyMap = {
    [CEP_ERROR_CODES.STATUS_READ_FAILED]: 'cepStatusCheckFailed',
    [CEP_ERROR_CODES.SYSTEM_INSTALL_MAC_ONLY]: 'cepSystemInstallMacOnly',
    [CEP_ERROR_CODES.SYSTEM_INSTALL_NOT_RECOMMENDED]: 'cepSystemInstallNotRecommended',
    [CEP_ERROR_CODES.SIGNED_ZXP_NOT_FOUND]: 'cepSignedZxpNotFound',
    [CEP_ERROR_CODES.SIGNED_ZXP_INVALID]: 'cepSignedZxpInvalid',
    [CEP_ERROR_CODES.INSTALL_FAILED]: 'cepInstallFailed',
    [CEP_ERROR_CODES.SYSTEM_UNINSTALL_MAC_ONLY]: 'cepSystemUninstallMacOnly',
    [CEP_ERROR_CODES.UNINSTALL_FAILED]: 'cepUninstallFailed',
    [CEP_ERROR_CODES.OPEN_FOLDER_FAILED]: 'cepOpenFolderFailed'
  };
  return {
    code,
    ...i18nMessage(keyMap[code] || 'cepUnknownError', params),
    params
  };
}

function _isMac() {
  return process.platform === 'darwin';
}

async function _exists(p) {
  try {
    await fsp.access(p);
    return true;
  } catch {
    return false;
  }
}

function _userCepExtensionsDir() {
  // macOS: ~/Library/Application Support/Adobe/CEP/extensions
  // Windows: %APPDATA%\Adobe\CEP\extensions
  return path.join(app.getPath('appData'), 'Adobe', 'CEP', 'extensions');
}

function _systemCepExtensionsDirCandidates() {
  if (_isMac()) {
    return [path.join('/', 'Library', 'Application Support', 'Adobe', 'CEP', 'extensions')];
  }

  if (process.platform === 'win32') {
    const pf86 = process.env['ProgramFiles(x86)'];
    const pf = process.env['ProgramFiles'];

    const candidates = [];
    if (pf86) candidates.push(path.join(pf86, 'Common Files', 'Adobe', 'CEP', 'extensions'));
    if (pf && pf != pf86) candidates.push(path.join(pf, 'Common Files', 'Adobe', 'CEP', 'extensions'));
    return candidates;
  }

  return [];
}


function _resolveBundledZxpPath() {
  // Packaged build: <app>.app/Contents/Resources/cep/zxp/LeadAEAssist_CEP.zxp
  const packaged = path.join(process.resourcesPath, 'cep', 'zxp', 'LeadAEAssist_CEP.zxp');
  if (app.isPackaged && fs.existsSync(packaged)) return packaged;

  // Dev build: <repo>/resources/cep/zxp/LeadAEAssist_CEP.zxp
  const dev = path.join(app.getAppPath(), 'resources', 'cep', 'zxp', 'LeadAEAssist_CEP.zxp');
  if (fs.existsSync(dev)) return dev;

  // Legacy local workspace fallback: some manual signing workflows leave the
  // generated archive at <repo>/build/LeadAEAssist_CEP.zxp. Keep this dev-only
  // fallback so local testing stays resilient, but packaged builds must ship the
  // canonical extraResource under Contents/Resources/cep/zxp.
  const legacyDev = path.join(app.getAppPath(), 'build', 'LeadAEAssist_CEP.zxp');
  if (!app.isPackaged && fs.existsSync(legacyDev)) return legacyDev;

  return packaged;
}

async function _preserveBridgeJsonToken(existingPanelDir) {
  const bridgePath = path.join(existingPanelDir, 'bridge.json');
  try {
    const raw = await fsp.readFile(bridgePath, 'utf-8');
    const data = JSON.parse(raw);
    const token = String(data?.token || '').trim();
    if (token) return raw; // preserve entire file if it has a runtime token
  } catch {}
  return null;
}

async function _restoreBridgeJson(panelDir, bridgeJsonRaw) {
  if (!bridgeJsonRaw) return;
  try {
    await fsp.writeFile(path.join(panelDir, 'bridge.json'), bridgeJsonRaw, 'utf-8');
  } catch {}
}

function _escapePowershellSingleQuotes(value) {
  return String(value || '').replace(/'/g, "''");
}

async function _unzipZxpToTemp(zxpPath) {
  // ZXP is a zip. We unzip to a temp folder and then install the extracted extension folder.
  const tmpBase = await fsp.mkdtemp(path.join(app.getPath('temp'), 'leadae-zxp-'));

  // Cross-platform extraction without adding npm deps:
  // - macOS: /usr/bin/unzip
  // - Windows: PowerShell Expand-Archive
  if (process.platform === 'win32') {
    const ps = process.env.SystemRoot
      ? path.join(process.env.SystemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
      : 'powershell.exe';
    const src = _escapePowershellSingleQuotes(zxpPath);
    const dst = _escapePowershellSingleQuotes(tmpBase);
    const cmd = `Expand-Archive -LiteralPath '${src}' -DestinationPath '${dst}' -Force`;
    execFileSync(ps, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', cmd], { stdio: 'ignore' });
  } else {
    const unzipBin = fs.existsSync('/usr/bin/unzip') ? '/usr/bin/unzip' : 'unzip';
    execFileSync(unzipBin, ['-q', '-o', zxpPath, '-d', tmpBase]);
  }

  return tmpBase;
}



function _resolveBundledExtensionDir() {
  // Packaged build (extraResources): <app>.app/Contents/Resources/cep/extensions/<EXTENSION_ID>
  const packaged = path.join(process.resourcesPath, 'cep', 'extensions', EXTENSION_ID);
  if (app.isPackaged && fs.existsSync(packaged)) return packaged;

  // Dev build: <repo>/cep/extensions/<EXTENSION_ID>
  const dev = path.join(app.getAppPath(), 'cep', 'extensions', EXTENSION_ID);
  if (fs.existsSync(dev)) return dev;

  // Fallback (some workflows): <repo>/resources/cep/extensions/<EXTENSION_ID>
  const fallback = path.join(app.getAppPath(), 'resources', 'cep', 'extensions', EXTENSION_ID);
  if (fs.existsSync(fallback)) return fallback;

  return packaged;
}

async function _copyDir(src, dest) {
  await fsp.rm(dest, { recursive: true, force: true });
  await fsp.mkdir(path.dirname(dest), { recursive: true });
  await fsp.cp(src, dest, { recursive: true, force: true });

  // Best-effort: clear quarantine attribute on macOS (can prevent CEP panels from loading).
  if (_isMac()) {
    try {
      execFileSync('/usr/bin/xattr', ['-dr', 'com.apple.quarantine', dest], { stdio: 'ignore' });
    } catch {
      // ignore
    }
  }
}

async function _rmrf(p) {
  await fsp.rm(p, { recursive: true, force: true });
}

async function _getStatus() {
  const userBase = _userCepExtensionsDir();
  const userPath = path.join(userBase, EXTENSION_ID);
  const userInstalled = await _exists(userPath);

  const systemBases = _systemCepExtensionsDirCandidates();
  let systemInstalled = false;
  let systemPath = null;
  for (const base of systemBases) {
    const p = path.join(base, EXTENSION_ID);
    if (await _exists(p)) {
      systemInstalled = true;
      systemPath = p;
      break;
    }
  }

  const bundledSource = _resolveBundledExtensionDir();
  const bundledZxp = _resolveBundledZxpPath();
  const bundledZxpExists = await _exists(bundledZxp);
  const bundledSourceExists = await _exists(bundledSource);

  return {
    ok: true,
    extensionId: EXTENSION_ID,
    bundledSource,
    bundledSourceExists,
    bundledZxp,
    bundledZxpExists,
    userBase,
    userPath,
    systemBases,
    systemPath,
    installed: {
      user: userInstalled,
      system: systemInstalled,
      any: userInstalled || systemInstalled
    }
  };
}

function registerCepInstallerHandlers(ipcMain) {
  ipcMain.handle('cep:get-status', async (event) => {
    try {
      assertTrustedIpcSender(event, 'cep:get-status');
      return await _getStatus();
    } catch {
      return { ok: false, error: cepError(CEP_ERROR_CODES.STATUS_READ_FAILED) };
    }
  });

  // Install/repair to the per-user CEP folder by default.
  // NOTE: Writing to /Library on macOS generally requires admin rights.
  ipcMain.handle('cep:install', async (event, options = {}) => {
    try {
      assertTrustedIpcSender(event, 'cep:install');

      const scope = String(options?.scope || 'user');

      // We only support user-scope installs reliably without elevated privileges.
      if (scope === 'system') {
        if (!_isMac()) {
          return { ok: false, error: cepError(CEP_ERROR_CODES.SYSTEM_INSTALL_MAC_ONLY) };
        }
        return { ok: false, error: cepError(CEP_ERROR_CODES.SYSTEM_INSTALL_NOT_RECOMMENDED) };
      }

      const destBase = _userCepExtensionsDir();
      const dest = path.join(destBase, EXTENSION_ID);

      // Preserve existing bridge.json with runtime token (if present)
      const preservedBridge = await _preserveBridgeJsonToken(dest);

      // Install ONLY from the signed ZXP (includes META-INF/signatures.xml).
      const zxpPath = _resolveBundledZxpPath();
      const zxpExists = await _exists(zxpPath);

      if (!zxpExists) {
        return {
          ok: false,
          error: cepError(CEP_ERROR_CODES.SIGNED_ZXP_NOT_FOUND, { zxpPath })
        };
      }

      const tmpDir = await _unzipZxpToTemp(zxpPath);

      // Locate extension root in the unzipped output.
      let extensionRoot = tmpDir;
      if (!fs.existsSync(path.join(extensionRoot, 'CSXS', 'manifest.xml'))) {
        const entries = await fsp.readdir(tmpDir, { withFileTypes: true });
        for (const ent of entries) {
          if (!ent.isDirectory()) continue;
          const candidate = path.join(tmpDir, ent.name);
          if (fs.existsSync(path.join(candidate, 'CSXS', 'manifest.xml'))) {
            extensionRoot = candidate;
            break;
          }
        }
      }

      if (!fs.existsSync(path.join(extensionRoot, 'CSXS', 'manifest.xml'))) {
        await _rmrf(tmpDir);
        return {
          ok: false,
          error: cepError(CEP_ERROR_CODES.SIGNED_ZXP_INVALID, { zxpPath })
        };
      }

      await _copyDir(extensionRoot, dest);
      await _restoreBridgeJson(dest, preservedBridge);
      await _rmrf(tmpDir);

      const metaInf = path.join(dest, 'META-INF', 'signatures.xml');
      const hasMeta = await _exists(metaInf);

      return {
        ok: true,
        scope: 'user',
        dest,
        installedFrom: 'zxp',
        zxpPath,
        hasSignatureMetadata: hasMeta,
        ...(await _getStatus())
      };
    } catch (err) {
      return {
        ok: false,
        error: cepError(CEP_ERROR_CODES.INSTALL_FAILED, {
          detail: String(err?.message || '').trim()
        })
      };
    }
  });

  ipcMain.handle('cep:uninstall', async (event, options = {}) => {
    try {
      assertTrustedIpcSender(event, 'cep:uninstall');

      const scope = String(options?.scope || 'user');

      if (scope === 'system') {
        if (!_isMac()) return { ok: false, error: cepError(CEP_ERROR_CODES.SYSTEM_UNINSTALL_MAC_ONLY) };
        const destBase = path.join('/', 'Library', 'Application Support', 'Adobe', 'CEP', 'extensions');
        const dest = path.join(destBase, EXTENSION_ID);
        await _rmrf(dest);
        return { ok: true, scope: 'system', removed: dest, ...(await _getStatus()) };
      }

      const destBase = _userCepExtensionsDir();
      const dest = path.join(destBase, EXTENSION_ID);
      await _rmrf(dest);
      return { ok: true, scope: 'user', removed: dest, ...(await _getStatus()) };
    } catch (err) {
      return {
        ok: false,
        error: cepError(CEP_ERROR_CODES.UNINSTALL_FAILED, {
          detail: String(err?.message || '').trim()
        })
      };
    }
  });

  ipcMain.handle('cep:open-folder', async (event, options = {}) => {
    try {
      assertTrustedIpcSender(event, 'cep:open-folder');

      const scope = String(options?.scope || 'user');
      const base = scope === 'system'
        ? path.join('/', 'Library', 'Application Support', 'Adobe', 'CEP', 'extensions')
        : _userCepExtensionsDir();

      const panelPath = path.join(base, EXTENSION_ID);
      const toOpen = fs.existsSync(panelPath) ? panelPath : base;

      const res = await shell.openPath(toOpen);
      if (res) {
        return {
          ok: false,
          error: cepError(CEP_ERROR_CODES.OPEN_FOLDER_FAILED, {
            detail: String(res || '').trim(),
            targetPath: toOpen
          })
        };
      }
      return { ok: true, opened: toOpen };
    } catch (err) {
      return {
        ok: false,
        error: cepError(CEP_ERROR_CODES.OPEN_FOLDER_FAILED, {
          detail: String(err?.message || '').trim()
        })
      };
    }
  });
}

module.exports = registerCepInstallerHandlers;
