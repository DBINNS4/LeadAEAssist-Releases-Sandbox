// ipc/backup.handlers.js
// Standalone backup queue (mirror/template) for Adobe Automate panel.
// Provides a lightweight in-memory queue with best-effort verification and state broadcasting.

const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const crypto = require('crypto');
const { BrowserWindow } = require('electron');
const { v4: uuidv4 } = require('uuid');
const licenseService = require('../services/licenseService');
const { moveReplace, uniqueTempPath } = require('../utils/fsSafe');
const {
  assertApprovedPaths,
  extractAbsolutePathsFromObject
} = require('../utils/ipcPathGuards');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');

const DEFAULT_VERIFY_MODE = 'fast'; // none | fast (size) | full (sha1)
const DEFAULT_COLLISION = 'version'; // version | overwrite | skip

const state = {
  jobs: [],
  paused: false,
  activeJobId: null
};

let processing = false;
let cancelRequested = false;

function deepCloneJob(job) {
  return {
    ...job,
    items: (job.items || []).map(it => ({ ...it }))
  };
}

function snapshotState() {
  return {
    paused: state.paused,
    activeJobId: state.activeJobId,
    jobs: state.jobs.map(deepCloneJob)
  };
}

function broadcastState() {
  const snap = snapshotState();
  BrowserWindow.getAllWindows().forEach(win => {
    try {
      win.webContents.send('backup-state', snap);
    } catch {
      // ignore broadcast errors
    }
  });
}

async function ensureDir(dir) {
  if (!dir) return;
  await fsp.mkdir(dir, { recursive: true });
}

async function fileExists(p) {
  try {
    await fsp.access(p, fs.constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

async function hashFile(filePath) {
  const hash = crypto.createHash('sha1');
  const stream = fs.createReadStream(filePath);
  return new Promise((resolve, reject) => {
    stream.on('data', chunk => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });
}

async function verifyCopy(src, dest, mode) {
  if (mode === 'none') return { ok: true };

  try {
    const [srcStat, destStat] = await Promise.all([fsp.stat(src), fsp.stat(dest)]);
    if (srcStat.size !== destStat.size) {
      return { ok: false, error: 'Size mismatch after copy' };
    }
    if (mode === 'full') {
      const [srcHash, destHash] = await Promise.all([hashFile(src), hashFile(dest)]);
      if (srcHash !== destHash) {
        return { ok: false, error: 'Checksum mismatch after copy' };
      }
    }
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message || String(err) };
  }
}

function safeRelative(root, target) {
  if (!root) return null;
  try {
    const rel = path.relative(root, target);
    if (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) {
      return rel;
    }
  } catch {
    // ignore and fall back to basename
  }
  return null;
}

async function resolveDestination(baseDest, onCollision) {
  const exists = await fileExists(baseDest);
  if (!exists) return baseDest;

  switch (onCollision) {
    case 'overwrite':
      return baseDest;
    case 'skip':
      return null;
    case 'version':
    default: {
      const { dir, name, ext } = path.parse(baseDest);
      for (let i = 1; i <= 999; i++) {
        const candidate = path.join(dir, `${name}_v${i}${ext}`);
        if (!(await fileExists(candidate))) return candidate;
      }
      return baseDest;
    }
  }
}

function computeDestination(job, item) {
  const relFromRoot = item.sourceRoot ? safeRelative(item.sourceRoot, item.sourcePath) : null;
  const rel = relFromRoot || path.basename(item.sourcePath);
  const parts = [job.destinationRoot];
  if (job.projectName) parts.push(job.projectName);
  if (job.mode === 'template' && job.template) parts.push(job.template);
  parts.push(rel);
  return path.join(...parts);
}

function clampInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isInteger(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function createJob(payload) {
  const destinationRoot = String(payload?.destinationRoot || '').trim();
  if (!destinationRoot) throw new Error('Destination root is required for backup jobs.');

  const items = Array.isArray(payload?.items)
    ? payload.items
        .map(it => ({
          id: uuidv4(),
          sourcePath: String(it?.sourcePath || '').trim(),
          sourceRoot: String(it?.sourceRoot || '').trim()
        }))
        .filter(it => it.sourcePath)
    : [];

  if (!items.length) {
    throw new Error('At least one source item is required for backup jobs.');
  }

  const verifyMode = ['none', 'fast', 'full'].includes(payload?.verifyMode)
    ? payload.verifyMode
    : DEFAULT_VERIFY_MODE;
  const onCollision = ['version', 'overwrite', 'skip'].includes(payload?.onCollision)
    ? payload.onCollision
    : DEFAULT_COLLISION;
  const concurrency = clampInt(payload?.concurrency, 1, 8, 1);

  return {
    id: uuidv4(),
    status: 'queued',
    addedAt: Date.now(),
    destinationRoot,
    mode: payload?.mode || 'mirror',
    verifyMode,
    onCollision,
    projectName: String(payload?.projectName || '').trim() || null,
    template: String(payload?.template || '').trim() || null,
    concurrency,
    writeHtml: !!payload?.writeHtml,
    items: items.map(it => ({
      ...it,
      status: 'pending',
      destPath: '',
      result: '',
      sizeBytes: null,
      startedAt: null,
      endedAt: null
    }))
  };
}

async function processItem(job, item) {
  if (cancelRequested || job.cancelRequested) {
    const err = new Error('cancelled');
    err.code = 'BACKUP_CANCELLED';
    throw err;
  }

  item.startedAt = Date.now();
  item.status = 'copying';
  broadcastState();

  const destPath = computeDestination(job, item);
  const resolvedDest = await resolveDestination(destPath, job.onCollision);
  if (!resolvedDest) {
    item.status = 'skipped';
    item.result = 'Skipped due to collision rule';
    item.endedAt = Date.now();
    return;
  }

  item.destPath = resolvedDest;
  await ensureDir(path.dirname(resolvedDest));

  const srcStat = await fsp.stat(item.sourcePath);
  item.sizeBytes = Number(srcStat.size) || 0;

  const tempPath = uniqueTempPath(resolvedDest, '.partial');
  try {
    await fsp.copyFile(item.sourcePath, tempPath);
    await moveReplace(tempPath, resolvedDest);

    const verifyResult = await verifyCopy(item.sourcePath, resolvedDest, job.verifyMode);
    if (!verifyResult.ok) {
      const err = new Error(verifyResult.error || 'Verification failed');
      err.code = 'BACKUP_VERIFY_FAILED';
      throw err;
    }

    try {
      const sourceMeta = await fsp.stat(item.sourcePath);
      try {
        await fsp.utimes(resolvedDest, sourceMeta.atime, sourceMeta.mtime);
      } catch (metaErr) {
        console.warn(`Backup: failed to set timestamps for ${resolvedDest}`, metaErr);
      }
      try {
        await fsp.chmod(resolvedDest, sourceMeta.mode);
      } catch (metaErr) {
        console.warn(`Backup: failed to set permissions for ${resolvedDest}`, metaErr);
      }
    } catch (metaErr) {
      console.warn(`Backup: failed to read source metadata for ${item.sourcePath}`, metaErr);
    }

    item.status = 'completed';
    item.endedAt = Date.now();
  } catch (err) {
    try { await fsp.unlink(tempPath); } catch {}
    try {
      const destStat = await fsp.stat(resolvedDest);
      if (err?.code === 'BACKUP_VERIFY_FAILED' || destStat.size !== srcStat.size) {
        await fsp.unlink(resolvedDest);
      }
    } catch {}

    item.status = 'failed';
    item.result = err?.message || String(err);
    item.endedAt = Date.now();
  }
}

async function runWithConcurrency(items, concurrency, handler, abortSignal) {
  let index = 0;
  const workers = new Array(Math.min(concurrency, items.length)).fill(0).map(async () => {
    while (true) {
      if (abortSignal.aborted) break;
      const currentIndex = index++;
      if (currentIndex >= items.length) break;
      try {
        await handler(items[currentIndex]);
      } catch (err) {
        if (!abortSignal.aborted) {
          abortSignal.aborted = true;
          abortSignal.error = err;
        }
        break;
      }
    }
  });
  await Promise.allSettled(workers);
}

function markPendingItems(job, status, result) {
  const endedAt = Date.now();
  job.items.forEach(item => {
    if (item.status === 'pending') {
      item.status = status;
      item.result = result;
      item.endedAt = endedAt;
    }
  });
}

async function processJob(job) {
  job.status = 'running';
  job.startedAt = Date.now();
  job.cancelRequested = false;
  state.activeJobId = job.id;
  broadcastState();

  const abortSignal = { aborted: false, error: null };

  try {
    await runWithConcurrency(job.items, job.concurrency, async item => {
      if (cancelRequested || job.cancelRequested) {
        const err = new Error('cancelled');
        err.code = 'BACKUP_CANCELLED';
        throw err;
      }
      await processItem(job, item);
      broadcastState();
    }, abortSignal);

    if (abortSignal.aborted && abortSignal.error) {
      throw abortSignal.error;
    }
  } catch (err) {
    abortSignal.aborted = true;
    abortSignal.error = err;
  } finally {
    if (abortSignal.aborted) {
      if (abortSignal.error?.code === 'BACKUP_CANCELLED' || cancelRequested || job.cancelRequested) {
        markPendingItems(job, 'cancelled', 'Cancelled before processing');
        job.status = 'cancelled';
      } else {
        markPendingItems(job, 'skipped', 'Skipped due to earlier failure');
        job.status = 'failed';
        job.error = abortSignal.error?.message || String(abortSignal.error);
      }
    } else if (job.items.some(it => it.status === 'failed')) {
      job.status = 'failed';
    } else {
      job.status = 'completed';
    }

    job.endedAt = Date.now();
    state.activeJobId = null;
    broadcastState();
  }
}

async function processQueue() {
  if (processing || state.paused) return;
  const nextJob = state.jobs.find(j => j.status === 'queued');
  if (!nextJob) return;

  processing = true;
  cancelRequested = false;
  await processJob(nextJob);
  processing = false;

  if (!state.paused) {
    processQueue();
  }
}

function registerBackupHandlers(ipcMain) {
  // Defensive: avoid crashing the app if this registrar is called twice.
  // Electron throws when registering a second ipcMain.handle() for the same channel.
  if (ipcMain && ipcMain.__leadae_backupHandlersRegistered) return;
  if (ipcMain) ipcMain.__leadae_backupHandlersRegistered = true;

  ipcMain.handle('backup-add-job', async (event, payload) => {
    assertTrustedIpcSender(event, 'backup-add-job');
    if (!licenseService.isFeatureEnabled('backup')) {
      return { success: false, error: 'License required for backup' };
    }
    try {
      const senderId = event?.sender?.id;
      const knownPaths = [];

      if (payload?.destinationRoot) knownPaths.push(payload.destinationRoot);
      if (Array.isArray(payload?.items)) {
        for (const item of payload.items) {
          if (item?.sourcePath) knownPaths.push(item.sourcePath);
          if (item?.sourceRoot) knownPaths.push(item.sourceRoot);
        }
      }

      // Deep scan for any absolute paths (defensive against future payload changes).
      const nested = extractAbsolutePathsFromObject(payload || {});
      assertApprovedPaths(senderId, [...knownPaths, ...nested]);
    } catch (err) {
      return { success: false, error: err?.message || String(err) };
    }

    const job = createJob(payload || {});
    state.jobs.push(job);
    broadcastState();
    processQueue();
    return { success: true, jobId: job.id };
  });

  ipcMain.handle('backup-get-state', async (event) => {
    assertTrustedIpcSender(event, 'backup-get-state');
    return snapshotState();
  });

  ipcMain.handle('backup-run', (event) => {
    assertTrustedIpcSender(event, 'backup-run');
    if (!licenseService.isFeatureEnabled('backup')) {
      return { success: false, error: 'License required for backup' };
    }
    state.paused = false;
    processQueue();
    broadcastState();
    return { success: true };
  });

  ipcMain.handle('backup-pause', (event) => {
    assertTrustedIpcSender(event, 'backup-pause');
    state.paused = true;
    broadcastState();
    return { success: true };
  });

  ipcMain.handle('backup-resume', (event) => {
    assertTrustedIpcSender(event, 'backup-resume');
    if (!licenseService.isFeatureEnabled('backup')) {
      return { success: false, error: 'License required for backup' };
    }
    state.paused = false;
    processQueue();
    broadcastState();
    return { success: true };
  });

  ipcMain.handle('backup-cancel', (event) => {
    assertTrustedIpcSender(event, 'backup-cancel');
    cancelRequested = true;
    const activeJob = state.jobs.find(j => j.id === state.activeJobId);
    if (activeJob) activeJob.cancelRequested = true;
    broadcastState();
    return { success: true };
  });
}

module.exports = registerBackupHandlers;
