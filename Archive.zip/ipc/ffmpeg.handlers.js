// ipc/ffmpeg.handlers.js
// FFmpeg-related IPC endpoints: exec-ffmpeg, exec-ffprobe, ffmpeg:get-capabilities.

const {
  runFfmpeg,
  runFfprobe,
  runFfprobeJson,
  probeMedia,
  getCapabilities,
  getMuxerFormats
} = require('../services/ffmpegService');

const path = require('path');
const { fileURLToPath } = require('url');
const { isPathAllowed } = require('../utils/fsAccessControl');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');

// -----------------------------
// Arg policy (defensive)
// -----------------------------
// Even when the executable is fixed, untrusted args can still be abused
// (e.g., remote/network protocols, reading/writing arbitrary paths).

function _isWindowsDrivePath(s) {
  return typeof s === 'string' && /^[a-zA-Z]:[\\/]/.test(s);
}

function _toLocalPathIfFileUrl(p) {
  if (typeof p !== 'string') return p;
  if (p.startsWith('file://')) {
    try {
      return fileURLToPath(p);
    } catch {
      return p;
    }
  }
  return p;
}

function _looksLikeUriScheme(s) {
  if (typeof s !== 'string') return false;
  if (_isWindowsDrivePath(s)) return false;
  // Matches: "scheme:" at the beginning (e.g., http:, https:, rtmp:, pipe:)
  return /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(s);
}

function _isDisallowedScheme(s) {
  if (!_looksLikeUriScheme(s)) return false;
  const scheme = String(s).split(':', 1)[0].toLowerCase();
  // Allow file: URLs only. Everything else is blocked.
  return scheme !== 'file';
}

function _assertNoUriArgs(args) {
  for (const a of args) {
    const s = String(a ?? '');
    if (_isDisallowedScheme(s)) {
      throw new Error(`❌ FFmpeg args rejected: URI/protocol not allowed (${s})`);
    }
    // Also catch common URL forms that may not match the simple scheme regex above.
    if (/(^|\s)(https?:\/\/|rtsp:\/\/|rtmp:\/\/|srt:\/\/)/i.test(s)) {
      throw new Error(`❌ FFmpeg args rejected: network URL not allowed (${s})`);
    }
  }
}

function _looksPathLikeToken(token) {
  if (typeof token !== 'string' || !token.trim()) return false;
  const s = token.trim();
  return (
    s.startsWith('file://') ||
    _isWindowsDrivePath(s) ||
    path.isAbsolute(s) ||
    /^\.{1,2}[\\/]/.test(s) ||
    /[\\/]/.test(s) ||
    /\.(srt|ass|ssa|vtt|txt|cube|3dl|lut|ffconcat)$/i.test(s)
  );
}

function _unquoteToken(value) {
  if (typeof value !== 'string') return value;
  const s = value.trim();
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
    return s.slice(1, -1);
  }
  return s;
}

function _extractCandidatePathsFromFfmpegArgs(args) {
  const out = [];
  const ambiguous = [];
  if (!Array.isArray(args)) return out;

  const consumedIndexes = new Set();
  const pathValueFlags = new Set([
    '-i',
    '-attach',
    '-filter_script',
    '-filter_complex_script',
    '-vstats_file',
    '-passlogfile'
  ]);
  const filterFlags = new Set(['-vf', '-af', '-lavfi', '-filter_complex']);

  function extractFiltergraphPathCandidates(filterArg) {
    const paths = [];
    const localAmbiguous = [];
    const s = String(filterArg ?? '');
    const knownKv = /(?:^|[:;,])(filename|file|textfile|fontfile)\s*=\s*((?:'[^']*'|"[^"]*"|[^:;,])+)/gi;
    const knownPositional = /(?:^|[:;,])(?:subtitles|ass|movie|amovie|lut1d|lut3d)\s*=\s*((?:'[^']*'|"[^"]*"|[^:;,])+)/gi;
    let m;

    while ((m = knownKv.exec(s))) {
      paths.push(_unquoteToken(m[2]));
    }
    while ((m = knownPositional.exec(s))) {
      paths.push(_unquoteToken(m[1]));
    }

    const kvPair = /(?:^|[:;,])([a-zA-Z_][\w-]*)\s*=\s*((?:'[^']*'|"[^"]*"|[^:;,])+)/g;
    while ((m = kvPair.exec(s))) {
      const key = String(m[1] || '').toLowerCase();
      const value = _unquoteToken(m[2]);
      if (['filename', 'file', 'textfile', 'fontfile', 'subtitles', 'ass', 'movie', 'amovie', 'lut1d', 'lut3d'].includes(key)) continue;
      if (_looksPathLikeToken(value)) {
        localAmbiguous.push(`${key}=${value}`);
      }
    }

    return { paths, ambiguous: localAmbiguous };
  }

  for (let i = 0; i < args.length; i++) {
    const token = args[i];
    if (typeof token !== 'string') continue;

    if (pathValueFlags.has(token) && i + 1 < args.length) {
      out.push(args[i + 1]);
      consumedIndexes.add(i + 1);
      i++;
      continue;
    }

    if (filterFlags.has(token) && i + 1 < args.length) {
      const extracted = extractFiltergraphPathCandidates(args[i + 1]);
      out.push(...extracted.paths);
      ambiguous.push(...extracted.ambiguous);
      consumedIndexes.add(i + 1);
      i++;
      continue;
    }

    const inlineFilter = token.match(/^-(vf|af|lavfi|filter_complex)=(.*)$/);
    if (inlineFilter) {
      const extracted = extractFiltergraphPathCandidates(inlineFilter[2]);
      out.push(...extracted.paths);
      ambiguous.push(...extracted.ambiguous);
    }
  }

  // Output path is typically the last token that does not begin with '-'.
  for (let i = args.length - 1; i >= 0; i--) {
    const v = args[i];
    if (typeof v === 'string' && v.length && !v.startsWith('-')) {
      out.push(v);
      consumedIndexes.add(i);
      break;
    }
  }

  for (let i = 0; i < args.length; i++) {
    const token = args[i];
    if (typeof token !== 'string' || token.startsWith('-') || consumedIndexes.has(i)) continue;
    if (_looksPathLikeToken(token)) {
      ambiguous.push(token);
    }
  }

  return { paths: out, ambiguous };
}

function _extractCandidatePathsFromFfprobeArgs(args) {
  if (!Array.isArray(args)) return [];
  const paths = [];
  for (const token of args) {
    if (typeof token !== 'string') continue;
    const candidate = _unquoteToken(token);
    if (_looksPathLikeToken(candidate)) {
      paths.push(candidate);
    }
  }
  return paths;
}

function _assertPathsAllowed(senderId, extraction) {
  const id = Number(senderId);
  // If senderId is not available, fail closed.
  if (!Number.isFinite(id)) {
    throw new Error('❌ FFmpeg args rejected: missing sender context');
  }

  const paths = Array.isArray(extraction) ? extraction : extraction?.paths || [];
  const ambiguous = Array.isArray(extraction?.ambiguous) ? extraction.ambiguous : [];

  if (ambiguous.length) {
    throw new Error(`❌ FFmpeg args rejected: ambiguous path-like token (${ambiguous[0]})`);
  }

  for (const raw of paths) {
    const p0 = _toLocalPathIfFileUrl(String(raw ?? ''));
    if (!p0) continue;

    // If it looks like a URI scheme (other than file: which we already converted), reject.
    if (_isDisallowedScheme(p0)) {
      throw new Error(`❌ FFmpeg args rejected: URI/protocol not allowed (${p0})`);
    }

    // Require absolute paths to avoid cwd-dependent escape.
    if (!_isWindowsDrivePath(p0) && !path.isAbsolute(p0)) {
      throw new Error(`❌ FFmpeg args rejected: path must be absolute (${p0})`);
    }

    if (!isPathAllowed(id, p0)) {
      throw new Error(`❌ FFmpeg args rejected: path not approved (${p0})`);
    }
  }
}

function registerFfmpegHandlers(ipcMain) {
  ipcMain.handle('exec-ffmpeg', async (event, args = [], options = {}) => {
    assertTrustedIpcSender(event, 'exec-ffmpeg');
    // SECURITY: The renderer may NOT provide an executable path.
    // Signature: exec-ffmpeg(args[, options])
    if (!Array.isArray(args)) {
      throw new Error('❌ exec-ffmpeg rejected: args must be an array');
    }
    const safeOptions = (options && typeof options === 'object') ? options : {};

    // Tighten: block URI/network protocols and ensure file paths are inside user-approved roots.
    _assertNoUriArgs(args);
    _assertPathsAllowed(event?.sender?.id, _extractCandidatePathsFromFfmpegArgs(args));

    try {
      const value = await runFfmpeg(args, safeOptions);
      return { ok: true, value };
    } catch (error) {
      if (error && typeof error === 'object' && typeof error.code === 'string') {
        return { ok: false, error };
      }
      throw error;
    }
  });

  ipcMain.handle('exec-ffprobe', async (event, args = [], options = {}) => {
    assertTrustedIpcSender(event, 'exec-ffprobe');
    // Signature: exec-ffprobe(args)
    // SECURITY: The renderer may NOT provide an executable path.
    const safeArgs = Array.isArray(args) ? args : [];
    _assertNoUriArgs(safeArgs);

    _assertPathsAllowed(event?.sender?.id, _extractCandidatePathsFromFfprobeArgs(safeArgs));

    const safeOptions = (options && typeof options === 'object') ? options : {};
    return runFfprobe(safeArgs, safeOptions);
  });

  ipcMain.handle('ffprobe-json', async (event, filePath, extraArgs = [], options = {}) => {
    assertTrustedIpcSender(event, 'ffprobe-json');
    // Tighten: block URI/network protocols and require the file path be approved.
    const fp = _toLocalPathIfFileUrl(String(filePath ?? ''));
    _assertNoUriArgs([fp, ...(Array.isArray(extraArgs) ? extraArgs : [])]);
    _assertPathsAllowed(event?.sender?.id, [fp]);
    const safeOptions = (options && typeof options === 'object') ? options : {};
    return runFfprobeJson(fp, extraArgs, safeOptions);
  });

  ipcMain.handle('probe-media', async (event, file, options = {}) => {
    assertTrustedIpcSender(event, 'probe-media');
    const fp = _toLocalPathIfFileUrl(String(file ?? ''));
    _assertNoUriArgs([fp]);
    _assertPathsAllowed(event?.sender?.id, [fp]);
    const safeOptions = (options && typeof options === 'object') ? options : {};
    return probeMedia(fp, safeOptions);
  });

  ipcMain.handle('ffmpeg:get-capabilities', (event) => {
    assertTrustedIpcSender(event, 'ffmpeg:get-capabilities');
    return getCapabilities();
  });

  ipcMain.handle('get-ffmpeg-formats', (event) => {
    assertTrustedIpcSender(event, 'get-ffmpeg-formats');
    return getMuxerFormats();
  });
}

module.exports = registerFfmpegHandlers;
