'use strict';
// ipc/bridge.handlers.js
const { getBridgeInfo } = require('../services/bridgeAuthService');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');

function registerBridgeHandlers(ipcMain) {
  ipcMain.handle('bridge:get-credentials', async (event) => {
    try {
      assertTrustedIpcSender(event, 'bridge:get-credentials');
      // Forward structured errors so the renderer/CEP UI can show recovery guidance.
      return await getBridgeInfo();
    } catch (err) {
      if (err?.code === 'ERR_UNTRUSTED_ORIGIN') {
        return { ok: false, error: 'Unauthorized IPC sender.' };
      }
      return {
        ok: false,
        code: err?.code || 'ERR_BRIDGE_CREDENTIALS',
        error: err?.message || 'Failed to get bridge credentials.',
      };
    }
  });
}

module.exports = registerBridgeHandlers;
