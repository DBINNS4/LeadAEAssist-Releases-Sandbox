// ipc/license.handlers.js
// Licensing IPC is read-only from the renderer. Entitlement is verified and
// enforced in the main process.

const { dialog, BrowserWindow, app } = require('electron');
const os = require('os');
const path = require('path');
const fs = require('fs');
const licenseService = require('../services/licenseService');
const secureStore = require('../modules/secureStore');
const { sendLogMessage } = require('../modules/logUtils');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const { loadPublicRuntimeConfig } = require('../utils/publicRuntimeConfig');
const { readState } = require('../utils/state');

// Allow dev runs to simulate packaged behavior (so you can catch packaging-only config failures early).
// Usage: LEADAE_SIMULATE_PACKAGED=1 npm start
const IS_PACKAGED = !!app?.isPackaged || process.env.LEADAE_SIMULATE_PACKAGED === '1';
const __publicCfg = loadPublicRuntimeConfig({ isPackaged: IS_PACKAGED, allowDefaults: !IS_PACKAGED });

function _getParentWindowFromEvent(event) {
  try {
    const wc = event?.sender;
    if (!wc) return null;
    return BrowserWindow.fromWebContents(wc) || null;
  } catch {
    return null;
  }
}

function _safeLicenseDialogFilters() {
  // Allow a few common formats:
  // - token-only text file
  // - JSON wrapper that contains { token: "..." }
  // - custom extension (optional)
  return [
    { name: 'License', extensions: ['leadai_license', 'license', 'json', 'txt'] },
    { name: 'All Files', extensions: ['*'] }
  ];
}

function _lockedEntitlement() {
  return {
    status: 'LOCKED',
    tier: 'none',
    valid: false,
    expiresAt: null,
    reason: 'no_license',
    trial: null,
    // Minimal recovery surfaces only.
    features: { preferences: true, 'log-viewer': true, account: true }
  };
}

function _sanitizeEntitlementForRenderer(ent) {
  if (!ent || typeof ent !== 'object') return ent;
  const out = { ...ent };
  // Never expose device identifiers or subscription ids to renderer.
  delete out.deviceId;
  delete out.device_id;
  delete out._boundDeviceId;
  delete out.subscriptionId;
  delete out.subscription_id;
  return out;
}

function _broadcastLicenseChanged(entitlement) {
  try {
    const safe = _sanitizeEntitlementForRenderer(entitlement);
    const wins = BrowserWindow.getAllWindows ? BrowserWindow.getAllWindows() : [];
    for (const w of wins) {
      try { w?.webContents?.send('license:changed', safe); } catch {}
    }
  } catch {
    // ignore
  }
}

function _getDeviceIdMainProcess() {
  try {
    const current = licenseService.getEntitlement({ forceReload: false });
    const d = current && typeof current.deviceId === 'string' ? current.deviceId.trim() : '';
    if (d) return d;
  } catch {}
  try {
    const v = secureStore.loadSecret('deviceId');
    if (typeof v === 'string' && v.trim()) return v.trim();
  } catch {}
  try {
    // Generate a stable device id on first run.
    const { randomUUID } = require('crypto');
    const fresh = randomUUID();
    try { secureStore.saveSecret('deviceId', fresh); } catch {}
    return fresh;
  } catch {}
  return '';
}

function _scrubSafeMessage(raw) {
  let msg = 'unknown_error';
  try {
    msg = (raw && raw.message) ? String(raw.message) : String(raw || 'unknown_error');
  } catch {}
  return msg.replace(/\/[\w.-/]+/g, '[path]');
}

function _failure(code, retryable, message) {
  const safeMessage = _scrubSafeMessage(message);
  return {
    ok: false,
    error: safeMessage,
    code,
    retryable: !!retryable,
    message: safeMessage
  };
}

function _isRetryableStatus(status) {
  return status === 502 || status === 503 || status === 504;
}

function _isPendingEntitlementStatus(status, responseBody) {
  const body = String(responseBody || '').trim().toLowerCase();
  if (status === 404 && body === 'not_found') return true;
  if (status === 403 && body === 'not_entitled') return true;
  return false;
}

function _sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function _readResponseText(resp) {
  if (!resp || typeof resp.text !== 'function') return '';
  try {
    return String(await resp.text()).trim();
  } catch {
    return '';
  }
}


function isOfflineModeEnabled() {
  try {
    const state = readState() || {};
    return !!state?.preferences?.offlineMode;
  } catch {
    return false;
  }
}

async function _fetchEntitlementWithRetry(url, payload, options = {}) {
  const timeoutMs = Math.max(8000, Math.min(15000, Number(process.env.LEADAE_ENTITLEMENT_TIMEOUT_MS) || 10000));
  const waitForEntitlement = options?.waitForEntitlement === true;
  const maxAttempts = waitForEntitlement ? 8 : 3;
  let lastFailure = _failure('entitlement_unknown', false, 'unknown_error');

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    const controller = new AbortController();
    const timer = setTimeout(() => {
      try {
        controller.abort();
        sendLogMessage(
          'system',
          '[license:sync-entitlement] request timeout',
          JSON.stringify({ attempt, timeoutMs }),
          false,
          '',
          'warn'
        );
      } catch {}
    }, timeoutMs);

    try {
      const headers = { 'content-type': 'application/json; charset=utf-8' };

      const resp = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload),
        signal: controller.signal
      });

      if (!resp.ok) {
        const responseBody = await _readResponseText(resp);
        const retryableStatus = _isRetryableStatus(resp.status);
        const pendingEntitlement = waitForEntitlement && _isPendingEntitlementStatus(resp.status, responseBody);
        const retryable = retryableStatus || pendingEntitlement;
        const failureDetail = responseBody ? `: ${responseBody}` : '';
        const failure = _failure(`entitlement_http_${resp.status}`, retryable, `Entitlement fetch failed (${resp.status})${failureDetail}`);
        if (!retryable || attempt >= maxAttempts) {
          return failure;
        }

        const backoffMs = pendingEntitlement
          ? (500 * attempt) + 500 + Math.floor(Math.random() * 250)
          : (250 * attempt) + Math.floor(Math.random() * 200);
        sendLogMessage(
          'system',
          pendingEntitlement
            ? '[license:sync-entitlement] entitlement pending, retrying'
            : '[license:sync-entitlement] transient HTTP failure, retrying',
          JSON.stringify({ attempt, status: resp.status, responseBody, backoffMs }),
          false,
          '',
          'warn'
        );
        await _sleep(backoffMs);
        lastFailure = failure;
        continue;
      }

      return { ok: true, token: await _readResponseText(resp) };
    } catch (err) {
      const isAbort = err?.name === 'AbortError';
      const retryable = isAbort || err instanceof TypeError;
      const failure = _failure(
        isAbort ? 'entitlement_timeout' : 'entitlement_network_error',
        retryable,
        isAbort ? `Entitlement request timed out (${timeoutMs}ms)` : `Entitlement network error: ${_scrubSafeMessage(err)}`
      );

      if (!retryable || attempt >= maxAttempts) {
        return failure;
      }

      const backoffMs = 250 * attempt + Math.floor(Math.random() * 200);
      sendLogMessage(
        'system',
        '[license:sync-entitlement] transient network failure, retrying',
        JSON.stringify({ attempt, code: failure.code, backoffMs }),
        false,
        '',
        'warn'
      );
      await _sleep(backoffMs);
      lastFailure = failure;
    } finally {
      clearTimeout(timer);
    }
  }

  return lastFailure;
}

function registerLicenseHandlers(ipcMain) {
  ipcMain.handle('license:get-tier', (event) => {
    try {
      assertTrustedIpcSender(event, 'license:get-tier');
      const ent = licenseService.getEntitlement();
      return ent?.tier || 'none';
    } catch {
      return 'none';
    }
  });

  ipcMain.handle('license:is-enabled', (event, featureKey) => {
    try {
      assertTrustedIpcSender(event, 'license:is-enabled');
      return !!licenseService.isFeatureEnabled(String(featureKey || ''));
    } catch {
      return false;
    }
  });

  // Returns the current verified entitlement (safe to show to renderer).
  // NOTE: This does NOT include any secret material.
  ipcMain.handle('license:get-entitlement', (event, options) => {
    try {
      assertTrustedIpcSender(event, 'license:get-entitlement');
      const forceReload = !!options?.forceReload;
      return _sanitizeEntitlementForRenderer(licenseService.getEntitlement({ forceReload }));
    } catch {
      return _lockedEntitlement();
    }
  });

  // Clears any installed token from secure storage.
  ipcMain.handle('license:clear', (event) => {
    try {
      assertTrustedIpcSender(event, 'license:clear');
      const ent = licenseService.clearLicense();
      const safe = _sanitizeEntitlementForRenderer(ent);
      _broadcastLicenseChanged(ent);
      return safe;
    } catch {
      return _lockedEntitlement();
    }
  });

  // Opens a native file picker for a signed license file and installs it.
  // SECURITY: We do not reuse the generic "open-file-dialog" handler because
  // that one automatically adds the picked file to approved-roots, which would
  // allow the renderer to read the license token via fs IPC.
  ipcMain.handle('license:select-and-install', async (event) => {
    try {
      assertTrustedIpcSender(event, 'license:select-and-install');
      const parent = _getParentWindowFromEvent(event);
      const result = await dialog.showOpenDialog(parent, {
        title: 'Select License File',
        // showHiddenFiles helps users select dotfiles like ".leadai_license" on macOS.
        properties: ['openFile', 'showHiddenFiles'],
        filters: _safeLicenseDialogFilters()
      });
      if (result.canceled || !Array.isArray(result.filePaths) || !result.filePaths[0]) {
        return { ok: false, cancelled: true };
      }
      const filePath = result.filePaths[0];
      const ent = await licenseService.installLicenseFromFile(filePath);
      _broadcastLicenseChanged(ent);
      return { ok: true, entitlement: _sanitizeEntitlementForRenderer(ent) };
    } catch {
      // Avoid leaking filesystem details through error strings.
      return {
        ok: false,
        cancelled: false,
        error: 'License install failed'
      };
    }
  });

  // Fetches a signed entitlement token from your entitlement server and installs it.
  // This is the “no manual file” path.
  ipcMain.handle('license:sync-entitlement', async (event, options) => {
    try {
      assertTrustedIpcSender(event, 'license:sync-entitlement');
      const waitForEntitlement = options?.waitForEntitlement === true;

      if (isOfflineModeEnabled()) {
        return _failure('OFFLINE_MODE', false, 'Offline Mode is enabled. Disable Offline Mode in Preferences to sync your subscription.');
      }

      // Configure server URL:
      const baseUrl =
        process.env.LEADAE_ENTITLEMENT_URL ||
        String(__publicCfg?.entitlementUrl || '').trim() ||
        (IS_PACKAGED ? '' : 'http://127.0.0.1:8787');
      if (!baseUrl) {
        return _failure('entitlement_not_configured', false, 'Entitlement server not configured');
      }

      // Device id must be main-process only. Never trust renderer input.
      const deviceId = _getDeviceIdMainProcess();

      if (!deviceId) {
        return _failure('device_id_missing', false, 'Missing deviceId');
      }

      if (typeof fetch !== 'function') {
        return _failure('fetch_unavailable', false, 'fetch unavailable in main process');
      }

      const u = new URL('/entitlement', baseUrl);
      const fetchResult = await _fetchEntitlementWithRetry(
        u.toString(),
        { device_id: deviceId },
        { waitForEntitlement }
      );
      if (!fetchResult?.ok) return fetchResult;

      const token = String(fetchResult.token || '').trim();
      if (!token) {
        return _failure('entitlement_empty_token', false, 'Empty entitlement token');
      }

      // Reuse the existing safe install path by writing a temp file and calling installLicenseFromFile.
      const tmpPath = path.join(
        os.tmpdir(),
        `leadai_entitlement_${Date.now()}_${Math.random().toString(16).slice(2)}.leadai_license`
      );
      fs.writeFileSync(tmpPath, token, { mode: 0o600 });

      try {
        const ent = await licenseService.installLicenseFromFile(tmpPath);
        _broadcastLicenseChanged(ent);
        return { ok: true, entitlement: _sanitizeEntitlementForRenderer(ent) };
      } finally {
        try { fs.unlinkSync(tmpPath); } catch {}
      }
    } catch (err) {
      // IMPORTANT: don't swallow the real failure reason.
      // Keep message safe (no internal paths).
      let msg = 'unknown_error';
      try {
        msg = (err && err.message) ? String(err.message) : String(err || 'unknown_error');
      } catch {}
      msg = msg.replace(/\/[^\s]+/g, '[path]'); // crude path scrub
      try { console.error('[license:sync-entitlement] failed:', err); } catch {}
      return _failure('entitlement_sync_failed', false, `Entitlement sync failed: ${msg}`);
    }
  });
}

module.exports = registerLicenseHandlers;
