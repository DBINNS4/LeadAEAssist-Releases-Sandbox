// ipc/codex.handlers.js
const codex = require('../utils/codex');
const { getFormatCapabilities } = require('../utils/formatCapabilities');
const { getBinaryPaths } = require('../utils/ffmpegBridge');
const { getAvailableEncoderSet } = require('../utils/gpuEncoder');
const { validateInputAgainstCodex } = require('../utils/metadata');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const { execFileSync } = require('child_process');

const __muxerSetCache = new Map();
const __encoderPixFmtCache = new Map(); // key: `${ffmpegPath}::${encoder}` -> Set(pix_fmt)

function getEncoderPixelFormatSet(ffmpegPath, encoderName) {
  const enc = String(encoderName || '').trim();
  const bin = String(ffmpegPath || '').trim();
  if (!bin || !enc) return new Set();
  const key = `${bin}::${enc}`;
  if (__encoderPixFmtCache.has(key)) return __encoderPixFmtCache.get(key);

  let out = '';
  try {
    out = execFileSync(bin, ['-hide_banner', '-h', `encoder=${enc}`], { encoding: 'utf8' }) || '';
  } catch {
    // Fail open: if we can't read pix_fmts, we don't filter.
    const empty = new Set();
    __encoderPixFmtCache.set(key, empty);
    return empty;
  }

  const m = String(out).match(/Supported pixel formats:\s*([^\r\n]+)/i);
  const list = m && m[1] ? m[1].trim().split(/\s+/).filter(Boolean) : [];
  const set = new Set(list.map(s => String(s).trim()).filter(Boolean));
  __encoderPixFmtCache.set(key, set);
  return set;
}

function filterPixelFormatsByEncoder(pixelFormats, encoderPixFmtSet) {
  const set = (encoderPixFmtSet && typeof encoderPixFmtSet.has === 'function') ? encoderPixFmtSet : null;
  if (!set || set.size === 0) return pixelFormats || [];
  const out = [];
  for (const pf of (pixelFormats || [])) {
    const key = String(pf || '').trim();
    if (!key) continue;
    if (set.has(key)) out.push(key);
  }
  return [...new Set(out)];
}

function filterAudioCodecsByEncoders(audioCodecs, encoderSet) {
  const set = (encoderSet && typeof encoderSet.has === 'function') ? encoderSet : null;
  if (!set || set.size === 0) return audioCodecs || [];
  const alias = {
    opus: ['opus', 'libopus'],
    vorbis: ['vorbis', 'libvorbis'],
    aac: ['aac', 'libfdk_aac']
  };
  const out = [];
  for (const c of (audioCodecs || [])) {
    const key = String(c || '').toLowerCase().trim();
    if (!key) continue;
    const candidates = alias[key] || [key];
    if (candidates.some(name => set.has(name))) out.push(key);
  }
  return [...new Set(out)];
}

function getAvailableMuxerSet(ffmpegPath) {
  const key = String(ffmpegPath || '');
  if (!key) return new Set();
  if (__muxerSetCache.has(key)) return __muxerSetCache.get(key);
  let out = '';
  try {
    out = execFileSync(ffmpegPath, ['-hide_banner', '-muxers'], { encoding: 'utf8' }) || '';
  } catch (e) {
    console.warn('[codex] Failed to read muxer list from ffmpeg:', e?.message || e);
    const empty = new Set();
    __muxerSetCache.set(key, empty);
    return empty;
  }
  const set = new Set();

  // NOTE: ffmpeg output formats vary across builds.
  // Typical lines look like any of these:
  //   "  E mov             QuickTime / MOV"
  //   "  DE matroska        Matroska"
  //   "  mov               QuickTime / MOV"  (some builds omit the flags column)
  // The previous regex expected a 6-character flag column and produced an empty muxer set,
  // which caused codex:list-formats to return empty.
  for (const line of String(out).split(/\r?\n/)) {
    const s = String(line || '').trim();
    if (!s) continue;
    if (s.startsWith('-') || s.toLowerCase().startsWith('muxers:') || s.toLowerCase().startsWith('file formats:')) continue;

    const parts = s.split(/\s+/);
    if (!parts.length) continue;

    // If the first token is only flags/dots (e.g., "E", "DE", ".E"), then the muxer name is next.
    const t0 = parts[0];
    const looksLikeFlags = /^[D.]*E[.A-Z]*$/.test(t0) || /^[A-Z.]{1,6}$/.test(t0);
    const name = looksLikeFlags ? parts[1] : parts[0];
    if (name && /^[a-zA-Z0-9_]+$/.test(name)) set.add(name);
  }
  __muxerSetCache.set(key, set);
  return set;
}

function filterContainersByMuxers(containers, muxerSet) {
  const map = {
    mkv: 'matroska',
    matroska: 'matroska',
    mov: 'mov',
    mp4: 'mp4',
    mxf: 'mxf',
    mxf_opatom: 'mxf_opatom',
    mxf_d10: 'mxf_d10',
    wav: 'wav',
    aiff: 'aiff',
    // Panel uses "image_sequence" while FFmpeg's muxer is "image2"
    image_sequence: 'image2',
    image2: 'image2'
  };
  const out = [];
  for (const c of (containers || [])) {
    const key = String(c || '').toLowerCase().trim();
    if (!key) continue;
    const muxName = map[key] || key;
    if (muxerSet.has(muxName)) out.push(key === 'image2' ? 'image_sequence' : key);
  }
  return [...new Set(out)];
}

function listSupportedFormats() {
  const { ffmpegPath } = getBinaryPaths();
  const muxSet = getAvailableMuxerSet(ffmpegPath);
  const canFilterMuxers = muxSet && muxSet.size > 0;

  const all = codex.listFormats();
  const supported = [];
  const hasDnxVariants = all.some(k => /^dnxhr_/.test(String(k))) || all.some(k => /^dnxhd_\d+/.test(String(k)));

  for (const fmt of all) {
    if (hasDnxVariants && String(fmt).toLowerCase() === 'dnxhd') continue;

    try {
      const caps = getFormatCapabilities(fmt, ffmpegPath);
      if (!caps || !caps.encoderAvailable) continue;

      const compat = codex.getCompatibility(fmt) || {};
      const containers = canFilterMuxers
        ? filterContainersByMuxers(compat.containers || [], muxSet)
        : (compat.containers || []);
      if (!containers.length) continue;

      supported.push(fmt);
    } catch {
      // ignore individual failures; keep scanning
    }
  }
  return supported;
}

function listSupportedAudioCodecs() {
  const all = codex.listAudioCodecs();
  const { ffmpegPath } = getBinaryPaths();
  const encSet = getAvailableEncoderSet(ffmpegPath);

  // Some codec names have multiple possible encoder names depending on build.
  const alias = {
    opus: ['opus', 'libopus'],
    vorbis: ['vorbis', 'libvorbis'],
    aac: ['aac', 'libfdk_aac']
  };

  return all.filter(codec => {
    const key = String(codec || '').toLowerCase().trim();
    if (!key) return false;
    const candidates = alias[key] || [key];
    return candidates.some(name => encSet.has(name));
  });
}

function registerCodexHandlers(ipcMain) {
  ipcMain.handle('codex:list-formats', (event) => {
    assertTrustedIpcSender(event, 'codex:list-formats');
    try {
      return listSupportedFormats();
    } catch (e) {
      console.warn('[codex:list-formats] failed to detect supported formats:', e?.message || e);
      return [];
    }
  });
  ipcMain.handle('codex:list-audio-codecs', (event) => {
    assertTrustedIpcSender(event, 'codex:list-audio-codecs');
    try {
      return listSupportedAudioCodecs();
    } catch (e) {
      console.warn('[codex:list-audio-codecs] failed to detect supported audio codecs:', e?.message || e);
      return [];
    }
  });
  ipcMain.handle('codex:get-compatibility', (event, { format }) => {
    assertTrustedIpcSender(event, 'codex:get-compatibility');
    const compat = codex.getCompatibility(format) || { format };
    try {
      const { ffmpegPath } = getBinaryPaths();
      const muxSet = getAvailableMuxerSet(ffmpegPath);
      if (muxSet && muxSet.size > 0) {
        compat.containers = filterContainersByMuxers(compat.containers || [], muxSet);
      }
      if (compat.defaults?.container && compat.containers.length && !compat.containers.includes(compat.defaults.container)) {
        compat.defaults.container = compat.containers[0];
      }

      // Filter pixel formats by the resolved encoder's supported pix_fmts.
      // FFmpeg otherwise warns and picks a different pix_fmt unless you force +pix_fmt.
      const caps = getFormatCapabilities(format, ffmpegPath);
      const enc = caps?.videoEncoder;
      if (enc) {
        const pixSet = getEncoderPixelFormatSet(ffmpegPath, enc);
        compat.pixelFormats = filterPixelFormatsByEncoder(compat.pixelFormats || [], pixSet);
        if (compat.defaults?.pixelFormat && compat.pixelFormats.length && !compat.pixelFormats.includes(compat.defaults.pixelFormat)) {
          compat.defaults.pixelFormat = compat.pixelFormats[0];
        }
      }

      // Filter audio codecs by what this FFmpeg build can actually encode.
      const encSet = getAvailableEncoderSet(ffmpegPath);
      compat.audioCodecs = filterAudioCodecsByEncoders(compat.audioCodecs || [], encSet);
      if (compat.defaults?.audio && compat.audioCodecs.length && !compat.audioCodecs.includes(String(compat.defaults.audio).toLowerCase())) {
        compat.defaults.audio = compat.audioCodecs[0];
      }
    } catch {}
    return compat;
  });
  ipcMain.handle('codex:get-audio-constraints', (event, { codec }) => {
    assertTrustedIpcSender(event, 'codex:get-audio-constraints');
    return codex.getAudioConstraints(codec);
  });
  ipcMain.handle('codex:is-audio-container-valid', (event, { codec, container }) => {
    assertTrustedIpcSender(event, 'codex:is-audio-container-valid');
    return codex.isAudioContainerValid(codec, container);
  });
  ipcMain.handle('codex:get-spec', (event) => {
    assertTrustedIpcSender(event, 'codex:get-spec');
    return codex.loadSpec();
  });
  ipcMain.handle('codex:get-format-capabilities', (event, { format }) => {
    assertTrustedIpcSender(event, 'codex:get-format-capabilities');
    return getFormatCapabilities(format);
  });

  ipcMain.handle('validate-codex-input', async (event, { metadata, codexEntry }) => {
    assertTrustedIpcSender(event, 'validate-codex-input');
    try {
      return validateInputAgainstCodex(metadata, codexEntry);
    } catch {
      return true;
    }
  });
}

module.exports = registerCodexHandlers;
