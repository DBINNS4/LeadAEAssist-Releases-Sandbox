// ipc/transcode.handlers.js
// Transcode pipeline IPC: run-transcode, cancel-transcode, queue-add-transcode.

const {
  cancelTranscode,
  preflightTranscodeDisk,
  formatBytes
} = require('../modules/transcode');
const licenseService = require('../services/licenseService');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const {
  assertApprovedPaths,
  extractAbsolutePathsFromObject,
  toLocalPathIfFileUrl
} = require('../utils/ipcPathGuards');

function registerTranscodeHandlers(ipcMain) {
  const i18nMessage = (key, params = {}) => ({ key, params });

  const getPreflightWarningParams = (result) => {
    const skippedCount = Number(result?.skippedFiles);
    return {
      hasWarning: Boolean(result?.warning),
      skippedCount: Number.isFinite(skippedCount) && skippedCount > 0 ? skippedCount : 0
    };
  };

  ipcMain.handle('cancel-transcode', async (event, jobId) => {
    assertTrustedIpcSender(event, 'cancel-transcode');
    cancelTranscode(jobId);
    return '🛑 Cancel requested';
  });

  ipcMain.handle('transcode-preflight', async (event, config) => {
    assertTrustedIpcSender(event, 'transcode-preflight');

    if (!licenseService.isFeatureEnabled('transcode')) {
      const message = i18nMessage('transcodePreflightLicenseRequired');
      return { status: 'unknown', message, error: message };
    }

    const senderId = event?.sender?.id;
    const knownPaths = [];
    const normalizePaths = (paths) => paths
      .map(p => toLocalPathIfFileUrl(String(p ?? '').trim()))
      .filter(Boolean);
    if (Array.isArray(config?.inputFiles)) knownPaths.push(...normalizePaths(config.inputFiles));
    if (config?.outputFolder) knownPaths.push(...normalizePaths([config.outputFolder]));
    const nested = normalizePaths(extractAbsolutePathsFromObject(config || {}));
    assertApprovedPaths(senderId, [...knownPaths, ...nested]);

    try {
      const result = await preflightTranscodeDisk(config || {});
      if (result?.status === 'insufficient' && result.requiredBytes != null && result.freeBytes != null) {
        const requiredText = formatBytes(result.requiredBytes);
        const freeText = formatBytes(result.freeBytes);
        return {
          status: 'insufficient',
          message: i18nMessage('transcodePreflightInsufficientDiskSpace', {
            requiredText,
            freeText
          })
        };
      }

      if (result?.estimateBytes != null) {
        const estimateText = formatBytes(result.estimateBytes);
        const estimateMethod = result.estimateMethod ? String(result.estimateMethod) : '';
        const { hasWarning, skippedCount } = getPreflightWarningParams(result);

        // preflightTranscodeDisk now returns a batch-total estimate for v1 safety.
        const estimatedFiles = typeof result.estimatedFiles === 'number' ? result.estimatedFiles : null;
        const totalFiles = typeof result.totalFiles === 'number' ? result.totalFiles : null;
        if (result.freeBytes == null) {
          return {
            status: 'unknown',
            message: i18nMessage('transcodePreflightSkippedUnknownFreeSpace', {
              estimateText,
              estimateMethod,
              estimatedFiles,
              totalFiles,
              hasWarning,
              skippedCount
            })
          };
        }

        const requiredText = formatBytes(result.requiredBytes);
        const freeText = formatBytes(result.freeBytes);
        return {
          status: 'ok',
          message: i18nMessage('transcodePreflightEstimatedSizeSummary', {
            estimateText,
            estimateMethod,
            estimatedFiles,
            totalFiles,
            requiredText,
            freeText,
            hasWarning,
            skippedCount
          })
        };
      }

      return {
        status: 'unknown',
        message: i18nMessage('transcodePreflightEstimateUnavailable')
      };
    } catch (err) {
      return {
        status: 'unknown',
        message: i18nMessage('transcodePreflightSkippedWithErrorDetail', {
          errorDetail: String(err?.message || err || '').trim()
        })
      };
    }
  });
}

module.exports = registerTranscodeHandlers;
