// ipc/transcribe.handlers.js
// Transcription IPC compatibility shim.
//
// Canonical V1 queue flow:
//   - start:  queue-add-transcribe
//   - cancel: queue-cancel-job
//
// The legacy cancel-transcribe channel is retained for older renderers and
// now delegates to queue-cancel-job semantics whenever a queue is available.

const { cancelTranscribe } = require('../modules/transcribe');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');

function registerTranscribeHandlers(ipcMain) {
  ipcMain.handle('cancel-transcribe', async (event, jobId) => {
    // Compatibility-only: prefer queue-cancel-job from renderer code.
    assertTrustedIpcSender(event, 'cancel-transcribe');

    if (global.queue && typeof global.queue.cancelJob === 'function') {
      global.queue.cancelJob(jobId);
      return { key: 'transcribeCancelRequestedViaQueueBridge' };
    }

    // Fallback for non-queue contexts/tests.
    cancelTranscribe(jobId);
    return { key: 'transcribeCancelRequestedDirectFallback' };
  });
}

module.exports = registerTranscribeHandlers;
