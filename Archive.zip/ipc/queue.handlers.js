// ipc/queue.handlers.js
// Job queue management IPC: queue-get, queue-pause, queue-retry-job, queue-cancel-job, enqueue-job, queue-add-*.

const path = require('path');
const { sendLogMessage } = require('../modules/logUtils');
const licenseService = require('../services/licenseService');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const {
  assertApprovedPaths,
  extractAbsolutePathsFromObject,
  toLocalPathIfFileUrl
} = require('../utils/ipcPathGuards');

const QUEUE_PATH_FIELDS = [
  'source',
  'destination',
  'backupPath',
  'watchFolder',
  'outputFolder',
  'outputPath',
  'proxyDest',
  'proxyPreset',
  'sourcePath',
  'sourceFile',
  'mediaPath',
  'outputDir',
  'captionSidecarPath'
];

const QUEUE_PATH_CONTAINER_FIELDS = [
  'sourceFiles',
  'selectedFolders',
  'retryFiles',
  'inputFiles',
  'sourcePaths',
  'expandedSources',
  'sources',
  'proxySources',
  'removedFiles',
  'folderAssets'
];

const PROXY_PRESET_SENTINELS = new Set(['match-source-ffmpeg', 'match-source']);
const NON_PATH_SENTINELS = new Set([
  ...PROXY_PRESET_SENTINELS,
  'prores',
  'prores 422',
  'prores 422 hq',
  'prores 422 lt',
  'prores 422 proxy',
  'prores 4444',
  'h264',
  'h.264',
  'h265',
  'h.265',
  'hevc',
  'dnxhr',
  'dnxhd',
  'aac',
  'mp3',
  'wav',
  'flac',
  'copy',
  'libx264',
  'libx265',
  'vp9',
  'vp8'
]);

const TRANSCODE_STRICT_PATH_FIELDS = [
  'outputFolder',
  'watchFolder',
  'captionSidecarPath',
  'sourcePath',
  'sourceFile',
  'mediaPath',
  'outputPath',
  'outputDir'
];

const TRANSCODE_STRICT_PATH_CONTAINER_FIELDS = [
  'inputFiles',
  'sourceFiles',
  'sourcePaths',
  'expandedSources',
  'sources'
];

const isWindowsDrivePath = (value) => /^[a-zA-Z]:[\\/]/.test(value);
const isWindowsUncPath = (value) => value.startsWith('\\\\');
const isAbsolutePathLike = (value) =>
  isWindowsDrivePath(value) || isWindowsUncPath(value) || path.isAbsolute(value);

function normalizeAbsolutePathCandidate(value) {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (!trimmed) return null;
  if (NON_PATH_SENTINELS.has(trimmed.toLowerCase())) return null;

  const local = toLocalPathIfFileUrl(trimmed);
  if (typeof local !== 'string') return null;

  if (trimmed.startsWith('file:') && local === trimmed) return null;
  if (!isAbsolutePathLike(local)) return null;

  return local;
}

function collectQueuePaths(config) {
  // Keep queue path collection aligned across handlers: accepted forms are
  // absolute local filesystem paths and file:// URLs (canonicalized later).
  const paths = [];
  if (!config || typeof config !== 'object') return paths;

  for (const field of QUEUE_PATH_FIELDS) {
    const value = config[field];
    if (typeof value !== 'string') continue;

    const trimmed = value.trim();
    if (!trimmed) continue;

    if (field === 'proxyPreset') {
      const lower = trimmed.toLowerCase();

      if (!config.generateProxies) continue;

      if (PROXY_PRESET_SENTINELS.has(lower)) continue;
    }

    paths.push(trimmed);
  }

  for (const field of QUEUE_PATH_CONTAINER_FIELDS) {
    if (config[field]) {
      paths.push(...extractAbsolutePathsFromObject(config[field]));
    }
  }

  const discoveredPaths = extractAbsolutePathsFromObject(config);
  for (const candidate of discoveredPaths) {
    const normalized = normalizeAbsolutePathCandidate(candidate);
    if (normalized) paths.push(normalized);
  }

  return paths;
}

function validateStrictAbsolutePathField({ value, fieldLabel }) {
  if (typeof value !== 'string') return;
  const trimmed = value.trim();
  if (!trimmed) return;

  const local = toLocalPathIfFileUrl(trimmed);
  const isAbsolute = typeof local === 'string' && isAbsolutePathLike(local);
  if (isAbsolute) return;

  throw new Error(
    `❌ Path rejected: ${fieldLabel} must be an absolute path or file:// URL (${trimmed})`
  );
}

function validateTranscodeQueuePathForms(config) {
  if (!config || typeof config !== 'object') return;

  for (const field of TRANSCODE_STRICT_PATH_FIELDS) {
    validateStrictAbsolutePathField({
      value: config[field],
      fieldLabel: field
    });
  }

  for (const field of TRANSCODE_STRICT_PATH_CONTAINER_FIELDS) {
    const items = config[field];
    if (!Array.isArray(items)) continue;
    items.forEach((entry, index) => {
      validateStrictAbsolutePathField({
        value: entry,
        fieldLabel: `${field}[${index}]`
      });
    });
  }
}

function getQueue() {
  if (!global.queue) {
    throw new Error('Queue not ready');
  }
  return global.queue;
}

async function addPanelJob(event, panel, payload) {
  const queue = getQueue();

  const jobDescriptor =
    payload && typeof payload === 'object' && !Array.isArray(payload) && payload.config
      ? { ...payload }
      : { config: payload };

  const contract = typeof queue.getContract === 'function' ? queue.getContract(panel) : null;
  const config = jobDescriptor.config;

  // Licensing enforcement at queue-ingestion time.
  // Even though execution boundaries also enforce entitlements, failing early
  // prevents unlicensed jobs from persisting in memory/state.
  const isClone = panel === 'ingest' && !!config?.cloneMode;
  const feature = isClone ? 'clone' : panel;
  if (!licenseService.isFeatureEnabled(feature)) {
    throw new Error(`License required for ${feature}`);
  }

  // Enforce approved-roots policy at queue ingestion time.
  // Even if the job isn't executed immediately, we don't allow untrusted
  // configs containing arbitrary absolute paths to persist.
  if (panel === 'transcode') {
    validateTranscodeQueuePathForms(config);
  }

  const senderId = event?.sender?.id;
  const paths = collectQueuePaths(config);
  assertApprovedPaths(senderId, paths);

  if (contract?.validate) {
    const validationResult = await Promise.resolve(contract.validate(config));
    let errors = [];
    if (Array.isArray(validationResult)) {
      errors = validationResult.filter(Boolean);
    } else if (typeof validationResult === 'string') {
      errors = [validationResult];
    } else if (
      validationResult &&
      typeof validationResult === 'object' &&
      Array.isArray(validationResult.errors)
    ) {
      errors = validationResult.errors.filter(Boolean);
    }

    if (errors.length) {
      const err = new Error(errors.join('\n'));
      err.validationErrors = errors;
      throw err;
    }
  }

  return queue.addJob({ panel, ...jobDescriptor });
}

function ensurePanelStartupReady(panel, getStartupHealth) {
  if (typeof getStartupHealth !== 'function') return;
  const health = getStartupHealth() || {};
  const readinessByPanel = {
    ingest: !!health.ingestReady,
    transcode: !!health.transcodeReady,
    transcribe: !!health.transcribeReady
  };
  if (Object.prototype.hasOwnProperty.call(readinessByPanel, panel) && !readinessByPanel[panel]) {
    throw new Error(`${panel} unavailable: startup dependency failed to load`);
  }
}

function registerQueueHandlers(ipcMain, context = {}) {
  const { getStartupHealth } = context;
  ipcMain.handle('queue-add-ingest', (event, config) => {
    assertTrustedIpcSender(event, 'queue-add-ingest');
    ensurePanelStartupReady('ingest', getStartupHealth);
    return addPanelJob(event, 'ingest', config);
  });

  ipcMain.handle('queue-add-transcode', (event, config) => {
    assertTrustedIpcSender(event, 'queue-add-transcode');
    ensurePanelStartupReady('transcode', getStartupHealth);
    return addPanelJob(event, 'transcode', config);
  });

  ipcMain.handle('queue-add-clone', (event, payload) => {
    assertTrustedIpcSender(event, 'queue-add-clone');
    ensurePanelStartupReady('ingest', getStartupHealth);
    const descriptor =
      payload && typeof payload === 'object' && payload.config
        ? { ...payload }
        : { config: payload };
    const baseConfig = descriptor.config || {};
    descriptor.config = { ...baseConfig, cloneMode: true };
    return addPanelJob(event, 'ingest', descriptor);
  });

  ipcMain.handle('queue-add-transcribe', (event, config) => {
    // SECURITY: queue-add-transcribe can ultimately cause the main process to use
    // API keys (OpenAI, etc.) during execution. Only allow trusted local origins.
    assertTrustedIpcSender(event, 'queue-add-transcribe');
    ensurePanelStartupReady('transcribe', getStartupHealth);
    return addPanelJob(event, 'transcribe', config);
  });

  ipcMain.handle('queue-add-adobe', (event, payload) => {
    assertTrustedIpcSender(event, 'queue-add-adobe');
    const cfg = payload?.config ?? payload;
    return addPanelJob(event, 'adobe-utilities', cfg);
  });

  ipcMain.handle('queue-add-project-organizer', (event, config) => {
    assertTrustedIpcSender(event, 'queue-add-project-organizer');
    return addPanelJob(event, 'project-organizer', config);
  });

  ipcMain.on('adobe-utilities-log-message', (event, payload) => {
    assertTrustedIpcSender(event, 'adobe-utilities-log-message');
    const { msg = '', detail = '', isError = false, fileId = '', level, isWarning = false, jobId = null, stage = null, meta = null } = payload || {};
    const isWarn = isWarning || level === 'warn';
    const isErr = !!isError || level === 'error';
    const resolvedLevel = level || (isErr ? 'error' : isWarn ? 'warn' : 'info');

    sendLogMessage('adobe-utilities', msg, detail, isErr, fileId, resolvedLevel, jobId, stage, meta);
  });

  ipcMain.handle('queue-start', (event) => {
    assertTrustedIpcSender(event, 'queue-start');
    const queue = getQueue();
    queue.startQueue();
  });

  ipcMain.handle('queue-pause', (event) => {
    assertTrustedIpcSender(event, 'queue-pause');
    const queue = getQueue();
    queue.pauseQueue();
  });

  ipcMain.handle('queue-cancel-job', (event, id) => {
    assertTrustedIpcSender(event, 'queue-cancel-job');
    const queue = getQueue();
    queue.cancelJob(id);
  });

}

module.exports = registerQueueHandlers;
