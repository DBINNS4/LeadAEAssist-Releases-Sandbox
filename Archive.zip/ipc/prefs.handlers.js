// ipc/prefs.handlers.js
// Phase 3: Canonical QC & Delivery preferences store (state.json) with IPC access.
//
// Design goals:
//  - Provide a single canonical persisted store for QC & Delivery prefs.
//  - Support both ipcRenderer.invoke (ipcMain.handle) and ipcRenderer.send (ipcMain.on).
//  - Filter to known keys to avoid accidentally persisting unrelated localStorage data.
//  - Broadcast updates to other windows so pop-outs stay in sync even if localStorage isn't shared.

'use strict';

const { readState, writeState } = require('../utils/state');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const telemetryService = require('../services/telemetryService');

let qcDeliveryPrefs = null;
try {
  qcDeliveryPrefs = require('../utils/qcDeliveryPrefs');
} catch {
  qcDeliveryPrefs = null;
}

const STORE_KEY = 'qcDelivery';
const STORE_VERSION = 1;
const PREFERENCES_KEY = 'preferences';
const TEMP_MAX_AGE_DAYS_MIN = 0;
const TEMP_MAX_AGE_DAYS_MAX = 3650;
const ALLOWED_THEME_VALUES = new Set(['light', 'dark']);
const ALLOWED_LANGUAGE_VALUES = new Set(['en', 'es', 'fr', 'de', 'ja', 'zh']);
const KNOWN_PREFERENCE_KEYS = new Set([
  'offlineMode',
  'crashReporting',
  'apiKeyStored',
  'webhookLogging',
  'webhookOnlyFail',
  'clearTempOnStartup',
  'clearCacheOnStartup',
  'autoUpdateCheckOnLaunch',
  'autoUpdateAutoDownload',
  'webhookUrl',
  'theme',
  'language',
  'tempMaxAgeDays'
]);

function isKnownPreferenceKey(key) {
  return typeof key === 'string' && KNOWN_PREFERENCE_KEYS.has(key);
}

function prefsError(code, params = {}, extra = {}) {
  return {
    ok: false,
    code,
    params,
    error: code,
    ...extra
  };
}

function sanitizePreferencesValueByKey(key, value) {
  if (typeof key !== 'string' || !key) {
    return prefsError('PREFS_UNSUPPORTED_KEY', { key: String(key) }, { key: String(key) });
  }

  switch (key) {
    case 'offlineMode':
    case 'crashReporting':
    case 'apiKeyStored':
    case 'webhookLogging':
    case 'webhookOnlyFail':
    case 'clearTempOnStartup':
    case 'clearCacheOnStartup':
    case 'autoUpdateCheckOnLaunch':
    case 'autoUpdateAutoDownload': {
      if (typeof value !== 'boolean') {
        return prefsError('PREFS_VALUE_TYPE_BOOLEAN', { key }, { key });
      }
      return { ok: true, value };
    }

    case 'webhookUrl': {
      if (typeof value !== 'string') {
        return prefsError('PREFS_VALUE_TYPE_STRING', { key: 'webhookUrl' }, { key: 'webhookUrl' });
      }
      if (!value.trim()) {
        return { ok: true, value: '' };
      }
      try {
        const parsed = new URL(value);
        if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
          return prefsError('PREFS_INVALID_WEBHOOK_URL', {}, { key: 'webhookUrl' });
        }
      } catch {
        return prefsError('PREFS_INVALID_WEBHOOK_URL', {}, { key: 'webhookUrl' });
      }
      return { ok: true, value };
    }

    case 'theme': {
      if (typeof value !== 'string' || !ALLOWED_THEME_VALUES.has(value)) {
        return prefsError('PREFS_INVALID_THEME', {
          allowed: Array.from(ALLOWED_THEME_VALUES).join(', ')
        }, { key: 'theme' });
      }
      return { ok: true, value };
    }

    case 'language': {
      if (typeof value !== 'string' || !ALLOWED_LANGUAGE_VALUES.has(value)) {
        return prefsError('PREFS_INVALID_LANGUAGE', {
          allowed: Array.from(ALLOWED_LANGUAGE_VALUES).join(', ')
        }, { key: 'language' });
      }
      return { ok: true, value };
    }

    case 'tempMaxAgeDays': {
      if (!Number.isInteger(value)) {
        return prefsError('PREFS_TEMP_MAX_AGE_NOT_INTEGER', {}, { key: 'tempMaxAgeDays' });
      }
      if (value < TEMP_MAX_AGE_DAYS_MIN || value > TEMP_MAX_AGE_DAYS_MAX) {
        return prefsError('PREFS_TEMP_MAX_AGE_OUT_OF_RANGE', {
          min: TEMP_MAX_AGE_DAYS_MIN,
          max: TEMP_MAX_AGE_DAYS_MAX
        }, { key: 'tempMaxAgeDays' });
      }
      return { ok: true, value };
    }

    default:
      return prefsError('PREFS_UNSUPPORTED_KEY', { key: String(key) }, { key: String(key) });
  }
}

function sanitizePreferencesObject(input, options = {}) {
  const { allowUnknownKeys = false } = options;
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    return prefsError('PREFS_PAYLOAD_NOT_OBJECT');
  }

  const out = {};
  for (const [key, value] of Object.entries(input)) {
    if (!isKnownPreferenceKey(key)) {
      if (allowUnknownKeys) continue;
      return prefsError('PREFS_UNSUPPORTED_KEY', { key: String(key) }, { key: String(key) });
    }

    const sanitized = sanitizePreferencesValueByKey(key, value);
    if (!sanitized.ok) {
      return { ...sanitized, key };
    }
    out[key] = sanitized.value;
  }

  return { ok: true, preferences: out };
}

function filterPersistedPreferencesObject(input) {
  const out = {};
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    return { preferences: out, droppedKeys: [] };
  }

  const droppedKeys = [];
  for (const [key, value] of Object.entries(input)) {
    const sanitized = sanitizePreferencesValueByKey(key, value);
    if (!sanitized.ok) {
      droppedKeys.push(key);
      continue;
    }
    out[key] = sanitized.value;
  }

  return { preferences: out, droppedKeys };
}

function shallowEqualObjects(a, b) {
  if (a === b) return true;
  if (!a || !b || typeof a !== 'object' || typeof b !== 'object') return false;
  const aKeys = Object.keys(a);
  const bKeys = Object.keys(b);
  if (aKeys.length !== bKeys.length) return false;
  for (const key of aKeys) {
    if (a[key] !== b[key]) return false;
  }
  return true;
}

function getAllowedKeysSet() {
  try {
    const keys = qcDeliveryPrefs?.STORAGE_KEYS
      || (typeof qcDeliveryPrefs?.getStorageKeys === 'function' ? qcDeliveryPrefs.getStorageKeys() : null);
    if (Array.isArray(keys) && keys.length) return new Set(keys.map(String));
  } catch {
    // ignore
  }
  return new Set();
}

function isAllowedKey(key, allowedKeys) {
  const k = String(key || '');
  if (!k) return false;
  if (allowedKeys && allowedKeys.size) return allowedKeys.has(k);
  // Fallback safety: allow only caption-related prefixes.
  return /^(scc|mcc|vtt)-/.test(k);
}

function sanitizeStorageObject(obj, allowedKeys) {
  const out = {};
  if (!obj || typeof obj !== 'object') return out;
  for (const [kRaw, vRaw] of Object.entries(obj)) {
    const k = String(kRaw || '').trim();
    if (!isAllowedKey(k, allowedKeys)) continue;
    if (vRaw == null) continue;
    // Keep as string for compatibility with localStorage.
    out[k] = String(vRaw);
  }
  return out;
}

function sanitizePatchObject(obj, allowedKeys) {
  const out = {};
  if (!obj || typeof obj !== 'object') return out;
  for (const [kRaw, vRaw] of Object.entries(obj)) {
    const k = String(kRaw || '').trim();
    if (!isAllowedKey(k, allowedKeys)) continue;
    // null/undefined means delete
    out[k] = (vRaw == null) ? null : String(vRaw);
  }
  return out;
}

function ensureStoreShape(state) {
  const s = (state && typeof state === 'object') ? state : {};
  const existing = (s[STORE_KEY] && typeof s[STORE_KEY] === 'object') ? s[STORE_KEY] : {};
  const storage = (existing.storage && typeof existing.storage === 'object') ? existing.storage : {};
  return {
    ...existing,
    version: STORE_VERSION,
    storage: { ...storage }
  };
}

// Debounced disk writes to avoid thrashing on rapid localStorage updates.
let cachedState = null;
let writeTimer = null;
let preferencesWriteQueue = Promise.resolve();

function loadState() {
  if (!cachedState) cachedState = readState() || {};
  if (!cachedState || typeof cachedState !== 'object') cachedState = {};
  return cachedState;
}

function scheduleWrite(nextState) {
  // IMPORTANT: other parts of the app also write to state.json (preferences UI,
  // telemetry toggle, license, etc.). If we write a cached full copy here, we
  // can accidentally clobber unrelated updates.
  //
  // So: cache for reads, but at flush-time merge ONLY our qcDelivery store into
  // the latest on-disk state.
  cachedState = nextState;
  if (writeTimer) clearTimeout(writeTimer);
  writeTimer = setTimeout(() => {
    try {
      const latest = readState() || {};
      const store = (cachedState && typeof cachedState === 'object') ? cachedState[STORE_KEY] : null;

      const merged = (latest && typeof latest === 'object') ? { ...latest } : {};
      if (store && typeof store === 'object') {
        merged[STORE_KEY] = store;
      }

      const writeResult = writeState(merged);
      if (!writeResult?.ok) {
        throw writeResult?.error || new Error('Unknown state persistence error');
      }
      cachedState = merged;
    } catch (err) {
      console.error('❌ Failed to persist QC prefs to state.json:', err?.message || err);
    }
  }, 150);
}

function enqueuePreferencesWrite(task) {
  const runTask = async () => task();
  const queued = preferencesWriteQueue.then(runTask, runTask);
  preferencesWriteQueue = queued.catch(() => {});
  return queued;
}

function extractPreferencesPayload(payload) {
  const incoming = (payload && typeof payload === 'object') ? payload : {};
  const fromPreferencesSubtree = (incoming.preferences && typeof incoming.preferences === 'object')
    ? incoming.preferences
    : null;

  const source = fromPreferencesSubtree || incoming;
  const sanitized = sanitizePreferencesObject(source, { allowUnknownKeys: true });
  if (!sanitized.ok) return sanitized;
  return { ok: true, preferences: { ...sanitized.preferences } };
}

function mergePreferencesIntoState(state, payload) {
  const baseState = (state && typeof state === 'object') ? state : {};
  const existingPrefs = (baseState[PREFERENCES_KEY] && typeof baseState[PREFERENCES_KEY] === 'object')
    ? baseState[PREFERENCES_KEY]
    : {};
  const extracted = extractPreferencesPayload(payload);
  if (!extracted.ok) {
    return { ok: false, error: extracted.error, code: extracted.code, params: extracted.params, key: extracted.key };
  }
  const patch = extracted.preferences;
  return {
    ok: true,
    state: {
      ...baseState,
      [PREFERENCES_KEY]: {
        ...existingPrefs,
        ...patch
      }
    }
  };
}

async function getPreferencesState() {
  const latestState = readState() || {};
  const prefs = (latestState[PREFERENCES_KEY] && typeof latestState[PREFERENCES_KEY] === 'object' && !Array.isArray(latestState[PREFERENCES_KEY]))
    ? latestState[PREFERENCES_KEY]
    : {};

  const filtered = filterPersistedPreferencesObject(prefs);

  // Optional one-time migration: if legacy/invalid keys are present, rewrite cleaned prefs.
  if (!shallowEqualObjects(prefs, filtered.preferences)) {
    try {
      const writeResult = writeState({
        ...latestState,
        [PREFERENCES_KEY]: { ...filtered.preferences }
      });
      if (writeResult?.ok === false) {
        console.warn('⚠️ Failed to persist cleaned preferences during migration:', writeResult?.error || 'unknown error');
      }
    } catch (err) {
      console.warn('⚠️ Failed to persist cleaned preferences during migration:', err?.message || err);
    }
  }

  return { ok: true, preferences: { ...filtered.preferences } };
}

async function setPreferencesState(payload) {
  return enqueuePreferencesWrite(async () => {
    const latestState = readState() || {};
    const mergedState = mergePreferencesIntoState(latestState, payload);
    if (!mergedState.ok) {
      return {
        ok: false,
        error: mergedState.error,
        code: mergedState.code,
        params: mergedState.params,
        key: mergedState.key
      };
    }
    const writeResult = writeState(mergedState.state);
    if (!writeResult?.ok) {
      const err = writeResult?.error || new Error('Unknown state persistence error');
      return {
        ok: false,
        error: 'PREFS_PERSIST_FAILED',
        code: 'PREFS_PERSIST_FAILED',
        params: {
          detail: err?.message || String(err)
        }
      };
    }

    const preferences = (mergedState.state[PREFERENCES_KEY] && typeof mergedState.state[PREFERENCES_KEY] === 'object')
      ? mergedState.state[PREFERENCES_KEY]
      : {};

    // Offline Mode must override crash uploading even if crash reporting is enabled.
    try {
      telemetryService.refreshNetworkGates?.();
    } catch {}

    return { ok: true, preferences: { ...preferences } };
  });
}

function broadcastQcDeliveryUpdate(senderId, store) {
  // Broadcast to other windows so pop-outs can sync even if localStorage isn't shared.
  // Avoid hard dependency on Electron in tests.
  let BrowserWindow;
  try {
    ({ BrowserWindow } = require('electron'));
  } catch {
    return;
  }
  try {
    const windows = BrowserWindow.getAllWindows?.() || [];
    for (const win of windows) {
      const wc = win?.webContents;
      if (!wc || typeof wc.send !== 'function') continue;
      if (typeof senderId === 'number' && wc.id === senderId) continue;
      wc.send('prefs:qc-delivery-updated', store);
    }
  } catch {
    // Never fail the caller.
  }
}

function applySetPayload(payload, senderId) {
  const allowedKeys = getAllowedKeysSet();
  const state = loadState();
  const store = ensureStoreShape(state);

  const p = (payload && typeof payload === 'object') ? payload : {};

  if (p.replace && p.storage && typeof p.storage === 'object') {
    store.storage = sanitizeStorageObject(p.storage, allowedKeys);
  } else if (p.patch && typeof p.patch === 'object') {
    const patch = sanitizePatchObject(p.patch, allowedKeys);
    for (const [k, v] of Object.entries(patch)) {
      if (v == null) delete store.storage[k];
      else store.storage[k] = v;
    }
  } else if (typeof p.key === 'string') {
    const key = p.key;
    if (isAllowedKey(key, allowedKeys)) {
      if (p.value == null) delete store.storage[key];
      else store.storage[key] = String(p.value);
    }
  }

  const nextState = { ...state, [STORE_KEY]: store };
  scheduleWrite(nextState);
  broadcastQcDeliveryUpdate(senderId, store);

  return store;
}

function registerPrefsHandlers(ipcMain) {
  ipcMain.handle('prefs:get-preferences', async (event) => {
    assertTrustedIpcSender(event, 'prefs:get-preferences');
    return getPreferencesState();
  });

  ipcMain.handle('prefs:set-preferences', async (event, payload) => {
    assertTrustedIpcSender(event, 'prefs:set-preferences');
    return setPreferencesState(payload);
  });

  ipcMain.handle('prefs:get-qc-delivery', async (event) => {
    assertTrustedIpcSender(event, 'prefs:get-qc-delivery');
    const state = loadState();
    const store = ensureStoreShape(state);
    return store;
  });

  ipcMain.handle('prefs:set-qc-delivery', async (event, payload) => {
    assertTrustedIpcSender(event, 'prefs:set-qc-delivery');
    const senderId = event?.sender?.id;
    const store = applySetPayload(payload, senderId);
    return { ok: true, store };
  });

  // Fire-and-forget path for high-frequency updates.
  ipcMain.on('prefs:set-qc-delivery', (event, payload) => {
    assertTrustedIpcSender(event, 'prefs:set-qc-delivery');
    const senderId = event?.sender?.id;
    applySetPayload(payload, senderId);
  });
}

module.exports = registerPrefsHandlers;
