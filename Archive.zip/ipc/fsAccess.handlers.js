// ipc/fsAccess.handlers.js
//
// Renderer-safe filesystem IPC.
//
// IMPORTANT:
//  - Do not expose Node fs primitives directly to the renderer.
//  - All file ops must be validated against the approved-roots policy
//    in utils/fsAccessControl.

'use strict';

const fs = require('fs');
const fsPromises = require('fs/promises');
const path = require('path');
const { generateChecksum } = require('../utils/hash');

const {
  evaluatePathAccess,
  isPathAllowed,
} = require('../utils/fsAccessControl');
const { atomicWriteFile } = require('../utils/fsSafe');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');

function deny(event, message) {
  event.returnValue = { ok: false, error: String(message || 'permission_denied') };
}

function ok(event, value) {
  event.returnValue = { ok: true, value };
}

function registerFsAccessHandlers(ipcMain) {
  const isDevBuild = String(process.env.NODE_ENV || '').toLowerCase() !== 'production';
  const deprecationSeen = new Set();
  const logSyncDeprecation = (event, channel) => {
    if (!isDevBuild) return;
    const senderId = event?.sender?.id ?? 'unknown';
    const senderUrl = event?.senderFrame?.url || event?.sender?.getURL?.() || 'unknown';
    const key = `${channel}:${senderId}`;
    if (deprecationSeen.has(key)) return;
    deprecationSeen.add(key);
    try {
      console.warn(`[fsAccess.handlers] Deprecated sync IPC channel used: ${channel} (senderId=${senderId}, senderUrl=${senderUrl}). Prefer invoke channel ${channel.replace(/Sync$/, '')}.`);
    } catch {
      // ignore logging failures
    }
  };

  const deniedMessage = decision => (
    decision?.reason === 'sensitive_path_denied'
      ? `permission_denied_sensitive_path${decision?.sensitivePath ? `:${decision.sensitivePath}` : ''}`
      : 'permission_denied'
  );

  const logDeniedAccess = (event, channel, targetPath, decision) => {
    const senderId = event?.sender?.id ?? 'unknown';
    const senderUrl = event?.senderFrame?.url || event?.sender?.getURL?.() || 'unknown';
    try {
      console.warn('[fsAccess.handlers] filesystem access denied', {
        channel,
        senderId,
        senderUrl,
        targetPath: String(targetPath || ''),
        reason: decision?.reason || 'not_approved',
        sensitivePath: decision?.sensitivePath || null,
      });
    } catch {
      // ignore logging failures
    }
  };

  const assertAllowed = (event, targetPath, channel) => {
    const senderId = event?.sender?.id;
    const decision = (typeof evaluatePathAccess === 'function')
      ? evaluatePathAccess(senderId, targetPath)
      : { allowed: isPathAllowed(senderId, targetPath), reason: 'not_approved' };
    if (!decision.allowed) logDeniedAccess(event, channel || 'unknown', targetPath, decision);
    return decision;
  };

  const permissionMessage = err => (err?.code === 'ERR_UNTRUSTED_ORIGIN' ? 'permission_denied' : (err?.message || err));
  const assertTrusted = (event, channel) => {
    try {
      assertTrustedIpcSender(event, channel);
    } catch (err) {
      if (err?.code === 'ERR_UNTRUSTED_ORIGIN') throw err;
      throw new Error(permissionMessage(err));
    }
  };

  const toSerializableDirents = entries => entries.map(d => ({
    name: d.name,
    isFile: typeof d.isFile === 'function' ? !!d.isFile() : false,
    isDirectory: typeof d.isDirectory === 'function' ? !!d.isDirectory() : false,
    isSymbolicLink: typeof d.isSymbolicLink === 'function' ? !!d.isSymbolicLink() : false,
  }));

  const toSerializableStat = st => ({
    size: Number(st.size) || 0,
    mtimeMs: Number(st.mtimeMs) || 0,
    ctimeMs: Number(st.ctimeMs) || 0,
    isFile: typeof st.isFile === 'function' ? !!st.isFile() : false,
    isDirectory: typeof st.isDirectory === 'function' ? !!st.isDirectory() : false,
  });

  // NOTE: These are sync channels on purpose to preserve legacy renderer code paths
  // that expect synchronous fs calls.

  ipcMain.handle('fs:exists', async (event, targetPath) => {
    try {
      assertTrusted(event, 'fs:exists');
      if (!assertAllowed(event, targetPath, 'fs:exists').allowed) return false;
      await fsPromises.access(targetPath, fs.constants.F_OK);
      return true;
    } catch {
      return false;
    }
  });


  ipcMain.handle('fs:isDuplicate', async (event, srcPath, destPath, method = 'sha256') => {
    try {
      assertTrusted(event, 'fs:isDuplicate');
      if (!assertAllowed(event, srcPath, 'fs:isDuplicate:src').allowed) return false;
      if (!assertAllowed(event, destPath, 'fs:isDuplicate:dest').allowed) return false;
      if (!fs.existsSync(destPath)) return false;

      const [srcHash, destHash] = await Promise.all([
        generateChecksum(srcPath, method),
        generateChecksum(destPath, method)
      ]);

      return srcHash === destHash;
    } catch {
      // Fail closed: if anything goes wrong, treat as "not duplicate" so we don't skip a copy.
      return false;
    }
  });

  ipcMain.handle('fs:readTextFile', async (event, filePath, encoding) => {
    assertTrusted(event, 'fs:readTextFile');
    const access = assertAllowed(event, filePath, 'fs:readTextFile');
    if (!access.allowed) throw new Error(deniedMessage(access));
    const enc = (typeof encoding === 'string' && encoding) ? encoding : 'utf8';
    const data = await fsPromises.readFile(filePath, { encoding: enc });
    return String(data);
  });

  ipcMain.handle('fs:writeTextFile', async (event, filePath, content, encoding) => {
    assertTrusted(event, 'fs:writeTextFile');
    const access = assertAllowed(event, filePath, 'fs:writeTextFile');
    if (!access.allowed) throw new Error(deniedMessage(access));
    const enc = (typeof encoding === 'string' && encoding) ? encoding : 'utf8';
    const parent = path.dirname(String(filePath));
    if (parent) await fsPromises.mkdir(parent, { recursive: true });
    await fsPromises.writeFile(filePath, String(content ?? ''), { encoding: enc });
    return true;
  });

  ipcMain.handle('fs:writeTextFileAtomic', async (event, filePath, content, encoding) => {
    assertTrusted(event, 'fs:writeTextFileAtomic');
    const access = assertAllowed(event, filePath, 'fs:writeTextFileAtomic');
    if (!access.allowed) throw new Error(deniedMessage(access));
    const enc = (typeof encoding === 'string' && encoding) ? encoding : 'utf8';
    let mode = 0o600;
    try {
      const st = await fsPromises.stat(filePath);
      if (st?.mode) mode = st.mode;
    } catch (err) {
      if (err?.code !== 'ENOENT') throw err;
    }
    await atomicWriteFile(filePath, String(content ?? ''), { mode, encoding: enc });
    return true;
  });

  ipcMain.handle('fs:mkdir', async (event, dirPath) => {
    assertTrusted(event, 'fs:mkdir');
    const access = assertAllowed(event, dirPath, 'fs:mkdir');
    if (!access.allowed) throw new Error(deniedMessage(access));
    await fsPromises.mkdir(dirPath, { recursive: true });
    return true;
  });

  ipcMain.handle('fs:readdir', async (event, dirPath, options) => {
    assertTrusted(event, 'fs:readdir');
    const access = assertAllowed(event, dirPath, 'fs:readdir');
    if (!access.allowed) throw new Error(deniedMessage(access));
    const withFileTypes = !!(options && typeof options === 'object' && options.withFileTypes);
    const entries = await fsPromises.readdir(dirPath, { withFileTypes });
    return withFileTypes ? toSerializableDirents(entries) : entries.map(String);
  });

  ipcMain.handle('fs:stat', async (event, targetPath) => {
    assertTrusted(event, 'fs:stat');
    const access = assertAllowed(event, targetPath, 'fs:stat');
    if (!access.allowed) throw new Error(deniedMessage(access));
    const st = await fsPromises.stat(targetPath);
    return toSerializableStat(st);
  });

  ipcMain.handle('fs:unlink', async (event, targetPath) => {
    assertTrusted(event, 'fs:unlink');
    const access = assertAllowed(event, targetPath, 'fs:unlink');
    if (!access.allowed) throw new Error(deniedMessage(access));
    await fsPromises.unlink(targetPath);
    return true;
  });

  ipcMain.handle('fs:copyFile', async (event, srcPath, destPath) => {
    assertTrusted(event, 'fs:copyFile');
    const srcAccess = assertAllowed(event, srcPath, 'fs:copyFile:src');
    const dstAccess = assertAllowed(event, destPath, 'fs:copyFile:dest');
    if (!srcAccess.allowed || !dstAccess.allowed) {
      throw new Error(deniedMessage(!srcAccess.allowed ? srcAccess : dstAccess));
    }
    const parent = path.dirname(String(destPath));
    if (parent) await fsPromises.mkdir(parent, { recursive: true });
    await fsPromises.copyFile(srcPath, destPath);
    return true;
  });

  if (isDevBuild) {
  ipcMain.on('fs:existsSync', (event, targetPath) => {
    logSyncDeprecation(event, 'fs:existsSync');
    assertTrusted(event, 'fs:existsSync');
    try {
      const access = assertAllowed(event, targetPath, 'fs:existsSync');
      if (!access.allowed) {
        event.returnValue = false;
        return;
      }
      event.returnValue = fs.existsSync(targetPath);
    } catch {
      event.returnValue = false;
    }
  });

  ipcMain.on('fs:readTextFileSync', (event, filePath, encoding) => {
    logSyncDeprecation(event, 'fs:readTextFileSync');
    try {
      assertTrusted(event, 'fs:readTextFileSync');
      const access = assertAllowed(event, filePath, 'fs:readTextFileSync');
      if (!access.allowed) return deny(event, deniedMessage(access));

      const enc = (typeof encoding === 'string' && encoding) ? encoding : 'utf8';
      const data = fs.readFileSync(filePath, { encoding: enc });
      ok(event, String(data));
    } catch (err) {
      deny(event, permissionMessage(err));
    }
  });

  ipcMain.on('fs:writeTextFileSync', (event, filePath, content, encoding) => {
    logSyncDeprecation(event, 'fs:writeTextFileSync');
    try {
      assertTrusted(event, 'fs:writeTextFileSync');
      const access = assertAllowed(event, filePath, 'fs:writeTextFileSync');
      if (!access.allowed) return deny(event, deniedMessage(access));

      const enc = (typeof encoding === 'string' && encoding) ? encoding : 'utf8';
      // Ensure parent directory exists when writing app-managed files.
      try {
        const parent = path.dirname(String(filePath));
        if (parent) fs.mkdirSync(parent, { recursive: true });
      } catch {
        // ignore
      }
      fs.writeFileSync(filePath, String(content ?? ''), { encoding: enc });
      ok(event, true);
    } catch (err) {
      deny(event, permissionMessage(err));
    }
  });

  ipcMain.on('fs:mkdirSync', (event, dirPath) => {
    logSyncDeprecation(event, 'fs:mkdirSync');
    try {
      assertTrusted(event, 'fs:mkdirSync');
      const access = assertAllowed(event, dirPath, 'fs:mkdirSync');
      if (!access.allowed) return deny(event, deniedMessage(access));
      fs.mkdirSync(dirPath, { recursive: true });
      ok(event, true);
    } catch (err) {
      deny(event, permissionMessage(err));
    }
  });

  ipcMain.on('fs:readdirSync', (event, dirPath, options) => {
    logSyncDeprecation(event, 'fs:readdirSync');
    try {
      assertTrusted(event, 'fs:readdirSync');
      const access = assertAllowed(event, dirPath, 'fs:readdirSync');
      if (!access.allowed) return deny(event, deniedMessage(access));

      const withFileTypes = !!(options && typeof options === 'object' && options.withFileTypes);
      const entries = fs.readdirSync(dirPath, { withFileTypes });
      ok(event, withFileTypes ? toSerializableDirents(entries) : entries.map(String));
    } catch (err) {
      deny(event, permissionMessage(err));
    }
  });

  ipcMain.on('fs:statSync', (event, targetPath) => {
    logSyncDeprecation(event, 'fs:statSync');
    try {
      assertTrusted(event, 'fs:statSync');
      const access = assertAllowed(event, targetPath, 'fs:statSync');
      if (!access.allowed) return deny(event, deniedMessage(access));

      const st = fs.statSync(targetPath);
      ok(event, toSerializableStat(st));
    } catch (err) {
      deny(event, permissionMessage(err));
    }
  });

  ipcMain.on('fs:unlinkSync', (event, targetPath) => {
    logSyncDeprecation(event, 'fs:unlinkSync');
    try {
      assertTrusted(event, 'fs:unlinkSync');
      const access = assertAllowed(event, targetPath, 'fs:unlinkSync');
      if (!access.allowed) return deny(event, deniedMessage(access));
      fs.unlinkSync(targetPath);
      ok(event, true);
    } catch (err) {
      deny(event, permissionMessage(err));
    }
  });

  ipcMain.on('fs:copyFileSync', (event, srcPath, destPath) => {
    logSyncDeprecation(event, 'fs:copyFileSync');
    try {
      assertTrusted(event, 'fs:copyFileSync');
      const srcAccess = assertAllowed(event, srcPath, 'fs:copyFileSync:src');
      if (!srcAccess.allowed) return deny(event, deniedMessage(srcAccess));
      const dstAccess = assertAllowed(event, destPath, 'fs:copyFileSync:dest');
      if (!dstAccess.allowed) return deny(event, deniedMessage(dstAccess));

      // Ensure parent directory exists.
      try {
        const parent = path.dirname(String(destPath));
        if (parent) fs.mkdirSync(parent, { recursive: true });
      } catch {
        // ignore
      }
      fs.copyFileSync(srcPath, destPath);
      ok(event, true);
    } catch (err) {
      deny(event, permissionMessage(err));
    }
  });
  }

}

module.exports = registerFsAccessHandlers;
