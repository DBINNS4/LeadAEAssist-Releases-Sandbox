'use strict';

const http = require('http');
const { randomBytes, randomUUID } = require('crypto');
const { app, shell } = require('electron');
const secureStore = require('../modules/secureStore');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const { readState } = require('../utils/state');

// IMPORTANT:
// - Dev: allow sandbox defaults so you can keep iterating fast.
// - Packaged: NEVER fall back to sandbox defaults.
// Allow dev runs to simulate packaged behavior (so you can catch packaging-only config failures early).
// Usage: LEADAE_SIMULATE_PACKAGED=1 npm start
const IS_PACKAGED = !!app?.isPackaged || process.env.LEADAE_SIMULATE_PACKAGED === '1';
const ALLOW_DEFAULTS = !IS_PACKAGED;

const { loadPublicRuntimeConfig } = require('../utils/publicRuntimeConfig');

const __publicCfg = loadPublicRuntimeConfig({ isPackaged: IS_PACKAGED, allowDefaults: ALLOW_DEFAULTS });

const PADDLE_ENV = String(__publicCfg?.paddle?.env || '').trim();
const PADDLE_CLIENT_TOKEN = String(__publicCfg?.paddle?.clientToken || '').trim();
const PRICE_MONTHLY = String(__publicCfg?.paddle?.priceMonthly || '').trim();
const PRICE_YEARLY = String(__publicCfg?.paddle?.priceYearly || '').trim();


function isOfflineModeEnabled() {
  try {
    const state = readState() || {};
    return !!state?.preferences?.offlineMode;
  } catch {
    return false;
  }
}

function offlineModeResult(actionLabel) {
  const action = String(actionLabel || '').trim() || 'action';
  return {
    ok: false,
    code: 'OFFLINE_MODE',
    error: `Offline Mode is enabled. ${action} is unavailable while offline. Disable Offline Mode in Preferences to continue.`
  };
}


function isDevPortalSchemeAllowed(protocol) {
  return protocol === 'https:' || (!IS_PACKAGED && protocol === 'http:');
}

function collectAllowedPortalHosts() {
  const fromConfig = [
    ...(__publicCfg?.portalAllowedHosts || []),
    ...(__publicCfg?.billingHosts || []),
    ...(__publicCfg?.entitlementHosts || [])
  ];

  const fromEntitlementUrl = [];
  try {
    const entBase =
      process.env.LEADAE_ENTITLEMENT_URL ||
      String(__publicCfg?.entitlementUrl || '').trim();
    if (entBase) fromEntitlementUrl.push(new URL(entBase).hostname);
  } catch {}

  const normalized = new Set();
  for (const host of [...fromConfig, ...fromEntitlementUrl]) {
    const h = String(host || '').trim().toLowerCase();
    if (h) normalized.add(h);
  }
  return normalized;
}

function validatePortalUrl(rawUrl) {
  const urlValue = String(rawUrl || '').trim();
  if (!urlValue) return null;

  let parsed;
  try {
    parsed = new URL(urlValue);
  } catch {
    return null;
  }

  if (!isDevPortalSchemeAllowed(parsed.protocol)) {
    return null;
  }

  const hostname = String(parsed.hostname || '').trim().toLowerCase();
  if (!hostname) return null;

  const allowedHosts = collectAllowedPortalHosts();
  if (IS_PACKAGED) {
    if (!allowedHosts.size || !allowedHosts.has(hostname)) return null;
  } else if (allowedHosts.size && !allowedHosts.has(hostname)) {
    return null;
  }

  return parsed.toString();
}

function _getDeviceIdMainProcess() {
  try {
    const v = secureStore.loadSecret('deviceId');
    if (typeof v === 'string' && v.trim()) return v.trim();
  } catch {}
  try {
    const fresh = randomUUID();
    try { secureStore.saveSecret('deviceId', fresh); } catch {}
    return fresh;
  } catch {}
  return '';
}

let server = null;
let port = null;
const checkoutContexts = new Map();
let serverCloseTimer = null;
// No Electron BrowserWindow for checkout anymore — we open in the user's browser.

function shutdownBillingServer() {
  try {
    if (serverCloseTimer) {
      clearTimeout(serverCloseTimer);
      serverCloseTimer = null;
    }
  } catch {}
  try {
    if (server) server.close();
  } catch {}
  server = null;
  port = null;
  checkoutContexts.clear();
}

// Ensure this helper never prevents the app from quitting.
try {
  app.on('before-quit', shutdownBillingServer);
  app.on('will-quit', shutdownBillingServer);
} catch {}

function createCheckoutNonce() {
  return randomBytes(24).toString('hex');
}

function isValidCheckoutNonce(nonce) {
  const candidate = String(nonce || '').trim();
  if (!candidate) return false;

  const context = checkoutContexts.get(candidate);
  if (!context) return false;
  if (context.consumed) return false;
  if (Date.now() > context.expiresAt) {
    checkoutContexts.delete(candidate);
    return false;
  }

  return true;
}

function getCheckoutContext(nonce) {
  const candidate = String(nonce || '').trim();
  if (!candidate) return null;
  if (!isValidCheckoutNonce(candidate)) return null;
  return checkoutContexts.get(candidate) || null;
}

function pageHtml(nonce) {
  const nonceQuery = encodeURIComponent(String(nonce || ''));
  return `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="referrer" content="no-referrer" />
    <meta http-equiv="Content-Security-Policy"
      content="default-src 'self';
               script-src 'self' https://cdn.paddle.com;
               style-src 'self' 'unsafe-inline';
               connect-src 'self' https://*.paddle.com;
               frame-src https://*.paddle.com;
               img-src 'self' data:;
               object-src 'none';
               base-uri 'none'">
    <title>Subscribe</title>
    <style>
      body { font-family: system-ui, -apple-system, Segoe UI, sans-serif; margin: 16px; }
      .box { border: 1px solid rgba(255,255,255,.15); border-radius: 10px; padding: 14px; }
      #status { margin-top: 10px; font-size: 12px; white-space: pre-wrap; }
    </style>
  </head>
  <body>
    <div class="box">
      <div><strong>Opening Paddle Checkout…</strong></div>
      <div id="status"></div>
    </div>
    <script src="https://cdn.paddle.com/paddle/v2/paddle.js"></script>
    <script src="/checkout.js?nonce=${nonceQuery}"></script>
  </body>
</html>`;
}

function checkoutJs() {
  return `(() => {
  const ENV = ${JSON.stringify(PADDLE_ENV)};
  const TOKEN = ${JSON.stringify(PADDLE_CLIENT_TOKEN)};
  const PRICE_MONTHLY = ${JSON.stringify(PRICE_MONTHLY)};
  const PRICE_YEARLY = ${JSON.stringify(PRICE_YEARLY)};

  const qs = new URLSearchParams(location.search);
  const nonce = String(qs.get('nonce') || '');

  const statusEl = document.getElementById('status');
  const setStatus = (m) => statusEl && (statusEl.textContent = String(m || ''));

  if (!window.Paddle) return setStatus('Paddle.js failed to load.');
  if (!TOKEN) {
    return setStatus('Billing not configured (missing client token).');
  }

  // Paddle.js uses sandbox explicitly; production is the default.
  try { if (String(ENV).toLowerCase() === 'sandbox') Paddle.Environment.set('sandbox'); } catch {}

  const sendCompletion = () => {
    if (!nonce) return;
    const url = '/complete?nonce=' + encodeURIComponent(nonce);
    try {
      if (navigator.sendBeacon) {
        navigator.sendBeacon(url, '');
        return;
      }
    } catch {}
    try {
      fetch(url, { method: 'POST', keepalive: true });
    } catch {}
  };

  const startCheckout = async () => {
    const contextUrl = '/checkout-context?nonce=' + encodeURIComponent(nonce);
    let context = null;
    try {
      const resp = await fetch(contextUrl, { cache: 'no-store' });
      if (!resp.ok) {
        setStatus('Checkout context request failed (' + resp.status + ').');
        sendCompletion();
        return;
      }
      context = await resp.json();
    } catch (err) {
      setStatus('Checkout context request failed: ' + (err?.message || err));
      sendCompletion();
      return;
    }

    const planRaw = String(context?.plan || 'monthly').toLowerCase();
    // Trial is configured on the Paddle price(s). Any legacy "trial" plan just maps to monthly.
    const plan = (planRaw === 'yearly' || planRaw === 'annual') ? 'yearly' : 'monthly';
    const deviceId = String(context?.deviceId || '');

    const wantsYearly = (plan === 'yearly');
    const priceId = wantsYearly ? PRICE_YEARLY : PRICE_MONTHLY;
    if (!priceId) {
      setStatus('Missing priceId for plan: ' + plan);
      sendCompletion();
      return;
    }

    try {
    Paddle.Initialize({
      token: TOKEN,
      eventCallback: (ev) => {
        try {
          if (!ev) return;
          if (ev.name === 'checkout.completed') {
            setStatus('Checkout completed.\\nTransaction: ' + (ev.data?.transaction_id || '—'));
            sendCompletion();
          } else if (ev.name === 'checkout.closed') {
            setStatus('Checkout closed.');
            sendCompletion();
          } else if (ev.name === 'checkout.error') {
            setStatus('CHECKOUT ERROR:\\n' + JSON.stringify(ev, null, 2));
            sendCompletion();
          }
        } catch (e) {
          setStatus('Event handler error: ' + (e?.message || e));
        }
      }
    });

    Paddle.Checkout.open({
      items: [{ priceId, quantity: 1 }],
      // IMPORTANT: bind purchase to this device so webhook can upsert entitlements.
      // Our entitlement-service webhook looks for evt.data.custom_data.device_id or evt.data.customData.device_id
      customData: deviceId ? { device_id: deviceId } : undefined,
      // Some integrations use snake_case. Harmless if ignored.
      custom_data: deviceId ? { device_id: deviceId } : undefined
    });
    } catch (err) {
      setStatus('Failed to open checkout: ' + (err?.message || err));
      sendCompletion();
    }
  };

  startCheckout();
})();`;
}

function handleBillingRequest(req, res) {
  const url = new URL(req.url || '/', 'http://127.0.0.1');
  if (url.pathname === '/checkout' || url.pathname === '/checkout.js' || url.pathname === '/checkout-context' || url.pathname === '/complete') {
    if (!isValidCheckoutNonce(url.searchParams.get('nonce'))) {
      res.writeHead(403, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' });
      res.end('forbidden');
      return;
    }
  }

  if (url.pathname === '/' || url.pathname === '/checkout') {
    res.writeHead(200, {
      'content-type': 'text/html; charset=utf-8',
      'cache-control': 'no-store'
    });
    res.end(pageHtml(url.searchParams.get('nonce')));
    return;
  }

  if (url.pathname === '/checkout.js') {
    res.writeHead(200, {
      'content-type': 'application/javascript; charset=utf-8',
      'cache-control': 'no-store'
    });
    res.end(checkoutJs());
    return;
  }

  if (url.pathname === '/checkout-context') {
    const context = getCheckoutContext(url.searchParams.get('nonce'));
    if (!context) {
      res.writeHead(403, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
      res.end(JSON.stringify({ error: 'forbidden' }));
      return;
    }

    res.writeHead(200, {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store'
    });
    res.end(JSON.stringify({
      deviceId: context.deviceId,
      plan: context.plan
    }));
    return;
  }

  if (url.pathname === '/complete') {
    const nonce = String(url.searchParams.get('nonce') || '').trim();
    const context = getCheckoutContext(nonce);
    if (context) {
      context.consumed = true;
      checkoutContexts.set(nonce, context);
    }
    res.writeHead(204, { 'cache-control': 'no-store' });
    res.end();
    shutdownBillingServer();
    return;
  }

  res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
  res.end('not found');
}

function ensureServer() {
  if (server && port) return Promise.resolve(port);
  return new Promise((resolve, reject) => {
    server = http.createServer((req, res) => {
      try {
        return handleBillingRequest(req, res);
      } catch {
        res.writeHead(500, { 'content-type': 'text/plain; charset=utf-8' });
        return res.end('server error');
      }
    });
    server.on('error', reject);
    // Don’t let sockets keep Electron alive if the user quits while checkout is open.
    server.on('connection', (socket) => {
      try { socket.unref(); } catch {}
    });
    server.listen(0, '127.0.0.1', () => {
      const addr = server.address();
      port = addr && typeof addr === 'object' ? addr.port : null;
      if (!port) return reject(new Error('Failed to bind localhost port'));
      // Don’t keep the process alive just because this server exists.
      try { server.unref(); } catch {}
      resolve(port);
    });
  });
}

async function openCheckoutWindow(options = {}) {
  if (isOfflineModeEnabled()) return offlineModeResult('Billing checkout');
  const planRaw = String(options.plan || 'monthly').toLowerCase();
  // Trial is configured on the Paddle price(s). Any legacy "trial" plan just maps to monthly.
  const plan = (planRaw === 'yearly' || planRaw === 'annual') ? 'yearly' : 'monthly';
  const checkoutNonce = createCheckoutNonce();
  // In packaged builds, refuse to open checkout unless explicitly configured.
  if (IS_PACKAGED) {
    if (!PADDLE_ENV || !PADDLE_CLIENT_TOKEN) {
      return { ok: false, error: 'Billing not configured (missing Paddle env/clientToken)' };
    }
    const wantsYearly = (plan === 'yearly');
    if (wantsYearly && !PRICE_YEARLY) {
      return { ok: false, error: 'Billing not configured (missing yearly priceId)' };
    }
    if (!wantsYearly && !PRICE_MONTHLY) {
      return { ok: false, error: 'Billing not configured (missing monthly priceId)' };
    }
  }

  const p = await ensureServer();

  const deviceId = _getDeviceIdMainProcess();
  if (!deviceId) {
    shutdownBillingServer();
    return { ok: false, error: 'Missing deviceId' };
  }

  checkoutContexts.clear();
  checkoutContexts.set(checkoutNonce, {
    deviceId,
    plan,
    consumed: false,
    expiresAt: Date.now() + (2 * 60 * 1000)
  });

  // Auto-shutdown the local server quickly if checkout doesn't complete.
  try {
    if (serverCloseTimer) clearTimeout(serverCloseTimer);
    serverCloseTimer = setTimeout(shutdownBillingServer, 2 * 60 * 1000);
    if (serverCloseTimer && typeof serverCloseTimer.unref === 'function') serverCloseTimer.unref();
  } catch {}

  const url =
    `http://127.0.0.1:${p}/checkout?plan=${encodeURIComponent(plan)}&nonce=${encodeURIComponent(checkoutNonce)}`;

  // Open checkout in the user's default browser.
  // This avoids Electron CSP/iframe/3DS issues entirely.
  try {
    await shell.openExternal(url);
    return { ok: true };
  } catch (err) {
    shutdownBillingServer();
    return { ok: false, error: `Failed to open browser: ${err?.message || err}` };
  }
}

async function openPortalWindow(_options = {}) {
  if (isOfflineModeEnabled()) return offlineModeResult('Billing portal');
  // Portal requires a valid installed entitlement token (Bearer auth).
  let token = '';
  try {
    const v = secureStore.loadSecret('licenseToken');
    if (typeof v === 'string') token = v.trim();
  } catch {}
  if (!token) return { ok: false, error: 'No active entitlement token installed' };

  const baseUrl =
    process.env.LEADAE_ENTITLEMENT_URL ||
    String(__publicCfg?.entitlementUrl || '').trim() ||
    (IS_PACKAGED ? '' : 'http://127.0.0.1:8787');

  if (!baseUrl) return { ok: false, error: 'Entitlement server not configured' };
  if (typeof fetch !== 'function') return { ok: false, error: 'fetch unavailable in main process' };

  // JWTs should not include whitespace, but storage/files can introduce newlines.
  const cleanToken = String(token || '').trim().replace(/\s+/g, '');
  if (!cleanToken) return { ok: false, error: 'No active entitlement token installed' };

  const u = new URL('/portal', baseUrl);
  const resp = await fetch(u.toString(), {
    method: 'POST',
    headers: {
      // Some proxies strip Authorization; server accepts JSON body token as fallback.
      'content-type': 'application/json; charset=utf-8',
      authorization: `Bearer ${cleanToken}`
    },
    body: JSON.stringify({ token: cleanToken })
  });
  if (!resp.ok) return { ok: false, error: `Portal request failed (${resp.status})` };

  const j = await resp.json().catch(() => ({}));
  const safePortalUrl = validatePortalUrl(j?.url);
  if (!safePortalUrl) return { ok: false, error: 'Portal URL invalid' };

  try {
    await shell.openExternal(safePortalUrl);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: `Failed to open browser: ${err?.message || err}` };
  }
}

function registerBillingHandlers(ipcMain) {
  ipcMain.handle('billing:open-checkout', async (event, options) => {
    assertTrustedIpcSender(event, 'billing:open-checkout');
    return openCheckoutWindow(options || {});
  });

  ipcMain.handle('billing:open-portal', async (event, options) => {
    assertTrustedIpcSender(event, 'billing:open-portal');
    return openPortalWindow(options || {});
  });
}

module.exports = registerBillingHandlers;
module.exports._private = {
  openCheckoutWindow,
  openPortalWindow,
  validatePortalUrl,
  collectAllowedPortalHosts,
  isValidCheckoutNonce,
  handleBillingRequest
};
