(function () {
  'use strict';

  function $(id) {
    return document.getElementById(id);
  }

  function normalizeRoute(route) {
    const raw = String(route || '').trim();
    if (!raw) return '/';
    let r = raw;
    if (!r.startsWith('/')) r = `/${r}`;
    // collapse multiple slashes
    r = r.replace(/\/+/g, '/');
    if (!r.endsWith('/')) r += '/';
    return r;
  }

  function parseHash() {
    const raw = String(window.location.hash || '');
    const withoutHash = raw.startsWith('#') ? raw.slice(1) : raw;
    const trimmed = withoutHash.trim();
    if (!trimmed) {
      return { route: '/', params: new URLSearchParams() };
    }

    const [routePart, queryPart] = trimmed.split('?');
    const params = new URLSearchParams(queryPart || '');
    const route = normalizeRoute(routePart || '/');
    return { route, params };
  }

  function setHashRoute(route, params) {
    const r = normalizeRoute(route);
    const qs = params && params.toString ? params.toString() : '';
    window.location.hash = qs ? `${r}?${qs}` : r;
  }

  function escapeHtml(s) {
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function getDataOrFallback(name, fallback) {
    try {
      const v = window[name];
      return v != null ? v : fallback;
    } catch {
      return fallback;
    }
  }

  const PAGES = getDataOrFallback('__HELP_PAGES__', {});
  const NAV = getDataOrFallback('__HELP_NAV__', { defaultRoute: '/', sections: [] });
  const SEARCH = getDataOrFallback('__HELP_SEARCH_INDEX__', []);

  const sidebarEl = $('sidebar');
  const contentEl = $('content');
  const searchInput = $('searchInput');
  const searchDropdown = $('searchDropdown');
  const versionEl = $('appVersion');

  function setVersionFromQuery() {
    try {
      const params = new URLSearchParams(window.location.search || '');
      const v = String(params.get('v') || '').trim();
      if (v) {
        versionEl.textContent = `v${v}`;
        versionEl.title = `App version ${v}`;
      } else {
        versionEl.textContent = '';
      }
    } catch {
      versionEl.textContent = '';
    }
  }

  function buildNavLink(slug, title, { isSub = false } = {}) {
    const li = document.createElement('li');
    li.className = 'nav-item';

    const a = document.createElement('a');
    a.href = `#${normalizeRoute(slug)}`;
    a.textContent = title;
    if (isSub) a.style.paddingLeft = '16px';
    li.appendChild(a);
    return li;
  }

  function renderNav(activeRoute) {
    if (!sidebarEl) return;

    // Clear
    sidebarEl.innerHTML = '';

    const sections = Array.isArray(NAV?.sections) ? NAV.sections : [];
    for (const section of sections) {
      const wrapper = document.createElement('div');
      wrapper.className = 'nav-section';

      const title = document.createElement('div');
      title.className = 'nav-title';
      title.textContent = section?.title || 'Section';
      wrapper.appendChild(title);

      const list = document.createElement('ul');
      list.className = 'nav-list';

      // Some sections are plain links with children.
      if (section?.slug) {
        // Home is a link too.
        if (section.slug === '/' || (section.docType === 'index' && !Array.isArray(section.children))) {
          list.appendChild(buildNavLink(section.slug, section.title || 'Home'));
        }
      }

      const children = Array.isArray(section?.children) ? section.children : [];
      for (const child of children) {
        // Workflows are grouped as { group, items }
        if (child && typeof child === 'object' && Array.isArray(child.items)) {
          const groupWrap = document.createElement('div');
          groupWrap.className = 'nav-subgroup';

          const groupTitle = document.createElement('div');
          groupTitle.className = 'nav-subgroup-title';
          groupTitle.textContent = child.group || 'Workflows';
          groupWrap.appendChild(groupTitle);

          const groupList = document.createElement('ul');
          groupList.className = 'nav-list';
          for (const item of child.items) {
            groupList.appendChild(buildNavLink(item.slug, item.title || item.slug, { isSub: true }));
          }
          groupWrap.appendChild(groupList);
          wrapper.appendChild(groupWrap);
          continue;
        }

        list.appendChild(buildNavLink(child.slug, child.title || child.slug));
      }

      wrapper.appendChild(list);
      sidebarEl.appendChild(wrapper);
    }

    // Highlight active link
    try {
      const links = sidebarEl.querySelectorAll('a[href^="#/"]');
      links.forEach((a) => {
        const href = a.getAttribute('href') || '';
        const slug = normalizeRoute(href.replace(/^#/, ''));
        if (slug === normalizeRoute(activeRoute)) a.classList.add('active');
        else a.classList.remove('active');
      });
    } catch {
      // ignore
    }
  }

  function renderNotFound(route) {
    const safe = escapeHtml(route);
    contentEl.innerHTML = `
      <h1>Page not found</h1>
      <p class="muted">No help page matches <code>${safe}</code>.</p>
      <div class="notice">
        <p><a href="#/">Go to Help Home</a></p>
        <p><a href="#/search/">Search help</a></p>
      </div>
    `;
  }

  function scoreResult(query, item) {
    const q = query.toLowerCase();
    const title = String(item.title || '').toLowerCase();
    const body = String(item.body || '').toLowerCase();
    if (!q) return 0;
    if (title === q) return 100;
    if (title.startsWith(q)) return 85;
    if (title.includes(q)) return 70;
    if (body.includes(q)) return 40;
    return 0;
  }

  function searchIndex(query) {
    const q = String(query || '').trim();
    if (!q) return [];
    const items = Array.isArray(SEARCH) ? SEARCH : [];
    const scored = [];
    for (const item of items) {
      const score = scoreResult(q, item);
      if (score <= 0) continue;
      scored.push({ item, score });
    }
    scored.sort((a, b) => b.score - a.score);
    return scored.map((s) => s.item);
  }

  function renderSearchDropdown(query) {
    if (!searchDropdown) return;
    const q = String(query || '').trim();
    if (!q) {
      searchDropdown.hidden = true;
      searchDropdown.innerHTML = '';
      return;
    }

    const results = searchIndex(q).slice(0, 8);
    if (!results.length) {
      searchDropdown.hidden = false;
      searchDropdown.innerHTML = `<div class="search-result"><div class="search-result-title">No matches</div><div class="search-result-meta">Press Enter to search anyway</div></div>`;
      return;
    }

    const frag = document.createDocumentFragment();
    for (const r of results) {
      const a = document.createElement('a');
      a.className = 'search-result';
      a.href = `#${normalizeRoute(r.slug)}`;

      const title = document.createElement('div');
      title.className = 'search-result-title';
      title.textContent = r.title || r.slug;
      a.appendChild(title);

      const meta = document.createElement('div');
      meta.className = 'search-result-meta';
      meta.textContent = `${r.docType || 'doc'} • ${r.slug}`;
      a.appendChild(meta);

      frag.appendChild(a);
    }

    searchDropdown.innerHTML = '';
    searchDropdown.appendChild(frag);
    searchDropdown.hidden = false;
  }

  function renderSearchResultsInto(container, query) {
    const q = String(query || '').trim();
    const results = searchIndex(q);

    const title = document.createElement('h2');
    title.textContent = q ? `Search results for “${q}”` : 'Search results';
    container.appendChild(title);

    if (!q) {
      const p = document.createElement('p');
      p.className = 'muted';
      p.textContent = 'Type in the search box above, or add ?q=... to the URL hash.';
      container.appendChild(p);
      return;
    }

    if (!results.length) {
      const p = document.createElement('p');
      p.className = 'muted';
      p.textContent = 'No matching pages.';
      container.appendChild(p);
      return;
    }

    const ul = document.createElement('ul');
    for (const r of results) {
      const li = document.createElement('li');
      const a = document.createElement('a');
      a.href = `#${normalizeRoute(r.slug)}`;
      a.textContent = r.title || r.slug;
      li.appendChild(a);

      if (r.excerpt) {
        const div = document.createElement('div');
        div.className = 'muted';
        div.style.marginTop = '4px';
        div.textContent = r.excerpt;
        li.appendChild(div);
      }
      ul.appendChild(li);
    }
    container.appendChild(ul);
  }

  function scrollToAnchor(anchorId) {
    const id = String(anchorId || '').trim();
    if (!id) return;
    // Defer until after layout.
    setTimeout(() => {
      try {
        const el = document.getElementById(id);
        if (el && typeof el.scrollIntoView === 'function') {
          el.scrollIntoView({ block: 'start' });
        }
      } catch {
        // ignore
      }
    }, 0);
  }

  function renderRoute(route, params) {
    const r = normalizeRoute(route);
    const page = PAGES[r];
    renderNav(r);

    if (!contentEl) return;
    if (!page || typeof page.html !== 'string') {
      renderNotFound(r);
      return;
    }

    document.title = page.title ? `${page.title} — Help` : 'Help';
    contentEl.innerHTML = page.html;

    // Special case: Search route gets dynamic results below the page content.
    if (r === '/search/') {
      const q = String(params?.get('q') || '').trim();
      const resultsWrap = document.createElement('div');
      resultsWrap.style.marginTop = '18px';
      resultsWrap.className = 'notice';
      renderSearchResultsInto(resultsWrap, q);
      contentEl.appendChild(resultsWrap);
    }

    // Optional anchor scroll (deep-link support)
    const anchor = String(params?.get('a') || '').trim();
    if (anchor) scrollToAnchor(anchor);
  }

  function onHashChange() {
    const { route, params } = parseHash();
    renderRoute(route, params);
  }

  function hideSearchDropdownSoon() {
    // Small timeout so click can register
    setTimeout(() => {
      try {
        searchDropdown.hidden = true;
      } catch {}
    }, 120);
  }

  function wireSearch() {
    if (!searchInput) return;

    searchInput.addEventListener('input', () => {
      renderSearchDropdown(searchInput.value);
    });

    searchInput.addEventListener('focus', () => {
      renderSearchDropdown(searchInput.value);
    });

    searchInput.addEventListener('blur', () => {
      hideSearchDropdownSoon();
    });

    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        searchDropdown.hidden = true;
        return;
      }
      if (e.key === 'Enter') {
        const q = String(searchInput.value || '').trim();
        const params = new URLSearchParams();
        if (q) params.set('q', q);
        setHashRoute('/search/', params);
      }
    });
  }

  function init() {
    setVersionFromQuery();
    wireSearch();

    window.addEventListener('hashchange', onHashChange);

    // First render
    const { route, params } = parseHash();
    const defaultRoute = normalizeRoute(NAV?.defaultRoute || '/');
    if (!route || route === '/') {
      // If no route was provided in hash, force to default route.
      if (!String(window.location.hash || '').trim()) {
        setHashRoute(defaultRoute);
        return;
      }
    }
    renderRoute(route, params);
  }

  // Kickoff
  try {
    init();
  } catch (err) {
    // Minimal crash fallback
    const msg = escapeHtml(err?.message || String(err));
    if (contentEl) {
      contentEl.innerHTML = `<h1>Help failed to load</h1><p class="muted">${msg}</p>`;
    }
  }
})();
