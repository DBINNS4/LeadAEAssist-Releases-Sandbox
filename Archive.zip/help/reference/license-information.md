# License information

## What this page is for
Use this page when you need the app's bundled legal notices without searching through the packaged app manually.

This page covers:
- where the packaged build ships the legal files
- what each file is for
- where to view the latest online terms in your browser

## Bundled legal files in the packaged app
The packaged build should ship the real legal files under:

`legal/`

The expected files are:
- `legal/LICENSE` — first-party proprietary software notice
- `legal/NOTICE` — distribution notice that points to the bundled legal materials
- `legal/THIRD_PARTY_LICENSES` — consolidated third-party notices included with the app
- `legal/APP-LICENSE.txt` — packaged-app proprietary notice
- `legal/Electron-MIT.txt` — Electron MIT license text
- `legal/FFmpeg-LGPLv2.1.txt` — FFmpeg LGPL v2.1 license text

## What the menu item opens
**Help -> License Information** opens this bundled page.

That means users can always reach licensing guidance from the native app menu without needing to inspect the install folder.

## View the latest terms online
- [View latest terms online](https://www.leadae.com/terms)
- [Privacy Notice](https://www.leadae.com/privacy)
- [Refund Policy](https://www.leadae.com/refund)

The online pages are the latest published versions. The bundled files are the packaged distribution notices that ship with the app.

## Important behavior
- This bundled help page works offline.
- The online links open in the user's default browser.
- If **Offline Mode** is enabled, the app may block the online links until the user disables Offline Mode.

## Related
- [Account and Licensing](/panels/account-and-licensing/)
- [Troubleshooting - Account and Licensing](/troubleshooting/account-and-licensing/)
- [Lead AE Assist Help](/)
