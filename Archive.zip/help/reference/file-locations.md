# File locations

## Purpose
This page names the main on-disk locations the app uses so support and users are not forced to play hide-and-seek with the filesystem.

## Canonical app data root
The app stores its own files under a stable root named `LeadAEAssist`.

### macOS
`~/Library/Application Support/LeadAEAssist/`

### Windows
`%APPDATA%\LeadAEAssist\`

## Common subfolders

### Logs
`LeadAEAssist/logs/`

Typical subfolders include:
- `logs/ingest/`
- `logs/clone/`
- `logs/transcode/`
- `logs/transcribe/`
- `logs/adobe-utilities/`
- `logs/project-organizer/`
- `logs/speed-test/`

Other subfolders can appear over time as new panels or support flows add job logging.

### Config
`LeadAEAssist/config/`

This area stores app configuration data.


### Preferences state and sensitive storage
The Preferences panel writes to a split storage model.

**Normal preference state**
- `LeadAEAssist/config/state.json`
- `LeadAEAssist/config/state.json.bak`

This is where the app stores supported non-secret preference keys such as:
- Offline Mode
- crash reporting
- theme
- language
- webhook settings
- maintenance settings
- auto-update settings

**Sensitive storage**
Some values (such as the AI API key) are stored separately from ordinary files and are intentionally not documented as file paths.

Important:
- the actual AI API key is **not** stored in plain `state.json`
- support should not ask users to paste secret contents casually
- `apiKeyStored` in `state.json` is only a flag, not the secret value itself

### Presets
Presets live under:
- `LeadAEAssist/config/presets/`

Example panel-specific preset locations:
- `config/presets/ingest/`
- `config/presets/transcode/`
- `config/presets/transcribe/`
- `config/presets/adobe-utilities/`
- `config/presets/project-organizer/`
- `config/presets/nle-utilities/`

Adobe Automate also uses a Media Encoder preset folder for `.epr` proxy presets:
- `config/presets/media-encoder/`

### Cache
`LeadAEAssist/cache/`

Use this for app cache and tracking data. Do not ask users to delete cache casually unless troubleshooting specifically calls for it.

### Temp
`LeadAEAssist/temp/`

Temporary working files can appear here.

### Previews
`LeadAEAssist/previews/`

Preview-related assets may appear here when the app creates them.


## Adobe Premiere CEP extension folder
The Preferences panel installs the bundled Premiere panel into the **user CEP extensions folder**.

### macOS
`~/Library/Application Support/Adobe/CEP/extensions/com.leadae.panel/`

### Windows
`%APPDATA%\Adobe\CEP\extensions\com.leadae.panel\`

Important:
- the UI works with the **user-scope** CEP folder
- **Open CEP Folder** opens either the installed panel folder or the base CEP extensions folder
- the status line in Preferences can also report a system-level CEP install if one is discovered, but user-scope install is the normal supported route from the app

## User-chosen output locations
Not everything is stored under the app data root. Many outputs go wherever the user told the panel to write them.

Examples:
- Ingest main copies go to the selected destination.
- Ingest backup copies go to the selected backup path.
- Transcode outputs go to the selected output folder.
- Transcribe outputs go to the selected output folder.
- Adobe Automate copies go to the selected destination.
- Adobe Automate backup copies go to the selected backup path.
- Log Viewer exports go to the user-selected export folder.

## Common destination-side ingest files
When using Ingest, users may see these files in the destination:
- `IngestLog_<timestamp>.txt`
- `IngestFailures_<timestamp>.txt`
- `RetryList_<timestamp>.txt`

If Auto Create Folder is on, those files appear inside the created subfolder rather than directly at the destination root.

## Common transcode output files
Transcode writes results to the user-selected output folder, not to the app data root.

Possible files include:
- transcoded media outputs
- `TranscodeLog_<timestamp>.txt` when **Save Log** is enabled for a manual job
- `<output-file>_metadata.json` when Preserve Metadata writes a compatibility sidecar

Batch jobs can add numeric suffixes such as `_000`, `_001`, and so on.
If the target name already exists, the app adds another suffix to avoid collisions.

### Watch Mode note
Transcode Watch Mode still uses the app log library under `logs/transcode/` for session logging.
Do not assume an Ingest-style `WatchLog_...` copy will appear in the transcode output folder.

## Common transcribe output files
Transcribe writes its deliverables to the user-selected output folder, not to the app data root.

Possible outputs include:
- transcript text files
- subtitle files such as `.srt` and `.vtt`
- caption files such as `.scc` and `.mcc`
- scripted CSV exports
- burn-in video exports

Raw Transcribe logs are typically **not** written to the output folder first. They live under:
- `LeadAEAssist/logs/transcribe/`

### Watch Mode note
Transcribe Watch Mode also archives its session logs in the app log library.
Do not assume a destination-side `WatchLog_...` copy will appear in the output folder.

## Subtitle Editor output files and preview cache
Subtitle Editor writes most of its corrected deliverables wherever the user chose to save them.

### Corrected text outputs
**Export Corrections** writes one corrected output that matches the active correction flow:
- `<root>.corrected.srt` for SRT correction exports, plus `<root>.corrected.srt.qc.json` and `<root>.corrected.srt.qc.txt`
- `<root>.corrected.vtt` for VTT correction exports, plus `<root>.corrected.vtt.qc.json` and `<root>.corrected.vtt.qc.txt`
- `<root>.corrected.final.json` for JSON correction exports unless the user chooses another `.json` filename

It does **not** auto-write sibling SRT/VTT/JSON exports from one basename anymore.

### Broadcast deliverables
Broadcast export actions can create:
- `<root>.scc`
- `<root>.mcc`
- `<output>.report.txt` sidecars when QC/report generation is involved

### Burn-in output
Burn-in writes:
- `<mediaBase>.burnin.mov`

Burn-in can also create or reuse a corrected `.srt`, because the FFmpeg burn-in path runs from SRT.

### Raw logging note
Subtitle Editor does **not** currently have a dedicated `LeadAEAssist/logs/subtitle-editor/` folder.
Its export/open activity is logged under the Transcribe logging surface:
- `LeadAEAssist/logs/transcribe/`

### Preview proxy cache
When the browser cannot decode source media directly, Subtitle Editor can create cached preview proxies under:
- `LeadAEAssist/temp/previews/`

These preview files are disposable runtime helpers, not the user's final deliverables.

## Common Adobe Automate output files
Adobe Automate writes several kinds of output, depending on configuration.

### Destination copies
Copied source media goes to the selected destination folder.

### Backup copies
If backup is enabled, backup copies go to the selected backup folder.

### Proxy outputs
Proxy outputs go to one of these:
- `Destination/Proxies` when no explicit proxy destination is chosen
- `SelectedProxyBase/Proxies` when the chosen proxy destination does not already end with `Proxies`
- the exact selected folder when it already ends with `Proxies`

That means the chosen proxy path is often a **base folder**, not always the final leaf folder.

### Destination-side Adobe log copy
When **Save Log** is enabled, Adobe Automate typically writes:
- `AdobeAutomateLog_<timestamp>.txt`

Users often look only in the proxy base and miss the actual destination-side log. Start with:
- the main destination
- the backup folder for backup-only cases
- the raw log library under `LeadAEAssist/logs/adobe-utilities/`

## Project Organizer output files and config locations
Project Organizer writes its created structure wherever the user pointed the panel.

### Generated folder tree
The organizer creates folders in one of two patterns:
- `OutputPath/ProjectName/...` when **Project Name** is filled in
- `OutputPath/...` when **Project Name** is blank

Important:
- a filled-in **Project Name** refuses to merge into a non-empty existing root folder
- a blank **Project Name** builds directly into the chosen output folder

### Attached assets
If files were attached to organizer folders, they are copied into those generated folders.
When destination filename collisions occur, the app can add suffixes such as `_1`, `_2`, and so on instead of overwriting.

### Raw organizer logs
Project Organizer writes raw per-job logs to:
- `LeadAEAssist/logs/project-organizer/`

Typical files include:
- `<timestamp>--<jobId>.jsonl`
- `<timestamp>--<jobId>.txt`

There is no destination-side convenience export like `OrganizerLog_<timestamp>.txt` at this time.

### Organizer preset/config locations
Preset dropdown files typically live under:
- `LeadAEAssist/config/presets/project-organizer/`

Manual **Save Config** exports can also be written anywhere the user chooses.
Those JSON files are useful support artifacts when the problem only appears with one specific layout.


## NLE Utilities side effects and backup folders
NLE Utilities does not write to a normal output folder.
It operates directly on the selected Avid or Adobe paths.

Common on-disk side effects include:

### Avid reset backup folders
When **Backup Before Reset** is enabled, the panel creates timestamped backup folders in place:

- `Settings/Site_Backup_<timestamp>/`
- `Avid Users/<user>/User_Backup_<timestamp>/`

### Avid rebuild trigger files
When **Rebuild DB** runs, or when **Delete DB** runs with **Auto Rebuild Databases** enabled, the panel can briefly create files like:

- `REBUILD_TRIGGER_<timestamp>_<random>.mxf`

Those files are temporary and are normally removed after about 15 seconds.

### Adobe cleanup side effects
Adobe cleanup actions delete matching files **in place** inside the selected folder tree or scope.
There is no separate export or quarantine folder.

Important:
- **Delete Autosaves** protects regular `.prproj` files outside Auto-Save-like folders.
- **Clear Cache** and **Remove Previews** can ask for a second confirmation if the folder name looks suspicious.

### NLE Utilities logging/export note
NLE Utilities does **not** expose a panel-side **Save Log** or export destination.
For support, preserve the summary text before the panel is reset or the folder path changes.


## Speed Test working files and side effects
Speed Test writes its permanent logs to the app log library, not to the tested target path.

### Raw logs
Permanent raw logs live under:
- `LeadAEAssist/logs/speed-test/`

Typical files include:
- structured per-job JSONL logs
- human-readable per-job TXT reports

### Temporary benchmark workspace inside the tested path
When a drive benchmark runs, the app creates a temporary hidden work folder inside the selected target:
- `.lead-speedtest/`

Possible temporary files include:
- `lead_speedtest_<sender>_<runId>_seq_a.tmp`
- `lead_speedtest_<sender>_<runId>_seq_b.tmp`
- `lead_speedtest_<sender>_<runId>_seq_c.tmp`
- `.__lead_speedtest_random_<sender>_<runId>_a.tmp`
- `.__lead_speedtest_random_<sender>_<runId>_b.tmp`
- `.__lead_speedtest_random_<sender>_<runId>_c.tmp`
- `.__lead_speedtest_active_<runId>.lock`
- `.__lead_speedtest_writecheck_<runId>.tmp`

The app tries to remove these files and delete the idle `.lead-speedtest` folder when the run completes.

Important:
- users may still notice the folder during the run or after an interrupted run
- stale temp files are cleaned later when they are old enough
- the tested path does **not** receive a destination-side `SpeedTestLog_...` export file

## Log Viewer export files
Log Viewer exports do **not** go into the app log library automatically.
They go wherever the user picked in the **Export Folder** control.

Common export filenames:
- `logs.txt`
- `logs.json`
- `logs.csv`

When the filtered TXT export resolves to a **single job id**, the viewer writes a richer single-job report instead:

- `job-report_<panel>_<YYYYMMDD_HHMMSS>_<jobId>.txt`

Important:
- **Open Log Folder** opens the app's raw log library, not the user-chosen export folder.
- If support needs both the raw archive and the user's exported summary, collect both.

## Premiere CEP panel installation location
The Lead AE Assist Premiere panel is installed as a CEP extension with the extension id:

`com.leadae.panel`

Typical per-user CEP extension locations:

### macOS
`~/Library/Application Support/Adobe/CEP/extensions/com.leadae.panel/`

### Windows
`%APPDATA%\Adobe\CEP\extensions\com.leadae.panel\`

The app's **Preferences -> Adobe Premiere Panel (CEP)** controls can:
- install/repair this panel
- uninstall it
- open the CEP folder directly

## Why support should care
Always separate these two ideas:
- **app library files** under `LeadAEAssist/`
- **workflow outputs** written to user-chosen destinations

If you mix those up, you end up telling the user to open the wrong folder and everyone gets to enjoy an unnecessary scavenger hunt.

## Related pages
- /panels/log-viewer/
- /reference/logs-and-support-bundle/
- /panels/ingest/
- /panels/transcribe/
- /panels/adobe-automate/


## Account and Licensing persistence (sensitive)
License data and related sensitive account details are intentionally not documented as normal on-disk file paths.

Support note:
- do **not** ask users to send sensitive storage files by default
- only collect sensitive items when support explicitly asks for them

### Account panel logging posture
There is no dedicated documented raw log folder such as `LeadAEAssist/logs/account/`.

For account/licensing issues, the most useful first artifacts are usually:
- the Account panel screenshot
- **Copy version info** output
- `LeadAEAssist/config/state.json`
- confirmation of whether another license file may still be present on the machine

### Verification keys (managed)
Verification files used by licensing are not normal end-user files to edit, and their location is intentionally not documented here.
