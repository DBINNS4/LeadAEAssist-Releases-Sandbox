# Reference

## What belongs here
Reference pages hold stable facts that support many panels:
- file locations
- log locations
- support collection
- output-format behavior

## Pages
- [License information](/reference/license-information/) — Where the bundled legal files live in the packaged app, what each file is for, and where to view the latest online terms.
- [Logs and support bundle](/reference/logs-and-support-bundle/) — Canonical log locations, what each area writes, and what support should collect before escalating.
- [File locations](/reference/file-locations/) — File-system map for temp data, output folders, preview proxies, CEP install paths, and app-support directories.
- [Transcribe output formats](/reference/transcribe-output-formats/) — Format chooser for SRT, VTT, TXT, JSON, SCC, MCC, and related Transcribe exports.

## Related
- [Lead AE Assist Help](/)
- [Log Viewer](/panels/log-viewer/)
- [Workflow - Export logs from Log Viewer](/workflows/export-logs-from-log-viewer/)
- [Workflow - Copy version info for support](/workflows/copy-version-info-for-support/)
