# Transcribe output formats

## Purpose
This page answers the user's most common format question:

**"Which output format should I pick?"**

## Plain Text (.txt)
Pick TXT when the user wants a readable transcript.

Good for:
- interview review
- script preparation
- searchable transcript handoff
- private documentation

Not ideal for:
- subtitle delivery to players/NLEs
- broadcast caption requirements

Key options:
- timestamp placement
- timecode format
- FPS override
- start TC
- speaker labels
- group by speaker

## SubRip (.srt)
Pick SRT for the default subtitle exchange workflow.

Good for:
- editorial handoff
- subtitle review
- player import where SRT is accepted
- Subtitle Editor follow-up work

Key options:
- line length / line count shaping
- max duration
- line endings
- speaker labels
- QC controls

## WebVTT (.vtt)
Pick VTT for web/native-player subtitle workflows.

Good for:
- browser/player subtitle workflows
- web delivery systems that expect WebVTT
- subtitle-editor follow-up work

Key options:
- subtitle shaping
- speaker labels
- style metadata
- QC controls

## Scenarist CC (.scc)
Pick SCC only when the downstream workflow explicitly requires it.

Good for:
- CEA-608 style caption deliveries
- broadcast or legacy caption pipelines that specifically request SCC

Not ideal for:
- generic subtitle review
- casual localization handoff
- users who do not know what SCC is but clicked it because it looked professional

Key warnings:
- SCC is **29.97 fps sensitive**.
- SCC can auto-force timecode/FPS prerequisites.
- SCC preview is illustrative, not final compliance proof.

## MacCaption (.mcc)
Pick MCC only when the downstream workflow explicitly requires it.

Good for:
- advanced caption deliverables
- workflows needing 708-oriented controls and/or optional 608 compatibility behavior

Key warnings:
- MCC is more specialized than SRT/VTT.
- MCC settings are more delivery-spec dependent than general subtitle formats.

## Scripted (CSV)
Pick Scripted CSV when the user wants a syncable text sheet rather than subtitle files.

Good for:
- editorial prep
- script or paper-edit workflows
- timecode/speaker/text handoff to other systems

## Burn-in
Pick Burn-in when the user wants text rendered into the video itself.

Good for:
- review copies
- client check versions
- workflows where the text must be visible without loading a subtitle sidecar

Key warning:
- Burn-in is a rendered video output, not a subtitle text file.
- The panel does not provide a text preview for burn-in.

## Practical selection guide
Choose like this:
- **Need a readable transcript?** -> TXT
- **Need the common subtitle file?** -> SRT
- **Need web-player subtitle output?** -> VTT
- **Need broadcast-style caption delivery?** -> SCC or MCC, only if the spec says so
- **Need an editorial sync sheet?** -> Scripted CSV
- **Need text baked into picture?** -> Burn-in

## Related pages
- /panels/transcribe/
- /troubleshooting/transcribe/
- /workflows/export-broadcast-captions-scc-mcc/
- /workflows/send-output-to-subtitle-editor/
