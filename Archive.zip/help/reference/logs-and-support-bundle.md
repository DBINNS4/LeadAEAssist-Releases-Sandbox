# Logs and support bundle

## Purpose
This page explains:
- where the app stores its raw logs
- which logs users can export from the UI
- which extra files support should ask for

## Canonical app data root
The app uses a stable userData root named `LeadAEAssist`.

Typical locations:

### macOS
`~/Library/Application Support/LeadAEAssist/`

### Windows
`%APPDATA%\LeadAEAssist\`

Inside that root, the most important support folders are:
- `logs/`
- `config/`
- `config/presets/`

## Raw log library structure
The app log library lives under:

`LeadAEAssist/logs/`

Typical panel subfolders include:
- `logs/ingest/`
- `logs/clone/`
- `logs/transcode/`
- `logs/transcribe/`
- `logs/adobe-utilities/`
- `logs/project-organizer/`
- `logs/speed-test/`

The Log Viewer reads from the app log library. It does **not** search the user's destination folders for copied log files.

## What the raw log files mean

### Structured per-job log
File pattern:
- `<timestamp>--<jobId>.jsonl`

Meaning:
- one JSON object per line
- best for parsing, detailed analysis, or support tooling
- contains panel, job id, stage, message, timestamp, and metadata

Use this when:
- support or detailed analysis needs machine-readable detail
- the human log looks too summarized

### Human-readable per-job report
File pattern:
- `<timestamp>--<jobId>.txt`

Meaning:
- a single text report for one job
- includes header metadata, outcome, timestamps, and readable log content

Use this when:
- the support team needs a job report a human can read quickly
- the user is emailing a log manually
- the app finished but the on-screen log is no longer visible

### Watch session log
File pattern:
- `<timestamp>.txt` inside the panel's log folder

Meaning:
- watch lifecycle messages for that panel
- start/stop activity
- watch-triggered job highlights
- final archive written when the watch session ends

Use this when:
- the user says Watch Mode skipped work
- files were not picked up consistently
- Save Log in Watch Mode did not export where expected

## Destination-side log files
Some workflows also write copies of logs into the user-chosen output folders.

### Manual Ingest
Possible files in the destination:
- `IngestLog_<timestamp>.txt`
- `IngestFailures_<timestamp>.txt`
- `RetryList_<timestamp>.txt`

If backup is enabled:
- `IngestLog_<timestamp>.txt` is also copied to the backup path

### Clone Mode launched from Ingest
Possible file in the destination:
- `clone-log-<timestamp>.txt`

### Manual Transcode
Possible file in the chosen output folder when **Save Log** is on:
- `TranscodeLog_<timestamp>.txt`

Possible sidecar file in preserve-metadata compatibility cases:
- `<output-file>_metadata.json`

That metadata sidecar is expected for some outputs such as:
- MP4/M4V when non-A/V source metadata cannot be embedded cleanly
- MKV/WebM compatibility-preserve cases
- image sequence outputs when Preserve Metadata is enabled

### Manual Transcribe
Manual Transcribe currently writes its raw per-job logs into the app log library, typically under:
- `LeadAEAssist/logs/transcribe/`

As currently implemented, Manual Transcribe does **not** expose a destination-side **Save Log** control like Manual Transcode.

That means support should usually start in the raw log library, not the output folder.

### Manual Adobe Automate
Adobe Automate always writes its raw per-job logs into:
- `LeadAEAssist/logs/adobe-utilities/`

When **Save Log** is on, Adobe Automate also attempts a destination-side text log copy named:
- `AdobeAutomateLog_<timestamp>.txt`

Where that copied log lands:
- usually the main destination
- in some no-proxy backup-only cases, the backup path can be used instead

Important Adobe nuance:
- raw logs are the reliable truth
- destination-side copies are convenience exports
- proxy jobs can also make users look in the wrong folder because the effective proxy folder may be `Destination/Proxies` or `SelectedProxyBase/Proxies`


### Project Organizer
Project Organizer writes its raw per-job logs into:
- `LeadAEAssist/logs/project-organizer/`

Typical artifacts include:
- structured per-job log files (`.jsonl`)
- human-readable per-job TXT job reports

Important Project Organizer nuances:
- there is **no panel-side Save Log** button
- there is **no destination-side organizer log copy** written into the generated folder tree
- if a run used **Save Config** or a panel preset, the JSON config/preset file can be just as important as the logs because it captures the exact folder tree, numbering state, output path, and attached asset mappings
- if a config/preset was loaded and paths disappeared, support should collect both the raw logs and the JSON file that was loaded

Support guidance:
- start with `logs/project-organizer/`
- then collect the organizer JSON config/preset file if one was involved
- then inspect the generated output folder only after the raw logs are secured


### Preferences
Preferences is different from the queue-driven production panels.

As currently implemented:
- there is **no dedicated raw `logs/preferences/` folder**
- there is **no Save Log button**
- there is **no destination-side TXT export**

That means the most useful support artifacts are usually **configuration files and screenshots**, not a panel log.

Start with:
- `LeadAEAssist/config/state.json`
- `LeadAEAssist/config/state.json.bak` if present
- screenshot of the Preferences panel, including any red save banner
- app version

Important storage note:
- the actual AI API key is **not** stored in plain `state.json`
- it is stored separately from normal files and is intentionally not documented as a file path
- do **not** ask the user to paste the secret value
- do **not** request sensitive storage files by default unless support explicitly asks for them

Preferences-specific support clues:
- invalid webhook URLs can block the save path before other writes happen
- crash-reporting changes can become **session-only** if runtime apply succeeds but persistence fails
- API-key reset/delete can fail **after** the ordinary preferences reset succeeds
- CEP install problems are usually diagnosed through the status/error text plus the user CEP extensions folder, not through a panel log export

### Account and Licensing
Account and Licensing is another support-heavy panel with **no dedicated raw `logs/account/` folder** and **no Save Log button**.

Start with:
- full screenshot of the panel
- **Copy version info** output
- exact small status-line text from Install / Sync / Portal / Billing actions
- `LeadAEAssist/config/state.json`
- confirmation of whether another license file may still be present on the machine

Important Account/Licensing nuances:
- **Clear License** only removes the license currently stored by the app; another license file on the machine can make it look ineffective
- browser checkout still needs **Sync Subscription** afterward to install entitlement
- **Manage Subscription** works best when an active subscription is already installed in the app
- **Offline Mode** blocks checkout, portal, and sync flows
- do **not** request raw license secrets or sensitive storage files by default

Useful support habit:
- collect the on-screen status text before the user closes the panel or changes state again


### Subtitle Editor
Subtitle Editor has **no dedicated raw `logs/subtitle-editor/` folder** and **no Save Log** button.

Start with:
- the source subtitle file
- any exported subtitle/caption output file
- any generated `*.report.txt` sidecar
- screenshot of the status line and QC panel
- raw Transcribe logs from `LeadAEAssist/logs/transcribe/`

Important Subtitle Editor nuances:
- **Export Corrections** writes one corrected file that matches the opened correction format (`.srt`, `.vtt`, or `.json`), not a sibling trio
- corrected **SRT** and **VTT** exports also create `.qc.json` and `.qc.txt` sidecars
- **Export SCC** and **Export MCC** can soft-fail or hard-fail via QC gating while still creating a report file
- **Burn-in** depends on an attached media path and a corrected `.srt`; if no SRT is known yet, Burn-in may prompt for one first
- preview proxies can be created under `LeadAEAssist/temp/previews/` when the browser cannot decode the original media
- the most useful support artifacts are often the report file plus the raw Transcribe log, not a mythical subtitle-editor log that does not exist

Support guidance:
- collect the report file first if SCC/MCC export was involved
- collect the corrected SRT/VTT export plus any `.qc.json` / `.qc.txt` sidecars when a correction export is involved
- collect the actual source subtitle file when mode-routing or import issues are suspected
- collect preview-cache clues only when the problem is about playback or preview generation


### NLE Utilities
NLE Utilities is different from the queue-driven production panels.

As currently documented from the app behavior:
- there is **no panel-side Save Log button**
- there is **no destination-side log export path**
- the primary immediate record is the text inside the **Avid summary** or **Adobe summary** box

Support guidance:
- capture the summary text or a screenshot **before** the user resets the panel or changes folders
- collect **Copy version info**
- use **Log Viewer** if matching NLE-related lines are present there, but do not promise the user a dedicated NLE export file

Important:
- the panel can create **Avid backup folders** during site/user reset
- the panel can briefly create **REBUILD_TRIGGER_...mxf** files during database rebuild
- Adobe cleanup deletes files in place and does not quarantine them elsewhere


### Speed Test
Speed Test writes its raw per-job logs into:
- `LeadAEAssist/logs/speed-test/`

That logging is automatic for both:
- **Network Test** runs
- **Drive Test** runs

Typical artifacts include:
- structured per-job log files (`.jsonl`)
- human-readable per-job TXT reports

Important Speed Test nuances:
- there is **no panel-side Save Log** button
- there is **no destination-side export file** written into the tested drive path
- the tested drive path may briefly contain a hidden **`.lead-speedtest/`** folder, but that is a temporary benchmark workspace, not the canonical long-term log archive
- if support needs a durable log, start with `logs/speed-test/` or use **Log Viewer**

### Watch Mode
Watch logging is panel-specific enough to be annoying.

#### Ingest Watch Mode
If **Save Log** is on and the user presses **Stop Watching**, the archived watch session log is exported as:
- `WatchLog_<archived-log-name>.txt`

That export is written to:
- destination
- backup, if backup is enabled

#### Transcode Watch Mode
The watch session log is still archived under the app log library, typically in:
- `LeadAEAssist/logs/transcode/`

As currently implemented, Transcode Watch Mode does **not** appear to mirror Ingest's destination-side `WatchLog_...` export into the chosen output folder.

#### Transcribe Watch Mode
The watch session log is archived under the app log library, typically in:
- `LeadAEAssist/logs/transcribe/`

As currently implemented, Transcribe Watch Mode also does **not** expose an Ingest-style destination-side `WatchLog_...` export path.

Important:
- Watch Mode Save Log is session-oriented behavior tied to watcher shutdown/finalization, not an immediate "write log now" button.
- Stopping the watcher can wait for already-queued watch-triggered jobs to finish or cancel before the session log archives.

## Using the Log Viewer
The app already has a manual diagnostics flow built in.

### Export filtered logs
1. Open **Log Viewer**.
2. Set the date filter.
3. Set the tool filter if needed.
4. Use **Errors only** if the log is noisy.
5. Choose an export folder.
6. Choose export format:
   - `txt` for support email
   - `json` for detailed analysis
   - `csv` for spreadsheet review or quick sorting
7. Click **Export**.

The export uses the currently filtered set, not the entire raw archive.

### Single-job TXT export behavior
When the filtered set resolves to **a single job** and the export format is **TXT**, the viewer writes a richer single-job report rather than a plain raw line dump.

Typical filename:
- `job-report_<panel>_<YYYYMMDD_HHMMSS>_<jobId>.txt`

That job report can include:
- panel
- job id
- outcome
- start / end / duration
- warning and error counts
- section headers such as Inputs, Outputs, Settings, and Stats
- stage-grouped log lines

If the user expected a plain raw log dump instead:
- widen the filter so multiple job ids are included, or
- export `json` / `csv`

### Open the raw log folder
In **Log Viewer**, use **Open Log Folder** when support needs the raw files from the app's log library.

## Important viewer limits support should understand
The Log Viewer is useful, but it is not magic. It has guardrails.

### On-screen render cap
The viewer renders only the newest **500** filtered results on screen by default.

Important:
- this is a **display** cap
- export still uses the full filtered set that was loaded into memory

### In-memory retention cap
The viewer keeps an in-memory retention window, defaulting to **5000** entries.

When that cap is reached, the oldest in-memory entries are discarded first.

### Per-file raw read caps
When the raw reader opens a log file, it only keeps:
- the last **8 MB** of that file
- the last **10,000 lines** of that file

If a file is truncated by either cap, the viewer adds a warning entry so the user is not lied to by omission.

This matters because:
- a massive long-running log may appear incomplete in the viewer
- export cannot recover lines that were never loaded
- for gigantic logs, you may still need the raw file itself

### Malformed lines
Damaged structured-log lines are skipped during parsing.
That means a damaged structured log can look shorter than the raw file on disk.

## Version info support should always collect
Open **Account and Licensing** and use **Copy version info**.

That version block is the right thing to request because it includes:
- app name and version
- app version and environment state
- runtime versions
- platform and architecture
- key dependency versions

When support only gets a screenshot and no version block, they are basically arguing with fog.

## Manual support bundle: current best practice
There is no single-click support bundle yet. Until that exists, collect this folder manually:

`SupportBundle_<date>_<user-or-ticket>/`

Recommended contents:
- `version-info.txt` from **Account and Licensing**
- `log-viewer-export.txt` or `.json` or `.csv`
- `raw-logs/` copied from the app's `logs/` folder
- `destination-logs/` containing any destination-side files such as:
  - `IngestLog_<timestamp>.txt`
  - `IngestFailures_<timestamp>.txt`
  - `RetryList_<timestamp>.txt`
  - `WatchLog_<...>.txt`
  - `TranscodeLog_<timestamp>.txt`
  - `AdobeAutomateLog_<timestamp>.txt`
  - `<output-file>_metadata.json` when preserve-metadata sidecars matter
- `screenshots/`
- `repro-steps.txt`

For Transcribe-specific cases, also collect:
- the relevant files from `LeadAEAssist/logs/transcribe/`
- the source media filename list
- the selected engine and output format
- whether translation was enabled
- whether **Edit Subtitle after export** was enabled

For Speed Test-specific cases, also collect:
- the relevant files from `LeadAEAssist/logs/speed-test/`
- whether the issue was **Network Test** or **Drive Test**
- for network issues:
  - whether Offline Mode was enabled
  - whether the Summary mentioned browser dependency download, verification, install, or checksum failures
  - whether VPN, captive portal, firewall, proxy, or DNS filtering was involved
- for drive issues:
  - the exact tested path or paths
  - mode (**Sequential** or **Random**)
  - test size
  - whether a hidden `.lead-speedtest` folder or stale lock file was present in the tested path

For Adobe Automate-specific cases, also collect:
- the relevant files from `LeadAEAssist/logs/adobe-utilities/`
- whether the job used:
  - Import into Premiere
  - Create Premiere Bins
  - Generate Proxies
- whether the proxy mode was:
  - Match Source (FFMPEG)
  - a real `.epr` preset
- whether **Disable FFmpeg fallback** was enabled
- the destination, backup, and proxy-destination relationship
- a screenshot of **Preferences -> Adobe Premiere Panel (CEP)** status if connection was involved

Suggested `repro-steps.txt` contents:
- panel used
- mode used
- source type: folder or file list
- destination and backup relationship
- verification method
- whether Save Log was on
- exact time the issue occurred
- exact error text

## Do not include these in a support bundle
A manual support bundle should stay useful without scooping up private material.

Exclude these by default:
- unrelated project media
- unrelated customer deliverables
- cloud credentials
- API keys
- stored secrets
- huge cache/temp folders unless support explicitly asks for them
- entire home directories because that way madness lies

## Related pages
- /panels/log-viewer/
- /reference/file-locations/
- /troubleshooting/log-viewer/
- /workflows/export-logs-from-log-viewer/
