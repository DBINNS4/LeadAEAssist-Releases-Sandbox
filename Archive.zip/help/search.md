# Search Help

Use the help search to find answers by feature, symptom, or file type.

## Search ideas
Try searches based on:
- panel name: `ingest`, `transcode`, `project organizer`
- symptom: `won't start`, `watch mode`, `permission denied`
- output type: `srt`, `vtt`, `scc`, `mcc`
- account task: `logs`, `version info`, `billing`, `license`

## Browse by section
If search does not surface what you need right away, start here:
- [Panel Guides](/panels/)
- [Troubleshooting](/troubleshooting/)
- [Workflows](/workflows/)
- [Reference](/reference/)

## Related
- [Lead AE Assist Help](/)
- [Troubleshooting](/troubleshooting/)
- [Logs and support bundle](/reference/logs-and-support-bundle/)
