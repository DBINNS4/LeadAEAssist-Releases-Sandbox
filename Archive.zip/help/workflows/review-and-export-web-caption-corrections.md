# Workflow - Review and export web caption corrections

## Goal
Use Subtitle Editor to review **SRT** or **VTT** content, fix timing or text, and export corrected subtitle files.

## What you need
- an opened **SRT** or **VTT** document in Subtitle Editor
- optional preview media

## Steps
1. Open the SRT or VTT file in Subtitle Editor.
2. Confirm the editor is in **web-caption mode**.
3. Review the cue list, preview, and QC panel.
4. Fix the text and timing as needed.
5. Click **Export Corrections**.
6. Choose the save location and filename in the format-specific dialog.
7. Confirm the corrected subtitle file appears in the target folder.

## Important export behavior
Export Corrections keeps the opened web-caption format:
- opened `.srt` -> corrected `.srt`
- opened `.vtt` -> corrected `.vtt`
- SRT/VTT exports also write `.qc.json` and `.qc.txt` sidecars

It does **not** fan out into sibling SRT/VTT/JSON files from one basename anymore.

## Best use case
This is the safest correction path when the user needs subtitle text deliverables rather than broadcaster-grade SCC/MCC packaging.

## Common failure points
- the user expected cross-format or multi-file output
- the wrong source format was opened
- the user attached no media and assumed preview playback was required for export

## Related pages
- /panels/subtitle-editor/
- /troubleshooting/subtitle-editor/
- /reference/file-locations/
