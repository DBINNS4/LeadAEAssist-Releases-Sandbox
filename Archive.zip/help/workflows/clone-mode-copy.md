# Workflow - Clone Mode copy

## Goal
Copy only selected folders from a source tree while preserving the folder structure at the destination.

## What you need
- one source folder
- destination folder
- optional backup folder
- time for the folder tree to load if the source is large

## Use Clone Mode when
- the user does **not** want the entire source copied
- the source is better treated as a folder tree than a flat file list
- preserving directory structure matters

## Do not use Clone Mode when
- the source is a file list
- the user wants Watch Mode
- the user needs Auto Create Folder
- the user is expecting a plain one-click card ingest

## Steps
1. Open **Ingest**.
2. Click **Select Source** and choose one source folder.
3. Turn on **Clone Mode**.
4. Wait for the folder tree to appear.
5. Use **Folder Filters** if you need to narrow the tree by name.
6. Select the folders to include.
7. Optionally turn on **Show File Count** if you need counts or a better size estimate.
8. Set the destination and optional backup path.
9. Choose verification and duplicate handling.
10. Click **Start**.

## Verify success
Check these:
- only the selected folders were copied
- structure is preserved at the destination
- the Summary reflects a clone job
- if Save Log was enabled, destination contains `clone-log-<timestamp>.txt`
- raw job logs exist under the app's `logs/clone/` folder

## Common failure points
- the source was not a folder
- Watch Mode was still active
- the user enabled Clone Mode before choosing a source folder
- the source tree could not be read
- no folders were selected before Start

## Related pages
- /panels/ingest/
- /troubleshooting/ingest/
- /reference/logs-and-support-bundle/
