# Workflow - Create burn-in from Subtitle Editor

## Goal
Create a reviewable burned-in movie from the current subtitle corrections and attached media.

## What you need
- a subtitle document open in Subtitle Editor
- attached media
- a place to save a corrected **SRT** if the editor does not already know one

## Steps
1. Open the subtitle document in Subtitle Editor.
2. Attach the media file with **Open Media…** if the editor does not already have it.
3. Click **Burn-in**.
4. If the editor prompts to export corrections first, save the corrected **SRT**.
5. Wait for FFmpeg processing to finish.
6. Confirm the burned-in output appears in the export directory.

## Expected result
The burn-in output is written as:
- `<mediaBase>.burnin.mov`

## Important behavior notes
- Burn-in runs from a corrected **SRT** path.
- If the editor does not already have one, Burn-in first tries to create it and then uses that SRT for FFmpeg.
- This can happen even while the user is editing broadcast content. The burn-in path is SRT-backed under the hood.
- A failed or cancelled SRT export blocks burn-in.
- Burn-in is a review/output action, not a subtitle-save substitute.

## Common failure points
- no media attached
- corrected SRT export was cancelled or failed
- output directory not writable
- FFmpeg processing failure

## Related pages
- /panels/subtitle-editor/
- /troubleshooting/subtitle-editor/
- /reference/file-locations/
