# Workflow - Embed captions in MXF

## Goal
Create an MXF that carries embedded captions from an MCC or SCC sidecar.

## What you need
- exactly one source video file
- one caption sidecar file in `.mcc` or `.scc`
- one output folder
- Audio Only off

## Rules this workflow enforces
Once a caption sidecar is attached:
- Match Source is forced on
- container is forced to **MXF**
- output-format/container controls are locked
- only one input file is allowed
- SCC is converted to MCC before embedding

## Steps
1. Open **Transcode**.
2. Leave **Watch Mode** off.
3. Click **Select Source** and choose one video file.
4. Under **Audio Settings**, click **Attach Captions (MCC/SCC)**.
5. Choose an MCC or SCC file.
6. Confirm the panel locked into MXF + Match Source behavior.
7. Click **Select Output** and choose the output folder.
8. Choose verification and Save Log as needed.
9. Click **Start**.

## Verify success
Check these:
- the output is an MXF
- the log reports embedded caption success
- the verification path confirms a SMPTE-436M ANC data stream in the MXF
- raw logs exist under `LeadAEAssist/logs/transcode/`

## Common failure points
- more than one input file selected
- audio-only export still enabled
- caption file was not MCC or SCC
- output MXF failed the ANC-stream verification check

## Related pages
- /panels/transcode/
- /troubleshooting/transcode/
- /reference/logs-and-support-bundle/
