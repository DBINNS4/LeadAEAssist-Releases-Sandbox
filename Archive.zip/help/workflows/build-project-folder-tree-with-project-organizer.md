# Build a folder tree with Project Organizer

## Use this workflow when
Use this when the user wants to create a standard project folder tree before media starts moving around.

## Steps
1. Open **Project Organizer**.
2. Decide whether this run should create a named root folder.
   - If yes, enter a **Project Name**.
   - If no, leave **Project Name** blank and understand that folders will be created directly in the chosen output folder.
3. Review the built-in root folders.
4. Add any extra root folders with **Custom Folder** + **Add Custom Folder**.
5. Click a parent folder and use **Add Subfolder** for any nested structure you need.
6. Drag the root folders into the desired order.
7. Turn **Prepend Numbering** on or off.
8. Click **Select Output Location** and choose the destination folder.
9. Confirm the Summary box reflects the intended structure.
10. Click **Generate**.
11. Wait for completion.
12. Review the Summary result and confirm the created folders on disk.

## Recommended checks after the run
- confirm the root folder landed where expected
- confirm numbering order matches the visible organizer order
- confirm no warnings/errors appeared in the Summary box

## Common gotcha
If the run fails because the root already exists and is not empty, either:
- choose a new Project Name, or
- choose a new Output Path

Do not bulldoze an existing live project folder unless that is truly intentional.
