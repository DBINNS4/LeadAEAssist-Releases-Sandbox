# Workflow - Install and connect the Premiere CEP panel

## Goal
Make the Lead AE Assist Premiere CEP panel available so Adobe Automate can import, create bins, and attach proxies.

## Steps
1. Open **Preferences**.
2. Scroll to **Adobe Premiere Panel (CEP)**.
3. Read the current status line.
4. Click **Install/Repair Panel**.
5. If needed, click **Open CEP Folder** to verify the panel files were written to the Adobe CEP extensions directory.
6. Open **Premiere Pro**.
7. Open or create a Premiere project.
8. Open the Lead AE Assist CEP panel inside Premiere.
9. Return to **Adobe Automate** in the desktop app.
10. Click the reconnect icon in the Adobe Automate toolbar.

## Verify success
A healthy setup should give you:
- a non-error CEP status in **Preferences**
- an open Lead AE Assist panel inside Premiere
- Adobe Automate no longer blocking on "Premiere CEP panel must be connected"

## If Install/Repair does not help
Check these next:
- fully quit and relaunch Premiere
- make sure you are not running duplicate copies of the desktop app
- reopen the Premiere project before reconnecting
- confirm the panel exists in the CEP extension folder shown in **File locations**

## Related pages
- /panels/adobe-automate/
- /troubleshooting/adobe-automate/
- /reference/file-locations/
