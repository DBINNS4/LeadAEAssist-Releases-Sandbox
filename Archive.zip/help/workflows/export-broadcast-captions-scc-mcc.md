# Workflow - Export broadcast captions (SCC / MCC)

## Goal
Create a broadcast-style caption deliverable from source media using the Transcribe panel.

## What you need
- source media with known/acceptable timebase
- one writable output folder
- a real downstream requirement for **SCC** or **MCC**
- patience for stricter timing/QC rules than consumer subtitle formats

## Use this workflow when
- the client or system explicitly requests SCC or MCC
- the workflow needs caption timing, placement, service, or broadcast-style QC controls

## Do not use this workflow when
- the downstream system accepts SRT or VTT
- the operator just wants a readable subtitle file
- the source timebase is unknown and nobody has checked it

## SCC path
Use SCC when the workflow specifically calls for **Scenarist CC / CEA-608** style output.

### Extra SCC warnings
- SCC is tied to a **29.97 fps** timebase.
- Selecting SCC can auto-adjust timecode/FPS prerequisites.
- The panel will warn before queueing if the source FPS or override looks incompatible.

## MCC path
Use MCC when the workflow specifically calls for **MacCaption / 708-oriented** output or 608 compatibility behavior carried inside the MCC authoring path.

### MCC focus areas
- service number
- language
- window placement
- optional 608 compatibility
- QC and shaping controls

## Steps
1. Open **Transcribe**.
2. Leave Watch Mode off unless this is a known watch-caption workflow.
3. Select the source files.
4. Confirm the probed FPS values.
5. Choose **SCC** or **MCC** as the output format.
6. Set Start TC, FPS override, and any service/placement/QC controls required by the workflow.
7. Choose the output folder.
8. Click **Start**.
9. Read any SCC preflight warning instead of treating it like decorative wallpaper.

## Verify success
Check these:
- the selected caption format actually wrote to the output folder
- the output timing/placement looks sane in downstream review
- raw logs exist under `LeadAEAssist/logs/transcribe/`

## Common failure points
- using SCC on non-29.97 media
- not understanding the difference between subtitle formatting and caption formatting
- blindly accepting defaults when the delivery spec requires service/placement/QC changes
- assuming the preview alone proves compliance

## Related pages
- /panels/transcribe/
- /troubleshooting/transcribe/
- /reference/transcribe-output-formats/
