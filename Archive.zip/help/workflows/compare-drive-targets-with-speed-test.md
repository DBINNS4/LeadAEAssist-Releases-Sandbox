# Workflow - Compare drive targets with Speed Test

## When to use this
Use this workflow when the user wants to compare:
- local SSD vs external SSD
- one NAS/share path vs another
- a proxy destination vs a transcode destination
- a cache/project/database path using **Random** mode

## Recommended method
The trick is simple: compare the same thing to the same thing.
If the mode or test size changes between runs, the comparison stops being useful.

## Steps
1. Open **Speed Test**.
2. Select up to three target folders using **Select Drive 1**, **2**, and **3**.
3. Pick a **Test Size**.
   - Start with **1 GiB** for a serious first comparison.
   - Use **2 GiB** when you want more stable sustained-throughput numbers.
4. Pick a **Mode**.
   - Use **Sequential** for copy/export/proxy-style questions.
   - Use **Random** for cache/project/database-style questions.
5. Click **Test Selected Drives**.
6. Let the batch finish.
7. Record the per-drive Write and Read results.
8. Re-run in the other mode if you need both sustained and small-I/O comparisons.

## How to choose the right folder
Benchmark the folder path that the real workflow will actually touch.
Examples:
- For shared storage, choose the mounted share path the NLE uses.
- For transcode comparisons, choose the real output destination path.
- For cache comparisons, choose the real cache/project/database path.

Do not benchmark one sibling folder and assume all sibling paths behave identically.
Storage systems love exceptions.

## Reading the comparison
### Sequential mode
Favor the target with better sustained Read/Write when the question is about:
- copying camera cards
- transcode output
- proxy generation
- large export targets

### Random mode
Favor the target with better small-I/O behavior when the question is about:
- project or cache responsiveness
- metadata-heavy work
- Avid database or similar small-file churn

Important:
- the current UI reports **MiB/s**, not IOPS
- use it as a comparative test, not a literal database benchmark

## Repeatability advice
- keep the same mode and size across targets
- stop other heavy I/O while testing
- retry once if one result is an obvious outlier
- move up to **2 GiB** if cache effects are making the comparison noisy

## What to save for support
- the exact paths tested
- test size
- mode
- screenshot of the Summary box
- raw logs from `LeadAEAssist/logs/speed-test/` if the comparison is being used to explain a workflow problem
