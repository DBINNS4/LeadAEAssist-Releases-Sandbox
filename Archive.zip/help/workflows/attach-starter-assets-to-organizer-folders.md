# Attach starter assets to organizer folders

## Use this workflow when
Use this when the user wants new projects to start with standard files already copied into the generated folders.

Examples:
- project templates
- cue sheets
- licensing PDFs
- notes documents
- graphics packages
- boilerplate spreadsheets

## Steps
1. Open **Project Organizer**.
2. Build or load the folder structure first.
3. For each destination folder row, do one of these:
   - click the **+** button and select files, or
   - drag files directly onto that folder row
4. Confirm the Summary box now shows attachment lines for the relevant folders.
5. Set the Output Path and optional Project Name.
6. Click **Generate**.
7. After completion, open the created folders and verify the files were copied.

## Notes
- The app expects attached entries to resolve to real readable files.
- If the same source file is attached twice to the same folder, the duplicate is skipped.
- If destination filename collisions happen, the app adds suffixes like `_1` instead of overwriting.
- If a loaded preset/config strips attached file paths, reattach the files and save a fresh config.
