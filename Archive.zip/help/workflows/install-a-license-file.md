# Workflow - Install a license file

## Goal
Install a locally provided license file into the app's secure store.

## Steps
1. Open **Account and Licensing** from the titlebar settings button.
2. Click **Install License…**.
3. Select the provided license file.
4. Wait for the panel to refresh.
5. Re-check:
   - **Status**
   - **Plan**
   - **Expires**
   - **Reason**

## Verify success
A healthy install usually gives you:
- a refreshed entitlement state
- **Active** or **Trial** status when the license is valid
- restored feature tabs if the license unlocks them

## Important note
The app expects a valid license for this product.
A random JSON file, stale export, or unrelated file will not install cleanly.

If install fails with the generic message, do not keep guessing. Move to `/troubleshooting/account-and-licensing/`.
