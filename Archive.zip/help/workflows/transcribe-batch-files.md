# Workflow - Batch transcribe files

## Goal
Transcribe one or more selected media files into one chosen subtitle/transcript output format.

## What you need
- one or more source files
- one writable output folder
- one selected transcription engine
- one selected output format

## Use this workflow when
- the source files are already known
- the user wants a one-time transcription batch
- the deliverable is one output format per run

## Do not use this workflow when
- the input files will arrive over time
- the job needs a watch folder
- the output folder is not known yet

## Steps
1. Open **Transcribe**.
2. Leave **Watch Mode** off.
3. Click **Select Files** and choose the source media.
4. Confirm the file-info grid looks sane.
5. Choose the engine, language, and accuracy.
6. Choose one output format.
7. Set the format-specific options for that deliverable.
8. Set **Translate** only if the job really needs translated text output.
9. Choose the output folder.
10. Decide whether **Edit Subtitle after export** should be enabled.
11. Click **Start**.
12. Confirm the start dialog.

## Verify success
Check these:
- the queue accepts the job
- the panel log shows progress
- the output folder receives the expected deliverable
- raw logs exist under `LeadAEAssist/logs/transcribe/`

## Common failure points
- missing output folder
- assuming the output picker is multi-select
- using WhisperAPI without a configured API key
- choosing SCC for non-29.97 media
- expecting Burn-in to behave like a text file export

## Related pages
- /panels/transcribe/
- /troubleshooting/transcribe/
- /reference/transcribe-output-formats/
