# Workflow - Send output to Subtitle Editor

## Goal
Automatically open the latest subtitle/caption output in **Subtitle Editor** after the Transcribe job finishes.

## What you need
- a Transcribe job that writes an editor-friendly subtitle/caption format
- **Edit Subtitle after export** enabled before the run
- a successful export, or at least a partial subtitle/caption file that was written

## Best-fit formats
This workflow is most natural with:
- **SRT**
- **VTT**
- **SCC**
- **MCC**

## Steps
1. Open **Transcribe**.
2. Turn on **Edit Subtitle after export**.
3. Select the source files.
4. Choose SRT, VTT, SCC, or MCC as the output format.
5. Set the output folder.
6. Run the job.
7. After completion, confirm that Subtitle Editor opens the latest exported subtitle/caption file.

## Important behavior note
The handoff logic prefers the output file that matches the selected Transcribe deliverable.
It also tries to carry the relevant format/QC settings into the Subtitle Editor context.

## Failure behavior note
Even after a failed Transcribe job, the app can still try to open the latest subtitle/caption output if a file was written.
That is useful for fixing QC rather than throwing away the run and pretending the work never happened.

## Common failure points
- the checkbox was off before the job started
- the chosen format was TXT, Scripted CSV, or Burn-in
- the job failed before any usable subtitle/caption file was written
- the output folder did not contain the file the handoff logic expected

## Related pages
- /panels/transcribe/
- /troubleshooting/transcribe/
