# Workflow - Adobe Automate copy, import, bins, and proxies

## Goal
Copy media to a destination, verify it, import it into Premiere, create bins, generate proxies, and attach those proxies back to the imported clips.

## What you need
- one or more source files
- a writable destination folder
- Premiere Pro open with a project loaded
- the Lead AE Assist Premiere CEP panel installed, open, and connected
- optional backup folder
- either:
  - **Match Source (FFMPEG)**, or
  - a working Adobe Media Encoder `.epr` preset

## Steps
1. Open **Adobe Automate**.
2. Click **Select Source** and choose the media files.
3. Click **Select Destination** and choose the main copy location.
4. Leave **Import into Premiere** on.
5. Leave **Create Premiere Bins** on.
6. Turn **Generate Proxies** on.
7. In **Proxy Settings**, choose one of these:
   - **Match Source (FFMPEG)** for the least-fragile setup
   - a real `.epr` preset if the workflow specifically requires AME
8. Optionally set a proxy base destination. If left blank, proxies go under `Destination/Proxies`.
9. Build the bin structure and drag files into bins if needed.
10. Choose verification and Save Log settings.
11. Click **Automate**.

## Verify success
Check all four layers:
- copied media exists in the destination
- the Premiere project contains the imported clips
- the requested bins exist in Premiere
- proxy files exist in the effective proxy folder and appear attached in Premiere

Also collect raw logs from:
- `LeadAEAssist/logs/adobe-utilities/`

## Common failure points
- Premiere not open with a project loaded
- CEP panel not installed or not connected
- duplicate basenames in the source selection
- invalid or missing `.epr` file
- AME stalled while FFmpeg fallback was disabled
- user checked the selected proxy base and forgot the app created a `Proxies` subfolder

## Related pages
- /panels/adobe-automate/
- /troubleshooting/adobe-automate/
- /workflows/install-and-connect-premiere-cep-panel/
