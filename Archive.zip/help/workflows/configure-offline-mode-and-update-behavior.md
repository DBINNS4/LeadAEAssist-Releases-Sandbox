# Workflow - Configure Offline Mode and update behavior

## Goal
Put the app into a predictable network/update state so support can tell whether a failure is caused by Offline Mode or by something else.

## Steps
1. Open **Preferences**.
2. In **General**, decide whether **Enable Offline Mode** should be on or off.
3. If the user needs:
   - update checks
   - entitlement sync
   - billing portal access
   - remote webhook delivery
   - Whisper API transcription

   then leave **Offline Mode off**.
4. Open **Advanced**.
5. In **Updates**, set:
   - **Check for updates on launch**
   - **Automatically download updates**
6. Read the **update status** line.
7. If needed, click **Check for Updates**.

## Verify success
A healthy result should look like this:
- Offline Mode reflects the intended setting
- the update status line matches reality
- no “disabled by Offline Mode” status appears when the user expects online behavior

## Important note
Offline Mode still allows `localhost` workflows.
It blocks non-local network access, not same-machine automation.

## Related pages
- /panels/preferences/
- /troubleshooting/preferences/
- /reference/file-locations/
