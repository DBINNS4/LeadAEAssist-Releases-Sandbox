# Workflow - Subscribe and sync subscription

## Goal
Complete checkout in the browser and then install the resulting entitlement into the desktop app.

## Steps
1. Open **Preferences** and confirm **Offline Mode** is off.
2. Open **Account and Licensing**.
3. In the **Billing** section, choose:
   - `Monthly`, or
   - `Yearly`
4. Click **Subscribe**.
5. Complete the checkout in the browser.
6. Return to the app.
7. Click **Sync Subscription**.
8. Wait for the status line to settle.

## Verify success
A healthy result usually gives you:
- **Status: Active** or **Trial**
- a populated **Plan**
- a future **Expires** value when applicable
- previously hidden licensed tabs becoming available again

## Important note
Checkout is not the final unlock step.
The desktop app still needs a valid subscription update, and **Sync Subscription** is the normal way to fetch it.

If checkout just completed, syncing again within the next few minutes can still be reasonable. The app already polls longer after a recent checkout.
