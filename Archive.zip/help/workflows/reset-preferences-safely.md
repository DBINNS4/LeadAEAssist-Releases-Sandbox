# Workflow - Reset Preferences safely

## Goal
Return the Preferences panel to its default state without guessing which pieces were actually reset.

## Steps
1. Open **Preferences**.
2. Review any values the user may want to preserve before reset:
   - webhook URL
   - update settings
   - maintenance flags
3. Click **Reset Preferences**.
4. Confirm the warning dialog.
5. Wait for the panel to repopulate.

## Verify success
A healthy reset should give you:
- no red save banner
- a success toast
- cleared webhook settings
- a fresh placeholder state in the API-key field

## Important note
Reset is a two-part operation:
- normal preferences are reset first
- then the saved AI API key is deleted

So it is possible for the preference reset to succeed while the API-key deletion still fails.
If that happens, treat it as an AI API key cleanup issue, not a full reset failure.

## Related pages
- /panels/preferences/
- /troubleshooting/preferences/
- /reference/logs-and-support-bundle/
