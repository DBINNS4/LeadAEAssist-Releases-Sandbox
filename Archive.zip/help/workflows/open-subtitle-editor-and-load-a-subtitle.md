# Workflow - Open Subtitle Editor and load a subtitle

## Goal
Open Subtitle Editor as a standalone window and load a subtitle/caption file for review.

## What you need
- a valid Subtitle Editor license
- one subtitle file in one of these formats:
  - `.json`
  - `.srt`
  - `.vtt`
  - `.scc`
  - `.mcc`
- optional preview media if the user wants synchronized playback

## Steps
1. Open **Transcribe**.
2. Click **Open Editor…**.
3. In the Subtitle Editor chooser, select or drop the subtitle file.
4. Optionally select or drop a video file for preview.
5. Click **Launch Editor**.
6. Confirm the title and metadata line match the expected file and format.
7. If needed, attach or replace preview media with **Open Media…**.

## Important behavior notes
- The subtitle file is required. Video is optional.
- The Launch button remains disabled until a valid subtitle file is selected.
- If the file is SRT or VTT, the window switches into web-caption mode.
- If the file is SCC or MCC, the window switches into broadcast mode.

## Common failure points
- the license does not include Subtitle Editor
- the wrong file type was dropped
- the user selected video only and expected that to be enough
- drag-and-drop path exposure failed in the current build

## Related pages
- /panels/subtitle-editor/
- /troubleshooting/subtitle-editor/
- /panels/transcribe/
