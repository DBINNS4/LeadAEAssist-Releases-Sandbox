# Workflow - Clean Adobe cache, autosaves, or previews safely

## Goal
Remove Adobe-generated junk from the correct folder without deleting unrelated project files.

## Steps
1. Open **NLE Utilities**.
2. Expand **Adobe Utilities**.
3. Click **Select Adobe Folder**.
4. Choose the narrowest sensible folder for the cleanup you want:
   - a cache folder for **Clear Cache**
   - an autosave root for **Delete Autosaves**
   - a preview/render-cache folder for **Remove Previews**
5. If needed, enter **Media Cache Scope** to target only a subfolder inside that base.
6. Optional: enable filters:
   - **Exclude Recent Files** + positive **Days**
   - **Skip Large Files** + positive **Max Size (MB)**
7. For **Clear Cache**, leave **Media Cache Filter** blank to use the default extension set, or enter a custom extension list.
8. Choose the action:
   - **Clear Cache**
   - **Delete Autosaves**
   - **Remove Previews**
9. Read the confirmation carefully.
10. If the panel asks for a second confirmation because the folder name looks suspicious, stop and verify the target before continuing.

## Safety behavior worth knowing
- **Delete Autosaves** only deletes `.prproj` files inside Auto-Save-like folders.
- Regular `.prproj` files outside Auto-Save folders are protected.
- **Clear Cache** and **Remove Previews** can ask for a second confirmation if the folder name does not look like a normal cache or preview folder.
- Scope must stay inside the selected Adobe folder.

## Verify success
A healthy run usually shows:
- deleted count
- skipped count when filters were used
- protected project count for autosave cleanup
- no scope-validation error
- no large-scan truncation warning

If the summary warns that the scan timed out or hit a file limit, narrow the folder and retry.

## Related pages
- /panels/nle-utilities/
- /troubleshooting/nle-utilities/
- /reference/file-locations/
