# Workflow - Copy version info for support

## Goal
Capture a deterministic build/runtime snapshot without exposing secret licensing material.

## Steps
1. Open **Account and Licensing**.
2. In **Version & Build**, wait for the spec block to finish loading.
3. Click **Copy version info**.
4. Paste the copied block into the support ticket, email, or case note.

## Verify success
A healthy copy usually gives you fields such as:
- app name and version
- build mode
- runtime versions
- OS and architecture
- key dependency versions

## Important note
This is one of the highest-value first artifacts for support.
It tells you what build the user is actually running without asking them to manually transcribe a bunch of technical trivia.
