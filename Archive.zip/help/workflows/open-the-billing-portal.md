# Workflow - Open the billing portal

## Goal
Open the browser-based billing portal for an already entitled account.

## Steps
1. Open **Preferences** and confirm **Offline Mode** is off.
2. Open **Account and Licensing**.
3. Confirm the app currently has a usable entitlement.
4. Click **Manage Subscription**.
5. Wait for the browser to open.

## Verify success
A healthy portal action gives you:
- a browser tab/window opening
- a billing/customer-portal page on an allowed host
- a short success message in the panel status line

## Important note
This action requires an active subscription already installed in the app.
If the app is locked and has no active subscription installed yet, the portal request can fail even though the button is still visible.
