# Workflow - Batch transcode

## Goal
Convert one or more selected source files into a new delivery format and write the outputs into one chosen folder.

## What you need
- one or more source files
- one output folder
- a clear target format/container
- an audio plan
- enough free disk space for the whole batch

## Recommended support-safe defaults
For a normal operator workflow:
- Verification: **Duration / Frame**
- Preserve Metadata: **On**
- Save Log: **On** if the user may need a handoff record
- Watch Mode: **Off**
- Match Source: **Off** unless the job truly uses one source file and wants source-driven frame/raster settings

## Steps
1. Open **Transcode**.
2. Leave **Watch Mode** off.
3. Click **Select Source** and choose one or more files.
4. Wait for the file-info grid to finish probing.
5. Choose the target **Output Format**.
6. Choose a compatible **Container**.
7. Set resolution, frame rate, pixel format, color range, LUT, and field order as needed.
8. Set audio codec, channels, sample rate, bitrate, and delay as needed.
9. Choose **Verification Method**.
10. Turn on **Save Log** if you want an output-folder copy of the final job log.
11. Click **Select Output** and choose the output folder.
12. Click **Start**.

## Verify success
Check these:
- the Summary shows the intended format/container
- the output folder contains the new media files
- batch outputs use suffixed names when needed
- if Save Log was enabled, the output folder contains `TranscodeLog_<timestamp>.txt`
- raw logs exist under `LeadAEAssist/logs/transcode/`

## Common failure points
- output format/container mismatch
- Match Source used with multiple files
- unsupported audio codec for the chosen container
- disk-space preflight abort
- the user expected existing outputs to be overwritten instead of suffixed

## Related pages
- /panels/transcode/
- /troubleshooting/transcode/
- /reference/logs-and-support-bundle/
