# Save and reuse Project Organizer configs

## Use this workflow when
Use this when the user has a folder layout they want to reuse later or share with another machine/user.

## Save a config
1. Open **Project Organizer**.
2. Build the desired folder tree.
3. Set numbering, root name, output path, and any attached assets as needed.
4. Click **Save Config**.
5. Save the JSON file to a known location.

## Load a config
1. Open **Project Organizer**.
2. Click **Load Config**.
3. Choose the saved JSON file.
4. Review the loaded structure.
5. Check whether the Output Path and attached assets survived approval re-check.
6. Re-select the output path or reattach files if needed.
7. Save the cleaned-up config again if this will be reused often.

## Notes
- The panel also supports in-app presets in `LeadAEAssist/config/presets/project-organizer/`.
- Loading a config does **not** guarantee every old absolute path is still trusted.
- If paths are removed on load, that is usually an approval/sanitization issue, not a parsing failure.
