# Workflow - Save AI API key and global webhook settings

## Goal
Store the AI API key securely and define one valid global webhook configuration for the workflow panels.

## Steps
1. Open **Preferences**.
2. In **AI Settings**, enter the AI API key.
3. In **Webhooks & Integration**, either:
   - leave the URL blank, or
   - enter a valid `http://` or `https://` webhook URL
4. If a valid URL is present, enable one or both of:
   - **Enable Webhook Logging**
   - **Send Only on Failure**
5. Click out of the edited field, or tab to another control, so the auto-save path runs.

## Verify success
A healthy result should give you:
- no red save banner
- the API-key field cleared back to placeholder state
- a placeholder that says the key is saved
- webhook controls staying enabled instead of greying back out

## Important note
If the webhook URL is invalid, the save can be blocked before the API key write even begins.
Fix the URL first, then retry.

## Related pages
- /panels/preferences/
- /troubleshooting/preferences/
- /reference/logs-and-support-bundle/
