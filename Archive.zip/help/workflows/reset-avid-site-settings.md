# Workflow - Reset Avid site settings

## Goal
Reset the shared Avid site settings for the current installation root.

## Use this when
Use this when the problem looks machine-wide rather than user-specific, such as:
- multiple users seeing the same site-level weirdness
- startup/state issues that survive user switching
- corrupted site settings in the Avid installation root

## Steps
1. Quit **Media Composer** fully.
2. Open **NLE Utilities**.
3. Expand **Avid Utilities**.
4. Click **Select Avid Folder**.
5. Choose one of these:
   - the Avid root containing `Settings` and `Avid Users`
   - the `Settings` folder directly
6. Turn on **Backup Before Reset** if you want a recoverable copy.
7. Click **Reset Site**.
8. Confirm the dialog.

## What gets deleted
The panel deletes these site settings targets:
- `MCState`
- `Site_Attributes`
- `Site_Settings.xml`

## Where the backup goes
If **Backup Before Reset** is on, the backup folder is created inside `Settings`:

`Settings/Site_Backup_<timestamp>/`

## Verify success
A healthy run usually shows:
- the resolved Settings folder path
- the backup path, if backup was enabled
- deleted site setting files listed in the summary
- no warning that Media Composer is still running

## Related pages
- /panels/nle-utilities/
- /troubleshooting/nle-utilities/
- /reference/file-locations/
