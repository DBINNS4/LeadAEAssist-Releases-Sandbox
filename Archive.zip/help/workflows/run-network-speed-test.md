# Workflow - Run a network speed test

## When to use this
Use this workflow when the user wants to check:
- general internet throughput on the current machine
- whether VPN or office-network conditions are dragging things down
- whether a browser-dependency issue is blocking the built-in network test

## Steps
1. Open **Speed Test**.
2. In the **Network Test** section, read the Summary box before clicking anything.
   - If it already shows a browser-dependency state, let that state finish or fail cleanly first.
3. Confirm **Offline Mode** is not enabled.
4. Click **Run Network Test**.
5. If the panel shows dependency preparation first, wait for that stage to resolve.
6. When the run completes, record:
   - Download Mbps
   - Upload Mbps
   - Ping ms
   - the timestamp
7. If the result fails, capture the exact error text before resetting the panel.

## How to interpret the result
- Higher **Download** helps for pulling remote data faster.
- Higher **Upload** matters for pushing data out, cloud sync, and other outbound-heavy work.
- Lower **Ping** usually means snappier interactive network behavior.

Important:
- This test measures the current internet path through **FAST.com**.
- It does **not** directly benchmark a local SMB/NAS filesystem mount.
- Use the **Drive Tests** section for storage-path benchmarking.

## If the test fails
- If the message mentions **Offline Mode**, disable it and retry.
- If the message mentions the **browser dependency**, treat that first.
- If the message says the output was unreadable or non-JSON, suspect VPN, captive portal, firewall, proxy, or DNS filtering.
- If the message times out, retry once, then test on another network path.

## What to save for support
- a screenshot of the Summary box
- **Copy version info**
- raw logs from `LeadAEAssist/logs/speed-test/` if the failure repeats
