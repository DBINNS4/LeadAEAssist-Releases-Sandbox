# Workflow - Export a single-job report from Log Viewer

## What this workflow does
This produces the richer TXT report mode that Log Viewer uses when the filtered result set contains **a single job**.

Use it when support wants one neat report instead of a giant raw log dump.

## Step 1: Open Log Viewer
Open the panel and start broad:
- set a date range wide enough to include the job
- leave the tool filter on **All** if you are not certain yet

## Step 2: Find the job
Use one or more of these:
- the tool filter
- the source filename
- the output filename
- the job id if support already has it
- a distinctive error phrase

Search tips:
- Search is case-insensitive.
- Search can match fields that are not obvious in the visible line, such as metadata and file names.

## Step 3: Narrow until one job remains
The viewer only switches into single-job TXT mode when the filtered set resolves to one unique job id.

Good ways to narrow:
- choose the correct tool
- tighten the date range
- search by file name or job id
- temporarily turn on **Show Only Errors / Warnings** if the job is noisy

Important:
- if multiple jobs remain, TXT export falls back to `logs.txt`
- if no job id exists in the filtered set, TXT export also falls back to plain log lines

## Step 4: Set export format to TXT
Choose:
- **Export Format** = `TXT`

JSON and CSV are still useful, but they do not produce the single-job report layout.

## Step 5: Choose an export folder
1. Click **Export Folder**.
2. Pick a writable location.
3. Confirm the path is visible in the field.

## Step 6: Export
Click **Export Logs**.

When single-job mode is active, the output filename should look roughly like:

`job-report_<panel>_<YYYYMMDD_HHMMSS>_<jobId>.txt`

## Step 7: Verify the report
A good single-job report usually includes:
- panel
- job id
- outcome
- start / end / duration
- warning and error counts
- optional Inputs / Outputs / Settings / Stats sections
- stage-grouped log lines

If you instead got `logs.txt`:
- the filtered set still included multiple jobs, or
- the filtered entries did not carry a non-empty job id

## When to prefer JSON instead
Use JSON instead of the single-job TXT report when:
- you need the full structured details
- the user suspects malformed structured entries
- you need exact field preservation rather than a readable summary
