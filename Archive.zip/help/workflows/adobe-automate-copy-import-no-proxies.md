# Workflow - Adobe Automate copy and import without proxies

## Goal
Copy media to the destination and import those copied files into Premiere, with optional bins, but without generating proxies.

## What you need
- source files
- a writable destination folder
- Premiere Pro open with a project loaded
- the Lead AE Assist Premiere CEP panel installed, open, and connected

## Steps
1. Open **Adobe Automate**.
2. Click **Select Source** and choose the media files.
3. Click **Select Destination** and choose the main copy location.
4. Leave **Import into Premiere** on.
5. Leave **Create Premiere Bins** on if the user wants organized Premiere bins.
6. Leave **Generate Proxies** off.
7. Optionally drag files into bins and reorder the bin tree.
8. Choose verification and Save Log settings.
9. Click **Automate**.

## Verify success
Check these:
- files exist in the destination
- the imported clips in Premiere point to the destination copies
- bins exist in Premiere if bin creation was enabled
- raw logs exist under `LeadAEAssist/logs/adobe-utilities/`

## Common failure points
- destination missing
- Premiere CEP side not connected
- duplicate basenames
- verification failures preventing later Premiere actions

## Related pages
- /panels/adobe-automate/
- /troubleshooting/adobe-automate/
