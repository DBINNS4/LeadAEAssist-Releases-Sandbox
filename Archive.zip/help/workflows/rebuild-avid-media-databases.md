# Workflow - Rebuild Avid media databases

## Goal
Force Avid to refresh stale or broken media-database state in a known MXF folder tree.

## Use this when
Use this workflow when Media Composer shows symptoms like:
- offline media that should not be offline
- stale or missing clips in a known-good MXF folder
- media database corruption suspicion after a crash or storage event

## Steps
1. Quit **Media Composer** fully.
2. Open **NLE Utilities**.
3. Expand **Avid Utilities**.
4. Click **Select Avid Folder**.
5. Choose one of these:
   - the affected numbered MXF folder
   - the `Avid MediaFiles/MXF` folder
   - the `Avid MediaFiles` folder if you intend to scan deeper
6. Turn on **Show Counts** to confirm the folder contains the expected Avid database files.
7. If needed, turn on **Scan Subfolders**.
8. Decide whether you want:
   - **Delete DB** followed by manual rebuild, or
   - **Delete DB** with **Auto Rebuild Databases** on, or
   - **Rebuild DB** only
9. Read the confirmation dialog carefully.
10. Run the action.

## Verify success
A healthy run usually shows:
- database files found and deleted, or
- rebuild triggered in the expected MXF folders
- no warning about Media Composer still running
- no warning that only non-standard folders were scanned

If **Auto Rebuild Databases** or **Rebuild DB** was used, a temporary file like this may appear briefly:

`REBUILD_TRIGGER_<timestamp>_<random>.mxf`

That trigger file should usually be cleaned up after about 15 seconds.

## Important cautions
- Avoid this on shared Nexis/ISIS/Interplay/MediaCentral storage unless the workflow explicitly allows it.
- Do not run this on random folders just because they contain `.mxf` files.
- If the panel warns about non-standard paths, stop and verify the target before proceeding.

## Related pages
- /panels/nle-utilities/
- /troubleshooting/nle-utilities/
- /reference/file-locations/
