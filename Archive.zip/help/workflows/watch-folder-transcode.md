# Workflow - Watch-folder transcode

## Goal
Monitor one folder and automatically queue transcode jobs for files that arrive there.

## What you need
- one watch folder
- one output folder that is **outside** the watch folder
- a stable transcode preset/config
- a decision about whether existing files should be queued when the watcher starts

## Use this workflow when
- files arrive over time
- the user wants an always-on transcode station
- manual file picking would be a waste of everyone's remaining lifespan

## Do not use this workflow when
- the source is a one-time file batch
- the source is a single file job
- the output folder sits inside the watch folder
- the user needs Match Source on a single manual file

## Steps
1. Open **Transcode**.
2. Turn on **Enable Watch Mode**.
3. Click **Select Watch Folder** and choose one folder.
4. Click **Select Output** and choose a folder outside the watch folder.
5. Set the transcode format, container, audio settings, verification, and any webhook options.
6. Decide whether to enable **Process existing files on start**.
7. Click **Start Watching**.
8. Drop or copy source files into the watch folder.
9. When finished, click **Stop Watching**.
10. Let any already-queued watch jobs finish or cancel before expecting the session log to finalize.

## Verify success
Check these:
- the control row shows Watch Mode active
- new files trigger jobs after they settle
- outputs land in the chosen output folder
- raw watch/job logs appear under `LeadAEAssist/logs/transcode/`

## Important logging note
As currently implemented, Transcode Watch Mode archives its session log in the app log library.
It does **not** currently mirror Ingest's destination-side `WatchLog_...` export behavior.

## Common failure points
- output folder is the same as or inside the watch folder
- no watch folder was selected
- the user expected Watch Mode to process old files without enabling **Process existing files on start**
- the watched files were still being written and had not stabilized yet

## Related pages
- /panels/transcode/
- /troubleshooting/transcode/
- /troubleshooting/watch-mode/
- /reference/logs-and-support-bundle/
