# Workflow - Watch-folder transcription

## Goal
Monitor one folder and automatically queue Transcribe jobs for files that arrive there.

## What you need
- one watch folder
- one output folder **outside** the watch folder
- one stable transcribe preset/config
- one chosen output format

## Use this workflow when
- files arrive over time
- the user wants an always-on transcription station
- manual file picking would be busywork in a nice shirt

## Do not use this workflow when
- the source is a one-time file batch
- the output folder is inside the watch folder
- the user is still experimenting with engine/output settings and not ready to automate

## Steps
1. Open **Transcribe**.
2. Turn on **Enable Watch Mode**.
3. Click **Select Watch Folder** and choose one folder.
4. Click **Select Output** and choose a folder outside the watch folder.
5. Choose the engine, language, and output format.
6. Configure the format-specific options.
7. Enable translation or subtitle-editor handoff only if needed.
8. Click **Start Watching**.
9. Drop or copy files into the watch folder.
10. When finished, click **Stop Watching**.

## Verify success
Check these:
- the control row shows Watch Mode active
- incoming files trigger jobs after they settle
- outputs land in the chosen output folder
- watch/session logs archive under `LeadAEAssist/logs/transcribe/`

## Important logging note
Transcribe Watch Mode archives its session logs in the app log library.
Do not assume an Ingest-style `WatchLog_...` copy will appear in the output folder.

## Common failure points
- output folder is the same as or inside the watch folder
- no output format was selected
- user expected pre-existing files to be processed automatically without restarting the watcher under the right conditions
- Lead AI asset/model prep blocks the first watch start and looks like a dead UI when it is really a runtime bootstrap

## Related pages
- /panels/transcribe/
- /troubleshooting/transcribe/
- /troubleshooting/watch-mode/
- /reference/logs-and-support-bundle/
