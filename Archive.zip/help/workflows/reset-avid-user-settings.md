# Workflow - Reset Avid user settings

## Goal
Reset one Avid user's settings without deleting the `.ave` profile.

## Use this when
Use this when a single editor has symptoms like:
- broken layouts
- strange window state
- user-specific settings corruption
- one user affected while other users on the same system are fine

## Steps
1. Quit **Media Composer** fully.
2. Open **NLE Utilities**.
3. Expand **Avid Utilities**.
4. Click **Select Avid Folder**.
5. Choose one of these:
   - the Avid root containing `Settings` and `Avid Users`
   - the `Avid Users` folder directly
   - the specific user folder directly
6. If a dropdown is shown, select the correct user.
7. Turn on **Backup Before Reset** if you want a recoverable copy.
8. Click **Reset User**.
9. Confirm the dialog.

## What gets deleted
The panel deletes:
- `MCState`
- `*.xml`
- `*.avs`

It does **not** delete:
- `.ave`

## Where the backup goes
If **Backup Before Reset** is on, the backup folder is created inside that user's folder:

`Avid Users/<user>/User_Backup_<timestamp>/`

## Verify success
A healthy run usually shows:
- the selected user name in the summary
- a list of deleted settings files
- the backup path, if backup was enabled
- no warning that Media Composer is still running

## Related pages
- /panels/nle-utilities/
- /troubleshooting/nle-utilities/
- /reference/file-locations/
