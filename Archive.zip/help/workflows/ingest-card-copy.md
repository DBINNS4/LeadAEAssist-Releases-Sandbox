# Workflow - Ingest card copy

## Goal
Copy a source folder or card to a destination, optionally create a second backup copy, and end with a readable ingest report.

## What you need
- source folder or selected files
- destination folder
- optional backup folder
- a verification choice
- enough read/write access for all paths

## Recommended settings
For a normal support-safe default:
- Verification: **BLAKE3**
- Skip Duplicates: **On**
- Parallel Copy: **On**
- Auto Threads: **On**
- Save Log: **On** if the user may need to hand off proof of copy later

## Steps
1. Open **Ingest**.
2. Click **Select Source** and choose the source folder or the needed files.
3. Click **Select Destination**.
4. If a second copy is required, click **Select Backup** and enable **Enable Backup**.
5. Leave **Clone Mode** off for a standard ingest.
6. Leave **Watch Mode** off for a one-time manual copy.
7. Choose the verification method.
8. Turn on **Save Log** if you want a destination-side copy of the final ingest report.
9. Click **Start**.
10. Accept destination or backup creation prompts only if those paths are correct.
11. Wait for the Summary to show completion.

## Verify success
Check these:
- Summary reports success, skipped count, and failed count
- destination contains the expected copied media
- if backup was enabled, backup contains the expected copied media
- if Save Log was enabled, destination contains `IngestLog_<timestamp>.txt`
- if failures occurred, destination may also contain:
  - `IngestFailures_<timestamp>.txt`
  - `RetryList_<timestamp>.txt`

## Common failure points
- destination was never set
- backup was enabled without a backup path
- source, destination, and backup overlap
- verification method is too slow for the user's expectations
- Save Log was expected in Watch Mode style even though this was a manual ingest

## Related pages
- /panels/ingest/
- /troubleshooting/ingest/
- /reference/logs-and-support-bundle/
