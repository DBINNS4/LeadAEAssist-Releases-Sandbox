# Workflow - Export logs from Log Viewer

## Use this workflow when
Use this when support needs a clean filtered export instead of telling the user to rummage through raw folders like a confused badger.

Good cases:
- the user knows roughly when the issue happened
- the problem belongs to one panel or one class of errors
- support needs something easy to email or attach to a ticket

## Step 1: Open the panel and widen the date range
1. Open **Log Viewer**.
2. If the issue is not from today, change **View by Date**:
   - **Last 7 Days** for recent cases
   - **Custom Range** for anything older or date-sensitive

Tip:
- There is no dedicated "all time" button in the current UI.
- When in doubt, use **Custom Range** and go wider first.

## Step 2: Start broad before getting clever
Set these first:
- **View by Tool** = `All`
- **Show Only Errors / Warnings** = off
- **Include System Logs** = on only if the issue smells like startup/runtime trouble

Why:
- over-filtering too early is how people convince themselves the logs are missing when they simply hid them.

## Step 3: Narrow the result set
Once history is visible:
1. Set **View by Tool** to the relevant tool.
2. Use **Search Logs** for:
   - job id
   - filename
   - distinctive error text
3. Turn on **Show Only Errors / Warnings** only after the right time/tool window is confirmed.

Important label trap:
- Adobe Automate jobs appear under **Adobe Utilities** in the tool filter.

## Step 4: Decide the export format
Choose format based on who needs the file.

### TXT
Best for:
- support tickets
- email handoff
- readable human review

### JSON
Best for:
- detailed analysis
- preserving structure and metadata
- searching outside the app

### CSV
Best for:
- spreadsheet review
- sorting by job id, panel, severity, or file name

## Step 5: Choose the export folder
1. Click **Export Folder**.
2. Pick a writable folder.
3. Confirm the path appears in the export path field.

If export fails, retry with a boring local folder such as Desktop or Downloads.

## Step 6: Export
1. Click **Export Logs**.
2. Wait for the success toast.
3. Open the chosen export folder and confirm the file exists.

Common filenames:
- `logs.txt`
- `logs.json`
- `logs.csv`

## Step 7: Package the case properly
Send the export together with:
- **Copy version info** from **Account and Licensing**
- screenshots if the issue is visual
- raw logs from **Open Log Folder** when the case is messy or incomplete

## Good support habit
If the exported file still looks incomplete:
- check for the on-screen render-limit notice
- check for truncation warning entries
- collect the raw files from the log library too
