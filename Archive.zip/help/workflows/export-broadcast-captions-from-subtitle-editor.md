# Workflow - Export broadcast captions from Subtitle Editor

## Goal
Review a broadcast-style caption document and export **SCC** or **MCC** with the editor's QC/reporting path.

## What you need
- Subtitle Editor open with an **SCC** or **MCC** source, or another broadcast document that should be re-exported as SCC/MCC
- the correct Start TC and service context
- a writable destination folder

## Steps
1. Open the caption file in Subtitle Editor.
2. Confirm whether the target deliverable is **SCC** or **MCC**.
3. Review placement, timing, and QC issues before export.
4. If the document is MCC and carries multiple services, choose the correct **Service**.
5. If required, open **Start TC** and set the correct label offset.
6. Run **Normalize frames** if the QC panel flags frame-alignment issues.
7. Click **Export SCC** or **Export MCC**.
8. Save to the intended destination.
9. Read the status result and open the report file if the export soft-fails or hard-fails QC.

## Important behavior notes
- SCC defaults to **29.97 DF** and guards NDF behind an advanced setting.
- MCC can write a report and can fail based on service/QC/compatibility rules.
- A successful write is not always the same thing as a clean QC pass. The status line and report file are the truth.

## Expected sidecars
Exports can create a report file next to the target output:
- `<output>.report.txt`

## Common failure points
- wrong Start TC
- wrong MCC service selected
- SCC chosen when the workflow really wanted SRT or VTT
- QC gate configured to block or soft-fail output

## Related pages
- /panels/subtitle-editor/
- /troubleshooting/subtitle-editor/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
