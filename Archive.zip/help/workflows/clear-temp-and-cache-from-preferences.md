# Workflow - Clear temp and cache from Preferences

## Goal
Clean the app-owned temp and cache areas without rummaging blindly through the filesystem.

## Steps
1. Open **Preferences**.
2. Expand **Advanced**.
3. In **Storage & Maintenance**, note the displayed **Temp folder** path.
4. Set **Delete temp entries older than (days)** to the rule you want:
   - `7` keeps recent temp
   - `0` is the aggressive option
5. Click **Clear Temp Now**.
6. Read the maintenance status line.
7. Click **Clear Cache Now** if cache cleanup is also needed.
8. Read the updated maintenance status line again.

## Verify success
A healthy result should give you:
- a readable status message
- removed-count / freed-space feedback
- no save-error banner from the temp-age field

## Important note
**Clear Temp Now** obeys the age rule.
It is not automatically a full wipe unless the threshold allows it.

## Related pages
- /panels/preferences/
- /troubleshooting/preferences/
- /reference/file-locations/
