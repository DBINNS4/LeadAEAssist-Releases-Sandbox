# Workflows

## How to use this section
Workflow pages are the shortest path from goal to result. Use them when the user cares about *doing a job* and not reading an entire panel manual.

## Ingest
- [Workflow - Ingest card copy](/workflows/ingest-card-copy/)
- [Workflow - Clone Mode copy](/workflows/clone-mode-copy/)

## Transcode
- [Workflow - Batch transcode](/workflows/batch-transcode/)
- [Workflow - Watch-folder transcode](/workflows/watch-folder-transcode/)
- [Workflow - Embed captions in MXF](/workflows/embed-captions-in-mxf/)

## Transcribe and subtitles
- [Workflow - Batch transcribe files](/workflows/transcribe-batch-files/)
- [Workflow - Watch-folder transcription](/workflows/transcribe-watch-folder/)
- [Workflow - Send output to Subtitle Editor](/workflows/send-output-to-subtitle-editor/)
- [Workflow - Export broadcast captions (SCC / MCC)](/workflows/export-broadcast-captions-scc-mcc/)
- [Workflow - Open Subtitle Editor and load a subtitle](/workflows/open-subtitle-editor-and-load-a-subtitle/)
- [Workflow - Review and export web caption corrections](/workflows/review-and-export-web-caption-corrections/)
- [Workflow - Export broadcast captions from Subtitle Editor](/workflows/export-broadcast-captions-from-subtitle-editor/)
- [Workflow - Create burn-in from Subtitle Editor](/workflows/create-burn-in-from-subtitle-editor/)

## Adobe Automate
- [Workflow - Install and connect the Premiere CEP panel](/workflows/install-and-connect-premiere-cep-panel/)
- [Workflow - Adobe Automate copy, import, bins, and proxies](/workflows/adobe-automate-copy-import-bins-proxies/)
- [Workflow - Adobe Automate copy and import without proxies](/workflows/adobe-automate-copy-import-no-proxies/)

## Logs and support
- [Workflow - Export logs from Log Viewer](/workflows/export-logs-from-log-viewer/)
- [Workflow - Export a single-job report from Log Viewer](/workflows/export-single-job-report-from-log-viewer/)
- [Workflow - Copy version info for support](/workflows/copy-version-info-for-support/)

## NLE Utilities
- [Workflow - Rebuild Avid media databases](/workflows/rebuild-avid-media-databases/)
- [Workflow - Reset Avid user settings](/workflows/reset-avid-user-settings/)
- [Workflow - Reset Avid site settings](/workflows/reset-avid-site-settings/)
- [Workflow - Clean Adobe cache, autosaves, or previews safely](/workflows/clean-adobe-cache-autosaves-or-previews-safely/)

## Speed Test
- [Workflow - Run a network speed test](/workflows/run-network-speed-test/)
- [Workflow - Compare drive targets with Speed Test](/workflows/compare-drive-targets-with-speed-test/)

## Project Organizer
- [Workflow - Build a folder tree with Project Organizer](/workflows/build-project-folder-tree-with-project-organizer/)
- [Workflow - Attach starter assets to organizer folders](/workflows/attach-starter-assets-to-organizer-folders/)
- [Workflow - Save and reuse Project Organizer configs](/workflows/save-and-reuse-project-organizer-configs/)

## Preferences and account
- [Workflow - Configure Offline Mode and update behavior](/workflows/configure-offline-mode-and-update-behavior/)
- [Workflow - Save AI API key and global webhook settings](/workflows/save-ai-api-key-and-global-webhook-settings/)
- [Workflow - Clear temp and cache from Preferences](/workflows/clear-temp-and-cache-from-preferences/)
- [Workflow - Reset Preferences safely](/workflows/reset-preferences-safely/)
- [Workflow - Install a license file](/workflows/install-a-license-file/)
- [Workflow - Subscribe and sync subscription](/workflows/subscribe-and-sync-subscription/)
- [Workflow - Open the billing portal](/workflows/open-the-billing-portal/)

## Related
- [Lead AE Assist Help](/)
- [Panel Guides](/panels/)
- [Troubleshooting](/troubleshooting/)
