# Troubleshooting - Account and Licensing

## How to use this page
Start with the symptom you actually see.

For account problems, these are related but not identical:
- checkout in the browser
- license installation
- subscription sync
- billing portal access
- the panel's current status display

## The user completed checkout, but the app is still locked
### Most likely causes
- checkout finished in the browser, but the app was never synced afterward
- **Offline Mode** is enabled
- the purchase is still processing
- the subscription does not match the current machine yet

### Fast checks
- Open **Preferences** and check whether **Offline Mode** is on.
- Return to **Account and Licensing** and read **Status**, **Plan**, **Reason**, and any warning text.
- Press **Sync Subscription** and capture the exact status line.

### Fix steps
1. Turn **Offline Mode** off if it is enabled.
2. Return to **Account and Licensing**.
3. Click **Sync Subscription**.
4. Wait for the status line to settle.
5. If checkout happened only moments ago, try Sync again after a short wait.
6. If the app still stays **Locked**, collect **Copy version info**, a full screenshot, and the exact sync message.

### What to collect for support
- **Copy version info**
- screenshot of the panel after the sync attempt
- whether **Offline Mode** was enabled
- the exact status-line text shown by **Sync Subscription**

## Install License says “License install failed”
### Most likely causes
- the selected file is not a valid license for this app
- the license is expired or otherwise invalid
- the license belongs to a different machine
- the wrong file was selected

### Fast checks
- Confirm the file came from the licensing workflow, not from a random config or export.
- Confirm you selected the intended file.
- If the same file works on another machine, the license may be machine-specific.

### Fix steps
1. Click **Install License…** again.
2. Re-select the intended license file.
3. If the file is hidden, enable hidden files in your system picker and select it again.
4. If install still fails, stop retrying blindly and verify that the file is the correct license for this app and machine.
5. If the user purchased through checkout instead of receiving a file, switch to **Sync Subscription** instead.

### What to collect for support
- **Copy version info**
- screenshot of the failure message
- the file extension and where the file came from

## Clear License did not change anything
### Most likely causes
- another license file is still available on the machine
- the panel refreshed into a different valid license source
- the user expected every possible license source to be removed

### Fast checks
- Compare **Status**, **Plan**, and **Reason** before and after **Clear License**.
- Ask whether another license file was copied or installed outside the usual flow.

### Fix steps
1. Click **Clear License** once.
2. Check the panel again.
3. If the app still shows a license state, look for another license file that may still be in use.
4. Remove or rename that file only if the user really intends to stop using it.
5. Re-open the panel or restart the app and check again.

### Important note
**Clear License** removes the license currently stored by the app. It may not affect every other license file that is still present on the machine.

## Sync Subscription fails immediately
### Most likely causes
- **Offline Mode** is enabled
- the machine is offline
- the account or subscription is not ready yet
- the app could not refresh the current machine's subscription state

### Fast checks
- Check **Preferences** for **Offline Mode**.
- Read the exact sync status message.
- Check whether the message mentions:
  - Offline Mode
  - network error
  - timeout
  - missing subscription
  - account not ready

### Fix steps
1. Disable **Offline Mode** if it is on.
2. Confirm the machine has internet access.
3. Retry **Sync Subscription**.
4. If the error looks network-related, retry once after reconnecting.
5. If the message still points to account or machine mismatch, collect **Copy version info** and the exact error text.

### What to collect for support
- **Copy version info**
- exact sync status text
- screenshot of **Preferences** showing **Offline Mode**

## Manage Subscription fails or does nothing useful
### Most likely causes
- there is no active subscription installed in the app yet
- **Offline Mode** is enabled
- the browser could not be opened
- the current access state is incomplete or out of date

### Fast checks
- Check whether the panel is currently **Active**, **Trial**, or **Locked**.
- If the panel is **Locked**, portal access may fail until access is restored.
- Check whether **Offline Mode** is on.

### Fix steps
1. If the user is locked, restore access first with **Install License** or **Sync Subscription**.
2. Turn off **Offline Mode** if needed.
3. Retry **Manage Subscription**.
4. If it still fails, capture the exact status text rather than paraphrasing it.

### What to collect for support
- **Copy version info**
- current **Status / Plan / Reason**
- exact portal status message

## The feature tabs disappeared after a licensing change
### Most likely causes
- the current license no longer includes those features
- the app refreshed feature access after a license change
- only recovery panels are available right now

### Fast checks
- Confirm whether **Account and Licensing**, **Preferences**, and **Log Viewer** are still available.
- Check current **Status / Plan / Reason**.
- Ask whether the change happened after:
  - **Clear License**
  - **Install License**
  - **Sync Subscription**

### Fix steps
1. Open **Account and Licensing** from the titlebar settings button.
2. Read the current **Status / Plan / Reason**.
3. Restore valid access with **Install License** or **Sync Subscription** if needed.
4. Wait for the UI to refresh.

### Important note
If tabs vanished after a licensing change, the UI is usually responding to the current access state, not failing at random.

## The Expires date and Sync warning seem to contradict each other
### Most likely causes
- **Expires** shows the end of access
- the subscription needs to refresh sooner than that
- the app is already warning about an upcoming refresh

### Fast checks
- Read the warning banner.
- Check whether the warning mentions `refresh soon` or `offline grace`.

### Fix steps
1. Explain that **Expires** is the access end, not always the next online validation time.
2. Click **Sync Subscription** while online.
3. Re-check the warning state after sync.

## Copy version info failed
### Most likely causes
- clipboard access failed
- the version block itself did not load
- the environment blocked copy access

### Fast checks
- Check whether the status line says **Copy failed**.
- Confirm whether the version block is visible.

### Fix steps
1. If the block is visible, manually copy the visible text as a fallback.
2. If the block itself is unavailable, capture a screenshot and continue with support.

## What support should collect first
For most account and licensing cases, start with:
- **Copy version info**
- a screenshot of the full **Account and Licensing** panel
- the exact status-line text from install, sync, billing, or portal actions
- whether **Offline Mode** is on
- `LeadAEAssist/config/state.json` when requested

Avoid sharing secret license material unless support explicitly asks for it.
