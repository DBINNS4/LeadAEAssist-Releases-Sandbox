# Troubleshooting - Ingest

## Start here
Before digging into a specific symptom, answer these five questions:
1. Is this a normal ingest, Clone Mode job, or Watch Mode session?
2. Is the source a folder or a file list?
3. Is **Enable Backup** on?
4. Which verification method is selected?
5. Do the source, destination, and backup paths overlap?

A shocking amount of ingest misery is just one of those five wearing a fake moustache.

## Symptom: Ingest will not start
Common user wording:
- "Start does nothing."
- "It immediately stops."
- "The button changes back and nothing runs."

### Most likely causes
- No source is selected.
- No destination is set.
- Backup is enabled but no backup path is set.
- Clone Mode is on but no source folder or no clone selection exists.
- Watch Mode is on but the source is a file list instead of a folder.
- Verification is set to **None** and the confirmation prompt was cancelled.

### Fast checks
- In the Summary box, confirm **Source** and **Destination** are both populated.
- If **Enable Backup** is on, confirm **Backup** is populated.
- If **Clone Mode** is on, confirm the source is a folder and the tree has selections.
- If **Watch Mode** is on, confirm the source is a watch folder, not `N items selected`.
- Check the panel log for one of these exact messages:
  - `Please select a source folder or add files before starting.`
  - `Please set a destination before starting.`
  - `Backup path is required when dual copy is enabled.`
  - `Clone Mode requires a valid source folder.`
  - `Select at least one folder to clone.`

### Fix steps
1. Reselect the source.
2. Reselect the destination.
3. If backup is enabled, reselect the backup path.
4. If using Clone Mode, turn it off and back on after choosing a source folder.
5. If using Watch Mode, clear any file-list source and choose one folder.
6. If verification is **None**, start again and confirm the warning only if that is intentional.

## Symptom: Source path not found
Common user wording:
- "The source folder disappeared."
- "It says source not found."
- "I loaded a preset and now the path is wrong."

### Most likely causes
- The drive or network volume is not mounted.
- The preset points to an old path.
- The source was renamed or moved after the preset was saved.
- The user expected Watch Mode to accept a file list.

### Fast checks
- Confirm the path still exists in Finder or Explorer.
- If the panel came from a preset, ask the user to read the source path aloud and verify it still exists.
- Check whether the panel is showing a file-list summary instead of a folder path.

### Fix steps
1. Remount the drive or reconnect the network share.
2. Reselect the source.
3. Resave the preset after the correct path is loaded.
4. Do not use the missing-source override unless the goal is to intentionally queue a skipped job for tracking. It does **not** magically recover missing media.

### Notes for support
For a normal manual ingest, the app requires an explicit typed override before continuing with a missing source folder. That is a safety gate, not a suggestion.

## Symptom: Destination or backup path errors
Common user wording:
- "Destination is invalid."
- "Backup won't enable."
- "It says the folder is not writable."
- "Why can't I use this backup folder?"

### Most likely causes
- Destination or backup points to a file instead of a folder.
- Destination is inside the source.
- Source is inside the destination.
- Backup is inside the source.
- Destination and backup overlap or contain each other.
- The folder exists but is not writable.
- The folder does not exist and the user declined the create-folder prompt.

### Fast checks
- Confirm each path is a folder.
- Confirm source, destination, and backup are separate roots.
- Have the user try creating a plain text file in the destination and backup folders outside the app.
- Check the panel log for exact messages such as:
  - `Destination cannot be the same as the source or located inside the source folder.`
  - `Source cannot be the same as or located inside the destination folder.`
  - `Backup path is required when dual copy is enabled.`
  - `Destination and backup paths cannot match or contain each other.`
  - `Destination folder is not writable.`
  - `Backup folder is not writable.`

### Fix steps
1. Move the destination outside the source tree.
2. Move the backup outside both the source and destination trees.
3. Recreate the folder manually if permissions look suspicious.
4. If the destination or backup does not exist, rerun and accept the create-folder prompt if that location is correct.
5. On network or removable volumes, test write access in the OS first.

### Watch Mode note
Manual ingest can prompt to create a missing destination or backup. Watch-triggered jobs do not stop for a dialog. They skip when required output paths are missing.

## Symptom: Clone Mode is unavailable or the folder tree will not load
Common user wording:
- "Clone Mode won't stay on."
- "The tree is empty."
- "It says Clone Mode requires a folder."
- "The folder tree failed to load."

### Most likely causes
- The source is a file list, not a folder.
- Watch Mode was already active and had to be stopped.
- The source folder cannot be read.
- The clone helper module failed to load.
- The source tree is huge and the user thinks the load is frozen when it is still scanning.

### Fast checks
- Confirm the source is a single folder path.
- Turn off Watch Mode before enabling Clone Mode.
- Check whether the source path is on an unavailable or permission-restricted volume.
- Look for these messages:
  - `Clone Mode requires a folder; please select a source folder.`
  - `Stop Watch Mode before enabling Clone Mode.`
  - `Failed to load folder tree`
  - `Clone Mode is unavailable (clone module not loaded).`

### Fix steps
1. Turn off Watch Mode.
2. Choose one source folder.
3. Toggle Clone Mode on again.
4. If the tree still will not load, reselect the source folder.
5. If the folder tree is huge, wait for the initial scan and avoid turning on **Show File Count** until the tree is stable.

## Symptom: Watch Mode will not start or does not behave correctly
Common user wording:
- "Start Watching is greyed out."
- "It says Watch Mode needs a folder."
- "Nothing happens when new files arrive."
- "The log did not save."

### Most likely causes
- Watch Mode helper utilities are unavailable.
- The source is a file list, not a folder.
- Destination or backup is missing for watch-triggered jobs.
- The user expected Save Log to create an ingest log immediately instead of exporting the watch session log when watching stops.

### Fast checks
- Confirm the source is a folder.
- Confirm **Enable Watch Mode** is on and the button label changed to **Start Watching**.
- Confirm destination is set before starting the watcher.
- If backup is enabled, confirm backup is valid before starting the watcher.
- Check the log for messages like:
  - `Watch Mode requires a folder. Clear the file list and select a watch folder.`
  - `Watch Mode is unavailable (watch module not loaded).`
  - `Watch-triggered job skipped: destination missing`
  - `Watch-triggered job skipped: backup path missing`

### Fix steps
1. Clear any file-list source and choose one watch folder.
2. Set destination before starting Watch Mode.
3. If backup is enabled, validate the backup path before starting Watch Mode.
4. Stop and restart the watcher after path changes.
5. Remember that **Save Log** in Watch Mode exports the session log when **Stop Watching** is pressed.

See **Troubleshooting - Watch Mode** for the panel-agnostic watch diagnostics.

## Symptom: Webhook URL is rejected
Common user wording:
- "The webhook is valid but the app rejects it."
- "It won't accept localhost."
- "My private-network URL fails validation."

### Most likely causes
- The URL is not a full `http://` or `https://` URL.
- The URL has no hostname.
- The URL points to `localhost` or a private network target while **Allow private or localhost targets** is off.

### Fast checks
- Confirm the URL includes the protocol.
- Confirm the hostname is present.
- If the target is on a private network, confirm **Allow private or localhost targets** is enabled.

### Fix steps
1. Rewrite the URL as a full address.
2. Turn on **Allow private or localhost targets** only if the target is intentionally on a local or private network.
3. Run a small manual ingest first and confirm the webhook before reusing the preset.

## Symptom: Ingest is much slower than expected
Common user wording:
- "Verification is taking forever."
- "It stalls at the end."
- "Why is it slower than the old copy app?"

### Most likely causes
- **Byte Compare** is selected.
- **SHA-256** is selected.
- Parallel Copy is off.
- Auto Threads chose a conservative value because of the destination speed.
- Large Clone Mode estimates or file counts are still being calculated.
- The destination or backup volume is slow.

### Fast checks
- Confirm the verification method.
- Confirm **Parallel Copy** is on.
- Confirm **Auto Threads** is on or the manual thread count is reasonable.
- Ask whether the slowdown is during:
  - preflight
  - copy
  - verification
  - final summary

### Fix steps
1. Use **BLAKE3** for the normal default.
2. Use **xxHash64** only when the workflow allows a non-cryptographic fast check.
3. Avoid **Byte Compare** unless the job really needs it.
4. Leave **Auto Threads** on unless you have a tested reason to force a manual count.
5. For huge Clone Mode trees, turn off **Show File Count** unless the estimate is truly needed.

## Symptom: Files were skipped when the user expected a recopy
Common user wording:
- "It says skipped, but I wanted a fresh copy."
- "The file already existed and it did nothing."

### Most likely causes
- **Skip Duplicate Files** is enabled.
- The destination or backup content already verifies as identical.
- Filters excluded some of the candidate files before copy started.

### Fast checks
- Check whether **Skip Duplicate Files** is on.
- Check the Summary and log for verified duplicate skip lines.
- Check include/exclude extension filters.

### Fix steps
1. Turn off **Skip Duplicate Files** if the workflow requires a forced recopy.
2. Clear extension filters if they are not intentional.
3. Re-run the job with Save Log on so the user has a written report of what was skipped and why.

## Symptom: The job completed with failures
Common user wording:
- "Some files copied, some failed."
- "It finished with warnings."
- "Where is the retry list?"

### Most likely causes
- Some files failed on the initial pass and remained failed after retry handling.
- A destination or backup verification step failed.
- A removable or network volume disconnected mid-job.

### Fast checks
- Look for these files in the destination:
  - `IngestFailures_<timestamp>.txt`
  - `RetryList_<timestamp>.txt`
- Open the app's raw job log from the log library.
- Check whether the user had **Retry Failures** enabled.

### Fix steps
1. Review the failure list instead of guessing.
2. Reselect any disconnected source or destination volume.
3. Re-run only after the path problem is fixed.
4. Keep the failed file list and retry list with the support ticket.

## Symptom: Save Log did not put the file where the user expected
Common user wording:
- "I turned on Save Log but I do not see the file."
- "Where did the watch log go?"
- "The log is in the app but not the destination."

### Most likely causes
- The user is looking in the wrong folder.
- Auto Create Folder wrote the output inside a time-stamped subfolder.
- The job was Watch Mode, so the session log exported only when watching stopped.
- The user is checking the destination when the job was Clone Mode and only the app log library was written.

### Fast checks
- Confirm whether the job was manual ingest, Clone Mode, or Watch Mode.
- Confirm whether Auto Create Folder was on.
- Check the destination for:
  - `IngestLog_<timestamp>.txt`
  - `clone-log-<timestamp>.txt`
  - `WatchLog_<...>.txt`
- Check the raw app log library under `logs/ingest/` or `logs/clone/`.

### Fix steps
1. Open the destination folder and any auto-created subfolder.
2. If the job was Watch Mode, stop the watcher and look again.
3. If nothing appears in the destination, collect the raw job log from the app log library.

## What to collect for support
Minimum support packet:
- app version copied from **Account and Licensing**
- platform and OS version
- panel and mode used
- exact error text or screenshot
- Summary box text
- exported Log Viewer file or raw app log file
- destination-side files such as:
  - `IngestLog_<timestamp>.txt`
  - `IngestFailures_<timestamp>.txt`
  - `RetryList_<timestamp>.txt`

## Related pages
- /panels/ingest/
- /troubleshooting/watch-mode/
- /troubleshooting/permissions-paths-and-folders/
- /troubleshooting/webhooks-and-network/
- /reference/logs-and-support-bundle/
