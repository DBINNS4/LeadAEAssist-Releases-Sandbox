# Troubleshooting - NLE Utilities

## How to use this page
Start with the symptom.
Do not start by declaring that "Avid is weird today" or "Adobe must have corrupted itself again."
Those statements can be emotionally satisfying and technically useless.

## Symptom: The panel says NLE Utilities is unavailable because the app connection did not load correctly
Common user wording:
- "The whole panel is disabled."
- "Everything is greyed out."
- "It says the app connection failed."

### Most likely causes
- The panel connection failed to load.
- The app connection is incomplete.
- The app is running in an unexpected environment.

### Fast checks
- Fully quit and relaunch the app.
- Confirm this is the installed desktop app, not a broken preview copy.
- Check whether other filesystem-heavy panels also behave strangely.
- Look for a warning banner at the top of the panel describing missing functions.

### Fix steps
1. Relaunch the app.
2. If the panel is still disabled, collect **Copy version info** and a screenshot of the warning banner.
3. Open **Log Viewer** and export System logs if available.
4. Treat this as an app-startup or preload problem, not an Avid/Adobe media problem.

## Symptom: Delete DB or Rebuild DB says to select an MXF folder first
Common user wording:
- "I selected a folder, but it still says select MXF folder."
- "It won't touch the folder I picked."

### Most likely causes
- No folder is currently selected.
- The user picked a settings/user folder, not an Avid media folder.
- The panel is trying to protect against a non-standard or irrelevant path.

### Fast checks
- Confirm the path field is populated.
- Confirm the path is an `Avid MediaFiles/MXF` folder or its parent `Avid MediaFiles`.
- Turn on **Show Counts** to verify the folder contains Avid-style files.

### Fix steps
1. Click **Select Avid Folder** again.
2. Choose the actual media path:
   - `.../Avid MediaFiles/MXF`
   - or `.../Avid MediaFiles`
3. Retry the action.
4. If the user intentionally selected a non-standard folder, read the confirmation carefully before proceeding.

## Symptom: Site Reset or User Reset says required folders are missing
Common user wording:
- "It says Settings and Avid Users are missing."
- "Why won't it reset the user?"
- "I picked the Avid folder and it still complains."

### Most likely causes
- The user selected an Avid media folder instead of the Avid application/settings root.
- The selected folder does not contain both `Settings` and `Avid Users`.
- The folder is a legacy layout or a custom layout the app cannot resolve automatically.
- The relevant sibling folder exists, but the app did not get approval for the parent/root path.

### Fast checks
- Confirm the chosen folder is for settings, not media.
- Check whether the path contains:
  - `Settings`
  - `Avid Users`
- On macOS, look for a root like `/Users/Shared/AvidMediaComposer`.
- On Windows, look for a root like `C:\Users\Public\Public Documents\Avid Media Composer`.

### Fix steps
1. Re-select the folder using one of these:
   - the Avid root containing `Settings` and `Avid Users`
   - the `Settings` folder directly
   - the `Avid Users` folder directly
   - a specific user folder under `Avid Users`
2. Retry the action.
3. If the path is custom or legacy, turn on **Show Counts** and verify the folder contents before retrying.

## Symptom: Avid User dropdown is empty or the wrong user is selected
Common user wording:
- "There are no users in the list."
- "It picked the wrong editor."
- "My user is missing."

### Most likely causes
- The selected folder is a media folder, not a users/settings root.
- The user folders are not under `Avid Users`.
- The panel's active-user inference guessed based on `MCState` or newest timestamp and guessed wrong.
- The selected user no longer exists.

### Fast checks
- Confirm the selected path is the Avid settings root or `Avid Users`.
- Check whether the actual user folder exists on disk.
- Turn on **Show Counts** to confirm the app is looking at the right place.

### Fix steps
1. Re-select the correct root or `Avid Users` folder.
2. Choose the user manually from the dropdown.
3. If needed, select the specific user folder directly and retry.
4. Do not trust the auto-selected user without verifying the name first.

## Symptom: Delete DB or Rebuild DB warns about non-standard folders or shared storage
Common user wording:
- "It asked me twice."
- "Why is it warning about Nexis or non-standard paths?"
- "It says it will skip folders."

### Most likely causes
- The selected path is outside the standard `Avid MediaFiles/MXF` structure.
- The panel detected a shared-storage-risk scenario.
- Some subfolders do not look like valid MXF database targets.

### Fast checks
- Read the exact folder path.
- Confirm whether this is local storage or shared Nexis/ISIS/Interplay/MediaCentral storage.
- Confirm whether the user actually wants to operate on a non-standard folder.

### Fix steps
1. If the path is wrong, stop and re-select the correct folder.
2. If the path is intentionally non-standard, continue only after verifying the target.
3. On shared storage, escalate before deleting databases unless the workflow explicitly allows it.

## Symptom: Delete DB finished, but nothing was deleted
Common user wording:
- "It completed but removed zero files."
- "No .mdb or .pmr files found."

### Most likely causes
- The chosen folder does not contain the database files.
- **Scan Subfolders** was off when it needed to be on.
- The user picked the wrong level of the folder tree.
- Avid had already rebuilt or removed the files before the run.

### Fast checks
- Turn on **Show Counts**.
- Check whether **Scan Subfolders** is on.
- Confirm whether the chosen folder is the `MXF` root or one of the numbered subfolders.

### Fix steps
1. Turn on **Show Counts**.
2. If needed, turn on **Scan Subfolders**.
3. Re-select `Avid MediaFiles` or `Avid MediaFiles/MXF`.
4. Retry the action.

## Symptom: Auto Rebuild did not seem to work, or trigger files are still present
Common user wording:
- "I deleted the DB but Avid still looks stale."
- "I can see weird REBUILD_TRIGGER files."
- "Rebuild happened in some folders, not all."

### Most likely causes
- Media Composer was still running.
- The trigger file could not be created in some folders.
- The cleanup timer has not removed the trigger file yet.
- Folder permissions blocked file creation or removal.
- The wrong MXF folders were targeted.

### Fast checks
- Confirm Media Composer is fully closed.
- Look for summary lines saying rebuild triggered or failed in specific folders.
- Wait at least ~15 seconds before judging whether trigger-file cleanup failed.

### Fix steps
1. Quit Media Composer fully.
2. Re-run the action.
3. If a trigger file remains after a reasonable delay, remove it manually only after confirming the folder is correct.
4. If rebuild still fails, collect the summary text and exact folder path for support.

## Symptom: Reset User completed, but the user's profile still exists
Common user wording:
- "It didn't fully wipe the user."
- "The .ave file is still there."

### Most likely causes
- That is expected.
- **Reset User** deletes `MCState`, `.xml`, and `.avs`.
- It deliberately leaves the `.ave` profile intact.

### Fast checks
- Look at the deleted-file summary.
- Confirm whether the user expected a settings reset or a full profile deletion.

### Fix steps
1. Explain that `.ave` is intentionally preserved.
2. If the user truly wants to remove the profile too, do it manually outside the panel and only with explicit approval.

## Symptom: Backup Before Reset was on, but the user cannot find the backup
Common user wording:
- "It said it backed things up, but where?"
- "The reset worked and now I can't find the backup copy."

### Most likely causes
- The backup is stored inside the original Avid settings or user folder, not in a separate export location.
- The user is searching the wrong root.

### Fast checks
- For Site Reset, look in:
  - `Settings/Site_Backup_<timestamp>/`
- For User Reset, look in:
  - `Avid Users/<user>/User_Backup_<timestamp>/`

### Fix steps
1. Re-open the summary and read the backup path.
2. Open the backup folder directly from the filesystem.
3. If the summary is gone, reconstruct the path from the folder naming pattern above.

## Symptom: Adobe cleanup says Scope must stay inside the selected Adobe folder
Common user wording:
- "Why won't it accept this scope path?"
- "It says the scope is outside the folder."

### Most likely causes
- The scope path points outside the selected Adobe base folder.
- The scope points to a non-folder path.
- The scoped path does not exist.

### Fast checks
- Compare the selected Adobe folder with the scope value.
- Remove the scope and retry to confirm the base folder is valid.
- Check whether the scope is a file instead of a folder.

### Fix steps
1. Clear the scope field and retry.
2. If scope is required, enter a real subfolder under the selected Adobe base.
3. Re-select the Adobe base folder if needed.
4. Do not use `..`-style path gymnastics. The panel blocks that on purpose.

## Symptom: Adobe cleanup fails because Days or Max Size is empty
Common user wording:
- "It says Exclude Recent requires age."
- "Skip Large is on and now it errors."

### Most likely causes
- **Exclude Recent Files** is checked with no positive **Days** value.
- **Skip Large Files** is checked with no positive **Max Size (MB)** value.

### Fast checks
- Read the current checkbox states.
- Check whether the numeric fields are blank or zero.

### Fix steps
1. Enter a positive value for the enabled filter.
2. Or turn the filter off if it is not needed.
3. Retry the action.

## Symptom: Clear Cache or Remove Previews asks for a second confirmation
Common user wording:
- "Why is it asking me twice?"
- "It thinks this is the wrong folder."

### Most likely causes
- The selected path does not look like a normal cache or preview folder based on folder name.
- The panel is intentionally demanding a second confirmation before deleting from a suspicious path.

### Fast checks
- Read the selected Adobe folder.
- Ask whether the path actually contains:
  - `Media Cache`
  - `Media Cache Files`
  - `Preview Files`
  - `Render Cache`
  - similar expected folders

### Fix steps
1. If the path is wrong, stop and re-select the right folder.
2. If the path is intentionally custom, continue only after verifying its contents.
3. Prefer narrower subfolders over broad roots.

## Symptom: Delete Autosaves found nothing, or it "protected" project files instead
Common user wording:
- "It skipped my .prproj files."
- "It says protected project files."
- "No autosaves found."

### Most likely causes
- The `.prproj` files were outside Auto-Save-like folders.
- The selected folder is not where Premiere autosaves live.
- Filters skipped the files because of age or size.

### Fast checks
- Confirm the `.prproj` files are inside folders named like Auto-Save / Autosave.
- Check whether **Exclude Recent Files** or **Skip Large Files** is on.
- Look at the protected-project count in the summary.

### Fix steps
1. Select the actual autosave root.
2. Narrow the folder with **Scope** if helpful.
3. Relax age or size filters if they were overly strict.
4. Do not force-delete normal project files with this tool. The protection is intentional.

## Symptom: Large Adobe cleanup runs time out, truncate, or feel incomplete
Common user wording:
- "It scanned forever and still missed files."
- "It says results may be incomplete."
- "Huge folder, weird result."

### Most likely causes
- The folder tree is too broad.
- The recursive scan hit the timeout or file-count limit.
- Hidden/system directories were skipped.
- Metadata reads failed for some files.

### Fast checks
- Read the summary for:
  - timeout warnings
  - file-limit warnings
  - metadata/stat errors
- Confirm the user did not target an entire volume or giant home directory.

### Fix steps
1. Narrow the base folder.
2. Use **Scope** to target only the problem subtree.
3. Retry the action.
4. Do not treat a truncated scan as authoritative.

## Symptom: A preset loads, but the action says the path is invalid or access was not approved
Common user wording:
- "The preset loaded, but it still won't use the folder."
- "Why do I have to select it again?"

### Most likely causes
- Presets store the path text.
- Presets do **not** preserve folder-access approval.
- The folder moved, unmounted, or no longer exists.

### Fast checks
- Re-select the Avid or Adobe folder manually.
- Verify the folder still exists.
- Retry after re-approval.

### Fix steps
1. Re-select the folder from the picker.
2. Re-run the action.
3. Save the preset again only after verifying the path is correct.

## Support collection checklist
For any NLE Utilities problem, collect:
- screenshot or copied text from the Avid or Adobe summary box
- selected folder path
- state of the relevant checkboxes and filters
- app version info
- any matching Log Viewer export if NLE lines are present there

## Related pages
- /panels/nle-utilities/
- /workflows/rebuild-avid-media-databases/
- /workflows/reset-avid-user-settings/
- /workflows/reset-avid-site-settings/
- /workflows/clean-adobe-cache-autosaves-or-previews-safely/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
