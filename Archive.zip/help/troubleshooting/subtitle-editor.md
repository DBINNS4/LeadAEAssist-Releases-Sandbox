# Troubleshooting - Subtitle Editor

## How to use this page
Start from the symptom the user actually sees.
Do not start from whatever cursed phrase they invented for it after clicking six different things in three different panels.

## Symptom: Subtitle Editor will not open
Common user wording:
- "Open Editor does nothing."
- "It flashes and closes."
- "It says license required."

### Most likely causes
- The **Subtitle Editor** feature is not licensed.
- The window open call failed before a document session started.
- The editor is already open and loaded elsewhere, so the user is looking at the wrong window.

### Fast checks
- Confirm the user's license actually enables **Subtitle Editor**.
- Check whether an existing Subtitle Editor window is already open behind the main app.
- If the request came from Transcribe, confirm the handoff did not fail before the pop-out opened.

### Fix steps
1. Confirm entitlement first. Do not start doing filesystem ritual dances before checking the license.
2. Try **Open Editor…** again and look for a direct error message.
3. If the window already exists, bring that one forward and continue there.
4. If it still refuses to open, collect **Copy version info**, a screenshot, and the raw Transcribe logs.

## Symptom: Launch Editor is disabled on the start screen
Common user wording:
- "The launch button is greyed out."
- "I picked a video and it still won't go."

### Most likely causes
- No subtitle file is selected.
- The selected subtitle path is invalid or unsupported.
- The editor is still busy loading the previous request.

### Fast checks
- Confirm the **Subtitle file** box actually shows a filename.
- Confirm the file extension is one of: `.json`, `.srt`, `.vtt`, `.scc`, `.mcc`.
- Confirm the user is not trying to launch with video only.

### Fix steps
1. Choose the subtitle file again.
2. Leave the video box alone unless preview media is needed.
3. Wait for the current load to finish before clicking Launch repeatedly like it owes you money.

## Symptom: The editor rejects a dropped or chosen file
Common user wording:
- "It says unsupported subtitle file."
- "It won't accept this video."
- "Drop failed."

### Most likely causes
- Wrong subtitle extension.
- Wrong media extension.
- The build could not expose a usable file path for a drag-and-drop operation.

### Fast checks
- Check the file extension.
- For manual preview media picks, confirm the file is one of: `.mp4`, `.mov`, `.m4v`, `.mkv`, `.webm`.
- If the problem happened on drag-and-drop only, try the picker buttons instead.

### Fix steps
1. Use **Open Subtitle…** for the subtitle file.
2. Use **Open Media…** for the preview video.
3. If drag-and-drop specifically fails, fall back to the picker and note that path-exposure is the likely issue.

## Symptom: The user opened SRT or VTT but sees the wrong controls
Common user wording:
- "Why am I seeing broadcast tools?"
- "Why did it keep SCC-ish settings?"

### What is usually happening
The editor window is reused, and stale session state can make the user think the wrong mode survived.
The loader explicitly cleans web-caption docs to prevent SCC/MCC settings from bleeding forward, but a reproduction here is still worth capturing.

### Fast checks
- Confirm the opened file really ends in `.srt` or `.vtt`.
- Confirm the title/meta line shows the correct format.
- Confirm the toolbar is showing **Export Corrections** rather than SCC-only tools.

### Fix steps
1. Re-open the correct SRT/VTT file.
2. If the mode still looks wrong, close the window and open it again cleanly.
3. Capture screenshots and raw logs if the web/broadcast mode routing still misbehaves.

## Symptom: Open Media works, but the preview is blank, slow, or weird
Common user wording:
- "The subtitles loaded but the video doesn't play."
- "It says converting preview."
- "The preview takes forever the first time."

### Most likely causes
- Chromium cannot decode the original media directly.
- The editor is building a preview proxy in the temp preview cache.
- No compatible preview encoder is available.
- The selected file has audio but no video track.

### Fast checks
- Read the status line. It often tells you exactly whether the editor is using the original file, a cached preview, or a new preview conversion.
- Check whether `LeadAEAssist/temp/previews/` contains fresh preview files.
- Confirm the source actually contains video.

### Fix steps
1. Wait for the preview conversion to finish on first open.
2. Re-open the same file and confirm a cached preview is reused.
3. If preview conversion fails, try a browser-friendly source such as H.264 MP4.
4. If the source is audio-only, explain that the editor can still use time/audio context but there is no video picture to show.

## Symptom: The corrected export format was not what the user expected
Common user wording:
- "Why did it only export VTT?"
- "Where is the matching SRT?"
- "Why did JSON save as .final.json?"

### What is actually happening
**Export Corrections** now writes one corrected file, not a sibling trio.
- opened `.srt` -> corrected `.srt`
- opened `.vtt` -> corrected `.vtt`
- opened `.json` -> corrected `.json` (the default filename usually ends in `.corrected.final.json`)
- SRT/VTT exports also create `.qc.json` and `.qc.txt` sidecars
- Burn-in can still request an SRT export explicitly when it needs one

### Fix steps
1. Confirm which file type the user actually opened.
2. Explain that Export Corrections is single-format now.
3. If the workflow needs a broadcast deliverable, use **Export SCC** or **Export MCC** instead.
4. If the workflow needs burn-in, let Burn-in create or reuse the corrected SRT it needs.

## Symptom: Start TC changed the labels, but the captions did not move
Common user wording:
- "Start TC didn't retime anything."
- "The cue positions are the same."

### What is actually happening
That is the designed behavior.
**Start TC maps media time 0 to a displayed/exported SMPTE label. It does not shift cue start/end times.**

### Fix steps
1. Explain the difference between label offset and cue retime.
2. If the user actually needs timing changes, edit the cue timings or normalize/nudge them.
3. Use Start TC only for timecode labeling and broadcast export alignment.

## Symptom: Normalize frames or Debutt All did not do what the user expected
Common user wording:
- "Normalize didn't change my text."
- "Debutt moved the wrong boundary."

### Most likely causes
- The user expected text reflow instead of timing cleanup.
- The selected debutt policy trims start, end, or both in a way they did not notice.
- The issue was not a same-frame boundary problem to begin with.

### Fast checks
- Confirm the document uses SMPTE/frame-based timing where normalization matters.
- Confirm which debutt policy is selected.
- Check the QC panel for frame-alignment warnings.

### Fix steps
1. Use **Normalize frames** when cues are off-frame.
2. Use **Debutt All** only when adjacent cues share the same frame boundary.
3. If needed, undo and switch the debutt policy before rerunning it.

## Symptom: SCC export failed or says QC gate failed
Common user wording:
- "It saved a report instead of the file."
- "SCC not exported."
- "Why is DF/NDF being weird?"

### Most likely causes
- SCC QC gating is active.
- The export required a draft/overflow fallback and the delivery policy treated that as a failure.
- The document is trying to export NDF SCC without the advanced `allowNdf` setting.
- The content violates 608-safe timing or readability rules.

### Fast checks
- Check whether a `*.report.txt` file was created next to the intended SCC output.
- Read the status line carefully. It distinguishes:
  - passed
  - saved with warnings
  - saved but considered failed
  - not written at all
- Confirm whether the user really needed SCC.

### Fix steps
1. Open the report file first.
2. Fix the flagged timing/placement/text issues.
3. Confirm DF/NDF expectations. SCC defaults to DF, and NDF is intentionally guarded.
4. Re-export.
5. If the downstream workflow does not explicitly require SCC, switch to SRT or VTT and stop volunteering for extra pain.

## Symptom: MCC export failed or says gate failed
Common user wording:
- "MCC saved but failed."
- "Why is there a report file?"
- "The service looks wrong."

### Most likely causes
- MCC QC gating is active.
- The active service number is wrong.
- Structural validation or compatibility checks failed.
- The export settings conflict with fps or compatibility mode, especially around embedded CDP timecode.

### Fast checks
- Confirm the active **Service** selection.
- Confirm a `*.report.txt` file exists.
- Confirm the document fps and whether CDP timecode embedding is enabled.

### Fix steps
1. Pick the correct service first.
2. Read the report file.
3. Reduce settings complexity if the user mixed advanced compatibility options without a real delivery spec.
4. Re-export after correcting the QC failures.

## Symptom: Burn-in failed
Common user wording:
- "Burn-in asked me to save SRT first."
- "Burn-in failed immediately."
- "It exported subtitles first and then stopped."

### Most likely causes
- No media path is attached.
- No corrected **SRT** export is available yet.
- The SRT export Burn-in tried to start was cancelled or failed.
- FFmpeg burn-in processing failed.

### Fast checks
- Confirm a media file is attached.
- Confirm the session has a corrected `.srt`, not just VTT/JSON/SCC/MCC output.
- Confirm the output directory exists and is writable.

### Fix steps
1. Attach media with **Open Media…**.
2. Re-run **Burn-in** and complete the SRT save/export prompt if it appears.
3. Confirm the corrected SRT was actually written, then run Burn-in again.
4. If it still fails, collect the raw Transcribe log and the exact status text.

## Symptom: Multi-service MCC is missing the expected Service selector
Common user wording:
- "Where is service 2?"
- "It only shows one service."

### Most likely causes
- The imported MCC only contains one detected service.
- The document did not populate `cuesByService` / available service data on import.
- The user is actually editing SCC or web captions and expecting MCC behavior.

### Fast checks
- Confirm the source file is actually MCC.
- Confirm the file really contains more than one service.
- Check whether the title/meta line reflects MCC/708-style content.

### Fix steps
1. Verify the correct MCC file was opened.
2. If the source only has one service, explain that there is nothing to switch.
3. If a known multi-service MCC still shows no selector, capture the file and logs for parser investigation.

## Symptom: Click-to-place, row/indent inspector, or 608/708 placement controls are missing
Common user wording:
- "Where did the placement tools go?"
- "I only see web caption stuff."

### Most likely causes
- The user opened **SRT** or **VTT**, which intentionally hides broadcast placement controls.
- The current doc is not 708-capable, so 708 placement mode is hidden.
- Click-to-place is off, so some placement-target controls remain hidden.

### Fix steps
1. Confirm the file type.
2. For web captions, explain that those broadcast controls are intentionally absent.
3. For broadcast docs, turn on **Click-to-place** where needed.
4. For 708 placement mode, confirm the doc is really MCC / 708-capable.

## Symptom: Undo / redo / hotkeys behave strangely
Common user wording:
- "Spacebar won't play."
- "Delete didn't delete the cue."
- "Undo is inconsistent."

### Most likely causes
- The keyboard focus is inside a text field, so the editor intentionally avoids stealing the shortcut.
- The active cue selection is not where the user thinks it is.
- The user is trying to use cue-edit shortcuts before any subtitle document is loaded.

### Fix steps
1. Click out of the text field and retry the shortcut.
2. Select the correct cue.
3. Confirm a document is actually loaded.
4. Use the toolbar buttons if the reproduction depends on focus state.

## Symptom: The auto-open handoff from Transcribe did not happen
Common user wording:
- "Edit Subtitle after export was on but nothing opened."

### Most likely causes
- The Transcribe output format did not produce an editor-friendly file.
- The job failed before writing a usable subtitle/caption file.
- The latest-file lookup did not find the expected export.

### Fast checks
- Confirm the Transcribe job output type was SRT, VTT, SCC, or MCC.
- Confirm the output folder actually contains the exported subtitle/caption file.
- Try opening the same file manually in Subtitle Editor.

### Fix steps
1. Open Subtitle Editor manually.
2. Load the output file directly.
3. If the manual open works, treat the problem as a handoff/lookup issue and collect the Transcribe logs.

## Symptom: Support cannot find a Subtitle Editor log
Common user wording:
- "Where is the subtitle-editor log folder?"

### What is actually happening
There is no dedicated `logs/subtitle-editor/` folder.

### Fix steps
1. Start with:
   - `LeadAEAssist/logs/transcribe/`
2. Collect any generated subtitle report files:
   - `*.report.txt`
3. If preview media is involved, also inspect:
   - `LeadAEAssist/temp/previews/`
4. Save screenshots of the status line and QC panel before the user changes state again.

## Related pages
- /panels/subtitle-editor/
- /panels/transcribe/
- /workflows/open-subtitle-editor-and-load-a-subtitle/
- /workflows/review-and-export-web-caption-corrections/
- /workflows/export-broadcast-captions-from-subtitle-editor/
- /workflows/create-burn-in-from-subtitle-editor/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
