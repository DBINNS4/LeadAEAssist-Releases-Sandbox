# Troubleshooting

## How to use this section
Troubleshooting pages are symptom-first. Start with the thing that is broken, not the feature list. Each page is structured as:
- most likely causes
- fast checks
- fix steps
- what to collect for support

## Shared/global troubleshooting
- [Troubleshooting - Watch Mode](/troubleshooting/watch-mode/) — watch-folder behavior used by multiple panels.
- [Troubleshooting - Permissions, paths, and folders](/troubleshooting/permissions-paths-and-folders/) — path approval, folder rules, file/folder mismatches, and destination overlap errors.
- [Troubleshooting - Webhooks and network](/troubleshooting/webhooks-and-network/) — webhook delivery, Offline Mode, firewalls, and general network sanity.

## Panel-specific troubleshooting
- [Troubleshooting - Ingest](/troubleshooting/ingest/) — Use when copy jobs will not start, paths fail validation, backup rules conflict, or Watch Mode behaves strangely.
- [Troubleshooting - Transcode](/troubleshooting/transcode/) — Use when jobs are blocked, presets fail, output files are wrong, or watch-folder transcodes misbehave.
- [Troubleshooting - Transcribe](/troubleshooting/transcribe/) — Use when transcription will not start, Lead AI preparation blocks, outputs are wrong, or export formats fail.
- [Troubleshooting - Adobe Automate](/troubleshooting/adobe-automate/) — Use when Premiere connection fails, proxy generation blocks, or import/bins automation does not run.
- [Troubleshooting - Log Viewer](/troubleshooting/log-viewer/) — Use when expected logs are missing, filters hide entries, or TXT export does not match the visible results.
- [Troubleshooting - NLE Utilities](/troubleshooting/nle-utilities/) — Use when Avid reset/rebuild tools fail or Adobe cleanup looks too aggressive or incomplete.
- [Troubleshooting - Speed Test](/troubleshooting/speed-test/) — Use when network tests fail, drive benchmarks are blocked, or results look wrong or inconsistent.
- [Troubleshooting - Project Organizer](/troubleshooting/project-organizer/) — Use when organizer jobs are blocked, existing roots conflict, asset copies fail, or configs reload oddly.
- [Troubleshooting - Preferences](/troubleshooting/preferences/) — Use when Preferences do not save, secure-key state is confusing, Offline Mode blocks behavior, or reset acts partial.
- [Troubleshooting - Account and Licensing](/troubleshooting/account-and-licensing/) — Use when the app says Active but billing fails, Sync Subscription does not refresh, or license state looks contradictory.
- [Troubleshooting - Subtitle Editor](/troubleshooting/subtitle-editor/) — Use when the editor will not open, media preview fails, export blocks, or broadcast caption QC reports errors.

## Related
- [Lead AE Assist Help](/)
- [Panel Guides](/panels/)
- [Logs and support bundle](/reference/logs-and-support-bundle/)
- [File locations](/reference/file-locations/)
