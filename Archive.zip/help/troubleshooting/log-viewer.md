# Troubleshooting - Log Viewer

Use this page when the viewer itself is the problem, not just the panel whose logs you are trying to inspect.

## Symptom: The panel says "No logs found" or looks empty
Common user wording:
- "I know the job ran, but the viewer is blank."
- "The logs disappeared."
- "It only says no logs found."

### Most likely causes
- The date filter is still on **Today** and the job is older.
- The tool filter is wrong.
- **System logs** are still excluded.
- The user is expecting destination-side copied logs to appear automatically.
- The app log library was manually cleaned or never wrote the expected raw archive.

### Fast checks
- Change **View by Date** to **Custom Range** and set a wide span.
- Set **View by Tool** to **All**.
- Turn off **Show Only Errors / Warnings**.
- Turn on **Include System Logs**.
- Use **Open Log Folder** and confirm raw files exist under `LeadAEAssist/logs/`.

### Fix steps
1. Reset the viewer.
2. Re-open the panel and widen the date range.
3. Set tool filter to **All** first.
4. Only narrow the tool filter after confirming history exists.
5. If the user only has logs in a destination/output folder, collect those separately. Log Viewer does not crawl those folders.
6. If the raw log library is actually empty, collect the destination-side logs and version info instead.

## Symptom: I can see a copied log in the output folder, but not in Log Viewer
Common user wording:
- "The folder has `TranscodeLog_...txt`, but the viewer does not show it."
- "I have `IngestLog_...txt` in destination, so why isn't it in the app?"

### Most likely causes
- The copied destination-side log is a convenience export, not the source Log Viewer reads.
- The raw log library and the output folder are different places.
- The user is opening the wrong folder and assuming it is the app log library.

### Fast checks
- Click **Open Log Folder** from Log Viewer.
- Compare that location to the user's output or backup folder.
- Check `/reference/file-locations/` if the paths are unclear.

### Fix steps
1. Treat the app's `LeadAEAssist/logs/` folder as the raw source of truth.
2. Treat destination-side logs as helpful copies, not the primary archive.
3. If support needs both, collect both.
4. Do not tell the user "Log Viewer is broken" just because the output folder contains a copied log that the viewer does not index.

## Symptom: I only see the newest chunk of logs
Common user wording:
- "Older lines are missing."
- "It stops after a few hundred entries."
- "The top says it's only showing newest results."

### Most likely causes
- The on-screen render cap is showing only the newest **500** filtered results.
- One or more raw files hit the reader caps of **8 MB** and/or **10,000 lines**.
- The in-memory retention cap has already discarded older live entries during a long session.

### Fast checks
- Look for the viewer notice saying only the newest results are shown.
- Search for truncation warning entries mentioning a log file was truncated.
- Export the filtered set and compare it to what is visible on screen.

### Fix steps
1. Remember that on-screen display is not the full story.
2. Export the filtered set before assuming data is gone.
3. If the export is still incomplete, collect the raw log file from disk.
4. For giant logs, send the raw file rather than only a viewer export.

## Symptom: System logs are missing
Common user wording:
- "The crash happened during startup and I don't see anything."
- "Runtime errors are not showing."

### Most likely causes
- **Include System Logs** is off.
- The tool filter is not set to **System** or **All**.
- The relevant issue only occurred live in the current session and has not been archived as a panel job log.

### Fast checks
- Turn on **Include System Logs**.
- Set **View by Tool** to **System**.
- Reproduce the issue while the viewer is open if possible.

### Fix steps
1. Enable **Include System Logs**.
2. Retry the startup action if reproduction is safe.
3. Export the viewer state immediately after reproduction.
4. If nothing useful appears, collect version info and any platform crash artifacts separately.

## Symptom: Adobe Automate logs seem missing
Common user wording:
- "I ran Adobe Automate, but I don't see an Adobe filter."
- "Why is it under Adobe Utilities?"

### Most likely causes
- Log Viewer uses the log-channel label **Adobe Utilities**.
- Support is looking for a tool label named **Adobe Automate** and not finding it.

### Fast checks
- Open the **View by Tool** dropdown.
- Look for **Adobe Utilities**, not Adobe Automate.

### Fix steps
1. Filter by **Adobe Utilities** for Adobe Automate jobs.
2. Explain to the user that the tool filter label follows the log channel name, not the prettier tab caption.
3. If proxy/output confusion is also involved, check `/reference/file-locations/` because Adobe logs and proxy folders are easy to mix up.

## Symptom: Expand Task Details does not show extra JSON or deep metadata
Common user wording:
- "The button does nothing."
- "I clicked expand and still only saw the line."
- "Where is the hidden detail?"

### Most likely causes
- In normal app use, deep debug details are intentionally hidden.
- The button is mainly changing line wrapping/readability in normal user-facing builds.
- The selected entries do not contain extra detail/meta worth appending.

### Fast checks
- Expand a long line and see whether it becomes readable over multiple lines.
- Compare normal app behavior to any debug screenshots if someone is expecting extra detail.

### Fix steps
1. Treat **Expand Task Details** as a readability control first.
2. Do not promise it will reveal hidden JSON details in normal use.
3. If you need the full structured details, export JSON or collect the raw structured-log file.

## Symptom: Export failed or nothing happened
Common user wording:
- "Export does nothing."
- "The button says failed."
- "I clicked export but no file appeared."

### Most likely causes
- No export folder was selected.
- The selected export folder is not writable.
- The user expected the file to appear in the raw log library rather than the chosen export folder.
- The environment could not open the folder picker.

### Fast checks
- Confirm the **Export Folder** field is populated.
- Confirm the chosen folder is writable.
- Confirm which format is selected.

### Fix steps
1. Select an export folder again.
2. Use a simple writable local folder like Desktop or Downloads for the retry.
3. Retry export.
4. If it still fails, collect raw logs manually from **Open Log Folder** and note the failure in the support report.

## Symptom: TXT export gave me a job report instead of raw log lines
Common user wording:
- "Why did it make a formatted report?"
- "I wanted the raw text, not the summary page."

### Most likely causes
- The filtered result set resolved to a single job.
- TXT export switches to single-job report mode in that case.

### Fast checks
- Look at the filename. If it starts with `job-report_`, the viewer entered single-job TXT mode.
- Check whether the current filtered set only contains one job id.

### Fix steps
1. If the formatted report is fine, keep it.
2. If raw lines are preferred, widen the filters until multiple job ids are present.
3. Or export JSON/CSV instead.

## Symptom: Search does not find text that should be there
Common user wording:
- "I know the filename is in the logs."
- "Search missed the error."

### Most likely causes
- The current date/tool/error filters already removed the matching entries.
- The raw file was truncated before the matching line was loaded.
- The destination-side copied log contains the text, but the raw library does not.
- The structured log line was malformed and got skipped during parsing.

### Fast checks
- Reset the viewer.
- Widen the date range.
- Set tool to **All**.
- Turn off **Show Only Errors / Warnings**.
- Try searching for job id, filename, and a shorter error fragment.

### Fix steps
1. Relax filters first.
2. Export JSON and search inside it if the on-screen view is noisy.
3. If the file is large, inspect the raw log directly.
4. If a damaged structured log is suspected, collect the raw file for review.

## Symptom: Reset Viewer erased my logs
Common user wording:
- "Reset deleted everything."
- "The history vanished after reset."

### Most likely causes
- Reset cleared the in-memory view and restored default filters.
- The default date filter reverted to **Today**, which can hide older logs immediately.
- The export folder field was cleared, causing the user to think the whole state was lost.

### Fast checks
- Widen the date filter again.
- Confirm the raw log files still exist in **Open Log Folder**.

### Fix steps
1. Explain that Reset does not delete raw log files.
2. Re-open the older date range.
3. Re-select an export folder if needed.
4. Re-export the filtered set.

## Support collection checklist for Log Viewer cases
Collect these:
- viewer export (`txt`, `json`, or `csv`)
- raw files from `LeadAEAssist/logs/`
- version info from **Account and Licensing**
- exact filter settings used when the user said something was missing
- screenshots when the claim is visual, such as missing lines or confusing labels
