# Troubleshooting - Project Organizer

## How to use this page
Start with the symptom that matches what the user actually sees.
This panel fails in a small set of predictable ways.
No need to summon mysterious folder spirits until the boring causes are dead.

## Symptom: Generate is blocked or the summary says “Please set an Output Path before generating”
Common user wording:
- “Generate does nothing.”
- “It says to set an output path.”
- “The panel won’t start.”

### Most likely causes
- No Output Path is selected.
- The selected Output Path field was cleared by Reset or by loading a config that lost path approval.

### Fast checks
- Confirm the **Output Path** field is not blank.
- Click **Select Output Location** again and choose a real folder.
- If the user just loaded a preset/config, check whether the path silently disappeared afterward.

### Fix
1. Select a valid output folder.
2. Confirm the path now appears in the Output Path field.
3. Click **Generate** again.

### What to collect for support
- screenshot of the Summary box
- whether the problem happened after **Load Config** or preset selection

## Symptom: The panel says the Output Path cannot be accessed or must be an existing folder
Common user wording:
- “I picked a folder but it still says it is invalid.”
- “It says Output Path must be an existing folder.”
- “It says it cannot access the output path.”

### Most likely causes
- The chosen path no longer exists.
- The chosen path is not a directory.
- The folder exists but is not writable for this user/session.
- The path came from an old config and is no longer approved.

### Fast checks
- Open the path in Finder/File Explorer outside the app.
- Try creating a small test folder in that destination manually.
- Re-pick the destination from the panel instead of trusting the old stored path.

### Fix
1. Re-select the output location from the panel.
2. Choose a folder that already exists.
3. Confirm the current OS user can write into it.
4. Retry the job.

### What to collect for support
- exact Summary text
- whether the destination is local, external, cloud-synced, or network-mounted
- raw logs from `LeadAEAssist/logs/project-organizer/` if the issue repeats

## Symptom: The Project Name is rejected
Common user wording:
- “It won’t accept the folder name.”
- “The project name is invalid.”
- “Why can’t I use this name?”

### Most likely causes
The name includes something the sanitizer rejects, such as:
- `/` or `\`
- `..`
- trailing dot or trailing space
- Windows reserved device names
- illegal characters like `< > : " | ? *`
- reserved meta keys like `__proto__`

### Fast checks
- Remove slashes.
- Remove `..`.
- Trim leading/trailing whitespace.
- Replace punctuation-heavy names with a simple production-safe folder name.

### Fix
1. Use a plain folder-safe name.
2. Retry Generate.

### Support note
This same validation also affects **Custom Folder** and **Add Subfolder** names.
It is not just the Project Name field.

## Symptom: Add Subfolder says a folder must be selected first
Common user wording:
- “Add Subfolder doesn’t work.”
- “It says select exactly one folder.”

### Most likely causes
- No folder row is selected.
- More than one selection state is somehow present after a UI oddity.
- The user expects Add Subfolder to work without first clicking a target parent folder.

### Fast checks
- Click exactly one folder row in the organizer list.
- Confirm it is visibly highlighted.
- Retry **Add Subfolder**.

### Fix
1. Click the folder that should act as the parent.
2. Enter the subfolder name.
3. Click **Add Subfolder**.

### Support note
Selection is mostly a **nesting target** concept here, not a generation filter.
The user may confuse those two ideas.

## Symptom: A custom folder or subfolder cannot be added
Common user wording:
- “Add Custom Folder does nothing.”
- “It says the folder already exists.”
- “It keeps rejecting my subfolder name.”

### Most likely causes
- The name fails validation.
- The target id already exists.
- The user is trying to create a subfolder path that duplicates an existing path.

### Fast checks
- Try a short test name such as `REVIEW`.
- Check whether the same folder already exists in the list.
- For a subfolder, verify the parent folder is selected first.

### Fix
1. Use a valid new name.
2. Retry adding the folder.
3. If duplication is intentional, reuse the existing folder instead of creating another one.

## Symptom: The run fails because the root folder already exists
Common user wording:
- “It says the root exists.”
- “The folder already exists and it refuses to run.”

### Most likely causes
- The selected Output Path already contains a non-empty folder with the same Project Name.

### Important behavior
When **Project Name** is filled in, the organizer refuses to merge into a non-empty existing root folder.
That is deliberate.
It prevents accidental folder soup.

### Fast checks
- Check whether `Output Path/Project Name/` already exists.
- If it exists, inspect whether it is empty.

### Fix options
- choose a different Project Name, or
- choose a different Output Path, or
- empty the pre-existing target folder if that is truly intended and safe

### Support note
If the user wants to build directly into an existing folder tree, leaving **Project Name blank** changes the behavior. That can be useful, but it is also the fastest route to regrettable merges.

## Symptom: The run completes, but attached files were skipped or not copied
Common user wording:
- “The folders were created, but the files didn’t come over.”
- “Some attachments copied and some didn’t.”

### Most likely causes
- one or more attached paths were invalid
- one or more paths were not absolute anymore
- one or more assets were unreadable
- one or more assets were folders instead of files
- a loaded config had asset paths removed during approval re-check

### Fast checks
- confirm the missing asset still exists on disk
- confirm it is a file, not a folder
- confirm the current user can open it
- if the config was loaded from disk, ask whether the path survived the load

### Fix
1. Reattach the missing files using the **+** button or drag-and-drop.
2. Retry the job.
3. If a config/preset was involved, save a fresh one after reattaching valid files.

### What to collect for support
- the exact missing file path(s)
- the raw organizer TXT/JSONL logs
- the config/preset JSON if the problem appears only after loading

## Symptom: Attached files copied, but the filenames changed
Common user wording:
- “Why did it make `_1` copies?”
- “It renamed my asset.”

### Most likely causes
- another file with the same destination basename already existed
- two different attached sources had the same filename

### What is happening
The backend intentionally picks a unique destination path instead of overwriting an existing file.
That is why suffixes like `_1`, `_2`, and so on can appear.

### Fix
- clean up the destination if you need exact original names
- or accept the suffix behavior as collision protection

## Symptom: Cancel was pressed, and now the user is afraid the output tree is half-broken
Common user wording:
- “I cancelled it; what did it leave behind?”
- “Did it delete everything?”

### What happens
If the job had already created folders or copied files, the backend attempts to roll back **job-created artifacts only**.
It does not delete unrelated pre-existing folders or files.

### Fast checks
- inspect the output location
- compare it with the pre-run state if known
- check the raw job log for cleanup lines such as removed created folders or removed copied files

### Support note
Rollback is best-effort and intentionally conservative.
That is the right trade-off.
The app should clean up its own mess, not bulldoze existing project storage.

## Symptom: Loading a preset/config drops the output path or attached file paths
Common user wording:
- “My config loaded, but some paths vanished.”
- “The preset opened, but the output path is blank.”

### Most likely causes
- the stored path is no longer approved in the current session
- the attached asset paths were non-absolute
- the files no longer exist or are no longer approved

### What is happening
When the app loads organizer JSON, it sanitizes the payload and re-checks path approval.
Unapproved output paths and asset paths can be removed.
That is expected.

### Fix
1. Re-select the output path.
2. Reattach the missing files.
3. Save a new clean config/preset.

### What to collect for support
- the JSON config/preset file
- screenshot of the warnings shown after load
- raw organizer logs if the panel reported approval failures

## Symptom: The panel seems stuck during Generate
Common user wording:
- “The hamster is running forever.”
- “The progress bar barely moves.”

### Most likely causes
- a large attached file copy is in progress
- the destination path is slow or remote
- the job is in a long copy phase rather than folder-creation phase

### Important behavior
When attached files exist, progress is weighted mostly by **bytes copied**.
That is better than a fake folder-step bar, but long copies can still look slow if the destination is slow.

### Fast checks
- look at destination write activity outside the app
- see whether the summary/log shows copy-stage messages
- test the destination with **Speed Test** if the path may be slow

### What to collect for support
- attached file sizes
- destination type (local SSD, HDD, NAS, cloud-mounted, etc.)
- organizer raw logs

## What to collect before escalating
For repeatable Project Organizer problems, ask for:
- exact Summary text or a screenshot
- app version
- OS and storage type
- the organizer config/preset JSON if one was used
- raw logs from `LeadAEAssist/logs/project-organizer/`
- the intended Output Path and Project Name
