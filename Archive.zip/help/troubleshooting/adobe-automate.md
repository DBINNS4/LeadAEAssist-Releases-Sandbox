# Troubleshooting - Adobe Automate

## How to use this page
Start with the symptom. Do not start with a theory. Theories are how support turns into folklore.

## Symptom: Automate will not start, or the button stays disabled
Common user wording:
- "Start does nothing."
- "It scans and then stops."
- "The job never queues."

### Most likely causes
- No source files are selected.
- No destination is selected.
- Backup is enabled but no backup path is selected.
- Proxy generation is enabled but there is no valid destination or proxy destination.
- Import into Premiere / Create Bins / Generate Proxies is enabled but the Premiere CEP side is not connected.
- Source scanning timed out or got truncated and the user cancelled the confirmation.

### Fast checks
- Confirm the source field is populated.
- Confirm the destination field is populated unless this is truly a backup-only run.
- If backup is enabled, confirm the backup folder exists.
- If proxies are enabled, confirm destination or proxy destination exists.
- If any Premiere automation feature is enabled, confirm Premiere is open with a project loaded and the CEP panel is connected.
- Read the panel log for messages about:
  - missing destination
  - source scan timeout
  - source scan truncation
  - Premiere connection required

### Fix steps
1. Re-select the source files.
2. Re-select the destination folder.
3. Re-select the backup folder if backup is enabled.
4. Turn off Import into Premiere / Create Premiere Bins / Generate Proxies if the user only wants copy or backup behavior.
5. Reconnect the Premiere CEP side before retrying.
6. If source scan timed out, reduce the selection and run a smaller batch.

## Symptom: Adobe Automate says Premiere connection is required
Common user wording:
- "It says the Premiere CEP panel has to be connected."
- "Reconnect doesn't fix it."
- "Bridge only, not connected."

### Most likely causes
- Premiere Pro is not open.
- Premiere is open but no project is loaded.
- The Lead AE Assist CEP panel is not installed.
- The CEP panel is installed but not open.
- The local Assist bridge is unavailable or stale.
- Another copy of the app is holding the Premiere connection port.

### Fast checks
- Open **Preferences** and look at **Adobe Premiere Panel (CEP)** status.
- Use **Install/Repair Panel** if the panel is missing.
- Open Premiere Pro and load a project.
- Open the Lead AE Assist CEP panel inside Premiere.
- Return to Adobe Automate and click the reconnect icon.
- Check the Adobe Automate log for messages like:
  - `Adobe Automate requires the Premiere CEP panel to be connected`
  - `Bridge unavailable`
  - `Connection port ... is already in use`
  - `heartbeat failed`
  - `handshake failed`

### Fix steps
1. Open **Preferences -> Adobe Premiere Panel (CEP)**.
2. Use **Install/Repair Panel**.
3. Open Premiere Pro and load a project.
4. Open the Lead AE Assist panel inside Premiere.
5. Return to Adobe Automate and click the reconnect icon.
6. If the log mentions the connection port being in use, fully quit duplicate app instances and retry.

See **Install and connect the Premiere CEP panel** for the clean setup path.

## Symptom: A preset loads, but the job asks for access again or paths suddenly fail
Common user wording:
- "The preset loaded, but Start says it cannot access the folder."
- "Why does it ask for permission again?"
- "The path is there. It just won't use it."

### Most likely causes
- Saved configs preserve paths, but they do **not** preserve the app's folder-access approval state.
- The drive/path moved or is no longer mounted.
- The saved proxy preset `.epr` path no longer exists.

### Fast checks
- Re-select the destination, backup, and proxy destination manually.
- Re-load the `.epr` preset if one was used.
- Check whether the source and destination volumes are still mounted.
- Look for approval prompts that were cancelled.

### Fix steps
1. Re-select the source files.
2. Re-select destination, backup, and proxy destination.
3. Re-load the `.epr` file if needed.
4. Retry the job and accept any access prompts.
5. If the path still fails, verify the volume is mounted and the folder still exists.

## Symptom: The job is blocked by duplicate filename collisions
Common user wording:
- "It says there is a collision even though the files are in different folders."
- "Why won't it ingest both cards?"
- "Proxy collision detected."

### Most likely causes
- Two different source files share the same basename, so they would map to the same destination filename.
- Backup would create the same collision.
- Proxy generation would create the same `<base>_Proxy.<ext>` name for multiple sources.

### Fast checks
- Compare basenames only, not full folder paths.
- Look for same-name clips from different cards or days.
- Check whether the selected proxy preset would give the same output extension for multiple items.

### Fix steps
1. Rename the clashing source files before running the job.
2. Split the selection into separate runs.
3. Use different destination roots for different source groups.
4. Do not tell the user "it should be fine because the folders are different." The app is protecting them from an overwrite mess.

## Symptom: Some files are greyed out, marked Not importable, or never reach Premiere
Common user wording:
- "The file is dimmed."
- "Import is disabled for some clips."
- "Why didn't all files import?"

### Most likely causes
- The file is a known non-importable project/session type such as `.aep`, `.prproj`, or `.sesx`.
- Import was manually turned off for that file.
- Verification failed and the file was excluded from later Premiere work.
- The file was removed from the current job with the **x** button.
- The source scan failed or the file disappeared before queueing.

### Fast checks
- Look at the per-file row in **Unassigned Files**.
- Check whether the **Import** checkbox is off.
- Check whether the file says **Not importable**.
- Check the log for verification failures.

### Fix steps
1. Remove non-media project/session files from the source selection.
2. Re-enable Import for files that were manually turned off.
3. Resolve verification failures before expecting Premiere import.
4. Re-add files that were removed by mistake.

## Symptom: Add Sub Bin does not work, or files will not stay in bins
Common user wording:
- "Add Sub Bin does nothing."
- "The bin list vanished."
- "My file assignments disappeared."

### Most likely causes
- No parent bin was selected before pressing **Add Sub Bin**.
- **Create Premiere Bins** is off, which hides the bin/file assignment UI.
- The source list changed, which can invalidate previous assignments for removed files.

### Fast checks
- Confirm **Create Premiere Bins** is on.
- Confirm a parent bin is selected before adding a sub-bin.
- Confirm the file is still present in the current source list.

### Fix steps
1. Turn **Create Premiere Bins** on.
2. Select the parent bin.
3. Add the sub-bin again.
4. Reassign files after any major source-list change.

## Symptom: Proxies did not generate, or they generated but did not attach
Common user wording:
- "No proxies showed up."
- "The proxies exist on disk but Premiere didn't attach them."
- "It just sits on proxies."

### Most likely causes
- The Premiere CEP side is not connected.
- The proxy destination is missing or unwritable.
- The selected `.epr` file no longer exists.
- AME is unavailable or stalled.
- FFmpeg fallback was disabled, so the job could not recover.
- No files remained proxy-eligible after verification or per-file toggles.
- The user expected the chosen proxy folder to be the final folder, but the backend created a `Proxies` subfolder.

### Fast checks
- Confirm **Generate Proxies** is on.
- Confirm Premiere CEP connection is healthy.
- Confirm where the effective proxy folder actually is:
  - explicit proxy folder ending in `Proxies`, or
  - selected proxy base + `/Proxies`, or
  - destination + `/Proxies`
- Confirm the per-file **Proxy** toggles are on for the needed files.
- Check the log for phrases like:
  - `Match Source (FFMPEG)`
  - `Dispatching AME proxy job`
  - `AME not detected`
  - `FFmpeg fallback engaged`
  - `Attached ... proxy file(s)`

### Fix steps
1. Reconnect the Premiere CEP panel.
2. Re-check the actual proxy output folder.
3. Re-load the `.epr` file if a real AME preset is intended.
4. Leave FFmpeg fallback enabled unless the user has a deliberate reason not to.
5. If the user does not care about AME specifically, switch to **Match Source (FFMPEG)** and retry.
6. Verify attachment in Premiere's Proxies column, not just on disk.

## Symptom: The job says Match Source (FFMPEG), but the user expected AME
Common user wording:
- "Where did my preset go?"
- "Why is this using FFmpeg?"
- "I thought Match Source was an Adobe preset."

### Most likely causes
- The selected proxy mode is the virtual **Match Source (FFMPEG)** option.
- No real `.epr` preset is selected.
- AME was unavailable and the job fell back to FFmpeg.

### Fast checks
- Open the proxy preset dropdown.
- Check whether the selected item literally says **Match Source (FFMPEG)**.
- Check the log for FFmpeg fallback messages.

### Fix steps
1. If the user wants Adobe Media Encoder specifically, select a real `.epr` preset.
2. If the user wants a simple working proxy path, Match Source is valid and expected.
3. Do not call Match Source a broken preset. It is a different mode.

## Symptom: The webhook is rejected or never fires
Common user wording:
- "Webhook enabled but nothing happened."
- "It says the URL is invalid."
- "Why won't it send to localhost?"

### Most likely causes
- The URL is blank.
- The URL is not a full `http://` or `https://` address.
- The target is localhost/private network and **Allow private webhook targets** is off.
- The remote server rejected the request or timed out.

### Fast checks
- Confirm the exact URL in the field.
- Confirm whether the target is localhost/private.
- Check whether **Allow private webhook targets** is on.
- Look for log messages about validation, timeout, or HTTP response status.

### Fix steps
1. Use a full `http://` or `https://` URL.
2. Turn on **Allow private webhook targets** only if the user really intends to hit localhost/private infrastructure.
3. Retry and inspect the panel log for the returned status.

## Symptom: Save Log did not create the file where the user expected
Common user wording:
- "I turned on Save Log and I still can't find it."
- "Where is AdobeAutomateLog?"
- "The panel log disappeared."

### Most likely causes
- The user is looking only in the destination folder and not in the raw app log library.
- The run ended differently than the user expected.
- The user is looking in the selected proxy base instead of the actual destination.
- The on-panel log was hidden, but raw logs still exist.

### Fast checks
- Check `LeadAEAssist/logs/adobe-utilities/` first.
- Then check the destination for `AdobeAutomateLog_<timestamp>.txt`.
- In backup-only, no-proxy cases, also check the backup folder.
- Confirm **Save Log** was on before the run started.

### Fix steps
1. Start with the raw log library.
2. Then inspect destination-side log copies.
3. If support needs a reliable artifact, ask for the raw `.jsonl` and `.txt` job files from `logs/adobe-utilities/`.

## Symptom: Cancel does not seem instant
Common user wording:
- "I clicked Cancel and it kept working."
- "It says cancel requested."
- "Why is it still running?"

### Most likely causes
- Cancel is a backend queue request, not a magic freeze button.
- The UI waits for queue confirmation and final completion/cancel events.
- Proxy jobs may be waiting for CEP/AME/FFmpeg cleanup before they fully settle.

### Fast checks
- Look for `Cancel requested` in the log.
- Wait for either a cancelled state or a final completion/failure state.
- Check whether the job is currently in copy, import, proxies, or attach stages.

### Fix steps
1. Treat cancel as asynchronous.
2. Wait for the backend confirmation message.
3. If the job is truly wedged on the proxy stage, collect the raw Adobe Automate logs and note whether FFmpeg fallback was enabled.

## Related pages
- /panels/adobe-automate/
- /workflows/adobe-automate-copy-import-bins-proxies/
- /workflows/install-and-connect-premiere-cep-panel/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
