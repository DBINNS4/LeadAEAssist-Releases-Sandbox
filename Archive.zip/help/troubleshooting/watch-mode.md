# Troubleshooting - Watch Mode

## What this page covers
This page is for shared Watch Mode behavior across panels.
Use the panel-specific troubleshooting page when the problem is obviously Ingest-, Transcode-, or Transcribe-specific.

## Symptom: Start Watching is disabled or fails immediately
### Most likely causes
- No watch folder is selected.
- The selected path is not a folder.
- The output/destination path is missing or invalid.
- The output/destination path is inside the watch folder.
- The watcher module is unavailable in the current environment.

### Fast checks
- Confirm the source is one folder.
- Confirm the output path is a folder.
- Confirm the output path is outside the watch folder.
- Check the log for module-unavailable or folder-access messages.

### Fix steps
1. Re-select the watch folder.
2. Re-select the output/destination folder.
3. Move the output/destination outside the watch folder.
4. Restart Watch Mode after path changes.

## Symptom: New files arrive and nothing happens
### Most likely causes
- The files are still being written and have not passed stability checks yet.
- The panel ignores the file type or source state for that workflow.
- The watch session is running, but the destination/output path became invalid.
- The user expected Watch Mode to process files that were already present before the watcher started.

### Fast checks
- Confirm whether the panel has a **Process existing files on start** style control or behavior for that workflow.
- Confirm the files are fully copied and no longer growing.
- Check the watch session log in the app log library.
- Check whether the panel-specific output/destination path is still mounted and writable.

### Fix steps
1. For pre-existing files, restart the watcher under the panel's supported startup behavior.
2. Wait until incoming files are fully written.
3. Revalidate the output/destination path.
4. Review panel-specific filters or mode rules.

## Symptom: Stop Watching seems stuck
### What is usually happening
Stopping the watcher does not always mean immediate finalization.
The app can wait for already queued or in-progress watch-triggered jobs to finish or cancel before archiving the watch session log.

### Fast checks
- Check whether a watch-triggered job is still active.
- Check whether the log says it is waiting for jobs to finish/cancel before archiving.

### Fix steps
1. Let active watch-triggered jobs finish, or cancel them if appropriate.
2. Wait for the session log to archive before assuming Stop failed.

## Symptom: The watch log is hard to find
### Where to look first
Raw watch/session logs live in the app log library under the panel folder, for example:
- `LeadAEAssist/logs/ingest/`
- `LeadAEAssist/logs/transcode/`
- `LeadAEAssist/logs/transcribe/`

### Important panel differences
- **Ingest** can export a `WatchLog_...` copy to destination and backup when Save Log is on and the user stops watching.
- **Transcode** currently archives the session log in the app log library, but does not appear to mirror that export into the transcode output folder.
- **Transcribe** also archives watch/session logs in the app log library and does not currently expose a destination-side Save Log path like Ingest.

That difference is real and worth knowing before support gives the user the wrong scavenger hunt.

## Related pages
- /troubleshooting/ingest/
- /troubleshooting/transcode/
- /troubleshooting/transcribe/
- /reference/logs-and-support-bundle/
