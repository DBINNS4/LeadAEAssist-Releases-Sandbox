# Troubleshooting - Preferences

## How to use this page
Start with the symptom the user actually sees.
Preferences problems usually fall into a few buckets:
- load/migration warnings
- auto-save failures
- Offline Mode side effects
- AI API key issues
- webhook validation issues
- maintenance confusion
- CEP installer problems

Do not start by asking for the user’s secret key.
That is support malpractice with extra sparkle.

## Symptom: The Preferences tab is missing from the sidebar
Common user wording:
- “I don’t have Preferences anymore.”
- “The settings tab disappeared.”
- “I can’t open Preferences.”

### Most likely causes
- The feature is hidden by license gating.
- The entitlement changed and the UI recalculated visible tabs.
- The app is running in a state where license/entitlement visibility is stale.

### Fast checks
- Ask the user what plan/license state they currently have.
- Ask whether **Account & Licensing** and **Log Viewer** are also missing.
- Have the user relaunch the app after syncing or reinstalling the license if a license event just happened.

### Fix
1. Confirm the current entitlement actually includes the Preferences feature.
2. If the user just changed license state, relaunch the app.
3. If needed, use **Account & Licensing** to sync/install the entitlement and retry.

### What to collect for support
- app version
- current license tier / status
- screenshot of the sidebar

## Symptom: A warning says unsupported legacy keys were ignored while loading Preferences
Common user wording:
- “Settings loaded with a warning.”
- “It says legacy keys were ignored.”
- “Preferences loaded but showed a weird warning.”

### What this usually means
The app found old or unsupported keys in the stored preferences object.
The loader sanitized them and kept the supported values.

That is often a **recoverable migration warning**, not a hard failure.

### Fast checks
- Ask whether the user upgraded from an older build recently.
- Confirm the rest of the panel loaded normally.
- Check whether the warning is informational only and not paired with a persistent save failure.

### Fix
Usually none.
If the panel loads and saves afterward, the state was likely cleaned successfully.

### Escalate when
- the warning appears every launch
- settings keep disappearing after load
- save failures happen immediately afterward

### What to collect for support
- screenshot of the warning
- `LeadAEAssist/config/state.json`
- app version

## Symptom: The panel shows a red save error banner or acts “unsaved”
Common user wording:
- “My settings won’t save.”
- “It keeps showing an error.”
- “I changed a checkbox and now it has a red warning.”

### Most likely causes
- invalid webhook URL
- invalid temp max age value
- preferences persistence failure
- runtime crash-reporting toggle failure
- AI API key write failure after the normal preferences already saved

### Fast checks
- Read the exact save-error text.
- Check whether the user edited the webhook URL.
- Check whether the user edited the AI API key at the same time.
- Check whether **temp max age** is outside `0–3650`.
- Check whether the error mentions “session only,” crash reporting, key storage, or a save failure.

### Fix
1. Correct any invalid webhook URL.
2. Correct any invalid temp-age value.
3. Retry one change at a time instead of several at once.
4. If the problem is API-key-specific, test a normal checkbox change separately from the API key.
5. If the error mentions crash reporting, treat that as a crash-reporting problem first.

### Support note
The save order matters.
If the error happens after the normal preferences were already persisted, the banner can still appear even though some non-secret settings already changed successfully.

## Symptom: Offline Mode is on, and now updates, billing, sync, or remote automation stopped working
Common user wording:
- “Check for Updates says disabled.”
- “Subscription sync stopped.”
- “Webhooks stopped firing.”
- “Whisper API stopped working.”

### Most likely causes
- Offline Mode is enabled.
- The webhook target is remote, not localhost.
- The user expects online services to continue while the app is in no-network mode. That is not how this knob works.

### Fast checks
- Look at the **Enable Offline Mode** checkbox.
- Read the update status line.
- Check whether the webhook target is `localhost` or a real remote host.
- Ask whether the transcription engine is Whisper API.

### Fix
1. Disable Offline Mode if the workflow depends on network access.
2. Retry the blocked action:
   - update check
   - entitlement sync
   - billing portal
   - webhook-triggered automation
   - Whisper API transcription
3. If the workflow is intentionally local-only, use a `localhost` endpoint instead of a remote URL.

### Support note
Offline Mode stores the URL but disables remote execution.
That is why the field can still look filled in while nothing fires.

## Symptom: The AI API key field is blank, but the user says a key was already saved
Common user wording:
- “My key disappeared.”
- “The field is empty after restart.”
- “Did the app erase my key?”

### What is usually happening
This is expected.
The app never repopulates the actual secret value into the field.

A previously saved key is shown by placeholder state, not by printing the key back out.

### Fast checks
- Check the field placeholder.
- Ask whether it says:
  - `Saved (enter a new key to replace)`

### Fix
Usually none.
A blank field alone does not mean the key is gone.

### Replace or remove the key
- type a new key and let the field auto-save, or
- clear the field and save to delete it

## Symptom: The API key still will not save
Common user wording:
- “It saved my other settings but not the key.”
- “The API key failed.”
- “It says key storage failed.”

### Most likely causes
- saved-key write failure
- invalid webhook URL blocked the full save before the key write could start
- normal preferences save failed first, so the key write never started

### Fast checks
- Check whether the error text mentions secure store, vault, or delete/write failure.
- Check whether the webhook URL is invalid at the same time.
- Try saving a non-secret checkbox first to see whether ordinary preferences work.

### Fix
1. Fix any invalid webhook URL first.
2. Save a simple non-secret setting and confirm it succeeds.
3. Retry entering the API key.
4. If the key still will not save, escalate with environment details rather than asking the user to expose the secret.

### What to collect for support
- exact error text
- platform
- whether other preferences save correctly
- whether the field is trying to save a new key or remove an old one

## Symptom: Webhook Logging / Send Only on Failure is disabled or keeps turning off
Common user wording:
- “Those webhook checkboxes are greyed out.”
- “It unchecks them as soon as I type.”
- “Why can’t I enable webhook logging?”

### Most likely causes
- the URL field is blank
- the URL is invalid
- the protocol is not `http` or `https`

### Fast checks
- Make sure the field contains a full URL.
- Check for missing protocol.
- Check for malformed hostnames.

### Fix
1. Enter a valid `http://` or `https://` URL.
2. Move focus out of the field.
3. Re-enable the logging / failure checkbox.

### Support note
An invalid URL blocks more than just webhook settings.
It can also stop unrelated changes from saving because the panel validates before persisting.

## Symptom: The user clicked Clear Temp Now, but it removed little or nothing
Common user wording:
- “Clear Temp didn’t do anything.”
- “It says 0 B freed.”
- “The temp folder still has files.”

### Most likely causes
- the **temp max age** value is set high, so recent files are excluded
- the files are not old enough
- the user expected Clear Temp to be a full wipe
- remaining items are in cache or logs, not temp

### Fast checks
- Read the current **Delete temp entries older than (days)** value.
- Check whether the remaining files are actually under `LeadAEAssist/temp/`.
- Verify the user is not looking at cache or log folders instead.

### Fix
1. Reduce the age threshold.
2. Use `0` if the goal is “clear basically everything temp-like now.”
3. Run **Clear Temp Now** again.
4. Use **Clear Cache Now** separately for cache artifacts.

### Support note
The button label is a little too optimistic.
The actual cleanup obeys the age filter.

## Symptom: Update controls look wrong or the expected button is missing
Common user wording:
- “Download never appears.”
- “Restart & Install is missing.”
- “Check for Updates is disabled.”

### Most likely causes
- Offline Mode is enabled.
- No update is available.
- Automatic download is on, so the app is already handling the download path without showing the manual Download button.
- The update feed is empty or there are no published versions yet.

### Fast checks
- Read the **update status** line.
- Check **Offline Mode**.
- Check whether **Automatically download updates** is enabled.
- Ask whether the user already downloaded an update in this session.

### Fix
- If Offline Mode is on, turn it off and retry.
- If auto-download is on, wait for the status to change to progress or downloaded.
- If no update is available, there is nothing to download.
- If the feed is empty, treat it as “no update” unless there is separate evidence of a broken release channel.

## Symptom: Install/Repair Panel failed or the panel still does not appear in Premiere
Common user wording:
- “CEP install failed.”
- “Preferences says installed, but I still don’t see the panel.”
- “Open CEP Folder works, but Premiere doesn’t load it.”

### Most likely causes
- install/repair failed writing the user CEP extension folder
- Premiere was still open during install and did not reload the extension
- the wrong CEP folder was inspected
- the panel files exist but Premiere needs a restart
- the saved panel connection is stale on the Adobe side

### Fast checks
- Read the CEP status line and any CEP error message.
- Click **Open CEP Folder** and confirm the folder exists.
- Fully quit and relaunch Premiere.
- Reopen the Premiere project.
- Reconnect from Adobe Automate after Premiere loads the panel.

### Fix
1. Retry **Install/Repair Panel**.
2. Open the CEP folder and confirm `com.leadae.panel` exists.
3. Quit and relaunch Premiere.
4. Open the Lead AE Assist panel inside Premiere.
5. Retry the Adobe Automate connection.

### What to collect for support
- CEP status text
- CEP error text
- screenshot of the user CEP folder contents
- Premiere version
- whether Install/Repair or Uninstall was just run

## Symptom: Reset succeeded, but the app still thinks an API key exists
Common user wording:
- “I reset everything, but it still says a key is saved.”
- “Preferences reset, but the key didn’t go away.”

### Most likely causes
- the normal reset succeeded
- the saved key could not be deleted afterward

### Fast checks
- Read the reset warning text carefully.
- Check whether the warning says the saved API key may still be present.

### Fix
1. Retry the reset once.
2. If the warning persists, treat it as a saved-key deletion issue, not a general preferences reset issue.

### What to collect for support
- exact warning text
- platform
- whether non-secret preferences reset correctly

## Symptom: Theme keeps switching back or reset did not change the theme
Common user wording:
- “I changed it in Preferences, then it flipped back.”
- “Reset didn’t return the default theme.”

### Most likely causes
- the top-bar theme toggle and local-storage theme state are synchronizing back over the saved preference
- the save failed and the previous theme remained authoritative

### Fast checks
- Toggle the theme from the top bar once.
- Then change it once from Preferences.
- Confirm the save banner is clear.

### Fix
1. Use either the top-bar toggle or the Preferences dropdown once.
2. Let the change save cleanly.
3. Reopen the panel and verify both controls now agree.

## What to collect for support
For Preferences-specific support, the most useful artifacts are usually:

- screenshot of the panel, including any red save banner
- app version
- `LeadAEAssist/config/state.json`
- `LeadAEAssist/config/state.json.bak` if present
- screenshot of the CEP status area for Premiere-panel issues
- the exact maintenance status text for temp/cache problems

### Secret-handling rule
Do **not** ask the user to paste:
- the real AI API key
- raw decrypted secret-store contents

If support truly needs sensitive storage files, request them explicitly and carefully because they may still contain sensitive data.
