# Troubleshooting - Speed Test

## How to use this page
Start with the symptom.
Do not start with "the NAS feels cursed" or "the internet is broken again" unless you enjoy debugging by poetry.
The panel is specific enough that most failures fall into a small number of real buckets.

## Symptom: Run Network Test is disabled or the summary says the browser dependency is being prepared
Common user wording:
- "The button is greyed out."
- "It says preparing browser dependency."
- "It looks stuck before the test even starts."

### Most likely causes
- The app is preparing the browser component required for FAST.com.
- A previous browser-component setup attempt failed.
- Offline Mode is preventing a needed asset download.

### Fast checks
- Read the Summary box, not just the button state.
- Check whether the message mentions download, verify, install, checksum, or offline mode.
- Confirm whether the machine currently has internet access.
- Confirm whether Offline Mode is enabled.

### Fix steps
1. If the Summary clearly shows a dependency state, let that state finish or fail cleanly first.
2. If the message says Offline Mode is blocking the download, disable Offline Mode and retry.
3. If the message says the browser dependency is missing, failed verification, or failed installation, relaunch the app and retry.
4. If the same failure repeats, reinstall the app or repair the required browser component.
5. Collect the raw Speed Test logs if support needs to inspect the dependency state transitions.

## Symptom: The panel says License required
Common user wording:
- "It won't run at all."
- "It says license required for speed test."

### Most likely causes
- The active entitlement does not include the Speed Test feature.
- The app could not validate the entitlement state cleanly.

### Fast checks
- Open **Account and Licensing**.
- Copy version info.
- Confirm the user is signed into or using the expected licensed build/account.

### Fix steps
1. Verify the user's entitlement status in **Account and Licensing**.
2. If the build or account is wrong, correct that first.
3. If the user should have access but does not, treat it as a licensing/support issue, not a benchmark-engine issue.
4. Collect version info and entitlement screenshots before escalating.

## Symptom: The panel says Offline Mode is enabled and the network test is unavailable
Common user wording:
- "Drive tests work, but network test will not run."
- "It says Offline Mode blocks it."

### Most likely causes
- Offline Mode is enabled on purpose.
- The user forgot that Offline Mode affects only the network half of the panel.

### Fast checks
- Confirm that only **Network Test** is blocked.
- Confirm that **Drive Test** still runs.

### Fix steps
1. Disable Offline Mode.
2. Retry **Run Network Test**.
3. If the network section still fails, continue with the relevant browser-dependency or parse-error symptom below.

## Symptom: Network test fails with unreadable output, parse error, or a generic FAST.com failure
Common user wording:
- "It starts and then says the result was unreadable."
- "It failed but not with a normal speed result."
- "The network is fine, but this test still bombs."

### Most likely causes
- FAST.com is blocked by VPN, captive portal, firewall, DNS filtering, or corporate proxy behavior.
- The test tool returned non-JSON output.
- Chromium launched, but the external service flow did not return the expected result shape.

### Fast checks
- Check whether the machine is on a VPN or filtered corporate network.
- Check whether a captive portal is still intercepting traffic.
- Retry on a different network if available.
- Confirm the issue is only with **Network Test**, not general internet access.

### Fix steps
1. Temporarily disable VPN or traffic filtering if policy allows.
2. Retry the test on a known-clean connection.
3. If the same machine works on another network, the original network path is the problem, not the panel.
4. Export or collect the Speed Test raw logs so support can see the parse failure details.

## Symptom: Network test times out
Common user wording:
- "It spins forever and then fails."
- "It times out after a while."

### Most likely causes
- The FAST.com flow never completed within the app's timeout window.
- The network path is too restricted, unstable, or heavily filtered.
- Chromium launched but the test process stalled.

### Fast checks
- Retry once on the same network.
- Retry on another network if possible.
- Check whether VPN or captive portal conditions are present.

### Fix steps
1. Retry once to rule out a transient network wobble.
2. If the timeout repeats, test from another network path.
3. If the test works elsewhere, document the failing network environment and stop blaming the app.
4. Collect the raw Speed Test logs for the failed timeout attempt.

## Symptom: Network cancel does not look immediate
Common user wording:
- "I hit cancel and it did not vanish instantly."

### Most likely causes
- Cancel is waiting for the dependency-prep request or child process shutdown to settle.
- The UI is intentionally trying to exit cleanly, not tear down the world with a hammer.

### Fast checks
- Confirm the Cancel button switched into a busy state.
- Confirm the Summary eventually changes to a cancelled or final error message.

### Fix steps
1. Use Cancel only once; repeated clicking is not helpful.
2. If the test remains wedged after the cancel attempt resolves, relaunch the app.
3. Collect logs if cancellation repeatedly fails to resolve cleanly.

## Symptom: Drive test says to select a drive first
Common user wording:
- "It won't start."
- "I clicked Test Selected Drives and it told me to pick a drive."

### Most likely causes
- No drive path is currently selected.
- The user expected the panel to remember previous selections, but it had already been reset or auto-cleared after a successful run.

### Fast checks
- Check the three drive path boxes.
- Confirm at least one box shows a real path instead of **No drive selected**.

### Fix steps
1. Click **Select Drive 1**, **2**, or **3**.
2. Choose a writable folder on the actual target path you want to benchmark.
3. Retry the batch.

## Symptom: Drive test fails with insufficient free space
Common user wording:
- "It says I do not have enough room."
- "Why does a 1 GiB test need more than 1 GiB free?"

### Most likely causes
- The panel adds a safety margin on top of the temporary benchmark footprint.
- Sequential mode can use a larger temporary working set than the user expected.
- The target path is fuller than the user realized.

### Fast checks
- Check the free space on the selected target.
- Reduce the test size and retry.
- Compare whether the failure is happening in Sequential or Random mode.

### Fix steps
1. Reduce **Test Size**.
2. Free space on the selected path.
3. Retry the benchmark.
4. If the path is nearly full because it is production storage, benchmark a safer test folder on the same mounted target after confirming it reflects the same underlying storage path.

## Symptom: Drive test says the drive is read-only or lacks write permissions
Common user wording:
- "It can see the folder but will not benchmark it."
- "It says not writable."

### Most likely causes
- The selected path is read-only.
- The share permissions allow browsing but not temp-file creation.
- Security software or OS permissions are blocking writes.

### Fast checks
- Create and delete a normal text file in the same folder outside the app.
- Confirm the selected path is not mounted read-only.
- Confirm the app still has filesystem access to that location.

### Fix steps
1. Re-select the target folder through the panel so the app refreshes the approved path.
2. Verify write access manually in the same folder.
3. If the share is intentionally read-only, benchmark another writable path on the correct storage target.
4. Retry.

## Symptom: Drive test fails with a lock-marker error or benchmark lock failure
Common user wording:
- "It says it cannot acquire the speed-test lock marker."
- "It mentions a marker or lock file."

### Most likely causes
- The app could not create its active lock file in `.lead-speedtest`.
- Another benchmark left behind an active-looking marker.
- The path allows some writes but blocks the app's lock-file creation pattern.

### Fast checks
- Check whether the selected path contains a `.lead-speedtest` folder.
- Look for leftover `.__lead_speedtest_active_...lock` files.
- Confirm no other Speed Test batch is currently running in another window.

### Fix steps
1. Make sure no other Speed Test batch is running.
2. Re-select the folder and retry.
3. If the same path keeps failing, inspect the hidden `.lead-speedtest` folder.
4. Remove stale lock files only if you have confirmed there is no active benchmark using that path.
5. If the share blocks that file pattern or hidden-folder creation, benchmark another writable folder on the same storage target.

## Symptom: Results are wildly inconsistent, suspiciously fast, or suspiciously slow
Common user wording:
- "The numbers make no sense."
- "This is way too fast."
- "The second run is completely different."

### Most likely causes
- OS cache or storage-controller burst behavior is affecting the run.
- Other heavy disk or network work is happening at the same time.
- The user benchmarked the wrong path.
- VPN, Wi-Fi contention, antivirus, sync tools, or background copy jobs are polluting the results.

### Fast checks
- Re-run the same test size and mode once more.
- Compare results while heavy background activity is stopped.
- Confirm the benchmarked path is the exact path the workflow uses.
- For drive tests, try a larger test size.

### Fix steps
1. Close other heavy I/O or network jobs.
2. Retry using **1 GiB** or **2 GiB** for sustained comparisons.
3. Benchmark the exact mounted share/path your workflow uses.
4. Treat a single weird run as suspicious data, not revelation.
5. If the problem is repeatable, collect the logs and the exact path/mode/size used.

## Symptom: Random mode does not show IOPS
Common user wording:
- "Why am I still seeing MiB/s?"
- "I expected IOPS or latency numbers."

### Most likely causes
- The current build does not render IOPS in the result summary.
- The tooltip talks about random-I/O behavior conceptually, but the output format remains throughput-style.

### Fast checks
- Read the result labels carefully.
- Confirm the panel is still showing Write/Read MiB/s with min/max values.

### Fix steps
1. Treat Random mode as a comparative small-I/O diagnostic, not a literal IOPS meter.
2. Use the same mode and size across targets so the comparison still has value.
3. Do not promise the user an IOPS number the panel does not actually produce.

## Symptom: My selected drive paths disappeared after the run finished
Common user wording:
- "It cleared my selections."
- "Why did the drive boxes blank themselves?"

### Most likely causes
- The batch completed successfully, and the panel intentionally cleared the selections.

### Fast checks
- Confirm the batch actually finished successfully.
- Check whether the Summary box still contains the completed results.

### Fix steps
1. Re-select the paths if you want to run another comparison.
2. Use screenshots, copied notes, or raw logs if you need to preserve exactly which paths were used.
3. Note that cancelled and preflight-blocked runs typically keep the selections, while clean successful runs do not.

## Symptom: I cannot find a saved Speed Test log in the tested folder
Common user wording:
- "Where did the log go?"
- "I expected a Save Log file next to the benchmark target."

### Most likely causes
- Speed Test does not expose a destination-side Save Log export.
- The user is looking in the benchmarked folder instead of the app log library.

### Fast checks
- Open **Log Viewer**.
- Open the app log root or raw `logs/speed-test/` folder.

### Fix steps
1. Look under `LeadAEAssist/logs/speed-test/`.
2. Use **Log Viewer** to export the relevant job if needed.
3. Do not promise a destination-side `SpeedTestLog_...` file. That file pattern does not exist at this time.

## What support should collect
For a Speed Test issue, gather:
- **Copy version info**
- the exact tested path(s)
- whether the issue was **Network** or **Drive**
- test size and mode
- whether Offline Mode was enabled
- whether the Summary mentioned browser dependency download/verify/install
- raw files from `LeadAEAssist/logs/speed-test/`
- screenshots of the Summary box if the user already reset the panel afterwards

## Related pages
- /panels/speed-test/
- /workflows/run-network-speed-test/
- /workflows/compare-drive-targets-with-speed-test/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
