# Troubleshooting - Webhooks and network

## Use this page when
Use this page when a job finishes but a webhook did not fire, a network feature is blocked, or the app behaves as though it is offline even though the machine seems connected.

Typical symptoms:
- webhook test or delivery fails
- update checks do nothing
- Sync Subscription does not refresh
- network speed tests fail
- online AI or billing actions are blocked

## Most common causes
- **Offline Mode** is enabled in [Preferences](/panels/preferences/).
- The destination service is rejecting the webhook URL, method, or payload.
- The machine has DNS, proxy, firewall, or captive-portal nonsense interfering with outbound requests.
- The user expects a local file write or UI action to behave like a network call. Some controls are local-only and never touch the network.
- The app can reach one service but not another, which creates the classic “but the internet works” mirage.

## Fast checks
- Open [Preferences](/panels/preferences/) and confirm whether **Offline Mode** is on.
- If the issue is a webhook, verify the exact URL and whether HTTPS certificates are valid.
- If the issue is a subscription or billing refresh, confirm the user is signed into the same account used during checkout.
- If the issue is a network benchmark, compare with [Speed Test](/panels/speed-test/) and check whether only FAST.com tests are failing.
- Check the relevant log path in [Logs and support bundle](/reference/logs-and-support-bundle/).

## Fix steps
1. Turn **Offline Mode** off if online behavior is expected.
2. Re-run the exact action and capture the timestamp.
3. For webhooks, test the receiving endpoint outside the app if possible so you can separate app behavior from endpoint behavior.
4. Confirm the URL, protocol, and any auth requirements are still correct.
5. If the machine is on a managed network, test again on a simpler network before blaming the app. Corporate firewalls are talented at manufacturing confusion.
6. Collect the related app logs and the receiving service's logs if available.

## Panels and features that commonly hit this issue
- [Ingest](/panels/ingest/)
- [Transcode](/panels/transcode/)
- [Transcribe](/panels/transcribe/)
- [Preferences](/panels/preferences/)
- [Account and Licensing](/panels/account-and-licensing/)
- [Speed Test](/panels/speed-test/)

## What to collect for support
- Exact feature being used
- Whether Offline Mode was on
- Timestamp of the failed attempt
- Full webhook URL host (do not include secrets)
- Logs from the app and, if possible, logs from the receiving service

## Related
- [/troubleshooting/](/troubleshooting/)
- [Preferences](/panels/preferences/)
- [Logs and support bundle](/reference/logs-and-support-bundle/)
