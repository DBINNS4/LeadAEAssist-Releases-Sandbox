# Troubleshooting - Transcode

## How to use this page
Start with the user's symptom, not the control name they clicked three minutes ago and have already misremembered.

## Symptom: Start is disabled or the job will not start
Common user wording:
- "Start does nothing."
- "The button stays greyed out."
- "It flips back and nothing runs."

### Most likely causes
- No input is selected.
- No output folder is selected.
- Watch Mode is on but no watch folder is selected.
- Watch Mode is on but the input is a file list instead of one folder.
- Match Source is on with multiple files or a folder.
- Required format/container/audio settings are missing.
- The webhook URL is invalid.
- Caption attach rules are violated.

### Fast checks
- In the Summary box, confirm input and output are populated.
- If Watch Mode is on, confirm the source is one folder.
- If Match Source is on, confirm there is exactly one video file.
- If captions are attached, confirm there is exactly one input file and Audio Only is off.
- Check the panel log for messages such as:
  - `Please add at least one input file or select a watch folder to start.`
  - `Please select an output folder.`
  - `Match Source requires exactly 1 input file.`
  - `Captions attach requires exactly 1 input file.`
  - `Captions require MXF output.`

### Fix steps
1. Re-select the input.
2. Re-select the output folder.
3. If Watch Mode is enabled, choose one folder, not files.
4. Turn off Match Source unless the job uses one video file.
5. Remove caption attachment unless the job is a single-file MXF caption embed.
6. Re-check output format, container, and audio settings before pressing Start again.

## Symptom: The option I need is missing, greyed out, or locked
Common user wording:
- "The codec is gone."
- "Why is this dropdown empty?"
- "I can see the option but it has a lock."

### Most likely causes
- The current FFmpeg build does not expose that encoder.
- Codex filtered the selection because it is incompatible with the current format.
- The selection is license-gated.
- Audio Only, caption attach, or image sequence mode disabled the field on purpose.

### Fast checks
- Ask what output format is currently selected.
- Check whether Audio Only is on.
- Check whether a caption sidecar is attached.
- Check whether the output is an image sequence.
- If the item has a lock icon, treat it as a license question first.

### Fix steps
1. Choose the output format first, then re-check downstream dropdowns.
2. Turn off Audio Only if the job is meant to be video.
3. Clear the caption sidecar if this is not a caption-embed job.
4. For locked items, confirm the user's license/edition.
5. Do not tell the user to type hidden values into presets. That is how configuration gremlins breed.

## Symptom: Match Source will not stay on or throws an error
Common user wording:
- "It says Match Source needs one file."
- "I turned it on and it turned itself back off."
- "Why is it not allowed on my watch folder?"

### Most likely causes
- Multiple files are selected.
- A folder is selected instead of a file.
- The selected file has no video stream.
- The resolution or frame rate implied by Match Source is license-restricted.

### Fast checks
- Confirm exactly one source file is selected.
- Confirm the file actually has video.
- Check the log for messages like:
  - `Match Source requires a single file input (not a watch folder or multiple files).`
  - `Match Source requires video inputs.`
  - `Resolution "..." is restricted.`

### Fix steps
1. Select one video file only.
2. Turn off Watch Mode.
3. Re-enable Match Source.
4. If the source is audio-only, leave Match Source off.
5. If the matched values are restricted, choose a licensed alternative manually.

## Symptom: Audio Only turned on by itself or video settings are disabled
Common user wording:
- "The video options are greyed out."
- "Why did it switch to audio-only?"
- "I cannot pick a container anymore."

### Most likely causes
- All selected inputs are audio-only files.
- The user manually enabled Audio Only.
- An image sequence output disabled the audio section.
- Caption attach locked some video controls.

### Fast checks
- Check the file-info grid for `Audio only` rows.
- Confirm whether the selected source actually has video.
- Check whether the output is an image sequence.
- Check whether a caption sidecar is attached.

### Fix steps
1. If the job should be video, reselect a video file.
2. If the job is audio-only, leave the mode on and pick the wrapper/output type.
3. If image sequence output is not intended, switch back to a normal container.
4. If captions are attached by accident, clear the caption sidecar.

## Symptom: Caption attach is rejected or the output has no embedded captions
Common user wording:
- "It will not let me attach captions."
- "The output MXF has no captions."
- "Why did it fail when I attached SCC?"

### Most likely causes
- The caption file is not `.mcc` or `.scc`.
- More than one input file is selected.
- Audio Only is enabled.
- The final output is not MXF.
- The job ran, but the output failed the SMPTE-436 ANC stream check.

### Fast checks
- Confirm there is exactly one input file.
- Confirm the caption sidecar path ends in `.mcc` or `.scc`.
- Confirm the container is locked to MXF.
- Check the log for messages like:
  - `Caption file must be .mcc or .scc`
  - `Captions attach requires exactly 1 input file.`
  - `Captions cannot be embedded in audio-only exports.`
  - `no SMPTE-436M ANC data stream found in the output MXF`

### Fix steps
1. Use exactly one input file.
2. Use MCC or SCC only.
3. Leave Audio Only off.
4. Let the panel keep Match Source on and container locked to MXF.
5. Re-run and inspect the raw transcode log if the ANC stream verification fails.

## Symptom: Watch Mode will not start
Common user wording:
- "Start Watching is greyed out."
- "It says Watch Mode needs a folder."
- "It refuses my output folder."

### Most likely causes
- No watch folder is selected.
- The selected path is a file, not a folder.
- The output folder is missing or not writable.
- The output folder is the same as the watch folder or sits inside it.
- The watch utilities failed to load.

### Fast checks
- Confirm there is exactly one input folder.
- Confirm the output path is a folder.
- Confirm the output folder is outside the watch folder.
- Check the log for messages like:
  - `Watch Mode requires exactly one selected input folder.`
  - `Watch Mode requires a folder to watch.`
  - `Output folder cannot be the watch folder or inside it.`
  - `Watch Mode is unavailable (watch module not loaded).`

### Fix steps
1. Clear the input and select one watch folder.
2. Set a valid output folder outside the watch folder.
3. Stop and restart Watch Mode after path changes.
4. If the watch module is unavailable, treat it as an environment/build issue, not operator error.

See **Troubleshooting - Watch Mode** for the shared watch behaviors.

## Symptom: The job aborts for disk space or preflight
Common user wording:
- "It says not enough disk space."
- "Preflight blocked the job."
- "The estimate looks too big."

### Most likely causes
- The output volume really is too full.
- The batch estimate is based on the total selected files, not just the largest one.
- Some inputs were skipped during preflight because metadata/stat reads failed, producing a warning.

### Fast checks
- Read the full preflight message in the log.
- Confirm the selected output folder is on the expected volume.
- Check whether the estimate message mentions skipped files or missing output folder checks.

### Fix steps
1. Free space on the output volume.
2. Move the output to a larger volume.
3. Reduce the batch size.
4. Re-run after confirming the output folder is correct.

## Symptom: Verification was skipped, auto-switched, or the output was deleted
Common user wording:
- "Why didn't it run SSIM?"
- "Why was the file deleted after completion?"
- "Why does it say metadata verification only?"

### Most likely causes
- The job changed frame rate or geometry, so SSIM/PSNR auto-fell back to metadata.
- The job was audio-only.
- The output was an image sequence.
- The job used caption attach mode.
- Metadata verification detected a severe mismatch and marked the output for deletion.

### Fast checks
- Check whether the job changed resolution or frame rate.
- Check whether the output is audio-only or image sequence.
- Check whether a caption sidecar was attached.
- Look for messages like:
  - `Auto-switched to Metadata verification`
  - `Verification skipped for audio-only output.`
  - `Image sequence output: audio is disabled and file-based verification is skipped.`
  - `Verification failed; output marked as failed and will be removed.`

### Fix steps
1. Use Duration / Frame when the job intentionally changes geometry or rate.
2. Do not expect SSIM/PSNR on audio-only or image-sequence jobs.
3. Use the raw log to see whether the output was deleted for a real metadata mismatch.
4. If the workflow requires a kept partial file for debugging, note that the app prefers cleanup over preserving obviously bad outputs.

## Symptom: Save Log did not create the file the user expected
Common user wording:
- "I turned on Save Log and nothing showed up."
- "Where is my transcode log?"
- "Why is there no WatchLog in the output folder?"

### Most likely causes
- The user expects manual and watch logging to behave the same.
- Save Log was off.
- The user is looking in the output folder for a watch session log that is only archived in the app log library.

### Fast checks
- For manual jobs, look in the chosen output folder for `TranscodeLog_<timestamp>.txt`.
- For all jobs, check `LeadAEAssist/logs/transcode/`.
- If this was Watch Mode, confirm whether the user stopped the watcher and allowed in-flight watch jobs to finish.

### Fix steps
1. For manual jobs, check the output folder first.
2. For watch jobs, open the app log library and inspect `logs/transcode/`.
3. Use Log Viewer or raw logs if the user expected an Ingest-style destination export.

## Symptom: Output names are suffixed or look different from the source
Common user wording:
- "Why did it add `_000`?"
- "Why is there a `_01` on the file?"
- "Why was the filename cleaned up?"

### Most likely causes
- Batch jobs add numeric suffixes to keep outputs distinct.
- Existing output names triggered collision avoidance.
- Illegal filename characters were sanitized.

### Fast checks
- Confirm whether this was a batch job.
- Confirm whether a file with the target output name already existed.
- Check whether the original source name contained invalid filesystem characters.

### Fix steps
1. Explain that batch jobs intentionally suffix outputs.
2. Explain that collision avoidance adds another suffix when the target name already exists.
3. If stable naming is required for downstream systems, define and document that expectation before the job runs.

## Symptom: Webhook URL is rejected
Common user wording:
- "The webhook URL is correct and it still fails."
- "Why won't it take localhost?"
- "Why does HTTP work in dev but not in production?"

### Most likely causes
- The URL is not a full `http://` or `https://` address.
- The hostname is missing.
- The target is private/localhost and the private-target toggle is off.
- Some installations require HTTPS.

### Fast checks
- Confirm the full URL including protocol.
- Confirm the hostname exists.
- Check whether **Allow private or localhost targets** is enabled for private-network addresses.

### Fix steps
1. Rewrite the URL as a full address.
2. Turn on the private-target option only when the endpoint is intentionally on a local or private network.
3. Use HTTPS unless this is explicitly a local test environment.

## Related pages
- /panels/transcode/
- /troubleshooting/watch-mode/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
