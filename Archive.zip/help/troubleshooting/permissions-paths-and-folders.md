# Troubleshooting - Permissions, paths, and folders

## Use this page when
Use this page when a job is blocked by file-system rules rather than by codec, AI, or licensing behavior. Typical symptoms:
- a path is rejected even though it looks correct
- the user picked a file where the panel expects a folder
- the destination is inside the source, or vice versa
- a saved config reloads with empty paths
- the app says approval is required again

## Most common causes
- The selected control expects a **folder**, but a file was chosen.
- The selected control expects **files or a folder**, but the current mode narrows that down.
- The path was saved before macOS/Windows approval changed and needs to be re-approved.
- The destination, backup, or proxy location overlaps another protected path in a way the app blocks on purpose.
- The drive is read-only, disconnected, or inaccessible under the current user account.

## Fast checks
- Re-select the path from inside the app instead of pasting it by hand.
- Confirm whether the panel expects a **file**, **multiple files**, or **one folder**.
- Open [File locations](/reference/file-locations/) and confirm the expected output root.
- If the user loaded a preset/config, check whether paths were stripped because approval did not carry forward.
- Check whether **Offline Mode** is being confused with file-system access. They are different beasts.

## Fix steps
1. Reopen the affected panel and identify exactly which control is blocking the job.
2. Re-select the path with the panel's picker.
3. If the job uses more than one location, confirm these are all different where required:
   - source
   - destination
   - backup
   - proxy folder
4. Make sure the destination is not nested inside the source and the source is not nested inside the destination unless that panel explicitly supports it.
5. If the problem started after loading a config or preset, rebuild the path selections by hand once and save the config again.
6. If the user is on macOS and the path still fails, have them grant access again through the app's picker rather than trying to out-stubborn the OS.

## Panels that most often hit this issue
- [Ingest](/panels/ingest/)
- [Transcode](/panels/transcode/)
- [Transcribe](/panels/transcribe/)
- [Adobe Automate](/panels/adobe-automate/)
- [Project Organizer](/panels/project-organizer/)

## What to collect for support
- The exact panel name and mode
- The exact path type that was being chosen
- Whether the path was typed, pasted, loaded from config, or picked in the file dialog
- Relevant entries from [Logs and support bundle](/reference/logs-and-support-bundle/)

## Related
- [File locations](/reference/file-locations/)
- [Troubleshooting - Watch Mode](/troubleshooting/watch-mode/)
- [/troubleshooting/webhooks-and-network/](/troubleshooting/webhooks-and-network/)
