# Troubleshooting - Transcribe

## How to use this page
Start with the symptom the user sees, not the label they half-remember from twenty minutes ago.

## Symptom: Start is disabled or the job will not start
Common user wording:
- "Start does nothing."
- "It flips back and nothing runs."
- "Why won't it queue?"

### Most likely causes
- No files are selected.
- No output folder is selected.
- No output format is selected.
- Watch Mode is on but no watch folder is selected.
- The n8n/webhook URL is invalid.
- The panel is stopping on an SCC preflight warning or a Lead AI asset/bootstrap issue.

### Fast checks
- Look at the Summary box. It should show input, engine, output format, and output folder.
- Confirm there is at least one selected file in normal mode.
- Confirm there is one watch folder in Watch Mode.
- Confirm the output folder is set.
- If webhook logging is enabled, verify the URL is a real `http://` or `https://` address.

### Fix steps
1. Re-select the input.
2. Re-select the output folder.
3. Pick one output format.
4. Turn off Watch Mode unless this is really a folder watcher workflow.
5. Fix or disable the webhook URL.
6. Re-run and read the panel log before changing five other controls and summoning fresh confusion.

## Symptom: Start is blocked while using Lead AI
Common user wording:
- "Lead AI just says preparing models."
- "The summary changed and the job isn't starting."
- "It looks stuck on model prep."

### What is usually happening
Lead AI can require local runtime asset/model preparation before the job can run.
During that step the panel can temporarily repurpose the summary area to show startup status.

### Fast checks
- Confirm the selected engine is **Lead AI**.
- Check whether the summary/log mentions preparing assets or models.
- Wait for the preparation stage to complete before assuming the panel is frozen.

### Fix steps
1. Leave the panel open long enough for asset/model preparation to finish.
2. If the prep fails, capture the panel log and the raw Transcribe log.
3. Treat repeated asset bootstrap failures as an environment/runtime issue, not a user typo.

## Symptom: Translation target is locked to English or will not stay on the chosen language
Common user wording:
- "It keeps switching back to English."
- "Why is the translate target disabled?"
- "I want Spanish output but the dropdown is locked."

### Most likely causes
- The selected engine is not **WhisperAPI**.
- Translation is enabled, but the engine does not support non-English target selection in this UI.

### Fast checks
- Check the selected engine.
- Check the hint text under the Translate section.

### Fix steps
1. Switch the engine to **WhisperAPI** if the job needs a non-English translation target.
2. Re-enable translation.
3. Re-select the target language.
4. If the job only needs transcription in the source language, leave translation off and stop fighting the UI.

## Symptom: Accuracy is greyed out or keeps resetting to Auto
Common user wording:
- "I can't choose Accurate anymore."
- "Why did it lock the accuracy dropdown?"

### Most likely causes
- The selected engine is not **WhisperX**.

### Fast checks
- Check the engine dropdown.
- Check the hint under Accuracy.

### Fix steps
1. Switch back to **WhisperX** if the user explicitly needs Fast/Auto/Accurate control.
2. Otherwise leave Accuracy on `Auto`. That lock is intentional.

## Symptom: Watch Mode will not start
Common user wording:
- "Start Watching fails immediately."
- "It says the output path is invalid."
- "It won't accept my output folder."

### Most likely causes
- No watch folder is selected.
- No output folder is selected.
- No output format is selected.
- The output folder is the same as or inside the watch folder.
- The watch utilities are unavailable in the current build/environment.

### Fast checks
- Confirm the input is one watch folder, not a file list.
- Confirm the output folder is set.
- Confirm the output folder is outside the watch folder.
- Confirm one output format is selected.

### Fix steps
1. Turn Watch Mode off, clean up the input/output paths, then turn it back on.
2. Select one watch folder.
3. Select a different output folder outside the watch folder.
4. Pick one output format.
5. If the watch module itself is unavailable, treat that as a build/runtime problem.

See **Troubleshooting - Watch Mode** for shared watcher behavior.

## Symptom: The preview is blank or Burn-in has no sample text
Common user wording:
- "The preview disappeared."
- "Why is there no burn-in preview?"

### Most likely causes
- No input is selected yet.
- The panel is temporarily using the summary area for Lead AI asset/model prep.
- The selected format is **Burn-in**, which intentionally has no text preview.

### Fast checks
- Confirm files or a watch folder are selected.
- Confirm the engine is not in asset/bootstrap prep mode.
- Check the selected output format.

### Fix steps
1. Select input first.
2. Wait for Lead AI prep to finish if that is active.
3. For Burn-in, stop expecting a text sample. The deliverable is rendered video.

## Symptom: SCC export warns, fails, or makes the user miserable
Common user wording:
- "It says SCC needs 29.97."
- "SCC failed after a long job."
- "Why did selecting SCC change my timecode settings?"

### Most likely causes
- The source media is not near 29.97 fps.
- The FPS override is incompatible with SCC.
- FFprobe could not determine FPS for one or more files.
- SCC was chosen even though the workflow really wanted SRT or VTT.

### Fast checks
- Read the SCC preflight warning closely.
- Check the file-info grid FPS values.
- Check whether an FPS override was set.
- Confirm the downstream workflow truly requires SCC.

### Fix steps
1. If the source is not 29.97, transcode it to an SCC-friendly timebase first.
2. Remove or correct the FPS override.
3. If the downstream system does not explicitly require SCC, switch to SRT or VTT.
4. Re-run after confirming the timecode style and Start TC are appropriate.

### Important note
Selecting SCC can auto-prime timecode/FPS prerequisites. That is intentional, not the UI being haunted.

## Symptom: WhisperAPI job fails with API key or file-size errors
Common user wording:
- "It says OpenAI API key not configured."
- "This file is too large for WhisperAPI."
- "Why does the same file work locally but not with the API engine?"

### Most likely causes
- No OpenAI API key is configured.
- The source file exceeds the API path's size limit.
- The source extension is incompatible and temporary conversion or upload flow fails.

### Fast checks
- Confirm the selected engine is **WhisperAPI**.
- Check whether the log mentions missing API key.
- Check whether the log mentions file size limits.

### Fix steps
1. Configure the OpenAI API key in Preferences or the environment expected by the app.
2. For very large files, use a local engine or split/transcode the media first.
3. Re-run and capture the Transcribe job log if the conversion/upload path still fails.

## Symptom: The output format is wrong or the app only made one deliverable
Common user wording:
- "I asked for captions and subtitles."
- "Why did it only make SRT?"
- "Where is the second export?"

### Most likely causes
- The panel only activates **one output format per job**.
- The user assumed the output-format area was multi-select.

### Fast checks
- Check the output format dropdown.
- Check the job summary line for **Output**.

### Fix steps
1. Explain that this panel runs one output format per job.
2. Run a second job or use a second preset for the other deliverable.
3. Do not promise that hidden preset editing will unlock multi-export magic. It will mostly unlock new support tickets.

## Symptom: Subtitle Editor did not open after export
Common user wording:
- "It finished but the editor never popped open."
- "Edit Subtitle after export didn't work."

### Most likely causes
- **Edit Subtitle after export** was off.
- The chosen output format does not map to a supported subtitle/caption handoff path.
- The export failed before producing a file the editor could open.
- The output folder does not contain the latest subtitle/caption file the handoff code expects.

### Fast checks
- Confirm **Edit Subtitle after export** was enabled before the run.
- Confirm the output format was SRT, VTT, SCC, or MCC.
- Check whether the job produced an output file in the output folder.

### Fix steps
1. Re-enable **Edit Subtitle after export**.
2. Re-run with an editor-friendly subtitle/caption format.
3. If the job failed but still wrote a subtitle file, try opening it manually with **Open Editor…**.
4. If the output file exists and the handoff still fails, capture the panel log and raw job log.

## Symptom: n8n / webhook URL is rejected
Common user wording:
- "The webhook URL is invalid."
- "It won't accept localhost."

### Most likely causes
- The URL is missing `http://` or `https://`.
- The URL has no hostname.
- The target is localhost/private-network and private targets are not allowed.

### Fast checks
- Read the full URL.
- Confirm whether **Allow private or localhost targets** is on.

### Fix steps
1. Enter a full URL.
2. Add a hostname.
3. Enable private targets only when the workflow really uses an local or private-network endpoint.
4. If webhook logging is not critical, turn it off and run the transcription job first.

## Symptom: The log is hard to find
Common user wording:
- "Where did Transcribe put the log?"
- "I checked the output folder and there is nothing there."

### Most likely causes
- The user expects Transcribe to behave like Manual Transcode or Manual Ingest.
- The user is looking only in the output folder.

### Fast checks
- Open the app log library.
- Look in `LeadAEAssist/logs/transcribe/`.
- If this was Watch Mode, look there for the archived session log as well.

### Fix steps
1. Open **Log Viewer** or the raw logs folder.
2. Collect the relevant `.txt` and `.jsonl` files from `logs/transcribe/`.
3. Do not tell the user to hunt for a destination-side `TranscribeLog_...` file unless the app actually grows that feature later.

## Related pages
- /panels/transcribe/
- /workflows/transcribe-watch-folder/
- /workflows/export-broadcast-captions-scc-mcc/
- /workflows/send-output-to-subtitle-editor/
- /troubleshooting/watch-mode/
- /reference/transcribe-output-formats/
- /reference/logs-and-support-bundle/
