# Log Viewer

## What this panel does
Log Viewer is the app's built-in diagnostic console for troubleshooting and post-job review.

It is built to:
- load archived logs from the app's log library
- listen for live log traffic while panels are running
- filter by date, tool, severity, and search text
- open the raw app log folder
- export the filtered result set as TXT, JSON, or CSV

This panel is a **viewer and exporter**, not a log management system.
It does **not** delete raw logs, rewrite them, or search arbitrary folders on the machine.

## Why users end up here
Use Log Viewer when:
- a job failed and you need the exact message history
- the output folder contains a copied log but you also need the raw archive
- a user knows "something went wrong" but does not remember which panel said it
- you need a filtered export instead of a full folder dump
- the app is license-locked but diagnostics are still needed

The licensing system deliberately treats Log Viewer as a recovery surface, so it is expected to stay available when other production panels are restricted.

## Before you start
Confirm these first:
- If the problem is older than today, change the date filter. The default is **Today**.
- If the issue came from Adobe Automate, remember the tool filter label is **Adobe Utilities**.
- If the issue involves startup/runtime behavior, remember **System logs are hidden by default**.
- If the user only has a destination-side copied log, do not assume Log Viewer will see it. The viewer reads the app's log library, not arbitrary output folders.
- Collect **Copy version info** from **Account and Licensing** together with the log export when support asks for it.

## Default starting state
After the panel initializes or after **Reset Viewer**, the panel returns to roughly this baseline:
- View by Date: **Today**
- View by Tool: **All**
- Show Only Errors / Warnings: **Off**
- Include System Logs: **Off**
- Search Logs: blank
- Expand Task Details: **Off**
- Export Format: **TXT**
- Export Folder: blank

Important:
- **Reset Viewer does not delete raw log files.**
- Reset clears the current in-memory view, restores the default filters, clears the chosen export folder, and reloads logs from disk.

## What the viewer actually reads
Log Viewer loads from the app's canonical raw log folder under:

`LeadAEAssist/logs/`

It recursively reads:
- structured log files (`.jsonl`)
- human-readable `.txt` job logs
- archived watch session logs stored in panel log folders

It does **not** do these things:
- scan the user's destination or backup folders
- index copied destination-side log exports automatically
- open or read arbitrary folders outside the app's log library

That means a user can absolutely have a valid `IngestLog_...txt` or `TranscodeLog_...txt` in an output folder while Log Viewer still shows nothing from that folder directly.

## Status states you may see
When the panel is first opened, it can show different empty states.

### Loading logs...
The panel is currently reading archived log files from disk.

### No logs yet.
The raw log library did not return any archived logs.

### No logs found.
The panel loaded logs, but the current filters returned zero matches.

That difference matters. "No logs yet" is a library-empty state.
"No logs found" is usually a filter problem.

## What each line means
Rendered log lines are shown in this basic shape:

`[date][panel][jobId][stage][LEVEL] message`

Examples of what those fields mean:
- **date** - local timestamp used for sorting and display
- **panel** - the emitting panel or subsystem
- **jobId** - the job identifier when one exists
- **stage** - the current job phase, such as copy, transcode, verify, complete, or runtime
- **LEVEL** - INFO, WARN, or ERROR in normal app use

Important:
- In normal app use, **debug-level entries are hidden**.
- Some older plain-text logs do not contain full structured fields, so jobId or stage can show as `-`.

## Panel map

### Log Filters

**View by Date**  
Options:
- Today
- Last 7 Days
- Custom Range

Behavior:
- The start/end date fields stay hidden until **Custom Range** is selected.
- There is no dedicated "All dates" shortcut in the current UI.
- If support needs older history, switch to **Custom Range** and set a wide span.

**Start Date / End Date**  
These only affect results when **Custom Range** is active.

**View by Tool**  
Options currently include:
- All
- Ingest
- Transcode
- Clone
- Organizer
- Transcribe
- Adobe Utilities
- NLE Utilities
- Speed Test
- Comparison
- Resolution
- System

Important tool-label nuance:
- **Adobe Utilities** in Log Viewer maps to the panel whose user-facing tab is **Adobe Automate**.
- **Comparison** and **Resolution** are utility channels. They are less common than the main panel logs and may not appear in every build or workflow.

**Show Only Errors / Warnings**  
Limits the current result set to warning/error-severity lines.

Important severity nuance:
- Structured logs carry real levels.
- Older plain-text logs rely partly on heuristic parsing, so severity filtering on old TXT logs is not as pristine as structured log data.

### Log Display

**Search Logs**  
Free-text search over the currently loaded log set.

Important:
- Search is case-insensitive.
- Search is broader than the visible message text. It can also search fields such as:
  - panel/type
  - job id
  - stage
  - detail text
  - extra fields
  - file name

This is why searching for a file name or job id can work even if that text is not obvious in the main visible line.

**Include System Logs**  
System entries are hidden unless:
- this checkbox is on, or
- the tool filter is set directly to **System**

That is deliberate. Otherwise runtime/startup noise would drown the panel.

**Log output area**  
The on-screen list is rendered oldest-to-newest so the latest line stays at the bottom.
When the user stays near the bottom, the viewer auto-follows new entries.
If the user scrolls up to inspect older lines, the viewer stops snapping to the latest line until the user returns to the bottom.

### Primary controls

**Expand Task Details**  
This control is more modest than its label suggests.

What it definitely does:
- toggles readable wrapping for long log lines

What it may also do:
- show extra detail when that information is available

In normal app use, treat **Expand Task Details** mainly as a readability control.

**Reset Viewer**  
Resets the filters and export settings back to the default state and reloads logs from disk.

It does **not**:
- erase archived log files
- wipe the log library
- clear destination-side copied logs

**Open Log Folder**  
Opens the raw app log library root.

Important:
- this opens the app's `LeadAEAssist/logs/` folder
- it does **not** jump to the currently filtered panel subfolder
- it does **not** open the user's output folder
- it does **not** follow your current search/filter state

### Export section

**Export Format**  
Options:
- TXT
- JSON
- CSV

**Export Folder**  
Choose where the export file should be written.

The text field is read-only because the folder is expected to come from the picker.

**Export Logs**  
Writes the current filtered set to the chosen export folder.

If no export folder is selected, export stops and asks the user to choose one first.

## Export behavior

### TXT export
TXT export has two modes.

#### Normal multi-job TXT export
When the filtered set contains multiple job ids, or no job ids, TXT export writes a plain formatted line dump.

Default filename:
- `logs.txt`

#### Single-job TXT export
When the filtered set resolves to **a single job**, TXT export upgrades itself into a richer single-job report.

Typical filename:
- `job-report_<panel>_<YYYYMMDD_HHMMSS>_<jobId>.txt`

That report can include:
- panel
- job id
- outcome
- start time
- end time
- duration
- warning count
- error count
- Inputs / Outputs / Settings / Stats sections when metadata exists
- grouped stage sections containing chronological log lines

This is why support sometimes gets a polished little report instead of a raw line dump.
The viewer is doing that on purpose.

### JSON export
JSON export writes the filtered entries as a pretty-printed array.

Default filename:
- `logs.json`

Good for:
- detailed analysis
- handoff for deeper investigation
- preserving structured fields such as metadata and job ids

### CSV export
CSV export writes a flat spreadsheet-friendly view.

Default filename:
- `logs.csv`

Current columns:
- `timestamp`
- `panel`
- `type`
- `level`
- `jobId`
- `stage`
- `message`
- `detail`
- `meta`
- `status`
- `file`

Good for:
- quick sorting
- spreadsheet review
- counting failures/warnings by tool or job

### Export ordering
All export formats write the filtered set in **chronological order** from oldest to newest.

That is deliberate.
It makes the exported report easier to read than dumping the newest line first and forcing people to read history backward like time-traveling paperwork goblins.

## Screen limits and load limits
This panel has guardrails. Good guardrails, but still guardrails.

### On-screen render cap
The viewer renders only the newest **500** filtered results on screen by default.

If the filtered set is larger than that, the panel shows a notice explaining that only the newest window is visible.
Export still uses the full filtered set that was loaded.

### In-memory retention cap
The viewer keeps an in-memory retention window with a default cap of **5000** entries.

When that limit is hit, the oldest in-memory entries are discarded first.

### Per-file raw read caps
When a raw log file is read, the loader keeps only:
- the last **8 MB** of that file
- the last **10,000 lines** of that file

If a file gets truncated by either cap, the viewer adds a warning entry explaining the limit.

Practical meaning:
- huge long-running logs may look incomplete
- export cannot magically include lines that were never loaded
- if you need the full file, collect the raw file itself

### Parse tolerance
Damaged structured-log lines are skipped instead of crashing the whole viewer.

That keeps the panel alive, but it also means a damaged structured log can appear shorter than the raw file on disk.

## What this panel does not do
Log Viewer is useful, but it is not a wizard tower.

It does **not**:
- delete raw logs
- clear the log library
- merge logs from arbitrary folders
- automatically collect every support file for you
- guarantee that destination-side copied logs are visible
- expose every hidden detail
- provide a dedicated "all time" filter shortcut

## Best support habits for this panel
Use this order:
1. Widen the date range first.
2. Set the tool filter second.
3. Turn on **Show Only Errors / Warnings** only after basic history is confirmed.
4. Turn on **Include System Logs** if the problem smells like startup/runtime trouble.
5. Search by job id, source filename, or distinctive error text.
6. Export JSON for detailed analysis, TXT for humans, CSV for quick spreadsheet triage.
7. Collect raw logs too when the case is messy.

## Related pages
- /workflows/export-logs-from-log-viewer/
- /workflows/export-single-job-report-from-log-viewer/
- /troubleshooting/log-viewer/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
