# Ingest

## What this panel does
Ingest copies media from a source folder or selected files into a destination and, optionally, a second backup location.

It is the app's copy-and-verify panel. Use it when you need one or more of these:
- verified copies
- dual copy / backup creation
- duplicate skipping
- extension-based filtering
- optional webhook notification
- Watch Mode for an incoming folder
- selective folder-tree copy through Clone Mode

Do not use this panel for transcoding, transcription, subtitle editing, or Premiere automation.

## Before you start
Confirm these up front:
- Your source is accessible.
- Your destination is a real folder path, not a file.
- If you plan to use **Enable Backup**, the backup path is a separate folder and is not inside the source or destination.
- You know whether you want:
  - a normal ingest
  - Clone Mode
  - Watch Mode
- You have picked a verification method that matches the job.

Important mode rules:
- **Clone Mode requires a source folder.** It does not support a file list.
- **Watch Mode requires a folder.** It does not support a file list.
- **Clone Mode and Watch Mode cannot be active at the same time.**
- **Auto Create Folder is disabled in Clone Mode.**

## Default starting state
After Reset or after the managed Default preset is applied, Ingest starts from a conservative baseline:
- Verification method: **BLAKE3**
- Skip Duplicates: **On**
- Parallel Copy: **On**
- Auto Threads: **On**
- Retry Failures: **Off**
- Save Log: **Off**
- Enable Backup: **Off**
- Auto Create Folder: **Off**
- Watch Mode: **Off**
- Include hidden files: **Off**
- Include Cache: **Off**

## How the source field works
**Select Source** behaves differently depending on the mode:
- In normal ingest mode, it can accept:
  - one folder
  - one file
  - multiple files
- In Watch Mode, it becomes **Select Watch Folder** and expects one folder.
- In Clone Mode, the source must be one folder so the app can build the folder tree.

When multiple files are selected, the source field may show a summary such as `N items selected` instead of listing every path. That is normal.

## Panel map

### Toolbar
**Preset dropdown**  
Shows available ingest presets. The app keeps a managed **Default** preset and sorts it to the top.

**Save**  
Saves the current ingest configuration as a JSON preset.

**Load**  
Loads a JSON preset from disk and applies it to the panel.

**Delete Preset**  
Deletes the currently selected preset. After deletion, the panel is reset back to the managed Default state.

**Info icon**  
Shows the technical overview tooltip for the panel.

### Input
**Select Source**  
Chooses the source folder or files for the job.

**Clone Mode**  
Switches the panel from a normal ingest into a folder-tree selective copy workflow.

### Clone section
This section appears when **Clone Mode** is enabled.

**Folder Filters**  
Type text to filter the visible folder tree by name.

**Select All**  
Bulk selects or deselects the clone tree.

**Show File Count**  
Requests per-folder counts and size calculations. This is useful for planning, but it can be slower on very large trees.

**Folder tree**  
Displays the source as a selectable folder hierarchy. Use this when you want only part of the source copied.

Notes:
- Clone Mode preserves folder structure at the destination.
- Clone Mode still respects verification and extension filters.
- Clone Mode disables Watch Mode and Auto Create Folder.

### File Handling Options
**Skip Duplicate Files**  
If enabled, the app tries to avoid re-copying files that already match the destination or backup. This is not a blind name match. The app uses verification logic to decide whether content is truly identical.

**Flatten Structure**  
Writes output without preserving the original folder tree. Use this carefully. It changes where files land and can make name collisions more likely.

**Include Cache**  
Includes common development and metadata folders that are skipped by default when this option is off. With Include Cache off, the app applies a conservative ignore list for names such as:
- `node_modules`
- `.git`
- `.svn`
- `.hg`
- `.idea`
- `.vscode`
- `__MACOSX`
- `Thumbs.db`
- `desktop.ini`

**Include hidden files**  
Includes hidden dotfiles and hidden folders. When this is off, dotfiles and common hidden system folders are skipped.

**Include extensions**  
Comma-separated allow list such as:
- `.mov,.mp4,.wav`

**Exclude extensions**  
Comma-separated deny list such as:
- `.tmp,.db,.DS_Store`

Notes:
- The app always skips marker and metadata files such as `.done`, `.doneflag`, `.DS_Store`, and AppleDouble `._*` files.
- If both include and exclude filters are used, the result can narrow down quickly. Check the Summary box if the job looks smaller than expected.

### Verification and Logging
**Verification Method**  
Available methods are:
- **None** - fastest, no integrity verification
- **Byte Compare** - safest, slowest
- **BLAKE3** - strong default and usually the best balance
- **SHA-256** - slower, often required for facility or IT compatibility
- **MD5** - legacy compatibility only
- **xxHash64** - very fast, non-cryptographic sanity-check style hashing

If you choose **None**, the app asks for confirmation before the job is queued.

**Save Log**  
For a manual ingest, this writes a copy of the final ingest report into the destination. If backup is enabled, a copy is also written to the backup path.

In Watch Mode, Save Log behaves differently:
- it does **not** write a per-file log at Start
- when you stop watching, the session log is exported to destination and backup if Save Log is on

### Automation / Webhook Integration
**Webhook**  
Enables webhook notification for the job.

**Allow private or localhost targets**  
By default, the webhook URL cannot point to `localhost` or a private network target. Turn this on only if you intentionally need a local or private-network endpoint.

**Send log**  
Includes log content in the webhook payload when supported by the backend flow.

**Webhook URL**  
Must be a full `http://` or `https://` URL. A bare hostname or unsupported protocol is rejected.

### Ingest Behavior
**Parallel Copy**  
Enables multi-threaded copy behavior.

**Auto Threads**  
Lets the app estimate a thread count from destination disk speed. In Watch Mode this remains conservative and is capped to avoid thrashing slower volumes.

**Retry Failures**  
Retries files that failed in the first pass.

**Threads slider**  
Manual thread count when Parallel Copy is on and Auto Threads is off.

### Watch Mode
**Enable Watch Mode**  
Turns Start into **Start Watching** and Cancel into **Stop Watching**. The source picker becomes **Select Watch Folder**.

**Process existing files on start**  
If enabled, the app scans the watch folder immediately when watching starts instead of only waiting for new arrivals.

Watch Mode notes:
- Watch Mode requires a folder, not a file list.
- Missing destination or backup paths cause watch-triggered jobs to skip instead of silently guessing what you meant.
- Save Log exports the watch session log when you stop watching.

### Output
**Select Destination**  
Required for all ingest jobs.

**Select Backup**  
Optional second destination. Selecting a backup path can auto-enable backup.

**Enable Backup**  
Requires a backup folder. If backup cannot be guaranteed, the ingest fails rather than pretending dual copy succeeded.

**Auto Create Folder**  
Creates a new time-stamped subfolder inside the destination. The naming pattern is:
- `Ingest_YYYY_MM_DD_HHMMSS`
- if that already exists, the app appends `_1`, `_2`, and so on

**Notes**  
Free-text job note written into the log.

**Start / Reset / Cancel**  
- **Start** queues a normal ingest or clone job.
- **Reset** returns the panel to the managed Default preset.
- **Cancel** cancels the current job.
- In Watch Mode, the labels become **Start Watching** and **Stop Watching**.

**Summary**  
Shows the job preview before start and the terminal summary after completion.

**Hide log window**  
Hides the panel's live log output. This only affects the UI. It does not stop logging.

## Mode interaction rules
This panel has several guardrails. Document them exactly because they explain a lot of user complaints.

### Normal ingest
Use this when you want:
- one source folder or file list
- a destination
- optional backup
- optional verification
- optional webhook
- optional Auto Create Folder

### Clone Mode
Use this when you want:
- a source folder treated as a tree
- only selected folders copied
- original folder structure preserved

Clone Mode side effects:
- disables Watch Mode
- disables Auto Create Folder
- requires a source folder
- uses Clone logs under the clone log library, not the ingest library

### Watch Mode
Use this when you want:
- a persistent watched folder
- automatic processing of new arrivals
- optional processing of existing files at start

Watch Mode side effects:
- requires a folder source
- Start becomes Start Watching
- Cancel becomes Stop Watching
- Save Log exports the watch session log when watching stops

## Recommended verification choices
Use these as default guidance for support and for the future help search snippets.

**BLAKE3**  
Best default for most jobs. Strong verification without the heavy cost of Byte Compare.

**Byte Compare**  
Use when the job is small enough or high enough risk that you want literal byte-for-byte confirmation. Expect it to take longer.

**SHA-256**  
Use when an external workflow or facility explicitly requires SHA-256.

**MD5**  
Use only for compatibility with older handoff requirements.

**xxHash64**  
Use when speed matters more than cryptographic strength and the goal is fast sanity checking.

**None**  
Use only when the speed tradeoff is intentional and understood. The app will force a confirmation step.

## Standard workflows

### Standard card or folder ingest
1. Open **Ingest**.
2. Click **Select Source** and choose a source folder or file list.
3. Click **Select Destination** and choose the main destination.
4. If a second copy is required, click **Select Backup** and turn on **Enable Backup**.
5. Choose the verification method. Leave **BLAKE3** unless you have a reason to change it.
6. Decide whether **Save Log** should write a copy of the final report into the destination.
7. Turn on **Auto Create Folder** only if you want a new time-stamped subfolder inside the destination.
8. Click **Start**.
9. If the destination or backup folder does not exist yet, confirm the creation prompt.
10. Review the Summary and the live log for skipped files, failures, or log-save messages.

### File-list ingest
Use this when the user selected one or more individual files instead of a source folder.
1. Click **Select Source** and choose the files.
2. Confirm the source field shows either the file path or an item count summary.
3. Set destination and any backup path.
4. Run the job normally.

Restrictions:
- Watch Mode does not support file lists.
- Clone Mode does not support file lists.

### Clone Mode selective copy
1. Choose a source folder.
2. Turn on **Clone Mode**.
3. Wait for the folder tree to load.
4. Use **Folder Filters** if the tree is large.
5. Select the folders to include.
6. Optionally enable **Show File Count** if you need a better estimate.
7. Set destination and optional backup.
8. Choose verification and duplicate handling.
9. Click **Start**.

Use Clone Mode when the user wants only part of a large source copied without flattening the entire source into a generic ingest.

### Watch folder ingest
1. Turn on **Enable Watch Mode**.
2. Click **Select Watch Folder** and choose the watched folder.
3. Set the destination and any backup path.
4. Decide whether **Process existing files on start** should be on.
5. Decide whether **Save Log** should export the watch session log when watching stops.
6. Click **Start Watching**.
7. When finished, click **Stop Watching**.
8. Review the Summary and exported watch log if Save Log was enabled.

## What gets written to disk

### User-chosen destination output
Manual ingest can create these files in the destination:
- `IngestLog_<timestamp>.txt` when **Save Log** is on
- `IngestFailures_<timestamp>.txt` when there were skipped or failed items to summarize
- `RetryList_<timestamp>.txt` when failures remain after retry handling

If **Enable Backup** is on and **Save Log** is on:
- a copy of `IngestLog_<timestamp>.txt` is also written to the backup path

If **Auto Create Folder** is on:
- these files are written inside the auto-created subfolder, not directly at the destination root

### App log library
The app always keeps job-scoped logs under its own userData log root.

Normal ingest jobs create log files under:
- `logs/ingest/`

Clone Mode jobs launched from the Ingest panel create log files under:
- `logs/clone/`

Typical files include:
- `<timestamp>--<jobId>.jsonl` for structured per-entry logs
- `<timestamp>--<jobId>.txt` for a human-readable job report

Watch Mode session logs are archived as plain `.txt` files in the same panel log area when watching stops.

### Watch Mode exported logs
If **Save Log** is on during Watch Mode:
- stopping the watcher exports the archived session log to destination
- if backup is enabled, it also exports the same watch log to backup

The exported file name starts with:
- `WatchLog_`

## Presets and saved state

### Presets
Ingest presets are stored as JSON files under the app configuration area:
- `config/presets/ingest/`

There are three ways presets matter:
- the toolbar dropdown chooses from saved presets
- **Save** writes a new JSON preset
- **Load** can open a preset JSON from disk even if it is not already in the dropdown

Deleting a preset resets the panel to the managed Default state.

### UI state remembered locally
The **Hide log window** toggle is remembered on the local machine. Hiding the log window does not disable logging.

## Common mistakes
These are the ones support will see over and over again.

### "It will not start"
Usually means one of these:
- no source selected
- no destination selected
- backup enabled without a backup path
- destination or backup overlaps with source
- Clone Mode has no selected folders
- Watch Mode is trying to use a file list instead of a folder

### "It skipped files I expected to copy"
Most common reasons:
- **Skip Duplicate Files** is on and the existing content already verifies as identical
- extension filters excluded the files
- hidden items were excluded
- Include Cache was off and the skipped item lived in a default ignored folder
- a watch-mode marker or system metadata file was intentionally skipped

### "The copy is too slow"
Most common reasons:
- Byte Compare is selected
- SHA-256 is selected
- Parallel Copy is off
- Auto Threads chose a conservative value on a slower destination
- Show File Count / size estimation made the preview phase feel slow on a huge tree

See **Troubleshooting - Ingest** for the full symptom guide.

## What support should ask for
When a user reports ingest trouble, support should ask for:
- app version from **Account and Licensing**
- platform and OS version
- whether the job was normal ingest, Clone Mode, or Watch Mode
- whether the source was a folder or file list
- exact source, destination, and backup relationship
- verification method
- whether Save Log was on
- exported Log Viewer output or the raw job log from the app log library
- screenshots of the Summary box and live log if the issue is intermittent

## Related pages
- /workflows/ingest-card-copy/
- /workflows/clone-mode-copy/
- /troubleshooting/ingest/
- /troubleshooting/watch-mode/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
