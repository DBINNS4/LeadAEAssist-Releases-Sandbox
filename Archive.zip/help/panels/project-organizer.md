# Project Organizer

## What this panel does
Project Organizer builds a repeatable project folder tree on disk.

It is used to:
- create a standard folder layout for a show, client, or facility
- add custom root folders and nested subfolders on top of the built-in defaults
- optionally prefix top-level folders with ordered numbers such as `01_PROJECT`, `02_MEDIA`, and so on
- optionally copy starter assets into specific folders while the structure is created
- save and reload organizer layouts as JSON configs or presets

This panel is **not** a media ingest tool.
It does not checksum cards, transcode media, or import into Premiere.
It is a filesystem structure builder with optional file-copy behavior attached.

## Before you start
A few things matter before the user clicks **Generate** and then wonders why the filesystem got weird.

- **Project Organizer is license-gated.** If the user's license does not include the feature, the queued job will be denied.
- The **Output Path must already exist** and it must be **writable**.
- The **Project Name** field is optional.
  - If it is filled in, the panel creates one root folder inside the Output Path.
  - If it is blank, the panel creates folders **directly inside the Output Path**.
- Top-level folder order matters when **Prepend Numbering** is enabled. The numbers are generated from the **current visible root-folder order**.
- Only **root folders** are draggable. Subfolders move with their parent tree and are not independently reorderable.
- Attached assets must resolve to readable files. Non-files, unreadable files, non-absolute paths, and invalid file URLs are skipped.
- The panel writes raw per-job logs automatically to `LeadAEAssist/logs/project-organizer/`. There is **no panel-side Save Log button**.

## Built-in default folders
The current default organizer tree starts with these root folders:
- `PROJECT`
- `MEDIA`
- `EDITOR`
- `ASSIST`
- `GFX`
- `MUSIC`
- `SFX`
- `MIX`
- `COLOR`
- `ONLINE`
- `QC`
- `EXPORTS`

Those are only the starting roots.
The user can add custom root folders or nested subfolders and then save the layout for reuse.

## Important behavior to understand
This panel has one slightly sneaky UI behavior that support should know cold:

- Clicking a folder mainly selects it as the **target parent** for **Add Subfolder**.
- It does **not** mean only that folder will be generated.
- The actual generated tree is the **full visible organizer structure**, unless folders were removed from the list.

Tiny naming goblin. Real support consequence.

## Panel map

### Toolbar

**Preset dropdown**  
Lists organizer preset JSON files from the panel preset folder.
The default preset is sorted to the top when present.

**Trash button**  
Deletes the currently selected preset through the shared preset system.
Use this carefully; it is preset management, not job reset.

**Save Config**  
Exports the current organizer state to a JSON file.
The saved payload includes:
- root name
- custom folder input text
- numbering setting
- output path
- custom folders
- folder order
- selected/visible folders snapshot
- attached asset paths

**Load Config**  
Loads an organizer JSON file from disk.
During load, the app sanitizes invalid data and can remove:
- bad folder entries
- invalid folder asset mappings
- non-absolute asset paths
- output paths or asset paths that are no longer approved

**Info icon**  
Shows the panel overview tooltip.
It explains that the panel is a reusable folder-tree builder with optional numbering and preset-based layout reuse.

### Folder Selection area

**Project Name**  
Optional root folder name.

Behavior:
- when filled, generation happens under `Output Path/Project Name`
- when blank, generation happens directly inside the output folder
- invalid names are blocked before queueing

Name validation currently rejects:
- path separators like `/` or `\`
- `..`
- trailing dots or spaces
- Windows reserved device names like `CON`, `PRN`, `AUX`, `COM1`, `LPT1`
- illegal characters such as `< > : " | ? *`
- reserved object-meta keys such as `__proto__`, `prototype`, and `constructor`

**Custom Folder**  
Text field used for either a new root folder or a new nested subfolder.

**Add Custom Folder**  
Creates a new root-level folder entry.
It is added to the end of the current root order.

**Add Subfolder**  
Creates a nested folder under the **single selected folder**.

Important:
- exactly **one** folder must be selected first
- the new folder is stored as a path-like id such as `PROJECT/GRAPHICS`
- duplicate ids are blocked

**Folder list**  
Shows the full current structure.

Behavior:
- root folders can be reordered by drag-and-drop
- subfolders are indented and not draggable on their own
- dragging a root folder carries its nested subfolders with it
- if a nested folder gets moved to root level by reorder logic, the app asks whether to:
  - move it to root, or
  - remove it from the organizer

**Plus button on each folder row**  
Opens a file picker and attaches one or more files to that folder.
Those files are copied into that folder when the job runs.

**Minus button on each folder row**  
Dual-purpose control:
- if the folder has attached files, it clears those attached files
- if the folder has no attached files, it removes the folder itself

When removing a root folder, the panel also removes all nested subfolders under that root.

**Drag-and-drop file attachment**  
Users can drag files directly onto a folder row.
The app silently approves dropped file paths as part of the explicit user gesture and stores them as attached assets.

### Output section

**Select Output Location**  
Opens a folder picker for the destination root.
The chosen path is written into the read-only path field.

**Output path field**  
Shows the currently selected output folder.
The panel validates that it exists and is a directory before queueing.

**Prepend Numbering**  
When enabled, root folders are renamed in summary/output order:
- `01_PROJECT`
- `02_MEDIA`
- `03_EDITOR`
- and so on

Important:
- numbering applies to **root folders only**
- subfolders keep their own local names under the numbered root
- the numbering order follows the **current displayed root-folder order**, not the original default order

### Controls row

**Generate**  
Queues a Project Organizer job and starts the queue runner.

Before queueing, the panel:
- refreshes attached-file mappings
- validates the Project Name
- validates the Output Path
- snapshots the visible organizer structure into the job config

During the job:
- the panel locks its controls
- the progress bar becomes active
- the hamster status indicator runs
- Cancel becomes enabled

**Reset**  
Resets the panel to the default built-in structure.

Reset clears:
- custom folders
- attached assets
- project name
- output path
- preset selection
- current numbering state back to enabled

Reset does **not** delete anything already created on disk.
It only resets the UI state.

**Cancel**  
Requests cancellation of the currently running organizer job.
The backend uses cooperative cancellation and cleanup rather than just sawing the process in half.

**Progress bar and inline percent**  
Shows job progress.

Current behavior:
- when no attached assets are present, progress is folder-step based
- when attached assets are present, progress is weighted mostly by **bytes copied**, so the bar does not sit there like a decorative brick during long copies

**Hamster status indicator**  
Visual busy indicator while the job is active.

### Summary box
The summary box is both a preview and a result surface.

Before generation it shows:
- Root Folder
- Selected Folders (really the visible tree)
- Output Path
- attachment lines such as `📎 PROJECT: template.prproj, notes.txt`

After generation it shows:
- success text, or
- success with warnings/errors, or
- validation/runtime failure text, or
- cancellation text

In diagnostics mode, the summary can also append raw backend fallback text.

## How structure creation works

### Root-folder behavior
There are two distinct modes.

#### Mode 1: Project Name is filled in
The app resolves:
- `Output Path/Project Name`

Rules:
- if that path exists and is an **empty folder**, the run can continue
- if it exists and is **not a folder**, the run fails
- if it exists and is a **non-empty folder**, the run fails to prevent accidental merge junk
- if it does not exist, the app creates it

#### Mode 2: Project Name is blank
The app uses the selected Output Path itself as the root.

Rules:
- folders are created directly inside the chosen output directory
- this can intentionally build into an existing destination tree
- support should warn users that blank Project Name is the easy way to spray a structure directly into a shared folder

### Folder sanitization and dedupe
The backend sanitizes every selected folder id path before creation.
It also removes duplicate folder selections after normalization.
If duplicates were removed, the job still runs and logs a warning.

### Folder creation order
Each selected visible path is created in order.
If numbering is enabled, root folders are renamed first, then the subfolder paths are resolved under the renamed root.

Example:
- visible path `PROJECT/GRAPHICS`
- numbering enabled with PROJECT first
- actual created path becomes `01_PROJECT/GRAPHICS`

## How attached file copying works
Attached files are optional.
If present, they are copied after the target folder path exists.

### Accepted asset behavior
The backend accepts readable files only.
It rejects or skips:
- invalid entries
- bad `file:` URLs
- non-absolute paths
- unreadable files
- folders passed where files were expected

### Duplicate handling
There are two different duplicate cases.

#### Same source path attached twice to the same folder
The duplicate is skipped and logged as a warning.

#### Different sources that would land on the same destination filename
The app picks a unique filename by adding a suffix such as `_1`, `_2`, and so on.
That means the copy can still succeed without overwriting an existing file.

### Rollback and safety
If the job is cancelled or a runtime failure happens after the app already created folders or copied files, the backend rolls back the artifacts created by **that job**.
It does not delete unrelated pre-existing folders or files.

That is the correct behavior.
Anything else would be filesystem vandalism wearing a support badge.

## Presets and config files
There are two closely related concepts here.

### Panel presets
The preset dropdown reads JSON files from:
- `LeadAEAssist/config/presets/project-organizer/`

Use panel presets when the goal is a reusable in-app layout choice.

### Save Config / Load Config
These buttons export or import organizer JSON files directly.
They are useful when:
- sending a layout to another user
- archiving a show-specific structure outside the app data folder
- support needs to inspect the exact organizer config that produced a problem

### Approval re-check on load
When a config or preset is loaded, the app re-checks path approval.
That means:
- unapproved output paths can be removed from the loaded config
- unapproved or non-absolute asset paths can be stripped from the loaded config

This is not corruption.
It is the app refusing to blindly trust stale absolute paths from an old file.

## What gets written to disk

### Organizer output tree
The visible organizer structure is created under either:
- `Output Path/Project Name/`, or
- `Output Path/` when Project Name is blank

### Attached assets
Attached files are copied into their mapped organizer folders.

### Raw logs
The app automatically writes raw logs to:
- `LeadAEAssist/logs/project-organizer/`

Typical files include:
- structured per-job JSONL logs
- human-readable per-job TXT job reports

There is no destination-side `OrganizerLog_...txt` convenience export at this time.
Start in the raw log library.

## Common operator patterns

### Build a reusable show template
1. keep the built-in roots you want
2. add any custom root folders
3. click a root folder and add nested subfolders under it
4. reorder the roots
5. decide whether numbering belongs in this workflow
6. save the layout as a preset/config before generating

### Attach starter kit files
Common examples:
- project templates
- slug graphics
- cue sheets
- licensing PDFs
- handoff notes
- empty spreadsheet shells

Attach those files to the relevant folder rows before generation so every new job starts with the same scaffolding.

## Related pages
- [Build a folder tree with Project Organizer](/workflows/build-project-folder-tree-with-project-organizer/)
- [Attach starter assets to organizer folders](/workflows/attach-starter-assets-to-organizer-folders/)
- [Save and reuse Project Organizer configs](/workflows/save-and-reuse-project-organizer-configs/)
- [Troubleshooting - Project Organizer](/troubleshooting/project-organizer/)
- [Logs and support bundle](/reference/logs-and-support-bundle/)
- [File locations](/reference/file-locations/)
