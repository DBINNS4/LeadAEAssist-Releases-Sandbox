# Panel Guides

## How to use this section
Open a panel guide when the user needs a full explanation of the UI: what the panel does, what each control means, which modes conflict, where outputs go, and what related troubleshooting pages to use.

## Main app panels
- [Ingest](/panels/ingest/) — Verified copy, backup copy, Clone Mode, and Watch Mode for source media.
- [Transcode](/panels/transcode/) — Batch transcode and watch-folder transcode with codec, preset, and container controls.
- [Transcribe](/panels/transcribe/) — Speech-to-text, caption export, translation, diarization, and Subtitle Editor handoff.
- [Adobe Automate](/panels/adobe-automate/) — Copy media, connect to Premiere, build bins, and create proxies.
- [Log Viewer](/panels/log-viewer/) — Inspect app job logs, filter by source and job, and export support-friendly reports.
- [NLE Utilities](/panels/nle-utilities/) — Avid reset/rebuild tools and safe Adobe cache, preview, and autosave cleanup.
- [Speed Test](/panels/speed-test/) — Benchmark network and storage throughput before copy, transcode, or watch-folder jobs.
- [Project Organizer](/panels/project-organizer/) — Create project folder trees, attach starter assets, and save reusable organizer configs.
- [Preferences](/panels/preferences/) — Global app settings including Offline Mode, update behavior, temp cleanup, API key, and CEP install.

## Secondary surfaces
- [Account and Licensing](/panels/account-and-licensing/) — license, billing, and version-info surface opened from the title bar.
- [Subtitle Editor](/panels/subtitle-editor/) — separate editor window launched from Transcribe or directly from a subtitle file.

## Related
- [Lead AE Assist Help](/)
- [Troubleshooting](/troubleshooting/)
- [Workflows](/workflows/)
- [Logs and support bundle](/reference/logs-and-support-bundle/)
