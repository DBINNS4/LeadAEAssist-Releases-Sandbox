# Subtitle Editor

## What this window does
Subtitle Editor is the app's dedicated pop-out review and correction window for subtitle and caption files.

Use it when the user needs to:
- open an existing subtitle or caption file and fix timing or text
- review the latest Transcribe output without leaving the app
- export corrected **SRT**, **VTT**, **SCC**, or **MCC** deliverables
- inspect broadcast placement and QC issues
- create a quick burn-in review file from a subtitle plus media source
- review multi-service **MCC** content with a service selector

This window is **not** the place to run transcription jobs. It edits or re-exports subtitle/caption material that already exists.

## Before you start
Check these first:
- The user has a license that enables **Subtitle Editor**.
- There is a subtitle file to open. The window will not fully launch into an editing session without one.
- If preview playback matters, there is a supported media file available.
- The user knows whether they are working on a **web caption** workflow (**SRT/VTT**) or a **broadcast caption** workflow (**SCC/MCC**).

Supported subtitle inputs:
- `.json`
- `.srt`
- `.vtt`
- `.scc`
- `.mcc`

Supported preview-media picks from the UI:
- `.mp4`
- `.mov`
- `.m4v`
- `.mkv`
- `.webm`

Important rules:
- **A subtitle file is required. Video is optional.**
- **This window is reused.** Opening it again focuses the existing Subtitle Editor window and can load a new file into it.
- **SRT/VTT and SCC/MCC are different editing modes.** The window intentionally changes controls depending on the document type.
- **License access is checked before the editor opens.** If the feature is not included in the current license, the editor will not start.

## How users get here
### From Transcribe
The most common entry points are in **Transcribe**:
- **Open Editor…** opens a blank Subtitle Editor window so the user can choose a file manually.
- **Edit Subtitle after export** can auto-open the newest editor-friendly subtitle/caption result after a Transcribe job completes.
- Even after a failed Transcribe job, the handoff logic can still try to open the latest written subtitle/caption file so the user can fix it instead of rerunning from scratch.

### Directly inside Subtitle Editor
If the window is already open, the user can switch files with:
- **Open Subtitle…**
- drag-and-drop onto the start screen
- drag-and-drop into the editor window when the chooser is visible

## Start screen behavior
When Subtitle Editor opens without an explicit file, the user sees a chooser screen instead of a blank white void. That is good. Blank white voids are where support tickets breed.

The chooser has two zones:
- **Subtitle file** - required
- **Video file (optional)** - preview only

Behavior notes:
- The **Launch Editor** button stays disabled until a valid subtitle path is selected.
- Dragging a file into either zone is supported.
- The subtitle zone accepts only supported subtitle/caption formats.
- The media zone accepts only supported video formats.
- If the build cannot expose a dropped file path, the drop fails with a clear status message instead of silently doing nonsense.

## Editor mode model
Subtitle Editor has two major UI modes.

### Web caption mode
Used for:
- **SRT**
- **VTT**

This mode emphasizes:
- text correction
- timing cleanup
- web-safe line and character limits
- simpler preview behavior

### Broadcast mode
Used for:
- **SCC**
- **MCC**
- JSON docs that resolve into the broadcast-style editor path

This mode emphasizes:
- SMPTE timecode display
- caption placement
- 608/708 behavior
- QC and deliverable gating
- service-aware MCC work

Important hygiene behavior:
- When the editor reuses a prior session and the user opens **SRT** or **VTT**, the main-process loader explicitly clears stale SCC/MCC metadata so broadcast-only settings do not bleed into web-caption work.

## Window map

### Header and file summary
The top-left title area shows the active document name.
The metadata line beneath it changes by format and can include details such as:
- fps
- DF/NDF state
- caption format
- cue or block count
- active 708 service number
- Start TC

This metadata is not just decorative. It is one of the fastest ways to notice that a user opened the wrong file or is editing the wrong service.

### Toolbar - always visible actions
**Open Subtitle…**  
Load a different subtitle/caption file into the current window.

**Open Media…**  
Attach or replace the preview media file.

**Service**  
Appears only for multi-service **MCC / 708** documents that actually expose more than one service. The dropdown labels look like `S1 (count)`, `S2 (count)`, and so on.

**Close**  
Closes the Subtitle Editor window. In the separate window view, this closes the actual window, not just a panel overlay.

### Toolbar - format-dependent actions
The toolbar injects more actions after the window builds the document context.

#### Export Corrections
Shown for non-SCC correction workflows.

Use this when the user is editing **SRT**, **VTT**, **JSON**, or another non-SCC document and wants a corrected text-sidecar export rather than a broadcast re-export.

Support-critical behavior:
- the export format follows the opened correction document when that document is **SRT**, **VTT**, or **JSON**
- the save dialog defaults to **SRT** when the opened document is SRT
- the save dialog defaults to **VTT** when the opened document is VTT
- the save dialog defaults to **JSON** when the opened document is JSON, usually with a name like `root.corrected.final.json`
- the export writes **one corrected file**, not a sibling SRT/VTT/JSON trio
- delivery-grade broadcast output still belongs to **Export SCC** or **Export MCC**
- burn-in/helper flows can still request **SRT** explicitly, because the FFmpeg burn-in path runs from an SRT sidecar

#### Export SCC
Shown for **SCC** authoring/re-export flows.

Use this when the current work needs a 608 Scenarist deliverable.

Export SCC can:
- pass cleanly
- write with warnings
- write but mark the export as failed for editing/QC follow-up
- block the write entirely when strict QC gating is enabled

The export result can also create a **report file** so the user can see why QC failed.

#### Export MCC
Shown for broadcast caption docs and hidden for web-caption docs.

Use this when the workflow needs a MacCaption / 708-oriented deliverable.

MCC export also supports QC gating and report generation.

#### Start TC
Shown for timecode-based caption workflows.

This control opens a modal that maps **media time 0** to a displayed **SMPTE timecode label**.

Important rule:
- **Start TC changes the displayed/exported label. It does not move the cue timings themselves.**

This is a major support trap. Users often think Start TC is a retime button. It is not. It is a timecode-label offset.

For SCC exports, the Start TC modal can also expose an **Include speaker names** option. That option stays off by default because some QC specs reject speaker labels in 608 deliverables.

#### Normalize frames
Shown for SMPTE-style documents.

This action snaps cue timings, and relevant 608 override timing, onto exact frame boundaries.

Use it when:
- QC complains that timings are not frame-aligned
- imported content drifts onto fractional frame boundaries
- the user has made several manual timing edits and wants a clean frame-safe pass

#### Glyphs
Shown for SCC / 608 authoring work.

This opens the **CEA-608 Glyph Picker** so the user can insert supported broadcast glyphs into the active caption field.

#### Burn-in
Shown on the SCC-style action strip.

Use this to make a reviewable burned-in video from the current subtitle corrections and attached media.

Support-critical behavior:
- Burn-in requires a **media path**.
- Burn-in also requires a known corrected **SRT** path.
- If the editor does not already have a corrected SRT, Burn-in tries to export one first before rendering the movie.
- This can happen even while the user is editing broadcast content, because the FFmpeg burn-in path is SRT-backed.
- The burn-in output is written as:
  - `<mediaBase>.burnin.mov`

The burn-in is created with FFmpeg and lands in the current output directory.

## Toolbar toggles and mode-specific controls
### Broadcast-only toggles
These appear for SCC/MCC-style work and are hidden for SRT/VTT.

**Row/indent inspector**  
Shows extra placement inspection helpers for broadcast caption work.

**Click-to-place**  
Turns on direct placement interaction inside the preview.

**608 move target**  
Used for 608 placement targeting. Available values are:
- `Block`
- `Line 1`
- `Line 2`

For pure SCC docs this target stays visible so the user can choose the move target before enabling click-to-place.

**708 placement**  
Used for 708-capable docs. Available values are:
- `Zones`
- `Exact`

### Web-only information
For SRT/VTT, the toolbar shows a compact limits summary such as:
- active format
- max lines per block
- max characters per line

Those limits come from the opened document's own shaping settings first, then local defaults.

## Preview area
### Layout
The preview area can run in two different layouts.

#### Single preview
Used for:
- SCC / 608-style work
- SRT / VTT preview

#### Dual preview
Used for **708-capable MCC** work.

The two panes are:
- **708 (authoring source)**
- **608 (derived, with overrides)**

This is extremely useful for support because it lets you see when the 608 compatibility path is diverging from the 708 authoring source.

### Preview controls
The preview area includes:
- safe-area guides
- play/pause
- scrub bar
- current time / duration display
- **Hide QC** toggle

Behavior notes:
- The preview splitter height is user-resizable and its size is stored locally.
- In web-caption mode, the preview uses web-safe guides instead of broadcast caption overlays.
- In broadcast mode, safe-area overlays and placement interaction are active.

### Media compatibility and preview proxies
The editor tries to play the original media directly when Chromium can decode it.

If the browser cannot decode the original media cleanly, the editor can:
- build a lightweight preview proxy with FFmpeg
- cache that preview under the user's app temp area
- reuse the cached preview later instead of transcoding again

Preview proxy notes:
- preview proxies are cached under `LeadAEAssist/temp/previews/`
- the cache key uses the source path plus file size and modification time, so a changed source file gets a fresh preview instead of a stale one
- if no compatible preview encoder is available, the editor falls back to the original file and warns the user

A separate support nuance:
- if the selected media has **no video track**, the editor warns that playback is audio-only

## Cue list and editing behavior
### Insert Caption
This does **not** create a random empty cue at an arbitrary time.

It splits the active cue at the current playhead time when possible.

### Delete Caption
Deletes the currently active cue.

### Debutt All
This bulk timing helper creates a small gap between adjacent cues so they do not share the same frame boundary.

Available policies:
- trim end (1-frame gap)
- trim start (1-frame gap)
- trim both (2-frame gap)

Debutt is available for both:
- broadcast captions
- web captions

### Cue highlighting and time sync
As playback moves, the editor highlights the cue that matches the current time.
In web-caption mode it avoids the classic silly bug where cue 1 shows at time 0 even when the first cue starts later.

## QC panel
The right-side QC panel is a major support surface, not decorative UI confetti.

It includes:
- total counts
- **Fail** and **Warn** filters
- navigation buttons for:
  - first fail
  - previous issue
  - next issue
- a cue data inspector
- a clickable QC issue list

Behavior notes:
- clicking a QC issue jumps the user to that cue
- the QC panel width/height is resizable and persisted locally
- **Hide QC** does exactly that; it does not delete issues or disable QC

## Import issues drawer
If the opened document carries import errors, warnings, or model issues, the editor shows an **Import issues** drawer beneath the main layout.

Behavior notes:
- import errors can auto-expand the drawer
- model issues are separated from generic import warnings
- this is useful for support when the file technically opens but arrived with parsing compromises

## Broadcast-specific behavior
### SCC
SCC work is locked to a **29.97** timebase in export logic.

Important SCC rules:
- DF is the default export mode
- NDF export is blocked unless the advanced `allowNdf` setting is explicitly enabled
- speaker labels are optional and risky for some delivery specs
- 608-safe wrapping and placement are enforced during export
- export can generate a QC report and can be blocked by strict delivery policy

### MCC
MCC work is treated as **true 708 authoring** with optional derived 608 compatibility.

Important MCC rules:
- the active 708 service number matters
- multi-service documents expose the service selector only when more than one service is actually present
- 608 compatibility can be included or disabled
- some options, such as embedded CDP timecode, are constrained by fps and compatibility mode
- export can generate a QC report and can also be blocked by strict delivery policy

## Export results and files
### Export Corrections
Typical results are format-specific:
- corrected `.srt` when the opened correction document is SRT
- corrected `.vtt` when the opened correction document is VTT
- corrected `.json` when the opened correction document is JSON, with the default filename usually ending in `.corrected.final.json`
- corrected `.qc.json` and `.qc.txt` sidecars next to SRT/VTT exports

The editor stores the chosen output path and directory after export so later actions know where to go. Burn-in specifically looks for a corrected `.srt`.

### Export SCC
Typical results:
- corrected `.scc`
- `.report.txt` sidecar when QC or verification reporting is involved

### Export MCC
Typical results:
- corrected `.mcc`
- `.report.txt` sidecar

### Burn-in
Typical result:
- `<mediaBase>.burnin.mov`

## Logs and support clues
Subtitle Editor does **not** currently have its own dedicated `logs/subtitle-editor/` folder.

The editor's main-process and export activity is logged under the **Transcribe** logging surface, so support should start here:
- `LeadAEAssist/logs/transcribe/`

Useful support artifacts for Subtitle Editor issues:
- the source subtitle file
- the exported output file
- any generated `*.report.txt` file
- screenshot of the QC panel and status line
- raw Transcribe log files
- preview-proxy behavior clues from `LeadAEAssist/temp/previews/` when media preview is involved

## Keyboard shortcuts worth knowing
These are the high-value ones support can actually use while reproducing an issue:
- **Cmd/Ctrl+O** - open subtitle file
- **Space** - play/pause
- **Left / Right Arrow** - step playhead
- **Enter** - split cue at current playhead
- **Shift+Enter** - merge cue
- **Delete / Backspace** - delete active cue
- **Cmd/Ctrl+Z** - undo
- **Cmd/Ctrl+Shift+Z** or **Cmd/Ctrl+Y** - redo
- **Cmd/Ctrl+,** - nudge cue start earlier
- **Cmd/Ctrl+.** - nudge cue end later
- **Escape** - close the window

## Typical support advice
### When the user wants a safe correction pass
Open the file, review QC, then use **Export Corrections**.
That keeps the corrected export in the same text format as the file they opened, without pretending they need broadcast deliverables.

### When the user needs a delivery-grade broadcast export
Open the file, check Start TC, placement, QC, and service selection, then export **SCC** or **MCC** and collect the report file if QC blocks or soft-fails the write.

### When the preview video is the problem
Attach media with **Open Media…** and remember that the editor may build a cached preview proxy under temp rather than play the original directly.

## Related pages
- /panels/transcribe/
- /troubleshooting/subtitle-editor/
- /workflows/open-subtitle-editor-and-load-a-subtitle/
- /workflows/review-and-export-web-caption-corrections/
- /workflows/export-broadcast-captions-from-subtitle-editor/
- /workflows/create-burn-in-from-subtitle-editor/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
