# NLE Utilities

## What this panel does
NLE Utilities is the app's destructive maintenance and recovery toolbox.

It is built to:
- delete and rebuild Avid media database files
- reset Avid site settings
- reset Avid user settings
- clean Adobe media cache files
- delete Premiere autosave projects inside Auto-Save folders
- remove Adobe preview or render-cache media
- save and reload presets for those maintenance settings

This panel is **not** a production pipeline panel. It does not copy footage, transcode media, or generate deliverables.
It is the "something is wrong, clean up the mess carefully" tab.

It is also **not** the same thing as **Adobe Automate**.
- **Adobe Automate** is for copy, import, bins, and proxies.
- **NLE Utilities -> Adobe Utilities** is for cleanup and reset work.

## Before you start
Read these first. This panel is where polite filesystem behavior goes to the gym.

- Most actions are **destructive** and do **not** use Trash or Recycle Bin.
- Quit **Media Composer** before Avid database deletion, rebuild, site reset, or user reset.
- For **Avid database** work, select:
  - an `Avid MediaFiles/MXF` folder, or
  - its parent `Avid MediaFiles` folder if you intentionally want subfolder scanning.
- For **Avid site/user settings** work, select one of these:
  - the Avid application root that contains both `Settings` and `Avid Users`
  - the `Settings` folder directly
  - the `Avid Users` folder directly
  - a specific user folder under `Avid Users/<name>`
- For **Adobe cleanup**, select the narrowest sensible folder. Do not point this at an entire drive unless you enjoy giant scans and regret.
- Presets remember path text, but they do **not** preserve the app's path-approval state. A loaded preset can still require the user to re-select or re-approve the folder.

## Default starting state
After **Reset**, the panel returns to its HTML/default control state.

Typical starting behavior:
- all sections are collapsed
- no Avid folder is selected
- no Adobe folder is selected
- Avid user dropdown is empty except for the placeholder
- **Scan Subfolders** is off
- **Backup Before Reset** is off
- **Show Counts** is off
- **Auto Rebuild Databases** is off
- Adobe age and size filters are off and blank
- custom Adobe extension filter is blank
- Adobe scope is blank

Important:
- **Reset** restores control values and clears summaries.
- **Reset** does not undo any deletion or reset that already happened on disk.

## How folder selection behaves

### Avid folder selection is intentionally flexible
The Avid picker is more forgiving than the button label makes it sound.

It can work from:
- a standard media path such as `.../Avid MediaFiles/MXF`
- the `Avid MediaFiles` parent
- the `Settings` folder
- the `Avid Users` folder
- an individual user folder inside `Avid Users`

The panel then tries to resolve the right base folder for the action you chose.

### The user dropdown can auto-populate
After you pick an Avid path, the panel tries to discover Avid user folders and populate **Avid User**.

It can also try to preselect the likely active user by checking:
- the main `MCState` file when available
- otherwise the newest per-user `MCState`

That is a convenience heuristic, not divine truth. Always verify the selected user before resetting anything.

### Show Counts is context-sensitive
**Show Counts** reports different file types depending on what kind of folder you selected.

Examples:
- media folders: counts MXF, `msmFMID.pmr`, `msmMMOB.mdb`, and the occasional `msmMMOB.mbd`
- user folders: counts `MCState`, `.xml`, `.avs`, and `.ave`
- settings folders: counts `MCState`, `Site_Attributes`, and `Site_Settings.xml`

### Scan Subfolders can be forced on for media-database work
If the selected Avid path is the `Avid MediaFiles` root or the `Avid MediaFiles/MXF` root, the database actions can auto-enable subfolder scanning for that run.
That is deliberate because the database files usually live in the numbered MXF subfolders, not only at the root.

## Panel map

### Toolbar

**Preset dropdown**  
Lists saved NLE Utilities presets.

**Delete preset**  
Deletes the currently selected preset file.

**Save Config**  
Saves the current panel state to a JSON preset.

**Load Config**  
Loads a saved preset or imported JSON config.

**Info icon**  
Shows the high-level technical overview for the panel.

### Avid Utilities section

**Select Avid Folder**  
Chooses the folder the Avid actions will target.

The same button is used for both:
- media database cleanup/rebuild
- site/user settings reset

That means the *right* folder depends on the action:
- database actions -> media folder
- site/user reset -> Avid settings/users root or user folder

**Avid User**  
Lists discovered Avid user folders.

Use this for **Reset User** unless you selected a specific user folder directly.

**Delete DB**  
Deletes Avid media database files from the selected target folders.

Primary targets:
- `msmFMID.pmr`
- `msmMMOB.mdb`

The code also reports or deletes `msmMMOB.mbd` if it exists, because some environments still manage to produce that typo-shaped oddity.

Important behavior:
- requires confirmation
- warns about shared Nexis/ISIS/Interplay/MediaCentral workflows
- can warn again if the path is outside the standard `Avid MediaFiles/MXF` structure
- can scan subfolders when that option is on, or auto-enable it for standard media roots

**Rebuild DB**  
Triggers an Avid database rebuild without first deleting the databases.

How it works:
- the panel creates a temporary trigger file named like `REBUILD_TRIGGER_<timestamp>_<random>.mxf`
- it writes that file into each target MXF folder
- it schedules cleanup of that trigger file about 15 seconds later

This is a practical nudge for Avid to rescan the folder structure.

**Reset Site**  
Deletes Avid site settings files from the resolved `Settings` folder.

Targets:
- `MCState`
- `Site_Attributes`
- `Site_Settings.xml`

If **Backup Before Reset** is on, the panel first copies those files into:
- `Settings/Site_Backup_<timestamp>/`

**Reset User**  
Deletes one Avid user's settings files.

Targets:
- `MCState`
- `*.xml`
- `*.avs`

Important:
- it **does not** delete the `.ave` user profile
- if **Backup Before Reset** is on, files are copied into:
  - `Avid Users/<user>/User_Backup_<timestamp>/`

**Scan Subfolders**  
Tells the Avid media-folder traversal logic to recurse into subfolders.

Use this for:
- broad MXF folder trees
- `Avid MediaFiles` roots
- larger media volumes

Do not use it casually on huge unrelated folder trees unless you want a slower scan and more warnings about truncation or timeout.

**Backup Before Reset**  
Creates a timestamped backup folder before:
- **Reset Site**
- **Reset User**

It does **not** apply to:
- **Delete DB**
- **Rebuild DB**
- Adobe cleanup actions

**Show Counts**  
Adds file-count summaries to help confirm the selected path is really what you think it is.

This is a sanity check feature. Use it before destructive work.

**Auto Rebuild Databases**  
Applies to the **Delete DB** path.

Meaning:
- first delete the database files
- then immediately create rebuild-trigger files in the target MXF folders

If Media Composer is still open, the panel warns and refuses the action.

**Avid summary box**  
Shows the current Avid action log and counts summary.

Treat this as the first support record for what happened in the panel.

### Adobe Utilities section

**Select Adobe Folder**  
Chooses the base folder for cache, autosave, or preview cleanup.

The base folder can be broad, but the app expects you to be sensible. A giant home directory is technically a folder too. It is also a terrible idea.

**Clear Cache**  
Recursively deletes Adobe media cache files.

Default targeted extensions:
- `.pek`
- `.cfa`
- `.ims`
- `.mcdb`
- `.mxf`
- `.mpgindex`
- `.mxfindex`
- `.wav.cfa`
- `.prmdc2`

If the custom extension filter field is filled in, that custom list replaces the defaults for the run.

**Delete Autosaves**  
Deletes Premiere autosave project files, but only when the `.prproj` file lives inside an Auto-Save-like folder.

Safety behavior:
- regular Premiere project files outside Auto-Save folders are protected
- the summary reports how many non-autosave projects were protected instead of deleted

**Remove Previews**  
Deletes Adobe preview/render-cache media.

Targeted extensions:
- `.mpg`
- `.mpeg`
- `.mp4`
- `.mov`
- `.avi`
- `.m4v`
- `.mxf`

**Exclude Recent Files**  
Skips files newer than the specified **Days** value.

Rule:
- turning this on without a positive **Days** value is a validation error

**Days**  
Age threshold used by **Exclude Recent Files**.

**Skip Large Files**  
Skips files larger than the specified **Max Size (MB)** value.

Rule:
- turning this on without a positive **Max Size (MB)** value is a validation error

**Max Size (MB)**  
Size threshold used by **Skip Large Files**.

**Media Cache Filter**  
Optional comma-separated or space-separated extension list for **Clear Cache**.

Example:
- `.cfa, .pek`
- `.mcdb .ims`

Important:
- it normalizes entries to lowercase extensions
- if the field contains only junk, the action fails validation instead of deleting whatever happens to match nothing

**Media Cache Scope**  
Optional folder path inside the selected Adobe folder.

Purpose:
- narrow a cleanup run to a known subfolder without re-picking the base folder

Rules:
- the scope must resolve **inside** the selected Adobe folder
- the scoped path must exist and be a folder
- if the scope points outside the selected folder, the action is blocked

**Adobe summary box**  
Shows the current Adobe cleanup result:
- deleted count
- skipped count
- protected-project count for autosave cleanup
- timeout/truncation warnings
- errors

### Full-panel reset and warnings

**Reset**  
Resets all NLE Utilities controls and summaries back to their starting state.

It does **not**:
- restore deleted files
- remove backup folders that were created
- remove Avid rebuild trigger files already written
- reverse Adobe cleanup actions

**Destructive warning banner**  
This is not decorative. Believe it.

The panel tools:
- can permanently delete files
- do not use OS trash
- are safest when run against a small, known-problem folder first

### Assistant links
The buttons below the panel open external assistant links for:
- Media Composer
- Premiere
- Resolve

These are shortcuts, not required parts of the utility workflow.

## Safety rails and guard behavior

### Avid non-standard path confirmation
For Avid database delete/rebuild, the app treats paths outside the standard `Avid MediaFiles/MXF` layout as risky.

That can trigger an additional confirmation.
The point is to stop users from "cleaning" random folders because they were technically selectable.

### Adobe folder-name safety guards
For Adobe cleanup, the app checks whether the chosen path *looks like* the type of folder being cleaned.

Examples:
- cache cleanup expects folder names like `Media Cache` or `Media Cache Files`
- preview cleanup expects names like `Preview Files`, `Render Cache`, or `Render Files`

If the path does not look right, the app asks for a second confirmation before continuing.

### Large scan limits
Recursive Adobe scans are generous but not infinite.

The cleanup scan can warn about:
- timeout
- file-limit truncation
- missing metadata during stat reads

If that happens, narrow the folder and retry.
Do not trust a huge whole-drive scan just because it eventually said something cheerful.

## What this panel does not do
It does **not**:
- send deleted files to Trash or Recycle Bin
- create media copies or backups outside the specific Avid reset backup folders
- produce deliverables like proxies, subtitles, or exports
- replace **Adobe Automate**
- expose a panel-side **Save Log** or export button

Support consequence:
- the summary panes are the primary on-screen record
- capture that text before resetting the panel or changing folders

## Support notes
When a user reports trouble with NLE Utilities, collect:
- a screenshot or copied text from the relevant summary box
- the exact selected Avid or Adobe folder path
- whether **Scan Subfolders**, **Backup Before Reset**, **Show Counts**, **Auto Rebuild**, **Exclude Recent Files**, **Skip Large Files**, and **Scope** were used
- **Copy version info** from **Account and Licensing**
- any relevant raw logs from **Log Viewer** if NLE lines are present there

## Related pages
- /workflows/rebuild-avid-media-databases/
- /workflows/reset-avid-user-settings/
- /workflows/reset-avid-site-settings/
- /workflows/clean-adobe-cache-autosaves-or-previews-safely/
- /troubleshooting/nle-utilities/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
