# Speed Test

## What this panel does
Speed Test is the app's built-in benchmark panel.

It is used to:
- measure **internet throughput and latency** for the current machine and network path
- compare **one to three storage targets** using the same test size and mode
- check **sequential** performance for large media movement
- check **random** performance for smaller, latency-sensitive filesystem work

It is a diagnostics panel, not a certification lab.
It gives grounded comparisons for this machine, this mount path, and this moment in time.
It does **not** automatically tune Ingest, Transcode, or Transcribe settings for you.

## Before you start
Read these first so nobody accidentally benchmarks the wrong thing and then blames physics.

- **Speed Test is license-gated.** If the user's license does not include the feature, both network and drive tests will refuse to run.
- **Offline Mode blocks network tests.** Drive tests are still allowed, but the network section will not run while Offline Mode is enabled.
- The network test may need to prepare or download a required browser component before the test can actually start.
- Drive tests are **folder-based**, not abstract volume probes. The app writes temporary benchmark files inside the selected path.
- Drive tests create a hidden work folder named **`.lead-speedtest`** inside each selected target path. Only test locations where temporary writes are acceptable.
- Test the **same path your workflow will really use**. For example, benchmark the actual mounted share or proxy destination path, not some different folder on the same storage system and then pretend it is the same thing.
- Close other heavy disk or network activity when possible. Background copy jobs, sync tools, media cache churn, VPN overhead, antivirus scanning, and other delightful gremlins can skew the results.
- Treat results as **comparative diagnostics**, not eternal truth carved into silicon.

## Default starting state
When the panel first opens, the typical starting state is:
- no network result shown yet
- no drive paths selected
- **Test Size** defaults to **1 GiB**
- **Mode** defaults to **Sequential**
- both Cancel buttons are disabled until a run is active

There are no presets, no saved configurations, and no output-path settings in this panel.
It is intentionally lean.

## Panel map

### Toolbar

**Info icon**  
Shows the technical overview tooltip for the panel.

The tooltip explains the intent of the panel and reminds users that:
- **Network** is about download/upload/ping
- **Sequential** is for sustained large-file movement
- **Random** is for many smaller reads and writes
- the best benchmark path is the **same path the NLE or job will actually use**

### Network Test section

**Run Network Test**  
Starts the network benchmark.

Current behavior:
- uses **FAST.com**
- asks for **upload** data too, not just download
- reports:
  - **Download** in Mbps
  - **Upload** in Mbps
  - **Ping** in ms

**Reset Network Test**  
Clears the network summary box.

This does **not** affect Drive Test results.

**Cancel**  
Cancels an active network test.

If Chromium dependency preparation is still in progress, Cancel can stop that request before the actual FAST.com test even starts.
If the external test process is already running, Cancel requests shutdown of that process.

**Inline status area**  
Shows transient state such as:
- dependency preparation
- cancel requested
- other inline state messages

**Network Summary box**  
Shows one of these kinds of output:
- the placeholder text when nothing has run yet
- Chromium dependency preparation/failure text
- final FAST.com results
- failure or cancellation text

### Drive Tests section

**Select Drive 1 / 2 / 3**  
Each button opens a folder picker.

Important:
- the panel stores the selected **folder path**, not a friendly volume nickname
- the path box shows the real selected path
- you can benchmark **one**, **two**, or **three** paths in the same batch
- they do **not** need to be different volumes, but the feature is most useful when comparing different targets or different share paths

**Drive path boxes**  
Show the currently selected paths.

When empty, they show **No drive selected**.
When a path is present, the box holds the raw path string and is not auto-translated over on language refresh.
Trust the exact path text shown in the box.

**Test Size**  
Available options are:
- **256 MiB**
- **512 MiB**
- **1 GiB**
- **2 GiB**

Larger sizes reduce cache weirdness and better reflect sustained throughput, but they take longer and require more free space.

**Mode**  
Available options are:
- **Sequential**
- **Random**

Use the same mode and size across targets when comparing them.
Otherwise the comparison becomes junk food for the brain.

**Test Selected Drives**  
Runs the drive benchmark batch.

Behavior:
- runs the selected paths **in order**
- uses the same size and mode across the whole batch
- disables the selection controls and dropdowns during the run
- shows batch progress across all selected paths
- writes a timestamped summary per tested path

**Reset Speed Test**  
Clears drive-test results, clears selected paths, and resets the drive progress UI.

This does **not** affect the Network Test section.

**Cancel Speed Test**  
Requests cancellation of the current drive-test batch.

Cancellation is cooperative.
That means the current low-level operation finishes its current chunk safely, then the run exits cleanly instead of face-planting into the filesystem.

**Inline progress bar and percent**  
The drive benchmark shows a shared progress bar for the current batch.

The UI starts in an **Initializing...** state, then switches to progress once the backend starts emitting byte progress.
After the run it briefly shows **Finalizing...** before tearing down the busy UI.

**Drive Summary box**  
Shows:
- selected mode
- selected test size
- iteration summary
- per-drive start lines
- warnings
- per-drive results or per-drive failures

## How network testing works

### Provider and browser component
The network test runs through **FAST.com**.
The app may need a usable browser component before the test can begin.

So the flow is:
1. make sure the app has the required browser component
2. run the FAST.com test
3. read the returned result
4. show Download / Upload / Ping in the summary box

### Runtime asset gate behavior
Before the actual test runs, the panel may show a dependency-preparation state such as:
- preparing browser dependency
- downloading browser dependency
- verifying download
- install/extract failure
- checksum failure
- offline-blocked download

This is not cosmetic noise.
It is the real gate in front of the actual network test.

### Concurrency and timeout
Only **one network test** can run at a time per app window.
If a second request is made while one is already active, the backend returns **ALREADY_RUNNING**.

The network test also has a **60 second timeout**.
If FAST.com never completes or the child process hangs, the app cancels it and returns a timeout error.

### Result format
A successful network result shows:
- **Download** Mbps
- **Upload** Mbps
- **Ping** ms
- a source line that explicitly names **FAST.com (Netflix)**
- a local timestamp

If FAST.com returns partial data, the panel can show **N/A** for missing fields.
That is better than hallucinating numbers.

## How drive testing works

### Batch shape
A drive-test batch can contain up to **three** selected paths.
The app processes them one after another.

The summary starts with:
- **Mode**
- **Test Size**
- **Iterations**

The panel currently uses:
- **5 total iterations**
- **1 warm-up iteration**

The warm-up sample is discarded from the final averages when enough samples exist.
That is deliberate.
The first run is often a cache-priming liar.

### What gets measured
For each tested path, the panel reports:
- **Write** average, min, max
- **Read** average, min, max

Units are **MiB/s**.

A successful drive summary line looks like:
- Drive N (path) Results
- Write MiB/s (min, max)
- Read MiB/s (min, max)
- timestamp

### Preflight validation
Before a drive test starts, the app validates the target path.

It checks:
- filesystem approval / allowed root access
- ability to create the benchmark work area
- free-space availability with a safety margin
- ability to write a small probe file in the benchmark area

If preflight fails, the test stops **before** the benchmark body runs.
Typical preflight failures include:
- **INSUFFICIENT_DISK_SPACE**
- **DRIVE_NOT_WRITABLE**
- **MARKER_CREATE_FAILED**
- disk-space-check warning/failure conditions

When preflight blocks the run, the UI intentionally keeps the selected paths so the user can fix the problem and retry.

## Sequential vs Random

### Sequential mode
Sequential mode is for **large, continuous file movement**.
It is the better comparison for questions like:
- how fast can I copy media to this destination?
- how well will this path handle exports or proxies?
- which destination is better for large transcode outputs?

Notes:
- writes are flushed to stable storage with `datasync()` / `sync()` when supported
- reads are still affected by OS cache to some degree, because filesystems are tricky little goblins
- the benchmark expands the working set across **three temp files** and staggers reads to reduce the most obvious warm-cache lies

### Random mode
Random mode is for **small-block, latency-sensitive storage behavior**.
It is more relevant for questions like:
- which path is better for many small project files?
- which cache location behaves better for metadata-heavy work?
- how ugly is this share for Avid database or cache-like access patterns?

Notes:
- random mode uses **4 KiB blocks**
- it writes and reads a changing block order across temporary files
- it uses a lagged-read strategy to reduce some cache bias

Important support note:
- the current UI still reports **MiB/s**, not **IOPS**
- the tooltip mentions IOPS/latency concepts, but the rendered results are still throughput-style numbers
- do **not** promise the user an IOPS readout that the panel does not actually show

## Test size options

### 256 MiB
Use this for quick checks when time matters more than purity.
It is the most vulnerable to cache distortion.

### 512 MiB
A decent middle ground for quick comparison runs.

### 1 GiB
The current default.
A good first serious comparison size.

### 2 GiB
Best for more stable sustained-throughput comparisons when the target has enough free space and the user can tolerate a longer run.

## Temporary files and cleanup
Drive tests do **not** write into the app's userData folder first.
They create a temporary benchmark workspace **inside the selected target path**.

### Work folder
For each tested target, the app creates:
- `.lead-speedtest/`

That folder is hidden-style by name, but whether the user actually sees it depends on the platform, share, and Finder/Explorer settings.

### Sequential temp files
Sequential mode creates files with names like:
- `lead_speedtest_<sender>_<runId>_seq_a.tmp`
- `lead_speedtest_<sender>_<runId>_seq_b.tmp`
- `lead_speedtest_<sender>_<runId>_seq_c.tmp`

### Random temp files
Random mode creates files with names like:
- `.__lead_speedtest_random_<sender>_<runId>_a.tmp`
- `.__lead_speedtest_random_<sender>_<runId>_b.tmp`
- `.__lead_speedtest_random_<sender>_<runId>_c.tmp`

### Marker and probe files
The app also uses control files such as:
- `.__lead_speedtest_active_<runId>.lock`
- `.__lead_speedtest_writecheck_<runId>.tmp`

The lock marker prevents overlapping benchmark runs from trampling each other.
The write-check file is used during writability preflight.

### Cleanup behavior
The app tries to:
- delete benchmark temp files at the end of the run
- remove the active lock marker
- remove the `.lead-speedtest` directory if it is idle and empty

It also reclaims stale leftovers later.
Current cleanup thresholds are approximately:
- stale temp files: **45 minutes** old
- stale markers: **60 minutes** old

So if the app or machine crashes mid-run, old junk is supposed to get swept up later instead of haunting the share forever.

## What gets logged
Speed Test logs automatically even though the panel has no **Save Log** button.

Raw logs are written under:
- `LeadAEAssist/logs/speed-test/`

Each run typically produces:
- a structured per-job **JSONL** log
- a human-readable per-job **TXT** report

There is **no destination-side log export path** for this panel.
If support needs the logs, start with:
- **Log Viewer**
- or the raw `logs/speed-test/` folder

## Best practice for useful comparisons
- compare targets using the **same mode** and **same test size**
- test the **actual workflow path**, not an approximate cousin of that path
- use **Sequential** for copy/export/proxy questions
- use **Random** for cache/project/database-style questions
- avoid running other heavy jobs during the test
- repeat the test if one run looks absurdly different from the others
- use a larger test size when trying to reduce cache noise

## What Reset does and does not do

### Reset Network Test
- clears the network summary box
- does not affect drive selections or drive results

### Reset Speed Test
- clears drive results
- clears selected drive paths
- resets the drive progress UI
- does not affect network results

Neither Reset action deletes raw job logs that were already written to the app log library.

## Related pages
- /workflows/run-network-speed-test/
- /workflows/compare-drive-targets-with-speed-test/
- /troubleshooting/speed-test/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
