# Adobe Automate

## What this panel does
Adobe Automate is the "copy first, then drive Premiere" workflow.

It is built to:
- copy selected source files to a destination
- optionally verify the copied files
- optionally make a backup copy
- optionally import the verified destination copies into Premiere
- optionally create Premiere bins and map files into them
- optionally generate proxies and attach them back to the imported master clips
- optionally send a webhook when the job completes
- write raw job logs and an optional destination-side text log

This panel is **not** the same thing as the **Adobe Utilities** cleanup section inside **NLE Utilities**.
That other section is for cache/autosave cleanup. This panel is for ingest, import, bins, and proxies.

## Before you start
Confirm these first:
- Your source media files are readable.
- The destination folder already exists and is writable.
- If backup is enabled, the backup folder already exists and is writable.
- If you plan to use Premiere automation, **Premiere Pro is open with a project loaded**.
- The **Lead AE Assist Premiere CEP panel** is installed, open, and connected if you want import, bins, or proxies.
- If proxies are enabled, you know whether you want:
  - **Match Source (FFMPEG)**, or
  - an actual Adobe Media Encoder `.epr` preset

Important rules:
- **This panel is copy-first.** Premiere import is driven from the destination copies, not directly from the original source files.
- **Destination is required for almost every real job.** The only true no-destination exception is a pure **backup-only** job with backup enabled and all Premiere/proxy features off.
- **If Import into Premiere, Create Premiere Bins, or Generate Proxies is enabled, the Premiere CEP panel must be connected.**
- **Duplicate basenames block the job.** If two different source files would land on the same destination, backup, or proxy filename, Adobe Automate stops before queueing.
- **Proxy attachment is a Premiere workflow here.** Even FFmpeg-generated proxies still rely on the Premiere side being connected so they can be attached to clips.

## Default starting state
After **Reset** or after defaults are re-applied, the panel starts from roughly this baseline:
- Import into Premiere: **On**
- Create Premiere Bins: **On**
- Generate Proxies: **Off**
- Backup: **Off**
- Verification method: **BLAKE3**
- Save Log: **Off**
- Webhook: **Off**
- Parallel copy: **On**
- Auto threads: **On**
- Retry failures: **Off**
- Notes: empty

Proxy-specific notes:
- The proxy destination row is hidden until **Generate Proxies** is turned on.
- The default proxy preset is the virtual **Match Source (FFMPEG)** option, even though that control is hidden until proxies are enabled.
- FFmpeg fallback is allowed by default. The **Disable FFmpeg fallback** checkbox only appears when proxy settings are visible.

## How source input works
### Normal source selection
Click **Select Source** to choose one or more source files.

The panel then builds a file-info grid and tries to show:
- file name
- format
- resolution
- fps
- audio summary
- duration

The app also keeps a per-file working list so you can:
- drag files into bins
- disable import for specific files
- disable proxy generation for specific files
- remove specific files from the current job with the **x** button

### Source expansion and re-scan
At queue time the panel re-scans the chosen source list before starting.
That matters because:
- source lists loaded from presets/configs may need fresh access approval
- missing files are re-checked at start time
- very large selections can still fail with a scan timeout or truncation warning

If the scan times out or gets truncated, do not treat the result as trustworthy until the user narrows the selection and retries.

## Panel map

### Toolbar
**Preset dropdown**  
Lists Adobe Automate presets.

**Delete preset**  
Deletes the currently selected preset from the panel preset folder.

**Save**  
Writes the current Adobe Automate config to a JSON preset file.

**Load**  
Loads a saved config JSON file.

**Info icon**  
Shows the technical overview tooltip for Adobe Automate.

**Reconnect icon**  
Attempts to reconnect the desktop app to the Assist bridge / Premiere CEP side.

Use it when:
- Premiere was opened after the desktop app
- the bridge session dropped
- Adobe Automate says Premiere connection is required
- the toolbar connection state looks stale

### Input
**Select Source**  
Choose one or more source files.

**Source field**  
Shows the selected source paths. If many files are selected, the field summarizes the count and lists the first portion of the set.

**File info grid**  
Shows probed media metadata. This helps support catch obvious mismatches before the job starts.

### Import Options
**Import into Premiere**  
When enabled, Adobe Automate sends the verified destination copies into the Premiere project through the CEP panel.

**Generate Proxies**  
Turns on proxy generation and proxy-attachment behavior.

**Create Premiere Bins**  
Shows the file-to-bin and bin-order tools and sends the resulting bin structure into Premiere.

Important:
- These three options are what make this panel "Premiere automation."
- If any of them are enabled, the Premiere CEP panel must be connected.

### Proxy Settings
This section becomes active when **Generate Proxies** is on.

**Select Proxy Destination**  
Choose the base location for proxies.

Important proxy-destination behavior:
- If you leave this blank, proxies default under the main destination as `Destination/Proxies`.
- If you choose a folder that does **not** already end with `Proxies`, the backend appends a `Proxies` subfolder.
- If you pick a folder already named `Proxies`, that folder is used directly.

That means the effective output is often:
- selected destination + `/Proxies`
- or selected proxy base + `/Proxies`

Do not promise the user that proxies will land exactly in the folder they clicked unless that folder already ends with `Proxies`.

**Proxy preset dropdown**  
Lists the available proxy modes:
- **Match Source (FFMPEG - dynamic, no .epr)** - virtual preset, no Adobe Media Encoder preset file required
- any discovered Adobe Media Encoder `.epr` presets from the local Media Encoder preset folder

**Load Preset**  
Lets the user pick a specific `.epr` file manually.

**Refresh**  
Reloads the list of available `.epr` presets.

**Disable FFmpeg fallback**  
Appears only while proxy settings are visible.

Meaning:
- unchecked = if AME is unavailable or stalls, Adobe Automate is allowed to recover by using FFmpeg
- checked = if AME is unavailable or stalls, the proxy job fails instead of recovering

Important proxy rules:
- **Match Source (FFMPEG)** is not an Adobe Media Encoder preset. It deliberately bypasses AME and uses FFmpeg-only proxy generation.
- If a real `.epr` preset is missing or invalid and fallback is allowed, the job can still recover with FFmpeg.
- Proxy generation only applies to proxy-enabled source files. If no files remain proxy-eligible, proxy generation is turned off for that run.

### Unassigned Files
This is the working list for selected files.

Each file row can show:
- an **Import** checkbox
- a **Proxy** checkbox when global proxy generation is enabled
- the file name
- status text such as bin assignment or "Not importable"
- an **x** remove button

Important per-file behavior:
- Turning **Import** off for a file also turns **Proxy** off for that file.
- Turning **Proxy** on for a file forces **Import** on for that file.
- Files removed with the **x** button are removed from the current job only.
- Known project/session file types like `.aep`, `.prproj`, and `.sesx` are treated as **not importable** and are forced off.

### Bin Setup
**Drag bins to order**  
Controls the order of top-level and nested bins.

**Drag files into bins**  
Assigns selected files to specific bins.

**New Bin Name + Add Bin**  
Creates a top-level bin.

**Add Sub Bin**  
Creates a nested bin under the currently selected bin.

Important:
- **Add Sub Bin** requires a parent bin to be selected first.
- If **Create Premiere Bins** is turned off, the bin/file assignment tools are hidden.

### Verification and Logging
**Verification Method**  
Options:
- None
- Byte Compare
- BLAKE3
- SHA-256
- MD5
- xxHash64

General guidance:
- **BLAKE3** is the sane default for most users.
- **Byte Compare** is the slowest but simplest to explain.
- **None** is fastest but removes the integrity gate.

Important verification behavior:
- Adobe Automate copies first and then evaluates verification.
- Files that fail verification are not treated as clean candidates for later Premiere import/proxy work.
- If the user wants "import whatever copied, even if verify failed," this panel is the wrong temperament. It is stricter than that.

**Save Log**  
Writes the usual raw per-job logs into the app log library and also attempts a destination-side text log copy for successful manual jobs.

Typical saved filename:
- `AdobeAutomateLog_<timestamp>.txt`

See **Logs and support bundle** for the exact behavior.

### Automation Integration
**Webhook**  
Enables an HTTP/HTTPS webhook at the end of the run.

**Allow private webhook targets**  
Allows localhost/private network targets. Leave this off unless the user explicitly needs it.

**Send Log**  
Sends the collected log payload rather than a minimal success payload.

**Webhook URL field**  
Must be a full `http://` or `https://` URL.

Important webhook rules:
- blank URL + webhook enabled = validation failure
- malformed URL = validation failure
- localhost/private targets are blocked unless explicitly allowed

### Ingest Behavior
These settings control the copy/backup stage, not Adobe Media Encoder.

**Parallel Copy**  
Enables multi-threaded copy behavior.

**Auto Threads**  
Lets the app decide the copy-thread count.

**Retry Failures**  
Retries failed copy attempts.

**Threads slider**  
Used when Auto Threads is off.

Important:
- These settings do **not** tune AME.
- They do **not** change the Premiere import logic.
- They mainly affect the filesystem copy workload.

### Output
**Select Destination**  
Main destination for copied media.

**Select Backup**  
Optional backup destination.

**Enable Backup**  
Turns backup copy behavior on.

Important:
- Backup path is required when backup is enabled.
- Destination is still required unless the job is truly backup-only.
- Using the same physical target logic for destination, backup, and proxy outputs is a bad idea even when the app does not explicitly stop you. Distinct paths avoid filesystem nonsense.

### Notes
**Notes**  
Freeform notes stored with the saved config and included in the job summary.

### Controls and status area
**Automate**  
Queues the Adobe Automate job.

**Reset**  
Restores the panel to the default state.

**Cancel**  
Requests cancellation from the backend queue.

**Progress bar / stage line / hamster wheel**  
Shows copy/progress status and Premiere-related stage changes.

Typical stage family:
- copy / backup / validate
- import
- bins
- proxies
- attach
- complete

**Summary box**  
Shows the job preview and live summary.

**Hide log window**  
Hides the on-panel log without deleting the raw logs.

**Log window**  
Shows panel messages for the current session.

## What actually happens when you click Automate
This is the real workflow, stripped of decorative nonsense:

1. The app re-checks the source selection and prompts for file access approval if needed.
2. It expands the source list again before queueing.
3. It validates:
   - source files
   - destination
   - backup
   - proxy destination
   - proxy preset file access
   - webhook URL
   - basename collisions
4. It copies files to the destination.
5. It verifies the copied files if verification is enabled.
6. It optionally makes backup copies.
7. If Premiere automation is enabled, it sends the verified destination copies into the Premiere CEP workflow.
8. If proxy generation is enabled:
   - **Match Source (FFMPEG)** forces FFmpeg-only proxy creation
   - real `.epr` presets try Adobe Media Encoder first
   - if AME fails or stalls and fallback is allowed, FFmpeg fallback can recover the job
9. It attempts proxy attachment back to the imported clips.
10. It archives raw logs and optionally writes a destination-side text log.

## Common working modes

### Standard copy + import + bins + proxies
Use this when the user wants a normal editorial ingest handoff into Premiere with proxy generation.

Typical settings:
- Destination set
- Import into Premiere: on
- Create Premiere Bins: on
- Generate Proxies: on
- Save Log: optional
- Premiere CEP panel connected

### Copy + import, no proxies
Use this when the user wants copied media and a Premiere bin structure but does not need proxies.

Typical settings:
- Destination set
- Import into Premiere: on
- Create Premiere Bins: on
- Generate Proxies: off

### Copy-only or backup-only
Use this when the user wants filesystem copy behavior without Premiere automation.

Typical settings:
- Import into Premiere: off
- Create Premiere Bins: off
- Generate Proxies: off
- Destination set for copy-only
- or Backup enabled + Backup path set for true backup-only

This is the only sane way to use Adobe Automate without depending on the CEP connection.

## Outputs and log files

### Filesystem outputs
Depending on settings, Adobe Automate can produce:
- copied media in the destination folder
- backup copies in the backup folder
- proxies in:
  - `Destination/Proxies`
  - or `SelectedProxyBase/Proxies`
  - or the exact selected folder if it already ends with `Proxies`

### Premiere outputs
If Premiere automation is enabled, the job can create:
- imported clips in the active Premiere project
- bin structures in Premiere
- attached proxies on the imported master clips

### Raw logs
Raw Adobe Automate logs are written under the app log library:

`LeadAEAssist/logs/adobe-utilities/`

Typical files:
- `<timestamp>--<jobId>.jsonl`
- `<timestamp>--<jobId>.txt`

### Destination-side manual log copy
When **Save Log** is on, a human-readable text log is typically copied out as:

`AdobeAutomateLog_<timestamp>.txt`

Where it lands:
- usually the main destination
- in some no-proxy backup-only situations, the backup destination may be used instead

If the user cannot find a destination-side log, start in `LeadAEAssist/logs/adobe-utilities/` first.

## Support-critical caveats
These are the things most likely to burn support time:

- **Duplicate basenames are fatal.** Two files from different folders with the same filename can block the run before it starts.
- **Loading a preset does not preserve path approval.** Stored paths may still need to be re-approved.
- **Create Bins off hides the per-file working list.** If a user says the import/proxy toggles disappeared, check that setting.
- **Match Source (FFMPEG) is expected to bypass AME.** That is not a bug.
- **Disabling FFmpeg fallback is a conscious tradeoff.** It makes proxy failures harsher and less forgiving.
- **Proxy destination is effectively a base path, not always the final leaf folder.** The backend often appends `Proxies`.

## Related pages
- /workflows/adobe-automate-copy-import-bins-proxies/
- /workflows/adobe-automate-copy-import-no-proxies/
- /workflows/install-and-connect-premiere-cep-panel/
- /troubleshooting/adobe-automate/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
