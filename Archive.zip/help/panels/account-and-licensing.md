# Account and Licensing

## What this panel does
Use **Account and Licensing** to:
- check your current **Status**, **Plan**, **Expires**, **Trial remaining**, and **Reason**
- install a license file
- clear the license currently stored by the app
- start a browser-based subscription checkout
- sync a recent purchase into the desktop app
- open the billing portal for an active subscription
- copy **Version Info** for support

## How to open it
Open this panel from the **top-left titlebar settings button**.

It is not a normal sidebar tab. The app keeps this panel available so you can still recover access even if paid feature tabs are hidden.

## Before you start
A few things matter here:

- **Offline Mode blocks online account actions.** That includes:
  - **Subscribe**
  - **Sync Subscription**
  - **Manage Subscription**
- **Install License** and **Sync Subscription** are different:
  - **Install License** uses a local license file.
  - **Sync Subscription** refreshes access from your account while you are online.
- **Checkout and unlock are different steps.** Completing checkout in the browser does not always unlock the app immediately. Return to the app and use **Sync Subscription** if needed.
- **Clear License** removes the license currently stored by the app. If another valid license file is still available on the machine, the app can still show a license state afterward.
- This panel does **not** have a built-in log export button. For support, use the on-screen status text, **Copy version info**, screenshots, and any requested config files.

## Important behavior to understand

### Status shows current access, not purchase history
The panel reflects what the app can use **right now**.

Common states are:
- **Active**
- **Trial**
- **Locked**

A completed purchase does not help until the app can refresh or install the matching license for this machine.

### Expires and sync warnings can both be true
The **Expires** field shows the end of access for the current subscription period.

You may still see a warning such as:
- **refresh soon**
- **offline grace**

That is normal. It means the app needs to reconnect and refresh its subscription before access runs out.

### Offline use is limited
Some subscriptions allow a short offline grace period, but it is not indefinite.

If the panel warns that a refresh is due, reconnect and use **Sync Subscription** soon.

### Checkout, sync, and billing all use your browser
The app opens your default browser for checkout and billing.

A typical flow is:
1. start checkout in the browser
2. finish payment there
3. return to the app
4. click **Sync Subscription** if the app still shows **Locked**

### Purchase controls can hide when access is already active
If the app already has a working license, the **Billing** section may hide or shrink.

That is expected. You can still use **Sync Subscription** as a recovery step when needed.

## Panel map

### Version Info card
This section shows version details that are useful for support, such as:
- app version
- platform and architecture
- other environment details the app reports safely

Use **Copy version info** whenever support asks what build you are running.

### License summary
The summary card shows:
- **Status**
- **Plan**
- **Expires**
- **Trial remaining**
- **Reason**

These values come from the currently active license or subscription state.

### Warning banner
The warning banner is not decoration.

It can explain conditions such as:
- **trial active**
- **refresh soon**
- **offline grace**

If you are troubleshooting access, read the warning text before clicking anything else.

### Install License…
Use this when you have a license file from your licensing workflow.

Notes:
- hidden files can still be selected if your operating system allows it
- the file must be a valid license for this app
- if install fails, verify that you selected the correct file for this app and machine

On success, the app refreshes the license summary.

### Clear License
Use **Clear License** to remove the license currently stored by the app.

Notes:
- this clears the app's stored license
- if another license file is still being used elsewhere on the machine, the app may still show a license state afterward

If the panel still looks active after a clear, compare **Status**, **Plan**, and **Reason** before and after the action.

### Sync Subscription
Use **Sync Subscription** after checkout or whenever your subscription state looks out of date.

Notes:
- **Offline Mode** blocks this action
- the machine needs internet access
- the billing system may take a moment to finish processing a very recent purchase

If sync fails, capture the exact status text and continue with the troubleshooting page.

### Manage Subscription
Use **Manage Subscription** to open the billing portal in your browser.

Notes:
- this works best when the app already shows an active subscription
- **Offline Mode** blocks this action
- if no active subscription is installed yet, the portal action can fail even if checkout finished earlier

### Billing section
When the app does not currently have active access, the panel may show:
- a plan dropdown
- **Subscribe**
- a status line

**Subscribe** opens the checkout page in your default browser.

After checkout, return to the app and use **Sync Subscription** if the app does not unlock on its own.

### Status lines
The panel uses small status lines for actions such as:
- copy success or failure
- install success or failure
- checkout, sync, or billing messages

These short messages are often the most useful thing to capture for support.

## Files and settings
This panel does not create normal media outputs.

The most commonly requested non-secret file is:
- `LeadAEAssist/config/state.json`

You usually only need that file when support asks for it.

## Support tips
Start with:
- a screenshot of the full panel
- the exact status-line text
- **Copy version info**
- whether **Offline Mode** is on

Do **not** share license secrets or private account material unless support explicitly asks for them.

## Related workflows
- Install a license file: `/workflows/install-a-license-file/`
- Subscribe and sync: `/workflows/subscribe-and-sync-subscription/`
- Open billing portal: `/workflows/open-the-billing-portal/`
- Copy version info: `/workflows/copy-version-info-for-support/`

## Related troubleshooting
Use `/troubleshooting/account-and-licensing/` when you see:
- install failure
- checkout completed but the app stayed locked
- sync failure
- portal failure
- Clear License appearing ineffective
- missing feature tabs after licensing changes
