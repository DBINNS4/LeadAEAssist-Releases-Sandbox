# Preferences

## What this panel does
Preferences is the app-wide settings panel.

Use it to:
- control **Offline Mode**
- set the app **theme** and **language**
- securely save the **AI API key**
- define the global **webhook URL** and related behavior
- toggle **crash reporting**
- control **auto-update** behavior
- run **temp** and **cache** cleanup
- install, remove, or inspect the **Adobe Premiere CEP panel**
- reset global settings back to defaults

This panel does not launch media jobs directly. It changes app-wide behavior that other panels use.

## Before you start
A few rules matter here:

- **There is no Save button.** Most settings save as soon as you change them or leave the field.
- Some settings apply **immediately**, especially:
  - **Offline Mode**
  - crash reporting
  - theme
  - language
- Some settings matter mostly on the **next launch**, such as:
  - **Clear temp on startup**
  - **Clear cache on startup**
- The **AI API key** field does **not** show the stored key back to you. A blank field can still mean a key is already saved.
- The Preferences tab can be hidden if the current license does not include it.
- Normal settings and sensitive values are not stored in exactly the same place.

## Important behavior to understand

### Saving is automatic
The panel saves as you change controls.

That means:
- checkboxes usually save on **change**
- text and number fields usually save on **change** or **blur**
- there is no final **Apply** step

If a save fails, the panel can show:
- a red inline error banner
- a toast
- an unsaved marker

### The AI API key is stored separately
The app treats the AI API key as sensitive.

What you will usually see:
- the field clears after load
- the real key is not printed back into the field
- a saved key is indicated by placeholder text rather than by showing the secret

### Mixed changes can partly succeed
If you change several things at once, some settings may save even if a later step fails.

A common example:
- ordinary preferences save correctly
- the AI API key update fails afterward

If that happens, re-check which settings actually changed.

### Theme can stay synced with the top bar
The Preferences theme dropdown and the top-bar theme toggle stay in sync.

If you reset Preferences and the theme still looks unchanged after reload, the saved theme state from the app or top bar may still win.

### Offline Mode is a real network gate
Offline Mode blocks non-local network access across the app.

That means remote services stop working until Offline Mode is turned off again.
Local machine workflows such as `localhost` can still work.

## Panel map

### General

**Enable Offline Mode**  
Turns app-wide Offline Mode on or off.

When enabled:
- non-local network calls are blocked
- update checks are disabled
- subscription and billing sync flows are blocked
- remote webhooks are disabled
- online transcription through Whisper API is unavailable
- local machine workflows such as `localhost` are still allowed

### Theme & Appearance

**Theme dropdown**  
Options:
- `Light`
- `Dark`

The selected theme updates the app and stays synced with the top-bar theme toggle.

**Language dropdown**  
Supported values currently include:
- English (`en`)
- Spanish (`es`)
- French (`fr`)
- German (`de`)
- Japanese (`ja`)
- Chinese (`zh`)

If saving the new language fails, the dropdown returns to the previous saved language.

### AI Settings

**AI API Key**  
Password field for the global AI API key.

Important behavior:
- the field clears after load
- the app does not reveal the stored key
- if a key is already saved, the placeholder changes to:
  - `Saved (enter a new key to replace)`

If you type a new key and save succeeds:
- the key is stored
- the field clears again
- the placeholder stays in the “saved” state

If you clear the field and save:
- the stored key is removed

### Webhooks & Integration

**Webhook URL**  
Global automation endpoint.

Validation rules:
- blank is allowed
- a non-blank value must be a valid `http://` or `https://` URL
- invalid URLs block related saves

**Enable Webhook Logging**  
Turns on webhook logging.

**Send Only on Failure**  
Keeps the webhook configuration active while limiting it to failure-oriented use.

Notes:
- the URL must be valid first
- if the URL is blank or invalid, the related webhook checkboxes are disabled
- the global webhook settings are reused by other workflow panels

When Offline Mode is on, remote webhooks stay saved but are not sent.

### Advanced ▸ Diagnostics

**Enable crash reporting**  
Controls crash-reporting preference.

This setting is a little unusual:
- the app tries to change crash-reporting behavior immediately
- then it saves the preference

If the immediate change works but the save fails, the change may only last until restart.

Offline Mode overrides crash uploading even when crash reporting is enabled.

### Advanced ▸ Updates

**Check for updates on launch**  
Controls automatic update checking during startup.

**Automatically download updates**  
Controls whether available updates begin downloading automatically.

**Check for Updates**  
Runs a manual update check now.

**Download**  
Appears when an update is available and automatic download is off.

**Restart & Install**  
Appears after an update has already been downloaded.

**Update status line**  
Shows states such as:
- checking
- no update available
- update available
- download progress
- ready to install
- disabled by Offline Mode
- error

### Advanced ▸ Storage & Maintenance

**Temp folder path**  
Shows the app-owned temp directory.

**Open Temp Folder**  
Opens that temp folder in Finder or File Explorer.

**Clear Temp Now**  
Runs temp cleanup using the current **Delete temp entries older than (days)** value.

**Clear Cache Now**  
Runs cache cleanup.

**Clear temp on startup**  
Runs temp cleanup automatically at startup.

**Clear cache on startup**  
Runs cache cleanup automatically at startup.

**Delete temp entries older than (days)**  
Accepted range:
- `0` to `3650`

This value controls both startup cleanup and manual **Clear Temp Now**.

### Advanced ▸ Adobe Premiere Panel (CEP)

**CEP status**  
Shows whether the bundled Premiere panel appears to be:
- installed in the user CEP folder
- installed in a system CEP folder
- not installed

The status line can also show the detected install path.

**Install/Repair Panel**  
Installs the bundled signed panel package into the **user CEP extensions folder**.

Notes:
- it keeps the install user-scoped
- on macOS the app may clear quarantine attributes from the installed extension
- it can preserve an existing `bridge.json` file when possible

**Uninstall Panel**  
Removes the user-scoped installed panel folder.

**Open CEP Folder**  
Opens either:
- the installed panel folder, if present
- or the base CEP extensions directory

### Reset Preferences

**Reset Preferences**  
Resets saved preferences to defaults after confirmation.

Reset does all of this:
- restores default preference values
- clears webhook URL and related webhook options
- clears the saved AI API key state
- repopulates the UI from the reset result
- clears earlier save-error state when successful

Important nuance:
- if normal preference reset succeeds but the AI API key cannot be removed, the panel warns that the key may still be present

### Save feedback
The panel uses two feedback surfaces:

**Inline save error banner**  
Used for save failures and some recoverable warnings.

**Toast**  
Used for:
- normal success messages
- non-fatal warnings
- persistent failure notices

## Where settings are saved

### Normal preferences
Saved in:
- `LeadAEAssist/config/state.json`
- `LeadAEAssist/config/state.json.bak`

### Sensitive values
The actual AI API key is stored separately from the plain settings file.

Do not share the real key unless support explicitly asks for it.

## Offline Mode in plain language

### What still works
- local filesystem operations
- local processing jobs
- local `localhost` automation endpoints

### What stops working
- update checks and downloads
- billing portal, checkout, and subscription sync
- remote webhook delivery
- Whisper API online transcription
- other non-local network-dependent flows

### What the user still sees
The saved webhook URL can remain visible in the field.

That is expected. Offline Mode disables remote execution, not the stored setting itself.

## Maintenance behavior

### Temp cleanup is age-based
The **days** field controls what manual temp cleanup removes.

### Cache cleanup is broader than temp cleanup
Cache cleanup clears browser-style cache layers and the app's own cache directories.

Users sometimes expect it to clear logs too.
It does not.

### There is no visible “Clear Logs” control here
For log collection or export, use **Log Viewer**.

## Adobe Premiere CEP install behavior
Preferences is the user-facing installer surface for the bundled CEP extension.

In normal use:
- **Install/Repair** writes to the user CEP extensions folder
- **Uninstall** removes the user copy
- **Open CEP Folder** opens the installed path when present, or the base CEP folder otherwise

## Related pages
- /workflows/configure-offline-mode-and-update-behavior/
- /workflows/save-ai-api-key-and-global-webhook-settings/
- /workflows/clear-temp-and-cache-from-preferences/
- /workflows/reset-preferences-safely/
- /workflows/install-and-connect-premiere-cep-panel/
- /troubleshooting/preferences/
- /reference/file-locations/
- /reference/logs-and-support-bundle/
