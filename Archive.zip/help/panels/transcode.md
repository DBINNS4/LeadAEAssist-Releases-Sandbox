# Transcode

## What this panel does
Transcode converts one or more source files into new media files in a user-chosen output folder.

It can also:
- watch a folder and automatically process arriving files
- run audio-only exports
- apply a LUT
- preserve source metadata where possible
- attach MCC or SCC captions into an MXF output
- run verification after encode
- send webhook notifications

Do not use this panel for verified source copying, transcription, subtitle editing, or Premiere automation.

## Before you start
Decide which operating mode you actually need:
- normal one-time transcode of one or more files
- Watch Mode on one folder
- audio-only export
- caption embedding into MXF

Confirm these up front:
- the source media is readable
- the output folder exists and is writable
- Watch Mode output is **outside** the watch folder
- you know whether you need a standard transcode, Match Source, or caption attach
- you understand that some dropdown options depend on available codecs, compatibility rules, and license state

## How this panel decides what you can pick
This panel does not show a giant static list of codecs like a cursed 2009 utility.
Most dropdowns are filtered live from three things:
- the Assist Codex compatibility layer
- the bundled FFmpeg tools
- license checks for locked options

That means:
- missing options are often intentional
- some options can appear disabled or locked
- a preset loaded from another machine or older version may normalize or warn if the saved choice is not available now

## Default starting state
After Reset or after the managed Default preset is applied, the Transcode panel returns to a conservative base state:
- Preserve Metadata: **On**
- Verification Method: **Duration / Frame**
- Save Log: **Off**
- Webhook: **Off**
- Watch Mode: **Off**
- Process existing files on start: **Off**
- Match Source: **Off**
- Audio Only: **Off**
- Output folder: blank
- Notes: blank

Most format-specific dropdowns are cleared until you choose an output format.

Important exception:
- if all selected inputs are audio-only files, the panel can auto-enable and lock **Audio Only** so users do not try to set video controls for files that have no video stream

## Input area

### Select Source
In normal mode, **Select Source** opens a file picker and accepts one or more files.

In Watch Mode, the same control becomes **Select Watch Folder** and accepts exactly one folder.

Rules that matter:
- normal mode is file-based, not folder-based
- Watch Mode is folder-based, not file-based
- Match Source requires one **video file**, so it is incompatible with watch folders and multiple selected files

### File info grid
After files are selected, the panel probes each one and fills the grid with:
- file name
- detected container/format label
- resolution
- frame rate
- audio summary
- duration

Support use:
- this is the quickest way to spot audio-only files, DNx sources, or obvious metadata mismatches before the user presses Start

Special case:
- in Watch Mode the file-info grid is hidden and replaced by a single watched-folder path field

## Video settings

### Match Source
**Match Source** is narrower than users assume.
It requires exactly one selected **video file** and uses source metadata to set:
- resolution
- frame rate
- field order

What it does not mean:
- it does not automatically clone every source setting
- it does not work for folders, Watch Mode, multiple files, or audio-only inputs

When Match Source succeeds:
- the panel fills resolution and frame rate from the source
- those controls are disabled to avoid accidental drift
- field order may also be populated from source metadata

If the source values are unusual for the selected output format, the panel can warn and still attempt the job.

### Preserve Metadata
**Preserve Metadata** is on by default.

In practice, preservation behavior depends on output type:
- for containers that can carry the data cleanly, metadata is preserved in-container where possible
- for MP4, M4V, MKV, and WebM, some non-A/V tracks or side data cannot be embedded reliably, so the app can write a sidecar metadata JSON file next to the output
- for image sequence outputs, metadata is written to a sidecar JSON because a frame sequence is not a single container file

That sidecar is not an error. It is the app trying not to throw metadata into the sea.

### Output Format and Container
These two dropdowns must agree.
The panel treats bad format/container pairs as real configuration errors, not mild suggestions.

Important rules:
- image sequence formats require the `image_sequence` container
- `image_sequence` container requires an image sequence output format
- ProRes 4444 style outputs plus MP4 can warn because MP4 does not support alpha

If the selected pair is incompatible, the job is blocked before FFmpeg runs.

### Resolution, Frame Rate, Pixel Format, Color Range, LUT, Field Order
These control the video encode when the job is not in audio-only mode and not in caption-attach mode.

Notes:
- some lists are filtered by the current output format
- a LUT file must be a supported LUT type such as `.cube`, `.3dl`, or `.dat`
- image sequence outputs still use video settings, but the audio section becomes unavailable
- field order matters for interlaced deliverables such as some XDCAM-style outputs

## Audio settings

### Audio Only
**Audio Only** converts the panel into an audio-wrapper export path.

When enabled:
- video-only controls are disabled
- the output type is effectively chosen by the audio wrapper
- the audio dropdown switches from normal codec choices into audio-only wrapper choices such as:
  - mp3
  - wav
  - flac
  - m4a
  - ogg
  - opus

The backend then resolves the actual encoder and default bitrate from that wrapper.

The panel can auto-enable Audio Only when all selected inputs have no video stream.
That is expected behavior, not a ghost in the machine.

### Normalize Audio
Applies normalization during output.
Use this when the workflow wants loudness correction or less wildly uneven source material.

### Audio codec/wrapper, channels, sample rate, bitrate
For normal video jobs, the audio dropdown reflects codecs allowed for the current output format and container.
For audio-only jobs, it behaves like a wrapper/output type selector.

Support notes:
- some channels or sample rates are rejected if they are not valid for the chosen codec/format combination
- `preserve` is a valid channel control state for many workflows
- image sequence outputs disable the whole audio section because frame sequences do not carry audio

### Audio Delay
The UI exposes audio delay in milliseconds.
The current start validation expects **0 ms or greater**.
If a user says a preset contains a negative delay, treat that as a preset/history artifact and validate against the current UI rules before re-running the job.

## Caption attach (MCC/SCC to MXF)
The caption row under Audio Settings is really its own constrained workflow.

When a caption sidecar is attached:
- only `.mcc` or `.scc` files are accepted
- `.scc` is converted to `.mcc` before embed
- Match Source is forced on
- container is forced to **MXF**
- output-format/container controls are locked
- exactly **one** input file is required
- audio-only mode is not allowed

Backend behavior:
- source video/audio essence is stream-copied into MXF where possible
- verification checks for an embedded SMPTE-436M ANC data stream instead of using normal transcode QC heuristics

This is not the right workflow for batch caption attachment or for a folder watch job.

## Verification and logging

### Verification Method
Available methods are:
- **Duration / Frame** - fast metadata-based verification; the safest default for day-to-day work
- **SSIM / PSNR** - slower visual-quality analysis; useful for QC, testing presets, or comparing lossy encodes

Behavior that matters:
- audio-only outputs skip normal video verification
- image sequence outputs skip file-based verification
- caption-attach jobs use a caption-specific verification path
- if a job changes geometry or frame rate, SSIM/PSNR can auto-fallback to metadata verification because direct frame comparison stops being meaningful

### Save Log
Manual one-time transcode:
- if Save Log is on, the app copies a readable `TranscodeLog_<timestamp>.txt` into the chosen output folder
- raw per-job logs still go into the app log library under `LeadAEAssist/logs/transcode/`

Watch Mode:
- the watch session log is still archived in the app log library when watching stops
- unlike Ingest, Transcode watch mode does **not** appear to export a `WatchLog_...` copy into the transcode output folder

That distinction matters when support says “look in the output folder” and the user quite reasonably says “there is nothing there.”

## Automation integration
The Webhook section lets the panel notify an n8n or similar endpoint.

Options:
- **Webhook** - enable webhook delivery
- **Allow private or localhost targets** - required for local or private-network hosts, `localhost`, or private network addresses
- **Send Log** - include log data in the webhook payload

Validation rules:
- the URL must be a full `http://` or `https://` address
- it must include a hostname
- some environments can require `https://`
- private or localhost targets are blocked unless explicitly allowed

## Watch Mode
Use Watch Mode when the source is a folder that will receive new files over time.

Rules:
- Watch Mode requires exactly one selected input folder
- the watched folder must exist and be accessible
- the output folder must exist and be accessible
- the output folder cannot be the watch folder or any subfolder of it
- the Start button stays disabled until both watch input and output pass validation

### Process existing files on start
If enabled, the panel queues eligible files that are already present in the watch folder when Watch Mode starts.
It does **not** mean the app will keep re-queuing old files forever.

### Stop Watching behavior
Stopping the watcher does not necessarily archive the session log immediately.
If watch-triggered jobs are still running or queued, the app waits for them to finish or cancel before finalizing the session log.

## Output section, notes, and controls

### Select Output
Choose the output folder for the transcode results.
This must be a folder, not a file path.

### Notes
Freeform notes saved with the preset/config and available for summary/log context.

### Start / Reset / Cancel
**Start**
- queues a manual transcode job
- or starts Watch Mode if Watch Mode is enabled

**Reset**
- clears current state back to the managed default baseline

**Cancel**
- cancels a queued/running manual job
- or becomes **Stop Watching** when Watch Mode is active

### Summary and log window
The Summary box is the fast human-readable configuration preview.
It is useful for support because it exposes the job mode without making the user recite every dropdown aloud like a hostage video.

The log area below it is append-only job output for the current panel session.

## What gets written to disk
Typical outputs include:
- transcoded media files in the selected output folder
- readable job log copy in the output folder when Save Log is enabled for a manual job
- metadata sidecar JSON files for preserve-metadata compatibility cases and image sequence outputs
- raw app logs under `LeadAEAssist/logs/transcode/`

Output naming behavior:
- single-file jobs usually use the source basename plus the chosen container extension
- batch jobs add a numeric suffix such as `_000`, `_001`, and so on
- if an output name already exists, the app adds another numeric suffix to avoid collision
- illegal filename characters are sanitized before writing

## Recommended workflows
Use these pages for common operator tasks:
- **Workflow - Batch transcode**
- **Workflow - Watch-folder transcode**
- **Workflow - Embed captions in MXF**

## Common trouble spots
Most support cases cluster around these:
- Start button disabled because Watch Mode input/output is invalid
- Match Source used with a folder or multiple files
- image sequence/container mismatch
- caption attach attempted with more than one input
- Save Log expected to behave like Ingest Watch Mode
- SSIM/PSNR expected on jobs that changed frame rate or geometry
- audio-only mode auto-enabled because the selected inputs contained no video stream

## Related pages
- /workflows/batch-transcode/
- /workflows/watch-folder-transcode/
- /workflows/embed-captions-in-mxf/
- /troubleshooting/transcode/
- /troubleshooting/watch-mode/
- /reference/logs-and-support-bundle/
- /reference/file-locations/
