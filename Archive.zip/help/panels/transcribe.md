# Transcribe

## What this panel does
Transcribe converts media into text, subtitle, caption, or burn-in deliverables in a user-chosen output folder.

Use it when you need one of these:
- plain transcript text
- subtitle files such as **SRT** or **VTT**
- broadcast caption files such as **SCC** or **MCC**
- syncable script CSV output
- a rendered burn-in deliverable
- optional translation after transcription
- optional automatic handoff to **Subtitle Editor**
- watch-folder automation for incoming files

Do not use this panel for media transcoding, ingest verification, or Premiere automation.

## Before you start
Confirm these up front:
- Your input media is readable.
- Your output folder exists and is writable.
- You know which transcription engine you actually want.
- You know which output format the user needs.
- If Watch Mode is planned, the watch folder and output folder are different locations.

Important rules:
- **This panel exports one output format per job.** The output format picker is a single selection, not a multi-select.
- **Watch Mode requires one watch folder and one output folder.**
- **The output folder must not be the same as or inside the watch folder.**
- **SCC is a broadcast-caption path, not a casual subtitle format.** It is much stricter than SRT or VTT.
- **Burn-in is a rendered video output.** It does not have a text preview.

## Default starting state
After Reset or after the managed defaults are re-applied, the panel starts from this baseline:
- Engine: **WhisperX**
- Language: **English**
- Accuracy: **Auto**
- Translation: **Off**
- Translate target: **English**
- Output format: **Plain Text (.txt)**
- Remove leading characters: **On**
- Watch Mode: **Off**
- Edit Subtitle after export: preserved from the user's previous workflow choice

## How input works
### Normal mode
In normal mode, **Select Files** accepts one or more source files.
The selected list is shown in the input field, and the file-info grid tries to probe each file for:
- format
- resolution
- fps
- audio summary
- duration

### Watch Mode
In Watch Mode, the input area changes from a file list into a single watch-folder path.
The file-info grid is hidden because the watcher is waiting for future files rather than working from a fixed batch.

## Panel map

### Toolbar
**Preset dropdown**  
Shows saved Transcribe presets.

**Save / Load**  
Save the current Transcribe configuration as a preset or load one from disk.

**Info icon**  
Shows the panel overview tooltip.

**Edit Subtitle after export**  
When enabled, successful subtitle/caption outputs can automatically open in **Subtitle Editor**. This is treated as a workflow preference and is preserved across resets.

**Open Editor…**  
Opens the Subtitle Editor directly without running a Transcribe job first.

### Input
**Select Files**  
In normal mode, selects one or more media files.

**Input field**  
Shows either the file list or the watch-folder path, depending on mode.

**File info grid**  
Shows the probed media summary for selected files. FFprobe failures appear here as per-file issues.

### Engine Settings
**Engine**  
Available engines are:
- **WhisperX**
- **WhisperAPI**
- **Lead AI**

Use them like this:
- **WhisperX** - local-style transcription path with adjustable accuracy options.
- **WhisperAPI** - API-backed path and the only engine that allows non-English translate targets in the current UI.
- **Lead AI** - local runtime path that can require asset/model preparation before a job starts.

**Language**  
Sets the transcription language.

**Accuracy**  
Available values are **Fast**, **Auto**, and **Accurate**.

Important engine rule:
- **Accuracy applies to WhisperX only.** When another engine is selected, the control is locked and forced back to `Auto`.

Important language rule:
- **Lead AI + non-English** can require a multilingual local model. The panel shows a hint when that combination is selected.

### Output format selector and sample preview
**Sample preview**  
Shows a format-oriented preview of what the output will roughly look like.

Preview notes:
- TXT, SRT, VTT, and Scripted CSV previews are text examples.
- SCC and MCC previews are illustrative and should not be treated as a final compliance proof.
- **Burn-in has no text preview** because the actual deliverable is rendered video.

**Output format dropdown**  
This selects one and only one output format for the job:
- Plain Text (`.txt`)
- SubRip (`.srt`)
- WebVTT (`.vtt`)
- Scenarist CC (`.scc`) - beta / advanced
- MacCaption (`.mcc`) - beta / advanced
- Scripted CSV (`.csv`)
- Burn-in video

See **Transcribe output formats** for the "which one should I use" reference.

### Plain Text (.txt)
Use TXT when the user wants a readable transcript instead of subtitles.

Main controls:
- **Timestamp Placement**
- **Timecode Format**
- **Frame Rate Override (FPS)**
- **Start Timecode Offset**
- **Include Speaker Names**
- **Group by Speaker**

Important TXT rule:
- Timestamp Placement controls whether TXT timecodes are included at all. If placement is `None`, timecode-specific fields are effectively irrelevant.

### SubRip (.srt)
Use SRT for the most common subtitle exchange workflow.

Main controls:
- **Max characters per line**
- **Max lines per subtitle block**
- **Max subtitle duration**
- **Line endings**
- **Include Speaker Names**
- **UTF-8 BOM**
- Advanced QC controls such as:
  - max CPS
  - min duration
  - min split duration
  - prevent overlaps
  - allow end extension
  - max end extension

### WebVTT (.vtt)
Use VTT when the output is headed toward web/native player subtitle workflows.

Main controls:
- **Max characters per line**
- **Max lines per subtitle block**
- **Max subtitle duration**
- **Include Speaker Names**
- **Include WebVTT style metadata**
- QC controls similar to SRT

### Scenarist CC (.scc)
Use SCC only when the user explicitly needs a CEA-608 style broadcast caption deliverable.

Main controls:
- **Max characters / max lines / max duration**
- **Start timecode**
- **Caption service (CC1-CC4)**
- **Text alignment**
- **Placement controls** with visual grid and nudge buttons
- Advanced 608 controls such as:
  - allow NDF
  - repeat control codes
  - repeat PAC codes
  - strict character encoding
  - safe margins
  - timing anchor
  - start reset behavior
  - pre-roll
  - prefix words
  - caption slip / offset
- QC controls such as:
  - QC enforcement
  - auto-shape mode
  - micro-cue / micro-gap merging
  - max retime shift
  - reading-speed and timing thresholds

Important SCC rules:
- SCC is wired around a **29.97 fps timebase**.
- Selecting SCC can auto-force supporting timecode/FPS prerequisites in the UI.
- The panel warns before queueing if the source FPS or the FPS override is incompatible.
- SCC is a brittle deliverable path. When in doubt, use SRT/VTT unless the downstream system explicitly requires SCC.

### MacCaption (.mcc)
Use MCC when the workflow needs a broadcast-style caption deliverable with 708-oriented controls and optional 608 compatibility.

Main controls:
- **Max characters / max lines / max duration**
- **Start timecode**
- **Frame rate override**
- **Caption slip / offset**
- **Text alignment**
- **708 service number**
- **Language**
- **Offset policy**
- **608 compatibility toggle**
- **CDP/service-info options**
- **Ping-pong windows**
- **Visual 708 placement** with anchor controls and a placement grid
- Advanced 608 compatibility controls and QC controls

Practical guidance:
- MCC is an advanced deliverable. Treat it like a specialist output, not the default subtitle path.

### Scripted (CSV)
Use Scripted CSV when the user wants syncable text for editorial or script workflows rather than subtitle files.

Main controls:
- **Timestamp Placement**
- **Timecode Format**
- **Frame Rate Override**
- **Start Timecode Offset**
- **Include Speaker Names**
- **Group by Speaker**

The exported CSV is designed around timecode, speaker, and text columns.

### Burn-in
Use Burn-in when the user wants video with the subtitle text rendered into the picture.

Important burn-in notes:
- Burn-in is **not** a text file export.
- The panel preview does not show a text sample for burn-in.
- The result is a rendered video file written to the output folder.

### Enhancements
This block modifies the transcript content before it is written to the deliverable.

Available options:
- **Remove non-speech**
- **Remove fillers**
- **Remove leading characters**
- **Redact explicit**

Use these carefully. They are convenience cleanup controls, not a magic truth serum.

### Translate
This block controls optional transcript translation.

Controls:
- **Enable translation**
- **Target language**

Important translation rules:
- In the current UI, **non-English translate targets require WhisperAPI**.
- When another engine is selected, the translate target is forced/locked back to English.
- The Translate section represents **post-process translation of the transcript output**, not a guaranteed one-step "translate instead of transcribe" engine mode.

### Automation / Webhook Integration
Controls:
- **Enable n8n webhook**
- **Allow private or localhost targets**
- **Webhook URL**
- **Send log**

Validation rules:
- The URL must be a full `http://` or `https://` address.
- A hostname is required.
- Localhost/private-network targets are rejected unless private targets are explicitly allowed.

### Watch Mode
**Enable Watch Mode**  
Turns the panel into a watch-folder workflow.

Behavior changes:
- **Select Files** becomes **Select Watch Folder**.
- The input switches from file list to one folder path.
- The file-info grid is hidden.
- **Start** becomes **Start Watching**.
- **Cancel** becomes **Stop Watching**.

Watch Mode rules:
- Watch Mode requires a watch folder.
- Watch Mode still requires an output folder.
- Watch Mode still requires one output format.
- The output folder must not be the same as or inside the watch folder.
- While a watch session is active, the watch checkbox is locked so the user cannot flip modes mid-session and create nonsense.

### Output
**Select Output**  
Required for all jobs.

**Output path field**  
Shows the currently selected destination folder.

Transcribe writes its deliverables to the selected output folder using the chosen output format.

### Notes
Free-text note area for user context.
The note is included in the job summary/log path rather than changing media content.

### Controls and status
**Start / Start Watching**  
Builds the config, validates it, runs preflight warnings, and queues the job or watcher.

**Reset**  
Restores the panel to defaults.

**Cancel / Stop Watching**  
Cancels the current job or stops the active watch session.

**Summary box**  
Shows the current job preview before the run and terminal summary afterward.

**Hide log window**  
Hides the live panel log without disabling actual log writing.

**Panel log**  
Shows live queue/status/error messages for the current panel session.

## Important behavior rules
### Lead AI asset/model preparation
Lead AI jobs can trigger startup preparation for local transcription assets/models.
During that phase:
- the Start action can be temporarily blocked
- the summary area can be reused to show the asset/model preparation status
- cancelling/failing the preparation restores the normal panel summary

This is normal. It is not the same as a frozen UI.

### Output is single-format, not multi-format
The panel stores output format as a single selected value and then turns that into one active output type in the final config.
If the user asks, "Why did it only make SRT and not VTT too?" the answer is: because this panel runs one output format per job.

### SCC can auto-adjust prerequisites
When SCC is selected, the panel can auto-normalize supporting settings such as:
- timecode inclusion
- timecode style
- FPS override

That is intentional. The UI is trying to stop the job from walking off a cliff.

### Reset preserves subtitle-editor handoff
Reset clears most job state, but it intentionally preserves **Edit Subtitle after export**. That is a workflow preference, not a transient field.

## Logging expectations
Raw Transcribe logs are written under:
- `LeadAEAssist/logs/transcribe/`

Important logging note:
- Manual Transcribe does **not** currently expose a destination-side **Save Log** option like Manual Transcode.
- Watch-session archives also live under the app log library.
- If support tells a user to look for a Transcribe log in the output folder first, support is guessing.

## Related pages
- /workflows/transcribe-batch-files/
- /workflows/transcribe-watch-folder/
- /workflows/export-broadcast-captions-scc-mcc/
- /workflows/send-output-to-subtitle-editor/
- /troubleshooting/transcribe/
- /reference/transcribe-output-formats/
- /reference/logs-and-support-bundle/
