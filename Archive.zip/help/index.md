# Lead AE Assist Help

## Start here
Use this bundled help when a user needs one of three things:
- **Learn a panel** step by step.
- **Unblock a failure** with symptom-first troubleshooting.
- **Collect the right evidence** before support escalates the issue.

This help is written for people using the shipped app.

## Fastest paths
- Need to **copy media** with verification or backup? See [Ingest](/panels/ingest/) or [Troubleshooting - Ingest](/troubleshooting/ingest/).
- Need to **transcode media** or run a watch folder? See [Transcode](/panels/transcode/) and [Troubleshooting - Watch Mode](/troubleshooting/watch-mode/).
- Need to **generate transcripts or captions**? See [Transcribe](/panels/transcribe/) and [Transcribe output formats](/reference/transcribe-output-formats/).
- Need to **fix licensing or billing confusion**? See [Account and Licensing](/panels/account-and-licensing/) and [Troubleshooting - Account and Licensing](/troubleshooting/account-and-licensing/).
- Need to **collect logs for support**? Start at [Logs and support bundle](/reference/logs-and-support-bundle/) or [Log Viewer](/panels/log-viewer/).

## Panel guides
Each panel guide explains what the panel does, what each control means, the default state, common workflows, outputs, and related troubleshooting.
- [Ingest](/panels/ingest/) — Verified copy, backup copy, Clone Mode, and Watch Mode for source media.
- [Transcode](/panels/transcode/) — Batch transcode and watch-folder transcode with codec, preset, and container controls.
- [Transcribe](/panels/transcribe/) — Speech-to-text, caption export, translation, diarization, and Subtitle Editor handoff.
- [Adobe Automate](/panels/adobe-automate/) — Copy media, connect to Premiere, build bins, and create proxies.
- [Log Viewer](/panels/log-viewer/) — Inspect app job logs, filter by source and job, and export readable reports.
- [NLE Utilities](/panels/nle-utilities/) — Avid reset/rebuild tools and safe Adobe cache, preview, and autosave cleanup.
- [Speed Test](/panels/speed-test/) — Benchmark network and storage throughput before copy, transcode, or watch-folder jobs.
- [Project Organizer](/panels/project-organizer/) — Create project folder trees, attach starter assets, and save reusable organizer configs.
- [Preferences](/panels/preferences/) — Global app settings including Offline Mode, update behavior, temp cleanup, API key, and CEP install.
- [Account and Licensing](/panels/account-and-licensing/) — Install a license file, subscribe, sync entitlement state, and collect version info for support.
- [Subtitle Editor](/panels/subtitle-editor/) — Review subtitle timing and text, export web or broadcast captions, and make burn-in previews.
## Troubleshooting
Use troubleshooting pages when the user is already blocked. They are organized by symptom, not by feature marketing fluff.
- [Troubleshooting - Ingest](/troubleshooting/ingest/) — Use when copy jobs will not start, paths fail validation, backup rules conflict, or Watch Mode behaves strangely.
- [Troubleshooting - Transcode](/troubleshooting/transcode/) — Use when jobs are blocked, presets fail, output files are wrong, or watch-folder transcodes misbehave.
- [Troubleshooting - Transcribe](/troubleshooting/transcribe/) — Use when transcription will not start, Lead AI preparation blocks, outputs are wrong, or export formats fail.
- [Troubleshooting - Adobe Automate](/troubleshooting/adobe-automate/) — Use when Premiere connection fails, proxy generation blocks, or import/bins automation does not run.
- [Troubleshooting - Log Viewer](/troubleshooting/log-viewer/) — Use when expected logs are missing, filters hide entries, or TXT export does not match the visible results.
- [Troubleshooting - NLE Utilities](/troubleshooting/nle-utilities/) — Use when Avid reset/rebuild tools fail or Adobe cleanup looks too aggressive or incomplete.
- [Troubleshooting - Speed Test](/troubleshooting/speed-test/) — Use when network tests fail, drive benchmarks are blocked, or results look wrong or inconsistent.
- [Troubleshooting - Project Organizer](/troubleshooting/project-organizer/) — Use when organizer jobs are blocked, existing roots conflict, asset copies fail, or configs reload oddly.
- [Troubleshooting - Preferences](/troubleshooting/preferences/) — Use when Preferences do not save, secure-key state is confusing, Offline Mode blocks behavior, or reset acts partial.
- [Troubleshooting - Account and Licensing](/troubleshooting/account-and-licensing/) — Use when the app says Active but billing fails, Sync Subscription does not refresh, or license state looks contradictory.
- [Troubleshooting - Subtitle Editor](/troubleshooting/subtitle-editor/) — Use when the editor will not open, media preview fails, export blocks, or broadcast caption QC reports errors.
- [Troubleshooting - Watch Mode](/troubleshooting/watch-mode/) — Shared Watch Mode issues that affect ingest, transcode, or transcribe watch-folder jobs.
## Workflows
Use workflow pages when the user knows what they want to achieve but does not want the entire panel manual thrown at them like a filing cabinet.
### Ingest
- [Workflow - Ingest card copy](/workflows/ingest-card-copy/)
- [Workflow - Clone Mode copy](/workflows/clone-mode-copy/)

### Transcode
- [Workflow - Batch transcode](/workflows/batch-transcode/)
- [Workflow - Watch-folder transcode](/workflows/watch-folder-transcode/)
- [Workflow - Embed captions in MXF](/workflows/embed-captions-in-mxf/)

### Transcribe and subtitles
- [Workflow - Batch transcribe files](/workflows/transcribe-batch-files/)
- [Workflow - Watch-folder transcription](/workflows/transcribe-watch-folder/)
- [Workflow - Send output to Subtitle Editor](/workflows/send-output-to-subtitle-editor/)
- [Workflow - Export broadcast captions (SCC / MCC)](/workflows/export-broadcast-captions-scc-mcc/)
- [Workflow - Open Subtitle Editor and load a subtitle](/workflows/open-subtitle-editor-and-load-a-subtitle/)
- [Workflow - Review and export web caption corrections](/workflows/review-and-export-web-caption-corrections/)
- [Workflow - Export broadcast captions from Subtitle Editor](/workflows/export-broadcast-captions-from-subtitle-editor/)
- [Workflow - Create burn-in from Subtitle Editor](/workflows/create-burn-in-from-subtitle-editor/)

### Adobe Automate
- [Workflow - Install and connect the Premiere CEP panel](/workflows/install-and-connect-premiere-cep-panel/)
- [Workflow - Adobe Automate copy, import, bins, and proxies](/workflows/adobe-automate-copy-import-bins-proxies/)
- [Workflow - Adobe Automate copy and import without proxies](/workflows/adobe-automate-copy-import-no-proxies/)

### Logs and support
- [Workflow - Export logs from Log Viewer](/workflows/export-logs-from-log-viewer/)
- [Workflow - Export a single-job report from Log Viewer](/workflows/export-single-job-report-from-log-viewer/)
- [Workflow - Copy version info for support](/workflows/copy-version-info-for-support/)

### NLE Utilities
- [Workflow - Rebuild Avid media databases](/workflows/rebuild-avid-media-databases/)
- [Workflow - Reset Avid user settings](/workflows/reset-avid-user-settings/)
- [Workflow - Reset Avid site settings](/workflows/reset-avid-site-settings/)
- [Workflow - Clean Adobe cache, autosaves, or previews safely](/workflows/clean-adobe-cache-autosaves-or-previews-safely/)

### Speed Test
- [Workflow - Run a network speed test](/workflows/run-network-speed-test/)
- [Workflow - Compare drive targets with Speed Test](/workflows/compare-drive-targets-with-speed-test/)

### Project Organizer
- [Workflow - Build a folder tree with Project Organizer](/workflows/build-project-folder-tree-with-project-organizer/)
- [Workflow - Attach starter assets to organizer folders](/workflows/attach-starter-assets-to-organizer-folders/)
- [Workflow - Save and reuse Project Organizer configs](/workflows/save-and-reuse-project-organizer-configs/)

### Preferences and account
- [Workflow - Configure Offline Mode and update behavior](/workflows/configure-offline-mode-and-update-behavior/)
- [Workflow - Save AI API key and global webhook settings](/workflows/save-ai-api-key-and-global-webhook-settings/)
- [Workflow - Clear temp and cache from Preferences](/workflows/clear-temp-and-cache-from-preferences/)
- [Workflow - Reset Preferences safely](/workflows/reset-preferences-safely/)
- [Workflow - Install a license file](/workflows/install-a-license-file/)
- [Workflow - Subscribe and sync subscription](/workflows/subscribe-and-sync-subscription/)
- [Workflow - Open the billing portal](/workflows/open-the-billing-portal/)

## Reference
Reference pages are for stable facts such as file locations, log paths, output formats, and support collection.
- [Logs and support bundle](/reference/logs-and-support-bundle/) — Canonical log locations, what each area writes, and what support should collect before escalating.
- [File locations](/reference/file-locations/) — File-system map for temp data, output folders, preview proxies, CEP install paths, and app-support directories.
- [Transcribe output formats](/reference/transcribe-output-formats/) — Format chooser for SRT, VTT, TXT, JSON, SCC, MCC, and related Transcribe exports.

## Suggested support triage order
1. Identify the panel or window involved.
2. Open the matching troubleshooting page.
3. Confirm whether **Offline Mode**, path approval, licensing, or watch-folder state is part of the problem.
4. Collect logs using [Logs and support bundle](/reference/logs-and-support-bundle/) or [Log Viewer](/panels/log-viewer/).
5. Capture exact version/build details with [Workflow - Copy version info for support](/workflows/copy-version-info-for-support/) if escalation is needed.

## Related
- [Panel Guides](/panels/)
- [Troubleshooting](/troubleshooting/)
- [Workflows](/workflows/)
- [Reference](/reference/)
- [Search Help](/search/)
