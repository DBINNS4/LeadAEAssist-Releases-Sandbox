const obfuscator = require('javascript-obfuscator');
const fs = require('fs');
const path = require('path');

const files = [
  'renderer.js',
  'renderer.ingest.js',
  'renderer.transcode.js',
  'renderer.project-organizer.js',
  'renderer.nle-utilities.js',
  'renderer.preferences.js',
  'renderer.account.js',
  'renderer.transcribe.js',
  'renderer.log-viewer.js',
  'renderer.reconcile.js',
  'renderer.clone-utils.js',
  'renderer.speed-test.js',
  'renderer.adobe-utilities.js',
  'renderer.subtitleEditor.js'
];

const outputDir = path.join(__dirname, 'dist-obfuscated');
if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

for (const file of files) {
  const input = fs.readFileSync(path.join(__dirname, file), 'utf8');
  const baseName = String(file).replace(/\.js$/i, '');
  const mapFileName = `${baseName}.js.map`;
  const mapOutPath = path.join(outputDir, mapFileName);

  const obfuscated = obfuscator.obfuscate(input, {
    // NOTE: Keep settings CSP-compatible (avoid unsafe-eval requirements).
    compact: true,
    selfDefending: false,
    controlFlowFlattening: true,
    stringArray: true,
    stringArrayEncoding: ['base64'],

    // --- Source maps (for Sentry symbolication) ---
    // Generate separate .map files so CI can upload them to Sentry.
    // IMPORTANT: These .map files should NOT be shipped to end users.
    // They are excluded from the packaged app via electron-builder config.
    sourceMap: true,
    sourceMapMode: 'separate',
    // Per docs, this is the *base name* and the obfuscator will append ".js.map".
    // Example: sourceMapFileName: "renderer" => "renderer.js.map".
    sourceMapFileName: baseName,
    // Default is 'sources-content' (includes original sources in the map).
    // Keep explicit so behavior doesn't drift.
    sourceMapSourcesMode: 'sources-content'
  });

  fs.writeFileSync(path.join(outputDir, file), obfuscated.getObfuscatedCode());

  // Write the separate source map.
  // This is a release-critical artifact for Sentry symbolication.
  const map = obfuscated.getSourceMap();
  if (typeof map !== 'string' || !map.trim()) {
    throw new Error(`Failed to generate sourcemap for ${file}`);
  }
  fs.writeFileSync(mapOutPath, map);
}
