/*
  scripts/package.js

  Single entry point for building a distributable package.

  This repo uses electron-builder configuration in package.json.
  We keep this wrapper so the npm script API stays stable and we can:
  - enforce NODE_ENV=production
  - verify required packaging artifacts exist
  - (optionally) generate required artifacts (obfuscation) in a clean checkout
  - run electron-builder using the locally installed version (no network)
*/

'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

function assertExists(label, p) {
  if (!fs.existsSync(p)) {
    console.error(`❌ Missing ${label}: ${p}`);
    process.exit(1);
  }
}

function resolveExisting(...candidates) {
  for (const p of candidates) {
    try {
      if (p && fs.existsSync(p)) return p;
    } catch {
      // ignore
    }
  }
  return null;
}

function resolveFastCliEntrypoint(projectRoot) {
  // Keep these in sync with the runtime resolver in ipc/misc.handlers.js.
  const moduleCandidates = ['fast-cli/distribution/cli.js', 'fast-cli/dist/cli.js'];
  const tried = [];

  // Prefer Node's resolver so we work even if dependencies are hoisted.
  for (const spec of moduleCandidates) {
    try {
      const resolved = require.resolve(spec, { paths: [projectRoot] });
      tried.push(resolved);
      if (resolved && fs.existsSync(resolved)) {
        return { entrypoint: resolved, tried };
      }
    } catch {
      tried.push(`(unresolved) ${spec}`);
    }
  }

  // Fallback: explicit paths (mirrors packaged-build fallback behavior).
  const fileCandidates = [
    path.join(projectRoot, 'node_modules', 'fast-cli', 'distribution', 'cli.js'),
    path.join(projectRoot, 'node_modules', 'fast-cli', 'dist', 'cli.js')
  ];
  tried.push(...fileCandidates);

  const existing = resolveExisting(...fileCandidates);
  return { entrypoint: existing, tried };
}

function removeIfExists(p) {
  try {
    if (p && fs.existsSync(p)) {
      fs.rmSync(p, { force: true });
    }
  } catch {
    // ignore
  }
}

function runNodeScript(label, scriptPath, projectRoot) {
  assertExists(label, scriptPath);
  const res = spawnSync(process.execPath, [scriptPath], {
    cwd: projectRoot,
    stdio: 'inherit',
    env: process.env
  });
  if (res.status !== 0) process.exit(res.status ?? 1);
}

function isStaleOutput(outputPath, inputPaths) {
  try {
    if (!fs.existsSync(outputPath)) return true;
    const outStat = fs.statSync(outputPath);
    const outMtime = outStat.mtimeMs || 0;

    for (const p of inputPaths) {
      try {
        if (!p || !fs.existsSync(p)) continue;
        const inStat = fs.statSync(p);
        const inMtime = inStat.mtimeMs || 0;
        if (inMtime > outMtime) return true;
      } catch {
        // best-effort
      }
    }
    return false;
  } catch {
    return true;
  }
}

function main() {
  const projectRoot = path.resolve(__dirname, '..');

  // Always build production artifacts when packaging
  process.env.NODE_ENV = 'production';

  // Select an explicit runtime config for packaging using LEADAE_BUILD_ENV.
  const selectRuntimeScript = path.join(projectRoot, 'scripts', 'select-runtime-config.js');
  runNodeScript('scripts/select-runtime-config.js', selectRuntimeScript, projectRoot);

  // Verify packaged config policy before creating artifacts.
  const verifyPackageConfigScript = path.join(projectRoot, 'scripts', 'verify-package-config-files.js');
  runNodeScript('scripts/verify-package-config-files.js', verifyPackageConfigScript, projectRoot);

  // Ensure CEP resources exist where index.html expects them.
  // Re-run the copy helper so `npm run package` works even in a clean checkout.
  const copyScript = path.join(projectRoot, 'build', 'copy-adobe-utilities.js');
  if (fs.existsSync(copyScript)) {
    runNodeScript('build/copy-adobe-utilities.js', copyScript, projectRoot);
  }

  // Fail packaging if resources/cep/extensions diverges from canonical cep/extensions.
  const verifyCepSyncScript = path.join(projectRoot, 'scripts', 'verify-cep-sync.js');
  runNodeScript('scripts/verify-cep-sync.js', verifyCepSyncScript, projectRoot);

  // Regenerate the signed CEP archive that packaged builds install from.
  // This is required because electron-builder copies extraResources from
  // resources/cep/zxp, while the Preferences panel installer resolves the ZXP
  // from the packaged app bundle at runtime.
  const signCepZxpScript = path.join(projectRoot, 'build', 'sign-cep-zxp.js');
  runNodeScript('build/sign-cep-zxp.js', signCepZxpScript, projectRoot);
  assertExists('resources/cep/zxp/LeadAEAssist_CEP.zxp', path.join(projectRoot, 'resources', 'cep', 'zxp', 'LeadAEAssist_CEP.zxp'));

  // Generate obfuscated renderer bundles if they're missing *or stale*.
  //
  // Important: several windows (including subtitle-editor.html) prefer the obfuscated
  // bundles at runtime. If we only check for existence, it's easy to accidentally
  // ship a build where dist-obfuscated/* is out of date.
  const obfuscateInputs = [
    path.join(projectRoot, 'renderer.js'),
    path.join(projectRoot, 'renderer.ingest.js'),
    path.join(projectRoot, 'renderer.transcode.js'),
    path.join(projectRoot, 'renderer.project-organizer.js'),
    path.join(projectRoot, 'renderer.nle-utilities.js'),
    path.join(projectRoot, 'renderer.preferences.js'),
    path.join(projectRoot, 'renderer.account.js'),
    path.join(projectRoot, 'renderer.transcribe.js'),
    path.join(projectRoot, 'renderer.log-viewer.js'),
    path.join(projectRoot, 'renderer.reconcile.js'),
    path.join(projectRoot, 'renderer.clone-utils.js'),
    path.join(projectRoot, 'renderer.speed-test.js'),
    path.join(projectRoot, 'renderer.adobe-utilities.js'),
    path.join(projectRoot, 'renderer.subtitleEditor.js')
  ];

  const obfuscatedRenderer = path.join(projectRoot, 'dist-obfuscated', 'renderer.js');
  const obfuscatedRendererMap = path.join(projectRoot, 'dist-obfuscated', 'renderer.js.map');
  const obfuscatedSubtitleEditor = path.join(projectRoot, 'dist-obfuscated', 'renderer.subtitleEditor.js');

  const obfuscatedStale =
    isStaleOutput(obfuscatedRenderer, obfuscateInputs) ||
    isStaleOutput(obfuscatedRendererMap, obfuscateInputs) ||
    isStaleOutput(obfuscatedSubtitleEditor, obfuscateInputs);

  if (obfuscatedStale) {
    const obfuscateScript = path.join(projectRoot, 'obfuscate-all.js');
    runNodeScript('obfuscate-all.js', obfuscateScript, projectRoot);
  }

  // Cleanup stale webpack artifacts from older telemetry experiments.
  // (We only ship the Sentry renderer init bundle now: dist-obfuscated/renderer.sentry.js)
  const staleSentryBundles = [
    path.join(projectRoot, 'dist-obfuscated', 'renderer.telemetry.js'),
    path.join(projectRoot, 'dist-obfuscated', 'renderer.telemetry.js.map'),
    path.join(projectRoot, 'dist-obfuscated', 'renderer.telemetry.js.LICENSE.txt')
  ];
  staleSentryBundles.forEach(removeIfExists);

  // Build the bundled Sentry renderer SDK (Route B) if it is missing.
  // This produces dist-obfuscated/renderer.sentry.js.
  // NOTE: We intentionally keep this separate from obfuscate-all.js:
  // - It's a webpack bundle (npm deps), not a hand-authored renderer.* file.
  // - It must be CSP-safe (no eval) and deterministic.
  const sentryRendererBundle = path.join(projectRoot, 'dist-obfuscated', 'renderer.sentry.js');
  const sentryRendererEntry = path.join(projectRoot, 'renderer.sentry.js');
  const webpackConfigPath = path.join(projectRoot, 'build', 'webpack.renderer.sentry.config.js');

  if (isStaleOutput(sentryRendererBundle, [sentryRendererEntry, webpackConfigPath])) {
    assertExists('renderer.sentry.js', sentryRendererEntry);
    assertExists('build/webpack.renderer.sentry.config.js', webpackConfigPath);

    const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx';
    const res = spawnSync(npx, ['webpack', '--config', webpackConfigPath], {
      cwd: projectRoot,
      stdio: 'inherit',
      env: process.env
    });
    if (res.status !== 0) process.exit(res.status ?? 1);
  }

  // Required app assets
  assertExists('dist-obfuscated/renderer.js', obfuscatedRenderer);
  assertExists('dist-obfuscated/renderer.js.map', obfuscatedRendererMap);
  assertExists('dist-obfuscated/renderer.subtitleEditor.js', obfuscatedSubtitleEditor);
  assertExists('dist-obfuscated/renderer.sentry.js', sentryRendererBundle);

  // Files that the app requires at runtime (easy to accidentally forget in electron-builder "files")
  assertExists('progressBridge.js', path.join(projectRoot, 'progressBridge.js'));
  assertExists('subtitle-editor.html', path.join(projectRoot, 'subtitle-editor.html'));
  assertExists('subtitle-editor.css', path.join(projectRoot, 'subtitle-editor.css'));

  // fast-cli entrypoint (network test dependency)
  // Fail packaging loudly if the dependency is missing so we don't ship a build
  // where the Network Speed Test always hard-errors at runtime.
  const fastCli = resolveFastCliEntrypoint(projectRoot);
  if (!fastCli.entrypoint) {
    console.error('❌ Missing dependency: fast-cli (required for Network Speed Test).');
    console.error('   Packaging was aborted because the fast-cli entrypoint could not be found.');
    console.error('   Ensure fast-cli is installed (and not pruned as a devDependency) before packaging.');
    console.error('   Tried:');
    for (const item of fastCli.tried) {
      console.error(`    - ${item}`);
    }
    process.exit(1);
  }

  // FFmpeg binaries (platform aware)
  const ffmpegName = process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg';
  const ffprobeName = process.platform === 'win32' ? 'ffprobe.exe' : 'ffprobe';

  const ffmpeg = resolveExisting(
    path.join(projectRoot, 'extra', 'ffmpeg', ffmpegName),
    path.join(projectRoot, 'extra', 'ffmpeg', 'ffmpeg'),
    path.join(projectRoot, 'extra', 'ffmpeg', 'ffmpeg.exe')
  );
  const ffprobe = resolveExisting(
    path.join(projectRoot, 'extra', 'ffmpeg', ffprobeName),
    path.join(projectRoot, 'extra', 'ffmpeg', 'ffprobe'),
    path.join(projectRoot, 'extra', 'ffmpeg', 'ffprobe.exe')
  );

  if (!ffmpeg) {
    console.error(
      '❌ Missing extra/ffmpeg/ffmpeg (or ffmpeg.exe) under:',
      path.join(projectRoot, 'extra', 'ffmpeg')
    );
    process.exit(1);
  }
  if (!ffprobe) {
    console.error(
      '❌ Missing extra/ffmpeg/ffprobe (or ffprobe.exe) under:',
      path.join(projectRoot, 'extra', 'ffmpeg')
    );
    process.exit(1);
  }

  const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx';
  const args = ['electron-builder', '--publish', 'never', ...process.argv.slice(2)];

  const result = spawnSync(npx, args, {
    cwd: projectRoot,
    stdio: 'inherit',
    env: process.env
  });

  if (result.error) {
    console.error('❌ Failed to run electron-builder:', result.error);
    process.exit(1);
  }

  process.exit(result.status ?? 1);
}

if (require.main === module) {
  main();
}
