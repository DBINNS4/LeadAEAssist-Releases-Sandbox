// scripts/verify-csp.mjs
// Simple regression guard: ensure our Electron renderer HTML pages keep a strict CSP.

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, '..');
const PAGES = ['index.html', 'subtitle-editor.html'];

function fail(msg) {
  console.error(`\n[CSP VERIFY] ❌ ${msg}`);
  process.exitCode = 1;
}

function ok(msg) {
  console.log(`[CSP VERIFY] ✅ ${msg}`);
}

function extractCsp(html) {
  // Very small, robust-ish extractor; we avoid a full HTML parser on purpose.
  const re = /<meta\s+[^>]*http-equiv=["']Content-Security-Policy["'][^>]*>/i;
  const m = html.match(re);
  if (!m) return null;

  const tag = m[0];
  // Prefer double-quoted content="..." (our pages use this) so embedded single quotes don't break.
  const doubleQuoted = tag.match(/content\s*=\s*"([^"]*)"/i);
  if (doubleQuoted) return doubleQuoted[1];

  const singleQuoted = tag.match(/content\s*=\s*'([^']*)'/i);
  return singleQuoted ? singleQuoted[1] : null;
}

function hasInlineScriptTags(html) {
  // Any <script> tag without a src attribute is considered inline.
  const scriptTags = html.match(/<script\b[^>]*>/gi) || [];
  return scriptTags.some(t => !/\bsrc\s*=\s*/i.test(t));
}

function hasInlineEventHandlers(html) {
  // Catch common inline event handlers like onclick=, onerror=, etc.
  // (This is a heuristic; it’s good enough to prevent accidental regressions.)
  return /\son[a-z]+\s*=\s*["']/i.test(html);
}

function parseDirectives(csp) {
  const directives = new Map();
  const parts = csp
    .split(';')
    .map(p => p.trim())
    .filter(Boolean);

  for (const part of parts) {
    const [name, ...rest] = part.split(/\s+/);
    directives.set(name.toLowerCase(), rest);
  }
  return directives;
}

function verifyPage(page) {
  const filePath = path.join(ROOT, page);
  const html = fs.readFileSync(filePath, 'utf8');

  const csp = extractCsp(html);
  if (!csp) {
    fail(`${page}: missing CSP meta tag`);
    return;
  }

  const directives = parseDirectives(csp);

  // Guard against the original blockers.
  const scriptSrc = (directives.get('script-src') || []).join(' ');
  if (/unsafe-inline/i.test(scriptSrc)) fail(`${page}: script-src contains 'unsafe-inline'`);
  if (/unsafe-eval/i.test(scriptSrc)) fail(`${page}: script-src contains 'unsafe-eval'`);

  const scriptAttr = (directives.get('script-src-attr') || []).join(' ');
  if (!scriptAttr) {
    fail(`${page}: missing script-src-attr directive (expected 'none')`);
  } else if (!/'none'/i.test(scriptAttr)) {
    fail(`${page}: script-src-attr is not 'none' (got: ${scriptAttr})`);
  }

  // NOTE: `frame-ancestors` is ignored when CSP is delivered via <meta http-equiv>.
  // It only works as an HTTP response header, so we don't require it for meta-based CSP.
  const frameAncestorsTokens = directives.get('frame-ancestors');
  if (frameAncestorsTokens) {
    const frameAncestors = frameAncestorsTokens.join(' ');
    if (!/'none'/i.test(frameAncestors)) fail(`${page}: frame-ancestors is not 'none'`);
  }

  const formAction = (directives.get('form-action') || []).join(' ');
  if (!/'none'/i.test(formAction)) fail(`${page}: form-action is not 'none'`);

  // Catch accidental regressions: inline scripts or inline event handlers.
  if (hasInlineScriptTags(html)) fail(`${page}: contains inline <script> tags (no src=)`);
  if (hasInlineEventHandlers(html)) fail(`${page}: contains inline event handlers (on*=)`);

  ok(`${page}: CSP looks strict (no unsafe-eval/inline in script-src, no inline scripts)`);
}

for (const page of PAGES) verifyPage(page);

if (process.exitCode) {
  console.error('\n[CSP VERIFY] One or more checks failed. Fix the issues above before shipping.');
  process.exit(process.exitCode);
}

console.log('\n[CSP VERIFY] All checks passed.');
