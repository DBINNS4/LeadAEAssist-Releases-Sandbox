#!/usr/bin/env node
 
const fs = require('fs');
const path = require('path');

const BRIDGE_PATH = path.join(
  __dirname,
  '..',
  'cep',
  'extensions',
  'com.leadae.panel',
  'bridge.json'
);

function fail(msg) {
  console.error(`❌ CEP bridge.json check failed: ${msg}`);
  process.exit(1);
}

try {
  if (!fs.existsSync(BRIDGE_PATH)) {
    console.warn(`⚠️ CEP bridge.json not found at ${BRIDGE_PATH} (skipping check).`);
    process.exit(0);
  }

  const raw = fs.readFileSync(BRIDGE_PATH, 'utf8');
  const json = JSON.parse(raw);

  if (typeof json.token === 'string' && json.token.trim() !== '') {
    fail('bridge.json token is non-empty. Ship only placeholder/no-token in CEP bundle.');
  }

  if (json.tokenSource && json.tokenSource !== 'placeholder') {
    fail(`tokenSource is "${json.tokenSource}", expected "placeholder" for shipped CEP bundle.`);
  }

  console.log('✅ CEP bridge.json placeholder check passed.');
  process.exit(0);
} catch (err) {
  fail(err.message || String(err));
}
