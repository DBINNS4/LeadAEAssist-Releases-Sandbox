// scripts/milestone0_mcc_roundtrip.js
// Milestone 0: MCC encode -> verify -> decode smoke test.
//
// Run:
//   node scripts/milestone0_mcc_roundtrip.js
//
// Exit code:
//   0 = PASS
//   1 = FAIL

'use strict';

// NOTE:
// This file has previously ended up with duplicated blocks during patching,
// which can lead to duplicate declarations. `var` is redeclare-safe.
var assert = require('node:assert/strict');

function requireOrDie(modPath) {
  try {
    // Intentionally CommonJS require (this repo is CommonJS).
     
    return require(modPath);
  } catch (err) {
    const msg = err && err.stack ? err.stack : String(err);
    // Give a very explicit error: Milestone 0 is about getting this runnable.
    console.error(`\n[Milestone0] Failed to require: ${modPath}\n${msg}\n`);
    process.exit(1);
  }
}

function normText(s) {
  return String(s || '').replace(/\s+/g, ' ').trim();
}

function framesToSecOrDie(fps) {
  // We prefer using the project's own time utils so frame rounding matches production.
  // If your repo moved this file, fix the import path here.
  const { framesToSeconds } = requireOrDie('../utils/timeUtils');
  return (frames) => framesToSeconds(frames, fps);
}

function run() {
  const fps = 29.97;
  const dropFrame = true;

  const { generateMCC, verifyMCC } = requireOrDie('../modules/sccEncoder');
  const { decodeMccText } = requireOrDie('../modules/mccDecoder');

  const f2s = framesToSecOrDie(fps);

  // Keep these safely within pop-on 608 constraints (<= 2 lines @ 32 cols) so this
  // test passes even before the "true 708 authoring" refactor.
  const segments = [
    {
      start: f2s(0),
      end: f2s(45),
      text: 'Hello world.'
    },
    {
      start: f2s(60),
      end: f2s(150),
      text: 'This is a longer caption that stays within limits.'
    },
    {
      start: f2s(165),
      end: f2s(240),
      text: 'Last cue.'
    }
  ];

  const mcc = generateMCC(segments, {
    fps,
    dropFrame,
    // Milestone 0: exercise both tracks in the file.
    include608Compatibility: true,
    telestreamCompression: false,
    serviceNumber: 1,
    language: 'eng'
  });

  // --- Verify MCC structure/checksums/parsing
  const verify = verifyMCC(mcc, {
    fps,
    dropFrame,
    strictPayloadParse: true,
    checkAncChecksum: true,
    checkCdpChecksum: true,
    checkCdpLength: true,
    checkCcCount: true,
    checkSequence: true
  });

  assert.equal(
    verify.ok,
    true,
    `verifyMCC failed. First errors:\n${JSON.stringify((verify.errors || []).slice(0, 10), null, 2)}`
  );

  // --- Decode preferring 708 (default behavior)
  const decoded708 = decodeMccText(mcc, { fps, dropFrame });
  assert.equal(decoded708.format, 'mcc');
  assert.equal(decoded708.kind, 'cea708');

  const decoded708Texts = (decoded708.cues || [])
    .map((c) => normText(c && c.text))
    .filter(Boolean);

  assert.equal(
    decoded708Texts.length,
    segments.length,
    `Expected ${segments.length} decoded 708 cues, got ${decoded708Texts.length}`
  );

  for (let i = 0; i < segments.length; i++) {
    const expected = normText(segments[i].text);
    const got = decoded708Texts[i];
    assert.equal(got, expected, `708 cue[${i}] text mismatch. Expected='${expected}' Got='${got}'`);
  }

  // --- Decode forcing 608 compatibility
  const decoded608 = decodeMccText(mcc, { fps, dropFrame, force608Compatibility: true });
  assert.equal(decoded608.format, 'mcc');
  assert.equal(decoded608.kind, 'cea608');

  const decoded608Texts = (decoded608.cues || [])
    .map((c) => normText(c && c.text))
    .filter(Boolean);

  assert.equal(
    decoded608Texts.length,
    segments.length,
    `Expected ${segments.length} decoded 608 cues, got ${decoded608Texts.length}`
  );

  for (let i = 0; i < segments.length; i++) {
    const expected = normText(segments[i].text);
    const got = decoded608Texts[i];
    assert.equal(got, expected, `608 cue[${i}] text mismatch. Expected='${expected}' Got='${got}'`);
  }

  // Pretty output for humans.
  console.log('[Milestone0] PASS: MCC encode -> verify -> decode (708 + 608)');
}

try {
  run();
} catch (err) {
  const msg = err && err.stack ? err.stack : String(err);
  console.error(`\n[Milestone0] FAIL\n${msg}\n`);
  process.exit(1);
}
