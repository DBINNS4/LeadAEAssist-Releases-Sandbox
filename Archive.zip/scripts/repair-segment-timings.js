const fs = require('fs');
const path = require('path');

const fps = 29.97;
const dropFrame = false;

function parseTimecode(tc) {
  const clean = String(tc).replace(',', '.');
  const parts = clean.split(/[:;]/);
  const [hh, mm, ss, ff] = parts.map(p => parseFloat(p));
  return hh * 3600 + mm * 60 + ss + (ff || 0) / fps;
}

function formatTimecode(seconds, df = false, frames = 29.97) {
  if (typeof seconds !== 'number' || isNaN(seconds)) return '00:00:00:00';
  const totalFrames = Math.floor(seconds * frames);
  const hh = Math.floor(totalFrames / (3600 * frames));
  const mm = Math.floor((totalFrames % (3600 * frames)) / (60 * frames));
  const ss = Math.floor((totalFrames % (60 * frames)) / frames);
  const ff = Math.floor(totalFrames % frames);
  const sep = df ? ';' : ':';
  return [hh, mm, ss, ff]
    .map(n => String(n).padStart(2, '0'))
    .join(':')
    .replace(/:(\d\d)$/, sep + '$1');
}

function repairSegmentTimings(filePath) {
  const json = JSON.parse(fs.readFileSync(filePath, 'utf8'));

  if (!Array.isArray(json.transcription)) {
    console.error('No transcription[] array found.');
    return;
  }

  for (const seg of json.transcription) {
    const toks = Array.isArray(seg.tokens)
      ? seg.tokens.filter(t => t?.text && !t.text.startsWith('[_]'))
      : [];

    if (!toks.length) continue;

    const from = toks[0]?.timestamps?.from;
    const to = toks.at(-1)?.timestamps?.to;

    const startSec = parseTimecode(from);
    const endSec = parseTimecode(to);

    const msStart = Math.floor(startSec * 1000);
    const msEnd = Math.floor(endSec * 1000);
    const frameStart = Math.floor(startSec * fps);
    const frameEnd = Math.floor(endSec * fps);

    seg.start = startSec;
    seg.end = endSec;
    seg.msStart = msStart;
    seg.msEnd = msEnd;
    seg.frameStart = frameStart;
    seg.frameEnd = frameEnd;
    seg.timecodeStart = formatTimecode(startSec, dropFrame, fps);
    seg.timecodeEnd = formatTimecode(endSec, dropFrame, fps);
  }

  const outPath = path.join(
    path.dirname(filePath),
    path.basename(filePath, '.json') + `.patched.json`
  );
  fs.writeFileSync(outPath, JSON.stringify(json, null, 2));
  console.log(`✅ Patched → ${outPath}`);
}

const input = process.argv[2];
if (!input) {
  console.error('❌ Usage: node repair-segment-timings.js path/to/file.json');
  process.exit(1);
}
repairSegmentTimings(input);
