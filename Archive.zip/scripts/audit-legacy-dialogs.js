#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

const REPO_ROOT = path.resolve(__dirname, '..');
const ALLOWLIST_PATH = path.join(REPO_ROOT, 'config', 'legacy-dialog-allowlist.json');
const DIALOG_PATTERN = /\b(?:window\.)?(alert|confirm|prompt)\s*\(/g;
const KINDS = ['alert', 'confirm', 'prompt'];
const EXCLUDED_RENDERER_FILES = new Set(['renderer.sentry.js']);
const QUIET = process.argv.includes('--quiet');

function skipSingleQuotedString(source, index) {
  let i = index + 1;
  while (i < source.length) {
    const ch = source[i];
    if (ch === '\\') {
      i += 2;
      continue;
    }
    if (ch === "'") return i + 1;
    i += 1;
  }
  return source.length;
}

function skipDoubleQuotedString(source, index) {
  let i = index + 1;
  while (i < source.length) {
    const ch = source[i];
    if (ch === '\\') {
      i += 2;
      continue;
    }
    if (ch === '"') return i + 1;
    i += 1;
  }
  return source.length;
}

function skipLineComment(source, index) {
  let i = index + 2;
  while (i < source.length && source[i] !== '\n') i += 1;
  return i;
}

function skipBlockComment(source, index) {
  const end = source.indexOf('*/', index + 2);
  return end === -1 ? source.length : end + 2;
}

function skipTemplateExpression(source, index) {
  let braceDepth = 1;
  let i = index;
  while (i < source.length && braceDepth > 0) {
    const ch = source[i];
    const next = source[i + 1];
    if (ch === '/' && next === '/') {
      i = skipLineComment(source, i);
      continue;
    }
    if (ch === '/' && next === '*') {
      i = skipBlockComment(source, i);
      continue;
    }
    if (ch === "'") {
      i = skipSingleQuotedString(source, i);
      continue;
    }
    if (ch === '"') {
      i = skipDoubleQuotedString(source, i);
      continue;
    }
    if (ch === '`') {
      i = skipTemplateLiteral(source, i);
      continue;
    }
    if (ch === '{') braceDepth += 1;
    if (ch === '}') braceDepth -= 1;
    i += 1;
  }
  return i;
}

function skipTemplateLiteral(source, index) {
  let i = index + 1;
  while (i < source.length) {
    const ch = source[i];
    const next = source[i + 1];
    if (ch === '\\') {
      i += 2;
      continue;
    }
    if (ch === '`') return i + 1;
    if (ch === '$' && next === '{') {
      i = skipTemplateExpression(source, i + 2);
      continue;
    }
    i += 1;
  }
  return source.length;
}

function findCallEnd(source, openParenIndex) {
  let depth = 1;
  let i = openParenIndex + 1;
  while (i < source.length && depth > 0) {
    const ch = source[i];
    const next = source[i + 1];
    if (ch === '/' && next === '/') {
      i = skipLineComment(source, i);
      continue;
    }
    if (ch === '/' && next === '*') {
      i = skipBlockComment(source, i);
      continue;
    }
    if (ch === "'") {
      i = skipSingleQuotedString(source, i);
      continue;
    }
    if (ch === '"') {
      i = skipDoubleQuotedString(source, i);
      continue;
    }
    if (ch === '`') {
      i = skipTemplateLiteral(source, i);
      continue;
    }
    if (ch === '(') depth += 1;
    if (ch === ')') depth -= 1;
    i += 1;
  }
  return i;
}

function normalizeSnippet(snippet) {
  return snippet.replace(/\s+/g, ' ').trim();
}

function getLineAndColumn(source, index) {
  const line = source.slice(0, index).split('\n').length;
  const lastNewlineIndex = source.lastIndexOf('\n', index - 1);
  const column = index - lastNewlineIndex;
  return { line, column };
}

function getBlockCommentRanges(source) {
  const ranges = [];
  const pattern = /\/\*[\s\S]*?\*\//g;
  for (const match of source.matchAll(pattern)) {
    ranges.push([match.index, match.index + match[0].length]);
  }
  return ranges;
}

function isInsideRanges(index, ranges) {
  return ranges.some(([start, end]) => index >= start && index < end);
}

function isLineCommentMatch(source, index) {
  const lineStart = source.lastIndexOf('\n', index - 1) + 1;
  const prefix = source.slice(lineStart, index);
  return prefix.includes('//');
}

function isFunctionDeclarationMatch(source, index) {
  const prefix = source.slice(Math.max(0, index - 24), index);
  return /(?:function|class)\s+$/.test(prefix);
}

function isTargetRendererFile(name) {
  if (!name.startsWith('renderer') || !name.endsWith('.js')) return false;
  if (EXCLUDED_RENDERER_FILES.has(name)) return false;
  if (/\s/.test(name)) return false;
  return name === 'renderer.js' || /^renderer\..+\.js$/.test(name);
}

function getRendererFiles() {
  return fs
    .readdirSync(REPO_ROOT)
    .filter((name) => isTargetRendererFile(name))
    .filter((name) => fs.statSync(path.join(REPO_ROOT, name)).isFile())
    .sort((a, b) => a.localeCompare(b));
}

function scanRendererFile(fileName) {
  const absolutePath = path.join(REPO_ROOT, fileName);
  const source = fs.readFileSync(absolutePath, 'utf8');
  const blockCommentRanges = getBlockCommentRanges(source);
  const results = [];

  for (const match of source.matchAll(DIALOG_PATTERN)) {
    const callStart = match.index;
    if (isInsideRanges(callStart, blockCommentRanges)) continue;
    if (isLineCommentMatch(source, callStart)) continue;
    if (isFunctionDeclarationMatch(source, callStart)) continue;

    const fullMatch = match[0];
    const kind = match[1];
    const openParenIndex = callStart + fullMatch.lastIndexOf('(');
    const callEnd = findCallEnd(source, openParenIndex);
    const snippet = normalizeSnippet(source.slice(callStart, callEnd));
    const { line, column } = getLineAndColumn(source, callStart);

    results.push({
      file: fileName,
      kind,
      line,
      column,
      snippet
    });
  }

  return results;
}

function emptyCounts() {
  return { alert: 0, confirm: 0, prompt: 0, total: 0 };
}

function summarize(entries) {
  const totalsByKind = emptyCounts();
  const countsByFile = new Map();

  for (const entry of entries) {
    totalsByKind[entry.kind] += 1;
    totalsByKind.total += 1;

    if (!countsByFile.has(entry.file)) {
      countsByFile.set(entry.file, emptyCounts());
    }
    const fileCounts = countsByFile.get(entry.file);
    fileCounts[entry.kind] += 1;
    fileCounts.total += 1;
  }

  return { totalsByKind, countsByFile };
}

function loadAllowlist() {
  const raw = fs.readFileSync(ALLOWLIST_PATH, 'utf8');
  const parsed = JSON.parse(raw);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error(`Allowlist must be an object: ${ALLOWLIST_PATH}`);
  }
  return parsed.maxAllowedByFile || {};
}

function compareAgainstAllowlist(countsByFile, allowlistByFile) {
  const files = new Set([...countsByFile.keys(), ...Object.keys(allowlistByFile)]);
  const overages = [];
  const headroom = [];

  for (const file of Array.from(files).sort((a, b) => a.localeCompare(b))) {
    const actual = countsByFile.get(file) || emptyCounts();
    const allowed = allowlistByFile[file] || {};

    for (const kind of KINDS) {
      const actualCount = actual[kind] || 0;
      const allowedCount = allowed[kind] || 0;
      if (actualCount > allowedCount) {
        overages.push({ file, kind, actual: actualCount, allowed: allowedCount });
      } else if (allowedCount > actualCount) {
        headroom.push({ file, kind, actual: actualCount, allowed: allowedCount });
      }
    }
  }

  return { overages, headroom };
}

function formatCountList(counts) {
  return KINDS.filter((kind) => counts[kind] > 0)
    .map((kind) => `${kind} ${counts[kind]}`)
    .join(', ');
}

function printInventory(entries, countsByFile, totalsByKind) {
  const filesWithDialogs = Array.from(countsByFile.entries()).sort((a, b) => {
    if (b[1].total !== a[1].total) return b[1].total - a[1].total;
    return a[0].localeCompare(b[0]);
  });

  console.log('Legacy browser dialog audit');
  console.log(`Inventory: ${totalsByKind.total} raw dialogs across ${filesWithDialogs.length} renderer files.`);
  console.log(`Totals: alert ${totalsByKind.alert}, confirm ${totalsByKind.confirm}, prompt ${totalsByKind.prompt}`);

  for (const [file, counts] of filesWithDialogs) {
    console.log(`- ${file}: ${counts.total} (${formatCountList(counts)})`);
  }

  if (!entries.length) {
    console.log('No raw alert()/confirm()/prompt() calls were detected in renderer application code.');
  }
}

function printOutcome(overages, headroom) {
  if (!overages.length) {
    console.log('Result: baseline guardrail passed. No unexpected raw dialogs were introduced.');
  } else {
    console.error('Result: audit failed. Raw dialog counts exceeded the temporary allowlist.');
    for (const item of overages) {
      console.error(
        `- ${item.file}: ${item.kind} count ${item.actual} exceeds allowlisted ceiling ${item.allowed}`
      );
    }
  }

  if (headroom.length && !QUIET) {
    console.log('Allowlist headroom detected (expected during cleanup, not a failure):');
    for (const item of headroom) {
      console.log(
        `- ${item.file}: ${item.kind} allowlist ${item.allowed}, current ${item.actual}`
      );
    }
  }
}

function main() {
  const files = getRendererFiles();
  const entries = files.flatMap(scanRendererFile).sort((a, b) => {
    if (a.file !== b.file) return a.file.localeCompare(b.file);
    if (a.line !== b.line) return a.line - b.line;
    return a.column - b.column;
  });

  const { totalsByKind, countsByFile } = summarize(entries);
  const allowlistByFile = loadAllowlist();
  const { overages, headroom } = compareAgainstAllowlist(countsByFile, allowlistByFile);

  if (!QUIET) {
    printInventory(entries, countsByFile, totalsByKind);
    console.log(`Allowlist: ${path.relative(REPO_ROOT, ALLOWLIST_PATH)}`);
  }

  printOutcome(overages, headroom);
  process.exitCode = overages.length ? 1 : 0;
}

main();
