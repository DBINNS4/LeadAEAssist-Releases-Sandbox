'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function collectFiles(rootDir) {
  const out = [];

  function walk(currentDir) {
    const entries = fs.readdirSync(currentDir, { withFileTypes: true });
    entries.sort((a, b) => a.name.localeCompare(b.name));

    for (const entry of entries) {
      const absolutePath = path.join(currentDir, entry.name);
      if (entry.isDirectory()) {
        walk(absolutePath);
      } else if (entry.isFile()) {
        out.push(path.relative(rootDir, absolutePath));
      }
    }
  }

  walk(rootDir);
  return out;
}

function sha256(filePath) {
  const buf = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(buf).digest('hex');
}

function main() {
  const root = path.resolve(__dirname, '..');
  const canonicalPanel = path.join(root, 'cep', 'extensions', 'com.leadae.panel');
  const packagedPanel = path.join(root, 'resources', 'cep', 'extensions', 'com.leadae.panel');

  if (!fs.existsSync(canonicalPanel)) {
    console.error(`[verify-cep-sync] Missing canonical CEP panel directory: ${canonicalPanel}`);
    process.exit(1);
  }

  if (!fs.existsSync(packagedPanel)) {
    console.error(`[verify-cep-sync] Missing packaged CEP panel directory: ${packagedPanel}`);
    console.error('[verify-cep-sync] Run `npm run copy:adobe-utils` to regenerate resources/cep/extensions.');
    process.exit(1);
  }

  const canonicalFiles = collectFiles(canonicalPanel);
  const packagedFiles = collectFiles(packagedPanel);

  const canonicalSet = new Set(canonicalFiles);
  const packagedSet = new Set(packagedFiles);

  const missingFromPackaged = canonicalFiles.filter((f) => !packagedSet.has(f));
  const extraInPackaged = packagedFiles.filter((f) => !canonicalSet.has(f));
  const changedFiles = [];

  for (const relPath of canonicalFiles) {
    if (!packagedSet.has(relPath)) continue;

    const sourceHash = sha256(path.join(canonicalPanel, relPath));
    const packagedHash = sha256(path.join(packagedPanel, relPath));
    if (sourceHash !== packagedHash) {
      changedFiles.push(relPath);
    }
  }

  if (missingFromPackaged.length || extraInPackaged.length || changedFiles.length) {
    console.error('[verify-cep-sync] CEP panel directories are out of sync.');

    if (missingFromPackaged.length) {
      console.error('\nMissing from resources/cep/extensions/com.leadae.panel:');
      missingFromPackaged.forEach((f) => console.error(`  - ${f}`));
    }

    if (extraInPackaged.length) {
      console.error('\nExtra files in resources/cep/extensions/com.leadae.panel:');
      extraInPackaged.forEach((f) => console.error(`  - ${f}`));
    }

    if (changedFiles.length) {
      console.error('\nFiles with different contents:');
      changedFiles.forEach((f) => console.error(`  - ${f}`));
    }

    console.error('\nRun `npm run copy:adobe-utils` to regenerate resources/cep/extensions from cep/extensions.');
    process.exit(1);
  }

  console.log('[verify-cep-sync] resources/cep/extensions/com.leadae.panel is in sync with cep/extensions/com.leadae.panel');
}

if (require.main === module) {
  try {
    main();
  } catch (error) {
    console.error('[verify-cep-sync] Failed:', error);
    process.exit(1);
  }
}
