#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-}"
if [[ "$MODE" != "sandbox" && "$MODE" != "prod" ]]; then
  echo "usage: $0 sandbox|prod" >&2
  exit 2
fi

ts="$(date +%Y%m%d%H%M%S)"
cp -v config/public.runtime.json "config/public.runtime.json.bak.$ts" >/dev/null || true

if [[ "$MODE" == "sandbox" ]]; then
  # Assume current public.runtime.json is your sandbox config already.
  # If you want an explicit sandbox template, keep it at config/public.runtime.sandbox.json and copy it here.
  echo "Switched to SANDBOX (no changes unless you add a sandbox template)."
else
  cp -v config/public.runtime.prod.json config/public.runtime.json
  echo "Switched to PROD."
fi
