#!/usr/bin/env bash
set -euo pipefail

MODE="${LEADAE_BUILD_ENV:-sandbox}"
if [[ "$MODE" != "sandbox" && "$MODE" != "prod" ]]; then
  echo "LEADAE_BUILD_ENV must be sandbox|prod (got: $MODE)" >&2
  exit 2
fi

export LEADAE_BUILD_ENV="$MODE"

echo "[dist] Building with LEADAE_BUILD_ENV=$LEADAE_BUILD_ENV"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
DEFAULT_CEP_P12_PATH="$REPO_ROOT/tools/zxpsigncmd/certs/LeadAEAssist_CEP.p12"
ZXPSIGN_BIN="$REPO_ROOT/tools/zxpsigncmd/CEP-Resources/ZXPSignCMD/4.1.3/macOS/ZXPSignCmd"

export CEP_P12_PATH="${CEP_P12_PATH:-$DEFAULT_CEP_P12_PATH}"

if [[ -z "${CEP_P12_PASSWORD:-}" ]]; then
  if [[ "$(uname -s)" == "Darwin" ]]; then
    CEP_P12_PASSWORD="$(security find-generic-password -a "$USER" -s "LeadAEAssist CEP P12 Password" -w 2>/dev/null || true)"
  else
    echo "[dist] ERROR: CEP_P12_PASSWORD is required on non-macOS hosts." >&2
    echo "[dist] Set credentials explicitly before running dist:" >&2
    echo "[dist]   export CEP_P12_PATH='/absolute/path/to/LeadAEAssist_CEP.p12'" >&2
    echo "[dist]   export CEP_P12_PASSWORD='your-p12-password'" >&2
    exit 1
  fi
fi

export CEP_P12_PASSWORD="${CEP_P12_PASSWORD:-}"
export CEP_TSA_URL="${CEP_TSA_URL:-http://time.certum.pl/}"
export CSC_NAME="${CSC_NAME:-LEAD AE INC (D4M9633X93)}"
export APPLE_NOTARYTOOL_PROFILE="${APPLE_NOTARYTOOL_PROFILE:-AssistNotarize}"

# Preflight checks
if [[ ! -f "$CEP_P12_PATH" ]]; then
  echo "[dist] ERROR: CEP_P12_PATH does not exist: $CEP_P12_PATH" >&2
  echo "[dist] Remediation:" >&2
  echo "[dist]   export CEP_P12_PATH='/absolute/path/to/LeadAEAssist_CEP.p12'" >&2
  exit 1
fi

if [[ -z "$CEP_P12_PASSWORD" ]]; then
  echo "[dist] ERROR: CEP_P12_PASSWORD is empty." >&2
  echo "[dist] Remediation:" >&2
  echo "[dist]   export CEP_P12_PASSWORD='your-p12-password'" >&2
  if [[ "$(uname -s)" == "Darwin" ]]; then
    echo "[dist]   security add-generic-password -a "$USER" -s 'LeadAEAssist CEP P12 Password' -w '<password>' -U" >&2
  fi
  exit 1
fi

if ! command -v npm >/dev/null 2>&1; then
  echo "[dist] ERROR: npm not found in PATH." >&2
  echo "[dist] Remediation: install Node.js and ensure npm is available." >&2
  exit 1
fi

if [[ ! -x "$ZXPSIGN_BIN" ]]; then
  echo "[dist] ERROR: required signing binary not found or not executable: $ZXPSIGN_BIN" >&2
  echo "[dist] Remediation: restore/initialize tools/zxpsigncmd so ZXPSignCmd is present and executable." >&2
  exit 1
fi

if [[ ! -x "/usr/bin/rsync" ]]; then
  echo "[dist] ERROR: required signing binary not found: /usr/bin/rsync" >&2
  echo "[dist] Remediation: install rsync (macOS Command Line Tools)." >&2
  exit 1
fi

PUBLISH_REPO="LeadAEAssist-Releases"
if [[ "$MODE" == "sandbox" ]]; then
  PUBLISH_REPO="LeadAEAssist-Releases-Sandbox"
fi

echo "[dist] Publish repo: DBINNS4/$PUBLISH_REPO"

# Control whether electron-builder uploads to GitHub Releases.
PUBLISH_MODE="${LEADAE_PUBLISH_MODE:-always}"
case "$PUBLISH_MODE" in
  always|never|onTag|onTagOrDraft) ;;
  *)
    echo "[dist] ERROR: LEADAE_PUBLISH_MODE must be always|never|onTag|onTagOrDraft (got: $PUBLISH_MODE)" >&2
    exit 2
    ;;
esac
echo "[dist] Publish mode: $PUBLISH_MODE"

RUNTIME_ASSET_PUBLISH_MODE="${LEADAE_PUBLISH_RUNTIME_ASSETS:-0}"
case "$RUNTIME_ASSET_PUBLISH_MODE" in
  1|true|TRUE|yes|YES) ;;
  0|false|FALSE|no|NO|'') ;;
  *)
    echo "[dist] ERROR: LEADAE_PUBLISH_RUNTIME_ASSETS must be 1|0|true|false|yes|no (got: $RUNTIME_ASSET_PUBLISH_MODE)" >&2
    exit 2
    ;;
esac
echo "[dist] Runtime asset publish: $RUNTIME_ASSET_PUBLISH_MODE"

# Run the same steps as `npm run dist`, but override the publish repo at the end.
# Runtime assets are staged separately from the app bundle; publishing them is opt-in.
npm run build:select-runtime-config
npm run assets:prepare
npm run copy:adobe-utils
npm run verify:cep-sync
npm run sign:cep-zxp

SIGNED_ZXP_PATH="$REPO_ROOT/resources/cep/zxp/LeadAEAssist_CEP.zxp"
if [[ ! -f "$SIGNED_ZXP_PATH" ]]; then
  echo "[dist] ERROR: signed CEP archive was not generated at $SIGNED_ZXP_PATH" >&2
  echo "[dist] Remediation: inspect build/sign-cep-zxp.js and the CEP signing environment variables above." >&2
  exit 1
fi

npm run verify:package-config

"$REPO_ROOT/node_modules/.bin/electron-builder" -c.publish.repo="$PUBLISH_REPO" --publish "$PUBLISH_MODE"

if [[ "$RUNTIME_ASSET_PUBLISH_MODE" =~ ^(1|true|TRUE|yes|YES)$ ]]; then
  echo "[dist] Publishing runtime assets to DBINNS4/$PUBLISH_REPO"
  npm run assets:publish -- --owner DBINNS4 --repo "$PUBLISH_REPO" --clobber
else
  echo "[dist] Runtime asset publish skipped. Set LEADAE_PUBLISH_RUNTIME_ASSETS=1 to upload staged runtime assets."
fi
