#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

function usage(exitCode = 0) {
  console.log(`
Transcode Matrix Smoke Test (Electron-safe)

Required:
  --input, -i         Path to a small media file (MOV/MP4/etc)

Important:
  Run this with Electron (NOT node):
    npx electron scripts/transcode_matrix.js ...

Optional:
  --spec              Path to config/codex_format_spec.json
                      (or set env CODEX_SPEC_PATH)
  --out, -o           Output root folder (default: ./_transcode_matrix)
  --mode              defaults | sweep | full (default: sweep)
  --formats           Comma-separated list of formats to include (default: all)
  --skip-formats      Comma-separated list of formats to skip
  --concurrency       Jobs at once (default: 1)
  --max-jobs          Stop after N jobs
  --preserve          true | false | both (default: true)
  --ffmpeg-dir        Directory containing ffmpeg + ffprobe
  --json              Report path
  --csv               Report path
  --list-formats      Print formats and exit
  --quiet             Less console noise
`.trim() + '\n');
  process.exit(exitCode);
}

function parseArgs(argv) {
  const out = {
    input: null,
    specPath: null,
    outRoot: null,
    mode: 'sweep',
    formats: null,
    skipFormats: null,
    concurrency: 1,
    maxJobs: null,
    preserve: 'true',
    ffmpegDir: null,
    jsonPath: null,
    csvPath: null,
    listFormats: false,
    quiet: false
  };

  const args = argv.slice(2);
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--help' || a === '-h') usage(0);
    else if (a === '--input' || a === '-i') out.input = args[++i] || null;
    else if (a === '--spec') out.specPath = args[++i] || null;
    else if (a === '--out' || a === '-o') out.outRoot = args[++i] || null;
    else if (a === '--mode') out.mode = (args[++i] || 'sweep').toLowerCase();
    else if (a === '--formats') out.formats = (args[++i] || '').split(',').map(s => s.trim()).filter(Boolean);
    else if (a === '--skip-formats') out.skipFormats = (args[++i] || '').split(',').map(s => s.trim()).filter(Boolean);
    else if (a === '--concurrency') out.concurrency = Math.max(1, parseInt(args[++i] || '1', 10) || 1);
    else if (a === '--max-jobs') out.maxJobs = Math.max(1, parseInt(args[++i] || '', 10) || 1);
    else if (a === '--preserve') out.preserve = String(args[++i] || 'true').toLowerCase();
    else if (a === '--ffmpeg-dir') out.ffmpegDir = args[++i] || null;
    else if (a === '--json') out.jsonPath = args[++i] || null;
    else if (a === '--csv') out.csvPath = args[++i] || null;
    else if (a === '--list-formats') out.listFormats = true;
    else if (a === '--quiet') out.quiet = true;
    else {
      console.error('❌ Unknown arg:', a);
      usage(2);
    }
  }
  return out;
}

function sanitizeName(v) {
  return String(v || '')
    .trim()
    .replace(/[^a-zA-Z0-9._-]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 90) || 'x';
}

function uniqBy(arr, keyFn) {
  const seen = new Set();
  const out = [];
  for (const x of arr || []) {
    const k = keyFn(x);
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(x);
  }
  return out;
}

function normalizeColorRange(v) {
  const s = String(v || '').trim().toLowerCase();
  if (!s) return '';
  if (s === 'limited') return 'limited';
  if (s === 'full') return 'full';
  return s;
}

function normalizeFrameRateLabel(label) {
  const raw = String(label || '').trim();
  if (!raw) return { fps: '', dropFrame: false, raw: '' };
  const lower = raw.toLowerCase();
  if (lower.endsWith('df')) return { fps: raw.slice(0, -2), dropFrame: true, raw };
  return { fps: raw, dropFrame: false, raw };
}

function makeJobId(prefix) {
  const stamp = Date.now();
  const rand = crypto.randomBytes(4).toString('hex');
  return `${prefix}-${stamp}-${rand}`;
}

function pickDefault(f, key, listKey) {
  const d = f?.[key];
  if (d != null && String(d).trim()) return String(d).trim();
  const list = Array.isArray(f?.[listKey]) ? f[listKey] : [];
  return list.length ? String(list[0]).trim() : '';
}

function buildDefaultCase(formatKey, f) {
  const containerFormat = pickDefault(f, 'defaultContainer', 'containers');
  const resolution = pickDefault(f, 'defaultResolution', 'resolutions');
  const fr = normalizeFrameRateLabel(pickDefault(f, 'defaultFrameRate', 'frameRates'));
  const pixelFormat = pickDefault(f, 'defaultPixelFormat', 'pixelFormats');
  const colorRange = normalizeColorRange(pickDefault(f, 'defaultColorRange', 'colorRanges'));
  const fieldOrder = pickDefault(f, 'defaultFieldOrder', 'fieldOrders') || 'progressive';
  const audioCodec = pickDefault(f, 'defaultAudio', 'audio');
  const channels = pickDefault(f, 'defaultChannels', 'channelOptions') || 'stereo';
  const sampleRate = pickDefault(f, 'defaultSampleRate', 'sampleRates') || '48000';
  const audioBitrate = String(f?.defaultAudioBitrate || '').trim();

  return {
    id: 'default',
    outputFormat: formatKey,
    containerFormat,
    resolution,
    frameRate: fr.fps,
    dropFrame: fr.dropFrame,
    pixelFormat,
    colorRange,
    fieldOrder,
    audioCodec,
    channels,
    sampleRate,
    audioBitrate
  };
}

function buildSweepCases(formatKey, f, preserveMode = 'true') {
  const base = buildDefaultCase(formatKey, f);
  const cases = [];

  const add = (id, patch = {}) => cases.push({ ...base, ...patch, id });

  add('baseline', {});

  if (preserveMode === 'both') {
    add('baseline_preserve_true', { preserveMetadata: true });
    add('baseline_preserve_false', { preserveMetadata: false });
  }

  for (const c of (f?.containers || [])) add(`container_${c}`, { containerFormat: String(c) });
  for (const r of (f?.resolutions || [])) add(`res_${r}`, { resolution: String(r) });

  for (const fr of (f?.frameRates || [])) {
    const n = normalizeFrameRateLabel(fr);
    add(`fps_${sanitizeName(n.raw)}`, { frameRate: n.fps, dropFrame: n.dropFrame });
  }

  for (const pf of (f?.pixelFormats || [])) add(`pix_${pf}`, { pixelFormat: String(pf) });
  for (const cr of (f?.colorRanges || [])) add(`range_${String(cr).toLowerCase()}`, { colorRange: normalizeColorRange(cr) });
  for (const fo of (f?.fieldOrders || [])) add(`field_${fo}`, { fieldOrder: String(fo) });
  for (const a of (f?.audio || [])) add(`audio_${a}`, { audioCodec: String(a) });
  for (const ch of (f?.channelOptions || [])) add(`ch_${sanitizeName(ch)}`, { channels: String(ch) });
  for (const sr of (f?.sampleRates || [])) add(`sr_${sr}`, { sampleRate: String(sr) });

  const normalizePreserve = (value) => {
    if (value === true || value === false) return value;
    if (preserveMode === 'false') return false;
    return true; // default
  };

  return uniqBy(
    cases.map(c => ({ ...c, preserveMetadata: normalizePreserve(c.preserveMetadata) })),
    (c) => [
      c.outputFormat, c.containerFormat, c.resolution, c.frameRate, c.dropFrame ? 'df' : 'ndf',
      c.pixelFormat, c.colorRange, c.fieldOrder, c.audioCodec, c.channels, c.sampleRate,
      String(c.preserveMetadata)
    ].join('|')
  );
}

function buildDefaultCases(formatKey, f, preserveMode = 'true') {
  const base = buildDefaultCase(formatKey, f);
  if (preserveMode === 'both') {
    return [
      { ...base, id: 'default_preserve_true', preserveMetadata: true },
      { ...base, id: 'default_preserve_false', preserveMetadata: false }
    ];
  }
  return [{ ...base, id: 'default', preserveMetadata: preserveMode !== 'false' }];
}


function buildFullCases(formatKey, f, preserveMode = 'true', maxJobs = null) {
  // Full cartesian product across option arrays for a single format.
  // This validates that the UI cannot generate an invalid combination.
  const base = buildDefaultCase(formatKey, f);

  const dims = {
    containerFormat: (f?.containers || []).map(String),
    resolution: (f?.resolutions || []).map(String),
    frameRateRaw: (f?.frameRates || []).map(String),
    pixelFormat: (f?.pixelFormats || []).map(String),
    colorRangeRaw: (f?.colorRanges || []).map(String),
    fieldOrder: (f?.fieldOrders || []).map(String),
    audioCodec: (f?.audio || []).map(String),
    channels: (f?.channelOptions || []).map(String),
    sampleRate: (f?.sampleRates || []).map(String)
  };

  for (const k of Object.keys(dims)) {
    if (!dims[k].length) dims[k] = [String(base[k] || '')];
  }

  const preserveValues = (preserveMode === 'both') ? [true, false] : [(preserveMode === 'false') ? false : true];

  const frList = dims.frameRateRaw.map(normalizeFrameRateLabel);
  const crList = dims.colorRangeRaw.map(normalizeColorRange);

  const out = [];
  for (const preserveMetadata of preserveValues) {
    for (const containerFormat of dims.containerFormat) {
      for (const resolution of dims.resolution) {
        for (const fr of frList) {
          for (const pixelFormat of dims.pixelFormat) {
            for (const colorRange of crList) {
              for (const fieldOrder of dims.fieldOrder) {
                for (const audioCodec of dims.audioCodec) {
                  for (const channels of dims.channels) {
                    for (const sampleRate of dims.sampleRate) {
                      const id = [
                        containerFormat,
                        resolution,
                        fr.raw,
                        pixelFormat,
                        colorRange,
                        fieldOrder,
                        audioCodec,
                        channels,
                        sampleRate,
                        preserveMetadata ? 'pres' : 'nopres'
                      ].map(sanitizeName).join('__');

                      out.push({
                        ...base,
                        id,
                        preserveMetadata,
                        containerFormat,
                        resolution,
                        frameRate: fr.fps,
                        dropFrame: fr.dropFrame,
                        pixelFormat,
                        colorRange,
                        fieldOrder,
                        audioCodec,
                        channels,
                        sampleRate
                      });

                      if (maxJobs && out.length >= maxJobs) return out;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  return out;
}

function writeJson(p, obj) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(obj, null, 2));
}

function csvEscape(v) {
  const s = (v == null) ? '' : String(v);
  if (/[\n\r,"]/g.test(s)) return '"' + s.replace(/"/g, '""') + '"';
  return s;
}

function writeCsv(p, rows) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  if (!rows.length) return fs.writeFileSync(p, '');
  const headers = Object.keys(rows[0]);
  const lines = [headers.join(',')];
  for (const row of rows) lines.push(headers.map(h => csvEscape(row[h])).join(','));
  fs.writeFileSync(p, lines.join(os.EOL));
}

function pickErrorSnippet(lines) {
  const arr = Array.isArray(lines) ? lines : [];
  const interesting = arr.filter(l => /\b(error|invalid|failed)\b/i.test(String(l)) || /❌|⚠️/.test(String(l)));
  const tail = interesting.length ? interesting.slice(-12) : arr.slice(-12);
  return tail.join('\n');
}

async function runWithConcurrencyLimit(items, concurrency, fn) {
  const results = new Array(items.length);
  let next = 0;
  const worker = async () => {
    while (true) {
      const idx = next++;
      if (idx >= items.length) return;
      results[idx] = await fn(items[idx], idx);
    }
  };
  await Promise.all(Array.from({ length: Math.max(1, concurrency) }, () => worker()));
  return results;
}

function loadSpecFromPath(specPath) {
  const raw = fs.readFileSync(specPath, 'utf8');
  const json = JSON.parse(raw);
  const formats = json?.formats && typeof json.formats === 'object' ? json.formats : {};
  return { json, formats };
}

async function main() {
  const opts = parseArgs(process.argv);

  if (opts.ffmpegDir) process.env.FFMPEG_DIR = opts.ffmpegDir;

  if (!opts.input) {
    console.error('❌ --input is required');
    usage(2);
  }

  const inputPath = path.resolve(opts.input);
  if (!fs.existsSync(inputPath)) {
    console.error('❌ Input file does not exist:', inputPath);
    process.exit(2);
  }

  const mode = String(opts.mode || 'sweep').toLowerCase();
  if (!['defaults', 'sweep', 'full'].includes(mode)) {
    console.error('❌ Invalid --mode. Use: defaults | sweep | full');
    process.exit(2);
  }

  const preserveMode =
    (opts.preserve === 'both') ? 'both' :
    (opts.preserve === 'false' || opts.preserve === '0') ? 'false' : 'true';

  // SPEC PATH: explicit flag > env var > repo-relative default
  const defaultSpec = path.resolve(process.cwd(), 'config', 'codex_format_spec.json');
  const specPath = path.resolve(opts.specPath || process.env.CODEX_SPEC_PATH || defaultSpec);

  if (!fs.existsSync(specPath)) {
    console.error('❌ Spec file not found:', specPath);
    console.error('   Fix: pass --spec "/full/path/to/config/codex_format_spec.json"');
    process.exit(2);
  }

  const { formats: formatsObj } = loadSpecFromPath(specPath);
  const allFormats = Object.keys(formatsObj).sort();

  if (!opts.quiet) {
    console.log('--- Transcode Matrix ---');
    console.log('Spec:', specPath);
    console.log('Formats in spec:', allFormats.length);
  }

  if (opts.listFormats) {
    allFormats.forEach(f => console.log(f));
    return;
  }

  let selected = allFormats;
  if (opts.formats && opts.formats.length) {
    const set = new Set(opts.formats.map(s => String(s).trim()));
    selected = selected.filter(k => set.has(k));
  }
  if (opts.skipFormats && opts.skipFormats.length) {
    const skip = new Set(opts.skipFormats.map(s => String(s).trim()));
    selected = selected.filter(k => !skip.has(k));
  }

  if (!selected.length) {
    console.error('❌ No formats selected.');
    console.error('   Spec loaded:', specPath);
    console.error('   Formats found:', allFormats.length);
    console.error('   Tip: try --list-formats to confirm the spec contents.');
    process.exit(2);
  }

  const outRoot = path.resolve(opts.outRoot || path.resolve(process.cwd(), '_transcode_matrix'));
  fs.mkdirSync(outRoot, { recursive: true });

  // These must exist in your repo:
  const { runTranscode, buildOutputName } = require('../modules/transcode');
  const { ffprobePath } = require('../utils/ffmpeg');

  let jobs = [];
  for (const formatKey of selected) {
    const f = formatsObj[formatKey];
    if (!f) continue;
    if (mode === 'defaults') jobs.push(...buildDefaultCases(formatKey, f, preserveMode));
    else if (mode === 'full') jobs.push(...buildFullCases(formatKey, f, preserveMode, opts.maxJobs || null));
    else jobs.push(...buildSweepCases(formatKey, f, preserveMode));
  }

  // Format-specific constraints: these reflect what the UI should allow.
  // If a case violates constraints, we mark it INVALID and skip running FFmpeg for it.
  function isSelectableCase(c) {
    const fmt = String(c.outputFormat || '').toLowerCase();
    const container = String(c.containerFormat || '').toLowerCase();
    const res = String(c.resolution || '').trim();
    const fps = String(c.frameRate || '').trim();
    const field = String(c.fieldOrder || '').trim();

    // XDCAM HD (mpeg2video in MXF): 1080 is typically interlaced; 23.976/24p and 50p at 1080 are not valid for this profile.
    if ((fmt === 'xdcam_hd35' || fmt === 'xdcam_hd50') && container === 'mxf') {
      if (res === '1920x1080') {
        const okFps = new Set(['25', '29.97', '29.97df', '30']);
        const okField = new Set(['interlaced_tff', 'interlaced_bff']);
        return okFps.has(fps) && okField.has(field);
      }
      // 720p remains permissive for now.
      return true;
    }
    return true;
  }

  const invalidJobs = jobs.filter(j => !isSelectableCase(j));
  jobs = jobs.filter(j => isSelectableCase(j));

  if (opts.maxJobs && mode !== 'full') jobs = jobs.slice(0, opts.maxJobs);

  const startedAt = new Date().toISOString();

  if (!opts.quiet) {
    console.log('Input:', inputPath);
    console.log('Out:', outRoot);
    console.log('Mode:', mode);
    console.log('Selected formats:', selected.length);
    console.log('Jobs:', jobs.length);
    console.log('Preserve metadata:', preserveMode);
    console.log('Concurrency:', opts.concurrency);
  }

  const runOne = async (job, idx) => {
    const formatKey = job.outputFormat;
    const caseId = job.id || `case_${idx}`;
    const caseDir = path.join(outRoot, sanitizeName(formatKey), sanitizeName(caseId));
    fs.mkdirSync(caseDir, { recursive: true });

    const jobId = makeJobId(`matrix_${sanitizeName(formatKey)}`);

    const cfg = {
      jobId,
      inputFiles: [inputPath],
      outputFolder: caseDir,
      outputFormat: job.outputFormat,
      containerFormat: job.containerFormat,
      resolution: job.resolution,
      frameRate: job.frameRate,
      dropFrame: !!job.dropFrame,
      pixelFormat: job.pixelFormat,
      colorRange: job.colorRange,
      fieldOrder: job.fieldOrder,
      audioCodec: job.audioCodec,
      channels: job.channels,
      sampleRate: job.sampleRate,
      audioBitrate: job.audioBitrate,
      preserveMetadata: (job.preserveMetadata !== false),
      audioOnly: false,
      watchMode: false,
      verification: null
    };

    if (!opts.quiet) console.log(`\n[${idx + 1}/${jobs.length}] ${formatKey} :: ${caseId}`);

    let res;
    let threw = null;
    try {
      res = await runTranscode(cfg);
    } catch (e) {
      threw = e;
      res = { success: false, cancelled: false, log: [], archivePath: '', structuredLogPath: '' };
    }

    const outName = buildOutputName(inputPath, 1, { containerFormat: job.containerFormat, appendSeq: false, isBatch: false });
    const finalOutPath = path.join(caseDir, outName);

    let outputExists = false;
    let outputBytes = 0;
    try {
      if (fs.existsSync(finalOutPath)) {
        const st = fs.statSync(finalOutPath);
        outputExists = st.size > 0;
        outputBytes = st.size;
      }
    } catch {}

    let probeOk = '';
    let probeSummary = '';
    if (outputExists) {
      try {
        const raw = execFileSync(
          ffprobePath,
          ['-v', 'error', '-show_streams', '-show_format', '-of', 'json', finalOutPath],
          { encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 }
        );
        const json = JSON.parse(raw || '{}');
        const streams = Array.isArray(json?.streams) ? json.streams : [];
        const v = streams.find(s => s.codec_type === 'video') || null;
        const a = streams.find(s => s.codec_type === 'audio') || null;
        probeOk = 'true';
        probeSummary = [
          v ? `v:${v.codec_name || '?'} ${v.pix_fmt || ''} ${v.width || ''}x${v.height || ''}`.trim() : 'v:none',
          a ? `a:${a.codec_name || '?'} ${a.sample_rate || ''}Hz ch=${a.channels || ''}`.trim() : 'a:none'
        ].join(' | ');
      } catch (e) {
        probeOk = 'false';
        probeSummary = `ffprobe failed: ${e?.message || String(e)}`;
      }
    }

    const logLines = Array.isArray(res?.log) ? res.log : [];
    const errorSnippet = threw ? `threw: ${threw?.message || String(threw)}` : pickErrorSnippet(logLines);

    const row = {
      idx: idx + 1,
      format: formatKey,
      case: caseId,
      container: job.containerFormat,
      resolution: job.resolution,
      frameRate: job.frameRate,
      dropFrame: job.dropFrame ? 'true' : 'false',
      pixelFormat: job.pixelFormat,
      colorRange: job.colorRange,
      fieldOrder: job.fieldOrder,
      audioCodec: job.audioCodec,
      channels: job.channels,
      sampleRate: job.sampleRate,
      preserveMetadata: String(cfg.preserveMetadata),

      success: res?.success ? 'PASS' : 'FAIL',
      outputExists: outputExists ? 'true' : 'false',
      outputBytes: String(outputBytes || 0),
      ffprobeOk: probeOk,
      ffprobeSummary: probeSummary,
      archivePath: res?.archivePath || '',
      structuredLogPath: res?.structuredLogPath || '',
      outputPath: finalOutPath,
      errorSnippet
    };

    if (!opts.quiet) {
      console.log(row.success, '|', row.outputExists === 'true' ? 'output ok' : 'no output', '|', probeSummary);
      if (row.success === 'FAIL') console.log(errorSnippet);
    }

    return row;
  };

  const rows = await runWithConcurrencyLimit(jobs, opts.concurrency, runOne);

  // Record invalid (non-selectable) cases as FAIL entries without running FFmpeg.
  if (invalidJobs.length) {
    for (const j of invalidJobs) {
      rows.push({
        idx: rows.length + 1,
        format: j.outputFormat,
        case: j.id || '',
        container: j.containerFormat,
        resolution: j.resolution,
        frameRate: j.frameRate,
        dropFrame: j.dropFrame ? 'true' : 'false',
        pixelFormat: j.pixelFormat,
        colorRange: j.colorRange,
        fieldOrder: j.fieldOrder,
        audioCodec: j.audioCodec,
        channels: j.channels,
        sampleRate: j.sampleRate,
        preserveMetadata: String(j.preserveMetadata !== false),

        success: 'SKIP',
        cancelled: 'false',
        outputExists: 'false',
        outputBytes: '0',
        imageSeqFrames: '0',
        ffprobeOk: '',
        ffprobeSummary: '',
        archivePath: '',
        structuredLogPath: '',
        outputPath: '',
        errorSnippet: 'INVALID_OPTION: UI should not allow this combination for the selected format/container.'
      });
    }
  }

  const passed = rows.filter(r => r.success === 'PASS').length;
  const failed = rows.filter(r => r.success === 'FAIL').length;
  const skipped = rows.filter(r => r.success === 'SKIP').length;

  const report = {
    startedAt,
    finishedAt: new Date().toISOString(),
    input: inputPath,
    specPath,
    outRoot,
    mode,
    preserveMode,
    formats: selected,
    jobCount: rows.length,
    passed,
    failed,
    rows
  };

  const jsonPath = path.resolve(opts.jsonPath || path.join(outRoot, 'report.json'));
  const csvPath = path.resolve(opts.csvPath || path.join(outRoot, 'report.csv'));
  writeJson(jsonPath, report);
  writeCsv(csvPath, rows);

  console.log('\n--- Matrix Summary ---');
  console.log('Jobs:', rows.length);
  console.log('Passed:', passed);
  console.log('Failed:', failed);
  console.log('Skipped (invalid UI options):', skipped);
  console.log('Report JSON:', jsonPath);
  console.log('Report CSV :', csvPath);

  process.exit(failed ? 1 : 0);
}

main().catch((err) => {
  console.error('❌ Matrix runner crashed:', err?.stack || err?.message || String(err));
  process.exit(2);
});
