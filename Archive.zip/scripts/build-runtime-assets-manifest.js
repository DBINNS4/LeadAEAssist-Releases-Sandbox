#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const { getSelection } = require('./select-runtime-config');
const {
  fail,
  readJson,
  writeJsonIfChanged,
  ensureDir,
  resolveFirstExisting,
  applyTemplate,
  joinUrl,
  parseGitHubReleaseBaseUrl,
  validateGitHubReleaseRelativeUrl,
  stageFileAsset,
  stageArchiveAsset
} = require('./runtime-assets-utils');

function cloneJson(value) {
  return JSON.parse(JSON.stringify(value));
}

function resolveRuntimeAssetsBaseUrl(projectRoot, options = {}) {
  const explicitBaseUrl = String(options.assetsBaseUrl || process.env.LEADAE_ASSETS_BASE_URL || '').trim();
  if (explicitBaseUrl) return explicitBaseUrl;

  const explicitSelectedPath = options.selectedRuntimePath
    ? path.resolve(options.selectedRuntimePath)
    : path.join(projectRoot, 'config', 'public.runtime.selected.json');
  if (fs.existsSync(explicitSelectedPath)) {
    const selectedRuntime = readJson(explicitSelectedPath);
    const selectedBaseUrl = String(selectedRuntime?.assets?.baseUrl || '').trim();
    if (selectedBaseUrl) return selectedBaseUrl;
  }

  const buildEnv = String(options.buildEnv || process.env.LEADAE_BUILD_ENV || '').trim();
  if (buildEnv) {
    const selection = getSelection(buildEnv, projectRoot);
    const selectedBaseUrl = String(selection?.selectedRuntime?.assets?.baseUrl || '').trim();
    if (selectedBaseUrl) return selectedBaseUrl;
  }

  fail(
    'Unable to resolve runtime asset base URL. Run scripts/select-runtime-config.js first or set LEADAE_ASSETS_BASE_URL.'
  );
}


function isChromiumRuntimeAssetDescriptor(descriptor = {}) {
  const desc = descriptor && typeof descriptor === 'object' ? descriptor : {};
  const entrypoint = String(desc.entrypoint || '').trim();
  const installDir = String(desc.installDir || '').trim();
  const relativeUrl = String(desc.relativeUrl || '').trim();
  if (String(desc.type || '').trim().toLowerCase() !== 'archive') return false;
  return (
    /Google Chrome for Testing/i.test(entrypoint) ||
    /(?:^|\/)chrome[-_]/i.test(installDir) ||
    /^chrom(?:e|ium)-/i.test(relativeUrl)
  );
}

function resolveAssetSourcePath(projectRoot, assetId, descriptor, options = {}) {
  const overrideMap = (options.assetSources && typeof options.assetSources === 'object') ? options.assetSources : {};
  const override = String(overrideMap[assetId] || '').trim();
  if (override) return override;

  const desc = descriptor && typeof descriptor === 'object' ? descriptor : {};
  const installPath = String(desc.installPath || '').trim();
  if (assetId === 'whisper.model.base.en' || /ggml-base\.en\.bin$/i.test(installPath)) {
    return resolveFirstExisting([
      process.env.LEADAE_WHISPER_BASE_EN_PATH,
      path.join(projectRoot, 'whisper.cpp', 'models', 'ggml-base.en.bin')
    ]);
  }

  if (assetId === 'whisper.model.base.multi' || /ggml-base\.bin$/i.test(installPath)) {
    return resolveFirstExisting([
      process.env.LEADAE_WHISPER_BASE_MULTI_PATH,
      path.join(projectRoot, 'whisper.cpp', 'models', 'ggml-base.bin')
    ]);
  }

  if (isChromiumRuntimeAssetDescriptor(desc)) {
    return resolveFirstExisting([
      process.env.LEADAE_CHROMIUM_STAGE_DIR,
      process.env.LEADAE_PUPPETEER_CHROME_DIR,
      path.join(projectRoot, 'vendor', 'puppeteer', 'chrome')
    ]);
  }

  return null;
}

function buildReleaseManifest(packagedManifest, releaseContext) {
  const releaseManifest = cloneJson(packagedManifest);
  releaseManifest.appVersion = releaseContext.version;
  releaseManifest.release = releaseContext.releaseTarget;

  const assets = (releaseManifest.assets && typeof releaseManifest.assets === 'object')
    ? releaseManifest.assets
    : {};

  for (const [, descriptor] of Object.entries(assets)) {
    if (!descriptor || typeof descriptor !== 'object') continue;
    const rel = String(descriptor.relativeUrl || '').trim();
    if (!rel) continue;
    descriptor.downloadUrl = joinUrl(releaseContext.baseUrl, rel);
  }

  return releaseManifest;
}

function buildRuntimeAssetsManifest(options = {}) {
  const projectRoot = path.resolve(options.projectRoot || path.join(__dirname, '..'));
  const packageJsonPath = path.join(projectRoot, 'package.json');
  const manifestPath = path.resolve(options.manifestPath || path.join(projectRoot, 'config', 'runtime.assets.manifest.json'));
  const releaseDir = path.resolve(options.releaseDir || path.join(projectRoot, 'release', 'runtime-assets'));
  const releaseManifestPath = path.resolve(options.releaseManifestPath || path.join(releaseDir, 'runtime.assets.manifest.json'));
  const pkg = readJson(packageJsonPath);
  const version = String(options.version || pkg.version || '').trim();
  if (!version) fail('package.json is missing version');

  const manifest = cloneJson(options.manifest || readJson(manifestPath));
  if (!manifest || typeof manifest !== 'object' || !manifest.assets || typeof manifest.assets !== 'object') {
    fail(`Invalid runtime assets manifest: ${manifestPath}`);
  }

  const baseUrlTemplate = resolveRuntimeAssetsBaseUrl(projectRoot, options);
  const baseUrl = applyTemplate(baseUrlTemplate, { APP_VERSION: version });
  const releaseTarget = parseGitHubReleaseBaseUrl(baseUrl) || {
    provider: 'generic',
    baseUrl,
    tag: null,
    owner: null,
    repo: null
  };

  ensureDir(releaseDir);

  const packagedManifest = cloneJson(manifest);
  const assets = packagedManifest.assets;
  const stagedAssets = [];

  for (const [assetId, descriptor] of Object.entries(assets)) {
    if (!descriptor || typeof descriptor !== 'object') continue;
    const rel = String(descriptor.relativeUrl || '').trim();
    if (!rel) fail(`runtime asset ${assetId} is missing relativeUrl`);
    if (releaseTarget.provider === 'github') {
      validateGitHubReleaseRelativeUrl(rel);
    }

    const sourcePath = resolveAssetSourcePath(projectRoot, assetId, descriptor, options);
    if (!sourcePath) {
      fail(
        `Could not resolve a source path for runtime asset ${assetId}. ` +
        'Provide an assetSources override or the matching LEADAE_* source environment variable.'
      );
    }

    let staged;
    if (descriptor.type === 'file') {
      staged = stageFileAsset(assetId, descriptor, sourcePath, releaseDir);
      descriptor.downloadUrl = null;
      descriptor.sha256 = staged.sha256;
      descriptor.size = staged.size;
      delete descriptor.seedSha256;
    } else if (descriptor.type === 'archive') {
      staged = stageArchiveAsset(assetId, descriptor, sourcePath, releaseDir);
      descriptor.downloadUrl = null;
      descriptor.sha256 = staged.sha256;
      descriptor.seedSha256 = staged.seedSha256;
      descriptor.size = staged.size;
    } else {
      fail(`Unsupported runtime asset type for ${assetId}: ${descriptor.type}`);
    }

    stagedAssets.push({
      assetId,
      sourcePath,
      outPath: staged.outPath,
      relativeUrl: rel,
      sha256: staged.sha256,
      size: staged.size,
      downloadUrl: joinUrl(baseUrl, rel)
    });
  }

  const releaseManifest = buildReleaseManifest(packagedManifest, {
    version,
    baseUrl,
    releaseTarget
  });

  const packagedChanged = writeJsonIfChanged(manifestPath, packagedManifest);
  const releaseChanged = writeJsonIfChanged(releaseManifestPath, releaseManifest);

  return {
    projectRoot,
    version,
    baseUrl,
    releaseTarget,
    manifestPath,
    packagedManifest,
    packagedManifestChanged: packagedChanged,
    releaseDir,
    releaseManifestPath,
    releaseManifest,
    releaseManifestChanged: releaseChanged,
    stagedAssets
  };
}

function formatStagedAssetLine(projectRoot, asset) {
  return `- ${asset.assetId}: ${path.relative(projectRoot, asset.outPath)} (${asset.size} bytes)`;
}

function main() {
  try {
    const result = buildRuntimeAssetsManifest();
    console.log(`Prepared runtime assets for v${result.version}:`);
    for (const asset of result.stagedAssets) {
      console.log(formatStagedAssetLine(result.projectRoot, asset));
    }
    console.log(`Updated packaged manifest: ${path.relative(result.projectRoot, result.manifestPath)}`);
    console.log(`Wrote release manifest: ${path.relative(result.projectRoot, result.releaseManifestPath)}`);
    if (result.releaseTarget.provider === 'github') {
      console.log(`Runtime asset release target: ${result.releaseTarget.owner}/${result.releaseTarget.repo} @ ${result.releaseTarget.tag}`);
    } else {
      console.log(`Runtime asset base URL: ${result.baseUrl}`);
    }
  } catch (error) {
    console.error(error?.message || String(error));
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  buildRuntimeAssetsManifest,
  buildReleaseManifest,
  resolveRuntimeAssetsBaseUrl,
  resolveAssetSourcePath,
  isChromiumRuntimeAssetDescriptor,
  formatStagedAssetLine,
  main
};
