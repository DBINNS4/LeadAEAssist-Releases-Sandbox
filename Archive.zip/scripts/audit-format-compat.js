/*
  Audit Codex format compatibility vs Transcode panel option coverage.

  Why this exists:
  - The Transcode panel uses a finite set of dropdown options.
  - Codex (config/codex_format_spec.json) defines what each format *allows*.
  - If Codex ever adds a new pixel format / resolution / frame rate, the UI can silently
    hide it unless the dropdown can represent that value.

  Run:
    node scripts/audit-format-compat.js
*/

const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const specPath = path.join(root, 'config', 'codex_format_spec.json');

if (!fs.existsSync(specPath)) {
  console.error('❌ Cannot find', specPath);
  process.exit(1);
}

const spec = JSON.parse(fs.readFileSync(specPath, 'utf-8'));
const formats = spec?.formats || {};

const uniq = (arr) => Array.from(new Set((arr || []).filter(Boolean).map(String)));
const union = (field) => {
  const out = [];
  for (const v of Object.values(formats)) {
    out.push(...(v?.[field] || []));
  }
  return uniq(out);
};

// These are the values the panel must be able to represent.
// They should be a **superset** of everything in codex_format_spec.json.
const UI = {
  containers: ['mov', 'mp4', 'mkv', 'mxf', 'webm', 'avi', 'image_sequence'],
  resolutions: ['720x480', '1280x720', '1920x1080', '3840x2160', '4096x2160'],
  frameRates: ['23.976', '24', '25', '29.97', '30', '50', '59.94', '60', '29.97df', '59.94df'],
  fieldOrders: ['progressive', 'interlaced_tff', 'interlaced_bff'],
  colorRanges: ['limited', 'full'],
  pixelFormats: [
    'yuv420p',
    'yuv422p',
    'yuv444p',
    'rgb24',
    'rgba',
    'rgb48le',
    'v210',
    'yuvj422p',
    'yuv422p10',
    'yuv422p10le',
    'yuv444p10le',
    'yuv420p10le'
  ]
};

function diff(label, have, need) {
  const haveSet = new Set((have || []).map(String));
  const missing = (need || []).map(String).filter(v => !haveSet.has(v));
  if (missing.length) {
    console.log(`\n❌ UI missing ${label} values from Codex spec:`);
    missing.sort().forEach(v => console.log('  -', v));
  } else {
    console.log(`✅ UI covers all Codex ${label} values.`);
  }
}

console.log('--- Codex/UI compatibility audit ---');
console.log('Formats:', Object.keys(formats).length);

diff('containers', UI.containers, union('containers'));
diff('resolutions', UI.resolutions, union('resolutions'));
diff('frameRates', UI.frameRates, union('frameRates'));
diff('fieldOrders', UI.fieldOrders, union('fieldOrders'));
diff('colorRanges', UI.colorRanges, union('colorRanges').map(v => String(v).toLowerCase()));
diff('pixelFormats', UI.pixelFormats, union('pixelFormats'));

// Format-level sanity checks
const problems = [];
for (const [key, v] of Object.entries(formats)) {
  const checkDefault = (defKey, listKey) => {
    const def = v?.[defKey];
    if (!def) return;
    const list = (v?.[listKey] || []).map(String);
    if (list.length && !list.includes(String(def))) {
      problems.push({
        format: key,
        issue: `${defKey}=${def} not present in ${listKey}=[${list.join(', ')}]`
      });
    }
  };

  checkDefault('defaultContainer', 'containers');
  checkDefault('defaultResolution', 'resolutions');
  checkDefault('defaultFrameRate', 'frameRates');
  checkDefault('defaultPixelFormat', 'pixelFormats');
}

if (problems.length) {
  console.log('\n⚠️  Spec sanity issues (defaults not in allowed lists):');
  for (const p of problems) {
    console.log(`  - ${p.format}: ${p.issue}`);
  }
} else {
  console.log('\n✅ Spec sanity: defaults appear inside allowed lists.');
}

// DNx quick summary (useful when debugging "stuck at 59.94" reports)
const dnx = Object.entries(formats)
  .filter(([k]) => k.startsWith('dnxhd_') || k.startsWith('dnxhr_'))
  .map(([k, v]) => ({
    format: k,
    resolutions: (v.resolutions || []).join(','),
    frameRates: (v.frameRates || []).join(','),
    fieldOrders: (v.fieldOrders || []).join(',')
  }));

if (dnx.length) {
  console.log('\n--- DNx formats (from codex_format_spec.json) ---');
  for (const row of dnx) {
    console.log(`${row.format}: res=[${row.resolutions}] fps=[${row.frameRates}] fields=[${row.fieldOrders}]`);
  }
}

console.log('\nDone.');
