// scripts/smoke-ipc.js
// Loads your IPC registrars with a mock ipcMain to ensure registration doesn’t explode.

const { registerIpcHandlers } = require('../ipc');

const mockIpcMain = (() => {
  const regs = [];
  const record = (type) => (channel, fn) => regs.push({ type, channel, fn: typeof fn });
  return {
    handle: record('handle'),
    on:     record('on'),
    once:   record('once'),
    _regs:  () => regs
  };
})();

registerIpcHandlers(mockIpcMain);

const regs = mockIpcMain._regs();
console.log(`Registered ${regs.length} IPC endpoints`);
console.log(regs.slice(0, 10)); // preview
