#!/usr/bin/env node

'use strict';

const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const BUILD_ENV = String(process.env.LEADAE_BUILD_ENV || '').trim();
const VALID_ENVS = new Set(['sandbox', 'prod']);
const PROD_EXPECTED = {
  entitlementHost: 'entitlement-service-prod.fly.dev',
  billingHosts: ['customer-portal.paddle.com']
};
const SANDBOX_EXPECTED = {
  entitlementHost: 'entitlement-service.fly.dev',
  billingHosts: ['sandbox-customer-portal.paddle.com']
};

function fail(message) {
  console.error(`❌ ${message}`);
  process.exit(1);
}

function parseJsonFile(filePath) {
  let raw;
  try {
    raw = fs.readFileSync(filePath, 'utf8');
  } catch (error) {
    fail(`Unable to read runtime config file: ${filePath} (${error.message})`);
  }

  try {
    return JSON.parse(raw);
  } catch (error) {
    fail(`Runtime config is not valid JSON: ${filePath} (${error.message})`);
  }
}

function asHost(urlValue, label) {
  try {
    const parsed = new URL(String(urlValue || '').trim());
    return parsed.hostname;
  } catch {
    fail(`${label} must be a valid URL. Received: ${urlValue}`);
  }
}

function normalizeHostList(value) {
  if (!Array.isArray(value)) return [];
  return value.map((entry) => String(entry || '').trim()).filter(Boolean);
}

function validateSharedRuntime(cfg, envName) {
  if (!cfg || typeof cfg !== 'object') {
    fail(`Selected ${envName} runtime config is not an object.`);
  }

  if (!cfg.paddle || typeof cfg.paddle !== 'object') {
    fail(`Selected ${envName} runtime config must include a "paddle" object.`);
  }

  const paddleEnv = String(cfg.paddle.env || '').trim();
  if (!paddleEnv) {
    fail(`Selected ${envName} runtime config is missing paddle.env.`);
  }

  if (!String(cfg.entitlementUrl || '').trim()) {
    fail(`Selected ${envName} runtime config is missing entitlementUrl.`);
  }

  return {
    paddleEnv,
    entitlementHost: asHost(cfg.entitlementUrl, 'entitlementUrl'),
    entitlementHosts: normalizeHostList(cfg.entitlementHosts),
    billingHosts: normalizeHostList(cfg.billingHosts)
  };
}

function validateProdRuntime(cfg) {
  const shared = validateSharedRuntime(cfg, 'prod');
  if (shared.paddleEnv !== 'production') {
    fail(`LEADAE_BUILD_ENV=prod requires paddle.env="production" (found "${shared.paddleEnv}").`);
  }

  if (shared.entitlementHost !== PROD_EXPECTED.entitlementHost) {
    fail(
      `LEADAE_BUILD_ENV=prod requires entitlementUrl host "${PROD_EXPECTED.entitlementHost}" (found "${shared.entitlementHost}").`
    );
  }

  if (!shared.entitlementHosts.includes(PROD_EXPECTED.entitlementHost)) {
    fail(`LEADAE_BUILD_ENV=prod requires entitlementHosts to include "${PROD_EXPECTED.entitlementHost}".`);
  }

  for (const host of PROD_EXPECTED.billingHosts) {
    if (!shared.billingHosts.includes(host)) {
      fail(`LEADAE_BUILD_ENV=prod requires billingHosts to include "${host}".`);
    }
  }

  if (shared.billingHosts.includes('sandbox-customer-portal.paddle.com')) {
    fail('LEADAE_BUILD_ENV=prod must not include sandbox Paddle billing host "sandbox-customer-portal.paddle.com".');
  }
}

function validateSandboxRuntime(cfg) {
  const shared = validateSharedRuntime(cfg, 'sandbox');
  if (shared.paddleEnv !== 'sandbox') {
    fail(`LEADAE_BUILD_ENV=sandbox requires paddle.env="sandbox" (found "${shared.paddleEnv}").`);
  }

  if (shared.entitlementHost !== SANDBOX_EXPECTED.entitlementHost) {
    fail(
      `LEADAE_BUILD_ENV=sandbox requires entitlementUrl host "${SANDBOX_EXPECTED.entitlementHost}" (found "${shared.entitlementHost}").`
    );
  }

  for (const host of SANDBOX_EXPECTED.billingHosts) {
    if (!shared.billingHosts.includes(host)) {
      fail(`LEADAE_BUILD_ENV=sandbox requires billingHosts to include "${host}".`);
    }
  }
}

function getSelection(buildEnv, projectRoot) {
  if (!VALID_ENVS.has(buildEnv)) {
    fail('LEADAE_BUILD_ENV is required and must be one of: sandbox, prod.');
  }

  const configDir = path.join(projectRoot, 'config');
  const sourcePath =
    buildEnv === 'prod'
      ? path.join(configDir, 'public.runtime.prod.json')
      : path.join(configDir, 'public.runtime.json');

  if (!fs.existsSync(sourcePath)) {
    fail(`Selected runtime source file does not exist: ${sourcePath}`);
  }

  const selectedRuntime = parseJsonFile(sourcePath);

  if (buildEnv === 'prod') {
    validateProdRuntime(selectedRuntime);
  } else {
    validateSandboxRuntime(selectedRuntime);
  }

  return {
    buildEnv,
    sourcePath,
    outputPath: path.join(configDir, 'public.runtime.selected.json'),
    selectedRuntime
  };
}

function writeSelection(selection) {
  fs.writeFileSync(selection.outputPath, `${JSON.stringify(selection.selectedRuntime, null, 2)}\n`, 'utf8');
  console.log(
    `✅ Runtime config selected for build env "${selection.buildEnv}": ${path.relative(process.cwd(), selection.sourcePath)} -> ${path.relative(process.cwd(), selection.outputPath)}`
  );
}

function main() {
  const projectRoot = path.resolve(__dirname, '..');
  const selection = getSelection(BUILD_ENV, projectRoot);
  writeSelection(selection);
}

if (require.main === module) {
  main();
}

module.exports = {
  getSelection,
  validateProdRuntime,
  validateSandboxRuntime,
  PROD_EXPECTED,
  SANDBOX_EXPECTED
};
