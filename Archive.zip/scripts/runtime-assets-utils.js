#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { URL } = require('url');
const { sha256FileHex, sha256DirectoryTreeHex } = require('../utils/runtimeAssetIntegrity');

function fail(message) {
  throw new Error(String(message || 'Runtime asset pipeline failed'));
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function writeJson(filePath, value) {
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

function writeJsonIfChanged(filePath, value) {
  const next = `${JSON.stringify(value, null, 2)}\n`;
  let current = null;
  try {
    current = fs.readFileSync(filePath, 'utf8');
  } catch {}
  if (current === next) return false;
  fs.writeFileSync(filePath, next, 'utf8');
  return true;
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function sha256Hex(filePath) {
  return sha256FileHex(filePath);
}

function copyFileAtomic(src, dest) {
  ensureDir(path.dirname(dest));
  const tmp = `${dest}.tmp`;
  fs.copyFileSync(src, tmp);
  fs.renameSync(tmp, dest);
}

function resolveFirstExisting(candidates) {
  for (const candidate of candidates || []) {
    try {
      if (candidate && fs.existsSync(candidate)) return candidate;
    } catch {}
  }
  return null;
}

function zipDirKeepParent(srcDir, outZip) {
  ensureDir(path.dirname(outZip));
  try { fs.rmSync(outZip, { force: true }); } catch {}

  if (process.platform === 'darwin') {
    execFileSync('/usr/bin/ditto', ['-c', '-k', '--keepParent', srcDir, outZip], { stdio: 'inherit' });
    return;
  }

  const parent = path.dirname(srcDir);
  const base = path.basename(srcDir);
  execFileSync('zip', ['-r', '-q', outZip, base], { cwd: parent, stdio: 'inherit' });
}

function applyTemplate(str, variables = {}) {
  return String(str || '').replace(/\{\{\s*([A-Z0-9_]+)\s*\}\}/gi, (_match, key) => {
    const hit = Object.prototype.hasOwnProperty.call(variables, key) ? variables[key] : '';
    return String(hit || '');
  });
}

function joinUrl(base, rel) {
  const b = String(base || '').replace(/\/+$/, '');
  const r = String(rel || '').replace(/^\/+/, '');
  return b && r ? `${b}/${r}` : (b || r);
}

function parseGitHubReleaseBaseUrl(baseUrl) {
  const trimmed = String(baseUrl || '').trim();
  if (!trimmed) return null;

  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch {
    return null;
  }

  if (!/^github\.com$/i.test(parsed.hostname)) return null;

  const parts = parsed.pathname.split('/').filter(Boolean);
  if (parts.length < 5) return null;
  if (parts[2] !== 'releases' || parts[3] !== 'download') return null;

  return {
    provider: 'github',
    owner: parts[0],
    repo: parts[1],
    tag: parts[4],
    baseUrl: trimmed
  };
}

function validateGitHubReleaseRelativeUrl(relativeUrl) {
  const rel = String(relativeUrl || '').trim();
  if (!rel) fail('Runtime asset is missing relativeUrl');
  if (rel.includes('/') || rel.includes('\\')) {
    fail(
      `GitHub release assets must use flat filenames. relativeUrl "${rel}" contains a path separator.`
    );
  }
  return rel;
}

function stageFileAsset(assetId, descriptor, srcPath, releaseDir) {
  const desc = descriptor && typeof descriptor === 'object' ? descriptor : {};
  const rel = String(desc.relativeUrl || '').trim();
  if (!rel) fail(`runtime asset ${assetId} is missing relativeUrl`);
  if (!desc.installPath) fail(`runtime asset ${assetId} is missing installPath`);
  if (!fs.existsSync(srcPath)) fail(`Missing source file for ${assetId}: ${srcPath}`);

  const outPath = path.join(releaseDir, rel);
  copyFileAtomic(srcPath, outPath);

  return {
    outPath,
    sha256: sha256Hex(outPath),
    size: fs.statSync(outPath).size
  };
}

function stageArchiveAsset(assetId, descriptor, srcDir, releaseDir) {
  const desc = descriptor && typeof descriptor === 'object' ? descriptor : {};
  const rel = String(desc.relativeUrl || '').trim();
  if (!rel) fail(`runtime asset ${assetId} is missing relativeUrl`);
  if (!desc.installDir) fail(`runtime asset ${assetId} is missing installDir`);
  if (String(desc.archiveFormat || '').toLowerCase() !== 'zip') {
    fail(`runtime asset ${assetId} must use archiveFormat=zip`);
  }
  if (!fs.existsSync(srcDir)) fail(`Missing source directory for ${assetId}: ${srcDir}`);

  const entrypoint = String(desc.entrypoint || '').trim();
  if (entrypoint) {
    const expectedEntrypoint = path.join(path.dirname(srcDir), entrypoint);
    if (!fs.existsSync(expectedEntrypoint)) {
      fail(`runtime asset ${assetId} entrypoint does not exist: ${expectedEntrypoint}`);
    }
  }

  const outPath = path.join(releaseDir, rel);
  zipDirKeepParent(srcDir, outPath);

  return {
    outPath,
    sha256: sha256Hex(outPath),
    seedSha256: sha256DirectoryTreeHex(srcDir, { rootName: path.basename(srcDir) }),
    size: fs.statSync(outPath).size
  };
}

module.exports = {
  fail,
  readJson,
  writeJson,
  writeJsonIfChanged,
  ensureDir,
  sha256Hex,
  sha256DirectoryTreeHex,
  copyFileAtomic,
  resolveFirstExisting,
  zipDirKeepParent,
  applyTemplate,
  joinUrl,
  parseGitHubReleaseBaseUrl,
  validateGitHubReleaseRelativeUrl,
  stageFileAsset,
  stageArchiveAsset
};
