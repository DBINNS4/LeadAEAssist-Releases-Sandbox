#!/usr/bin/env node

'use strict';

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const projectRoot = path.resolve(__dirname, '..');
const searchRoots = ['test', 'services/entitlement-service/test'];
const nodeTestNeedle = 'node:test';

function discoverFilesContainingNeedle(rootRelativePath, needle) {
  const rootAbsolutePath = path.join(projectRoot, rootRelativePath);
  if (!fs.existsSync(rootAbsolutePath)) {
    return [];
  }

  const discoveredFiles = [];
  const stack = [rootAbsolutePath];

  while (stack.length > 0) {
    const currentPath = stack.pop();
    const stats = fs.statSync(currentPath);

    if (stats.isDirectory()) {
      const entries = fs.readdirSync(currentPath, { withFileTypes: true });
      for (const entry of entries) {
        stack.push(path.join(currentPath, entry.name));
      }
      continue;
    }

    if (!stats.isFile()) {
      continue;
    }

    const fileContent = fs.readFileSync(currentPath, 'utf8');
    if (!fileContent.includes(needle)) {
      continue;
    }

    discoveredFiles.push(path.relative(projectRoot, currentPath));
  }

  return discoveredFiles;
}

const discoveredFiles = searchRoots
  .flatMap((rootRelativePath) => discoverFilesContainingNeedle(rootRelativePath, nodeTestNeedle))
  .sort((a, b) => a.localeCompare(b));

console.log('Discovered node:test files:');
if (discoveredFiles.length === 0) {
  console.log('  (none)');
} else {
  for (const filePath of discoveredFiles) {
    console.log(`  - ${filePath}`);
  }
}

const args = ['--test', '--test-force-exit', ...discoveredFiles];
const child = spawn(process.execPath, args, {
  stdio: 'inherit',
  cwd: projectRoot
});

child.on('error', (error) => {
  console.error(`Failed to start Node test runner: ${error.message}`);
  process.exit(1);
});

child.on('close', (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
    return;
  }

  process.exit(code ?? 1);
});
