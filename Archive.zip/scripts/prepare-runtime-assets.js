#!/usr/bin/env node
'use strict';

const buildRuntimeAssetsManifest = require('./build-runtime-assets-manifest');

if (require.main === module) {
  buildRuntimeAssetsManifest.main();
}

module.exports = buildRuntimeAssetsManifest;
