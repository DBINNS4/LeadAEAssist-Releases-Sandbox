#!/usr/bin/env node

'use strict';

const fs = require('fs');
const path = require('path');
const { getSelection } = require('./select-runtime-config');


function fail(msg) {
  console.error(msg);
  process.exit(1);
}

function assertNotBundled(extraResources, fromPath) {
  const hit = (extraResources || []).some((r) => {
    const f = (typeof r?.from === 'string') ? r.from : '';
    return f === fromPath;
  });
  if (hit) {
    fail(
      `❌ Packaging guard failed: extraResources must NOT include "${fromPath}".
` +
      `This dependency is now externalized into userData/assets (runtime assets).
` +
      `Remove it from build.extraResources before packaging.`
    );
  }
}

function assertRuntimeAssetsManifestWillBePackaged(buildFiles) {
  const files = Array.isArray(buildFiles) ? buildFiles : [];
  const includesConfigTree = files.includes('config/**/*');
  const includesManifestDirectly = files.includes('config/runtime.assets.manifest.json');
  const excludesManifest = files.includes('!config/runtime.assets.manifest.json');

  if (excludesManifest || (!includesConfigTree && !includesManifestDirectly)) {
    fail(
      '❌ Packaging guard failed: runtime assets manifest will not ship with the app.\n' +
      'Include config/runtime.assets.manifest.json via build.files (or keep config/**/*).\n' +
      'Packaged builds must be able to read the manifest without downloading it first.'
    );
  }
}


function assertLegalBundleFiles(projectRoot, buildFiles) {
  const files = Array.isArray(buildFiles) ? buildFiles : [];
  if (!files.includes('legal/**/*')) {
    fail(
      '❌ Packaging guard failed: build.files must include "legal/**/*".\n' +
      'Packaged builds must ship the bundled legal files under legal/.',
    );
  }

  const requiredLegalOnly = [
    'legal/Electron-MIT.txt',
    'legal/FFmpeg-LGPLv2.1.txt'
  ];

  for (const rel of requiredLegalOnly) {
    if (!fs.existsSync(path.join(projectRoot, rel))) {
      fail(
        `❌ Packaging guard failed: required legal file is missing (${rel}).\n` +
        'Packaged builds must include the bundled third-party license texts.'
      );
    }
  }

  const mirroredFiles = [
    ['LICENSE', 'legal/LICENSE'],
    ['NOTICE', 'legal/NOTICE'],
    ['THIRD_PARTY_LICENSES', 'legal/THIRD_PARTY_LICENSES'],
    ['APP-LICENSE.txt', 'legal/APP-LICENSE.txt']
  ];

  for (const [rootRel, legalRel] of mirroredFiles) {
    const rootAbs = path.join(projectRoot, rootRel);
    const legalAbs = path.join(projectRoot, legalRel);

    if (!fs.existsSync(rootAbs)) {
      fail(
        `❌ Packaging guard failed: required root legal file is missing (${rootRel}).\n` +
        'Keep the standard repo-level legal files present in source control.'
      );
    }

    if (!fs.existsSync(legalAbs)) {
      fail(
        `❌ Packaging guard failed: required packaged legal file is missing (${legalRel}).\n` +
        'Mirror the real legal files under legal/ so packaged builds always ship them.'
      );
    }

    const rootText = fs.readFileSync(rootAbs, 'utf8');
    const legalText = fs.readFileSync(legalAbs, 'utf8');
    if (rootText !== legalText) {
      fail(
        `❌ Packaging guard failed: ${legalRel} does not match ${rootRel}.\n` +
        'Keep the packaged legal copy in sync with the root legal file.'
      );
    }
  }
}

function assertRuntimeAssetScripts(packageJson) {
  const scripts = packageJson && typeof packageJson === 'object' && packageJson.scripts && typeof packageJson.scripts === 'object'
    ? packageJson.scripts
    : {};

  if (!scripts['assets:prepare']) {
    fail(
      '❌ Packaging guard failed: package.json must define scripts["assets:prepare"].\n' +
      'Release packaging must stage runtime assets and refresh the packaged manifest before electron-builder runs.'
    );
  }

  if (!scripts['assets:publish']) {
    fail(
      '❌ Packaging guard failed: package.json must define scripts["assets:publish"].\n' +
      'Release automation must have a canonical command for uploading staged runtime assets.'
    );
  }


  if (Object.prototype.hasOwnProperty.call(scripts, 'fetch:chrome')) {
    fail(
      '❌ Packaging guard failed: package.json must not define scripts["fetch:chrome"].\n' +
      'That legacy helper implied bundling Chromium into the app package. Chrome is now staged/published as a runtime asset.'
    );
  }
}

function assertPackagingScriptsDoNotPrefetchChrome(projectRoot, packageJson) {
  const packageDistScript = String(packageJson?.scripts?.dist || '');
  if (/\bfetch:chrome\b/.test(packageDistScript)) {
    fail(
      '❌ Packaging guard failed: package.json scripts.dist must not call fetch:chrome.\n' +
      'Chrome is externalized and should be acquired through runtime assets, not bundled during packaging.'
    );
  }

  const distShPath = path.join(projectRoot, 'scripts', 'dist.sh');
  if (!fs.existsSync(distShPath)) return;

  const distSh = fs.readFileSync(distShPath, 'utf8');
  if (/\bnpm\s+run\s+fetch:chrome\b/.test(distSh)) {
    fail(
      '❌ Packaging guard failed: scripts/dist.sh must not call npm run fetch:chrome.\n' +
      'Chrome is externalized and should be staged/published separately from the app bundle.'
    );
  }

  if (!/\bnpm\s+run\s+assets:prepare\b/.test(distSh)) {
    fail(
      '❌ Packaging guard failed: scripts/dist.sh must call npm run assets:prepare.\n' +
      'Release packaging should refresh runtime-asset metadata before electron-builder runs.'
    );
  }
}

function assertPackagingScriptsIncludeCepSigning(projectRoot, packageJson) {
  const signScript = String(packageJson?.scripts?.['sign:cep-zxp'] || '');
  if (!/build\/sign-cep-zxp\.js/.test(signScript)) {
    fail(
      '❌ Packaging guard failed: package.json must define scripts["sign:cep-zxp"] as the canonical CEP signing command.\n' +
      'Packaged builds install the signed CEP archive from resources/cep/zxp/LeadAEAssist_CEP.zxp.'
    );
  }

  const distShPath = path.join(projectRoot, 'scripts', 'dist.sh');
  if (fs.existsSync(distShPath)) {
    const distSh = fs.readFileSync(distShPath, 'utf8');
    if (!/\bnpm\s+run\s+sign:cep-zxp\b|build\/sign-cep-zxp\.js/.test(distSh)) {
      fail(
        '❌ Packaging guard failed: scripts/dist.sh must run the CEP signing step before electron-builder.\n' +
        'Otherwise the packaged app ships without resources/cep/zxp/LeadAEAssist_CEP.zxp and Preferences installs fail.'
      );
    }
  }

  const packageJsPath = path.join(projectRoot, 'scripts', 'package.js');
  if (fs.existsSync(packageJsPath)) {
    const packageJs = fs.readFileSync(packageJsPath, 'utf8');
    if (!/build\/sign-cep-zxp\.js/.test(packageJs)) {
      fail(
        '❌ Packaging guard failed: scripts/package.js must run the CEP signing step before electron-builder.\n' +
        'The package wrapper should be self-contained and regenerate resources/cep/zxp/LeadAEAssist_CEP.zxp.'
      );
    }
  }
}

const projectRoot = path.resolve(__dirname, '..');
const packageJson = JSON.parse(fs.readFileSync(path.join(projectRoot, 'package.json'), 'utf8'));
const buildFiles = packageJson?.build?.files || [];
const extraResources = packageJson?.build?.extraResources || [];

// Phase 4 guardrails: these must not ship inside the app bundle anymore.
assertNotBundled(extraResources, 'vendor/puppeteer');
assertNotBundled(extraResources, 'whisper.cpp/models');
assertRuntimeAssetsManifestWillBePackaged(buildFiles);
assertLegalBundleFiles(projectRoot, buildFiles);
assertRuntimeAssetScripts(packageJson);
assertPackagingScriptsDoNotPrefetchChrome(projectRoot, packageJson);
assertPackagingScriptsIncludeCepSigning(projectRoot, packageJson);

const requiredExclusions = ['!config/*.save', '!config/*.bak', '!config/*.tmp', '!config/*.local.json', '!config/*.example.json'];
const forbiddenSuffixes = ['.save', '.bak', '.tmp'];

const missingExclusions = requiredExclusions.filter((pattern) => !buildFiles.includes(pattern));
if (missingExclusions.length > 0) {
  console.error(`Missing required build.files exclusions: ${missingExclusions.join(', ')}`);
  process.exit(1);
}

const configDir = path.join(projectRoot, 'config');
const configFiles = fs.existsSync(configDir) ? fs.readdirSync(configDir).filter((name) => fs.statSync(path.join(configDir, name)).isFile()) : [];

// Never allow client-auth secret artifacts to exist in the repo workspace.
// Desktop apps cannot keep a shared secret secret; any such file is both insecure and will trip scanners.
const forbiddenClientSecretFiles = [
  'entitlement.client_secret',
  'entitlement.client_secret.prod'
];
const forbiddenFiles = configFiles.filter((name) => forbiddenSuffixes.some((suffix) => name.endsWith(suffix)));

if (forbiddenFiles.length > 0) {
  console.log(`Found local backup/tmp config files (expected in dev): ${forbiddenFiles.join(', ')}`);
}

const presentClientSecretFiles = forbiddenClientSecretFiles.filter((name) => configFiles.includes(name));
if (presentClientSecretFiles.length > 0) {
  console.error(`Forbidden client secret file(s) present in config/: ${presentClientSecretFiles.join(', ')}`);
  console.error('Remove these files from the workspace and never commit them.');
  process.exit(1);
}

// Files that must exist in config/ for a valid packaging workspace.
// Keep this list small and intentional; anything here is required for packaging.
const canonicalRuntimeFiles = [
  'public.runtime.json',
  'public.runtime.prod.json',
  'runtime.assets.manifest.json',
  'defaults.json',
  'license-verification-keys.json'
];
const missingCanonicalFiles = canonicalRuntimeFiles.filter((name) => !configFiles.includes(name));
if (missingCanonicalFiles.length > 0) {
  console.error(`Missing canonical runtime config file(s): ${missingCanonicalFiles.join(', ')}`);
  process.exit(1);
}

const selection = getSelection(String(process.env.LEADAE_BUILD_ENV || '').trim(), projectRoot);
if (!fs.existsSync(selection.outputPath)) {
  console.error(
    `Selected runtime artifact is missing (${path.relative(projectRoot, selection.outputPath)}). Run scripts/select-runtime-config.js before packaging.`
  );
  process.exit(1);
}

let selectedOnDisk;
try {
  selectedOnDisk = JSON.parse(fs.readFileSync(selection.outputPath, 'utf8'));
} catch (error) {
  console.error(`Unable to parse selected runtime artifact: ${selection.outputPath} (${error.message})`);
  process.exit(1);
}

if (JSON.stringify(selectedOnDisk) !== JSON.stringify(selection.selectedRuntime)) {
  console.error(
    `Selected runtime artifact does not match requested LEADAE_BUILD_ENV=${selection.buildEnv}. Regenerate it with scripts/select-runtime-config.js.`
  );
  process.exit(1);
}

const hasSelectedRuntimeMapping = extraResources.some((entry) => {
  if (!entry || typeof entry !== 'object') return false;
  return entry.from === 'config/public.runtime.selected.json' && entry.to === 'config/public.runtime.json';
});

if (!hasSelectedRuntimeMapping) {
  console.error('build.extraResources must map config/public.runtime.selected.json to config/public.runtime.json.');
  process.exit(1);
}

console.log(
  `Package config guard passed: runtime selection (${selection.buildEnv}) is valid, selected artifact matches the requested environment, and packaging rules are enforced.`
);
