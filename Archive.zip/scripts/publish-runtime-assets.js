#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const {
  fail,
  readJson,
  validateGitHubReleaseRelativeUrl
} = require('./runtime-assets-utils');

function parseCliArgs(argv = []) {
  const options = {
    dryRun: false,
    clobber: false,
    createIfMissing: false,
    projectRoot: path.resolve(__dirname, '..')
  };

  for (let i = 0; i < argv.length; i += 1) {
    const token = String(argv[i] || '').trim();
    if (!token) continue;

    if (token === '--dry-run') {
      options.dryRun = true;
      continue;
    }
    if (token === '--clobber') {
      options.clobber = true;
      continue;
    }
    if (token === '--create-if-missing') {
      options.createIfMissing = true;
      continue;
    }

    const next = argv[i + 1];
    if (token === '--manifest') {
      options.releaseManifestPath = path.resolve(String(next || ''));
      i += 1;
      continue;
    }
    if (token === '--release-dir') {
      options.releaseDir = path.resolve(String(next || ''));
      i += 1;
      continue;
    }
    if (token === '--owner') {
      options.owner = String(next || '').trim();
      i += 1;
      continue;
    }
    if (token === '--repo') {
      options.repo = String(next || '').trim();
      i += 1;
      continue;
    }
    if (token === '--tag') {
      options.tag = String(next || '').trim();
      i += 1;
      continue;
    }

    fail(`Unknown argument: ${token}`);
  }

  return options;
}

function resolvePublishContext(options = {}) {
  const projectRoot = path.resolve(options.projectRoot || path.join(__dirname, '..'));
  const releaseDir = path.resolve(options.releaseDir || path.join(projectRoot, 'release', 'runtime-assets'));
  const releaseManifestPath = path.resolve(options.releaseManifestPath || path.join(releaseDir, 'runtime.assets.manifest.json'));

  if (!fs.existsSync(releaseManifestPath)) {
    fail(`Release manifest does not exist: ${releaseManifestPath}`);
  }

  const releaseManifest = readJson(releaseManifestPath);
  const releaseMeta = (releaseManifest.release && typeof releaseManifest.release === 'object')
    ? releaseManifest.release
    : {};

  const owner = String(options.owner || releaseMeta.owner || '').trim();
  const repo = String(options.repo || releaseMeta.repo || '').trim();
  const tag = String(options.tag || releaseMeta.tag || '').trim();
  const provider = String(releaseMeta.provider || '').trim() || 'github';

  if (provider !== 'github') {
    fail(`Unsupported runtime asset publish provider: ${provider}`);
  }
  if (!owner || !repo || !tag) {
    fail('Runtime asset publish target is incomplete. Expected owner, repo, and tag in the release manifest or CLI args.');
  }

  return {
    projectRoot,
    releaseDir,
    releaseManifestPath,
    releaseManifest,
    provider,
    owner,
    repo,
    tag,
    repoRef: `${owner}/${repo}`
  };
}

function collectRuntimeAssetUploadFiles(context) {
  const assets = (context.releaseManifest.assets && typeof context.releaseManifest.assets === 'object')
    ? context.releaseManifest.assets
    : {};
  const files = [];
  const seen = new Set();

  for (const [assetId, descriptor] of Object.entries(assets)) {
    if (!descriptor || typeof descriptor !== 'object') continue;
    const rel = validateGitHubReleaseRelativeUrl(descriptor.relativeUrl);
    const assetPath = path.join(context.releaseDir, rel);
    if (!fs.existsSync(assetPath)) {
      fail(`Staged runtime asset is missing for ${assetId}: ${assetPath}`);
    }
    if (!seen.has(assetPath)) {
      files.push(assetPath);
      seen.add(assetPath);
    }
  }

  if (!seen.has(context.releaseManifestPath)) {
    files.push(context.releaseManifestPath);
  }

  return files;
}

function buildGhReleaseViewArgs(context) {
  return ['release', 'view', context.tag, '--repo', context.repoRef];
}

function buildGhReleaseCreateArgs(context) {
  return ['release', 'create', context.tag, '--repo', context.repoRef, '--title', context.tag, '--notes', ''];
}

function buildGhReleaseUploadArgs(context, files, options = {}) {
  const args = ['release', 'upload', context.tag, ...files, '--repo', context.repoRef];
  if (options.clobber) args.push('--clobber');
  return args;
}

function ensureGhAvailable() {
  const probe = spawnSync('gh', ['--version'], { stdio: 'ignore' });
  if (probe.error || probe.status !== 0) {
    fail('GitHub CLI (gh) is required to publish runtime assets. Install gh and authenticate before running assets:publish.');
  }
}

function runGh(args, options = {}) {
  const child = spawnSync('gh', args, {
    stdio: options.stdio || 'inherit',
    cwd: options.cwd,
    env: process.env
  });
  if (child.error) {
    throw child.error;
  }
  if (typeof child.status === 'number' && child.status !== 0) {
    throw new Error(`gh ${args.join(' ')} exited with code ${child.status}`);
  }
  return child;
}

function publishRuntimeAssets(options = {}) {
  const context = resolvePublishContext(options);
  const files = collectRuntimeAssetUploadFiles(context);

  if (options.dryRun) {
    return {
      ...context,
      files,
      commands: {
        view: buildGhReleaseViewArgs(context),
        create: options.createIfMissing ? buildGhReleaseCreateArgs(context) : null,
        upload: buildGhReleaseUploadArgs(context, files, options)
      }
    };
  }

  ensureGhAvailable();

  try {
    runGh(buildGhReleaseViewArgs(context), { cwd: context.projectRoot });
  } catch (error) {
    if (!options.createIfMissing) {
      throw new Error(
        `GitHub release ${context.repoRef}@${context.tag} does not exist or is not visible to gh. ` +
        'Create the release first, or re-run with --create-if-missing.\n' +
        `Original error: ${error.message}`
      );
    }
    runGh(buildGhReleaseCreateArgs(context), { cwd: context.projectRoot });
  }

  runGh(buildGhReleaseUploadArgs(context, files, options), { cwd: context.projectRoot });

  return { ...context, files };
}

function main() {
  try {
    const options = parseCliArgs(process.argv.slice(2));
    const result = publishRuntimeAssets(options);

    if (options.dryRun) {
      console.log(`Runtime asset publish plan for ${result.repoRef}@${result.tag}:`);
      for (const file of result.files) {
        console.log(`- ${path.relative(result.projectRoot, file)}`);
      }
      console.log(`gh ${result.commands.view.join(' ')}`);
      if (result.commands.create) {
        console.log(`gh ${result.commands.create.join(' ')}`);
      }
      console.log(`gh ${result.commands.upload.join(' ')}`);
      return;
    }

    console.log(`Published runtime assets to ${result.repoRef}@${result.tag}:`);
    for (const file of result.files) {
      console.log(`- ${path.relative(result.projectRoot, file)}`);
    }
  } catch (error) {
    console.error(error?.message || String(error));
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  parseCliArgs,
  resolvePublishContext,
  collectRuntimeAssetUploadFiles,
  buildGhReleaseViewArgs,
  buildGhReleaseCreateArgs,
  buildGhReleaseUploadArgs,
  publishRuntimeAssets,
  main
};
