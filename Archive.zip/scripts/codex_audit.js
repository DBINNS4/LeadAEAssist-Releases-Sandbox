#!/usr/bin/env node
/*
  Phase 0: Codex Build audit harness.

  What it checks:
    1) Spec sanity: defaults must be present in their corresponding allowed lists.
    2) UI coverage: the Transcode panel dropdowns must be able to represent every
       value Codex may return in compatibility.
    3) Runtime feasibility (lightweight): each format should have
         - a resolvable video encoder (utils/formatCapabilities)
         - at least one muxable container in the current FFmpeg build

  Notes:
    - This is intentionally an audit-only script. It should not modify any files.
    - It uses the same spec loading logic as the app (utils/codex).
      When run under Electron it can see a user override spec; when run under
      plain Node it will audit the repo's config/codex_format_spec.json.

  Usage:
    node scripts/codex_audit.js
    node scripts/codex_audit.js --ffmpeg ./extra/ffmpeg/ffmpeg
    node scripts/codex_audit.js --json

  Why this exists:
    FFmpeg builds vary ("legal" builds often omit encoders). The UI must not offer
    combinations that can fail at transcode time.

  References:
    - Pixel format selection: ffmpeg docs (-pix_fmt, -pix_fmts). See ffmpeg-all.
*/

'use strict';

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const codex = require('../utils/codex');
const { getFormatCapabilities } = require('../utils/formatCapabilities');
const { getBinaryPaths } = require('../utils/ffmpegBridge');
const { getAvailableEncoderSet } = require('../utils/gpuEncoder');

function parseArgs(argv) {
  const out = { ffmpeg: null, json: false, quiet: false };
  const args = Array.isArray(argv) ? argv.slice(2) : [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--ffmpeg') out.ffmpeg = args[++i] || null;
    else if (a === '--json') out.json = true;
    else if (a === '--quiet') out.quiet = true;
  }
  return out;
}

function uniq(arr) {
  return Array.from(new Set((arr || []).filter(v => v != null).map(v => String(v))));
}

function readText(p) {
  return fs.readFileSync(p, 'utf8');
}

function safeExists(p) {
  try { return !!(p && fs.existsSync(p)); } catch { return false; }
}

function extractFirstGroup(src, re) {
  const m = src.match(re);
  return m && m[1] ? m[1] : null;
}

function extractValueFields(src) {
  const values = [];
  const re = /value\s*:\s*['"]([^'"]+)['"]/g;
  let m;
  while ((m = re.exec(src))) values.push(m[1]);
  return values;
}

function extractBareSingleQuotedStrings(src) {
  const values = [];
  const re = /'([^']+)'/g;
  let m;
  while ((m = re.exec(src))) values.push(m[1]);
  return values;
}

function extractUiOptionsFromRenderer(rendererPath) {
  const src = readText(rendererPath);

  // Container list is assigned to `containerOptions` and then passed into setupStyledDropdown.
  const containerRegion = (() => {
    const idx = src.indexOf('function initContainerFormats');
    return idx >= 0 ? src.slice(idx, idx + 1000) : src;
  })();
  const containerArrayBody = extractFirstGroup(containerRegion, /const\s+containerOptions\s*=\s*\[([\s\S]*?)\];/m) || '';
  const containers = uniq(extractValueFields(containerArrayBody)).filter(v => /^[a-z0-9_]+$/i.test(v));

  const resolutionsBody = extractFirstGroup(src, /setupStyledDropdown\('resolution'\s*,\s*\[([\s\S]*?)\]\s*\)\s*;?/m) || '';
  const resolutions = uniq(extractBareSingleQuotedStrings(resolutionsBody)).filter(v => /^\d+x\d+$/.test(v));

  const frameRatesBody = extractFirstGroup(src, /setupStyledDropdown\('frameRate'\s*,\s*\[([\s\S]*?)\]\s*\)\s*;?/m) || '';
  const frameRates = uniq(extractBareSingleQuotedStrings(frameRatesBody)).filter(v => /^[0-9.]+(df)?$/i.test(v));

  // Pixel formats can be either:
  //   setupStyledDropdown('pixelFormat', [ ... ])
  // OR
  //   const pixelFormatOptions = [ ... ]; ensurePixelFormat('nv12', ...); setupStyledDropdown('pixelFormat', pixelFormatOptions);
  const pixelFormatsBody = extractFirstGroup(src, /setupStyledDropdown\('pixelFormat'\s*,\s*\[([\s\S]*?)\]\s*\)\s*;?/m) || '';
  let pixelFormats = uniq(extractValueFields(pixelFormatsBody)).filter(v => /^[a-z0-9_]+$/i.test(v));
  if (!pixelFormats.length) {
    const pfArrayBody = extractFirstGroup(src, /const\s+pixelFormatOptions\s*=\s*\[([\s\S]*?)\]\s*;?/m) || '';
    const fromArray = extractValueFields(pfArrayBody);
    const fromEnsure = [];
    const reEnsure = /ensurePixelFormat\(\s*['"]([^'"]+)['"]/g;
    let m;
    while ((m = reEnsure.exec(src))) fromEnsure.push(m[1]);
    pixelFormats = uniq([...fromArray, ...fromEnsure]).filter(v => /^[a-z0-9_]+$/i.test(v));
  }

  const colorRangesBody = extractFirstGroup(src, /setupStyledDropdown\('colorRange'\s*,\s*\[([\s\S]*?)\]\s*\)\s*;?/m) || '';
  const colorRanges = uniq(extractValueFields(colorRangesBody)).map(v => v.toLowerCase());

  const fieldOrdersBody = extractFirstGroup(src, /setupStyledDropdown\('fieldOrder'\s*,\s*\[([\s\S]*?)\]\s*\)\s*;?/m) || '';
  const fieldOrders = uniq(extractValueFields(fieldOrdersBody)).filter(Boolean);

  const channelsBody = extractFirstGroup(src, /setupStyledDropdown\('channels'\s*,\s*\[([\s\S]*?)\]\s*\)\s*;?/m) || '';
  const channelValues = uniq([
    ...extractValueFields(channelsBody),
    ...extractBareSingleQuotedStrings(channelsBody)
  ]);
  const channels = channelValues.filter(v => ['preserve', 'mono', 'stereo', '5.1', '7.1'].includes(String(v).toLowerCase()));

  const sampleRatesBody = extractFirstGroup(src, /setupStyledDropdown\('sampleRate'\s*,\s*\[([\s\S]*?)\]\s*\)\s*;?/m) || '';
  const sampleRates = uniq(extractBareSingleQuotedStrings(sampleRatesBody)).filter(v => /^\d+$/.test(v));

  const audioBitratesBody = extractFirstGroup(src, /setupStyledDropdown\('audioBitrate'\s*,\s*\[([\s\S]*?)\]\s*\)\s*;?/m) || '';
  const audioBitrates = uniq(extractValueFields(audioBitratesBody)).filter(v => /^\d+$/.test(v));

  return {
    containers,
    resolutions,
    frameRates,
    pixelFormats,
    colorRanges,
    fieldOrders,
    channels,
    sampleRates,
    audioBitrates
  };
}

function getAvailableMuxerSet(ffmpegPath) {
  const set = new Set();
  if (!ffmpegPath) return set;
  let out = '';
  try {
    out = execFileSync(ffmpegPath, ['-hide_banner', '-muxers'], { encoding: 'utf8' }) || '';
  } catch {
    return set;
  }
  for (const line of String(out).split(/\r?\n/)) {
    const s = String(line || '').trim();
    if (!s) continue;
    if (s.startsWith('-')) continue;
    const lower = s.toLowerCase();
    if (lower.startsWith('muxers:') || lower.startsWith('file formats:') || lower.startsWith('formats:')) continue;

    const parts = s.split(/\s+/);
    if (!parts.length) continue;
    const t0 = parts[0];
    const looksLikeFlags = /^[D.]*E[.A-Z]*$/.test(t0) || /^[A-Z.]{1,6}$/.test(t0);
    const name = looksLikeFlags ? parts[1] : parts[0];
    if (name && /^[a-zA-Z0-9_]+$/.test(name)) set.add(name);
  }
  return set;
}

function filterContainersByMuxers(containers, muxerSet) {
  const map = {
    mkv: 'matroska',
    matroska: 'matroska',
    mov: 'mov',
    mp4: 'mp4',
    mxf: 'mxf',
    mxf_opatom: 'mxf_opatom',
    mxf_d10: 'mxf_d10',
    wav: 'wav',
    aiff: 'aiff',
    // Panel uses "image_sequence" while FFmpeg's muxer is "image2"
    image_sequence: 'image2',
    image2: 'image2'
  };

  const out = [];
  for (const c of (containers || [])) {
    const key = String(c || '').toLowerCase().trim();
    if (!key) continue;
    const muxName = map[key] || key;
    if (muxerSet.has(muxName)) out.push(key === 'image2' ? 'image_sequence' : key);
  }
  return uniq(out);
}


const __encoderPixFmtCache = new Map(); // key: `${ffmpegPath}::${encoder}` -> Set(pix_fmt)
function getEncoderPixelFormatSet(ffmpegPath, encoderName) {
  const bin = String(ffmpegPath || '').trim();
  const enc = String(encoderName || '').trim();
  if (!bin || !enc) return new Set();
  const key = `${bin}::${enc}`;
  if (__encoderPixFmtCache.has(key)) return __encoderPixFmtCache.get(key);
  let out = '';
  try {
    out = execFileSync(bin, ['-hide_banner', '-h', `encoder=${enc}`], { encoding: 'utf8' }) || '';
  } catch {
    const empty = new Set();
    __encoderPixFmtCache.set(key, empty);
    return empty;
  }
  const m = String(out).match(/Supported pixel formats:\s*([^\r\n]+)/i);
  const list = m && m[1] ? m[1].trim().split(/\s+/).filter(Boolean) : [];
  const set = new Set(list.map(s => String(s).trim()).filter(Boolean));
  __encoderPixFmtCache.set(key, set);
  return set;
}

function diff(label, have, need) {
  const haveSet = new Set((have || []).map(String));
  const missing = (need || []).map(String).filter(v => v && !haveSet.has(v));
  return uniq(missing).sort();
}

function main() {
  const args = parseArgs(process.argv);
  const root = path.join(__dirname, '..');

  const rendererPath = path.join(root, 'renderer.transcode.js');
  if (!safeExists(rendererPath)) {
    console.error('❌ Cannot find renderer.transcode.js at', rendererPath);
    process.exit(1);
  }

  const ui = extractUiOptionsFromRenderer(rendererPath);

  const spec = codex.loadSpec();
  const formats = spec?.formats || {};
  const audio = spec?.audio || {};

  // Union across all format entries
  const unionFormats = (field) => {
    const out = [];
    for (const v of Object.values(formats)) out.push(...(v?.[field] || []));
    return uniq(out);
  };

  const unionLower = (field) => uniq(unionFormats(field).map(v => String(v).toLowerCase()));

  const specContainers = unionFormats('containers');
  const specResolutions = unionFormats('resolutions');
  const specFrameRates = unionFormats('frameRates');
  const specPixelFormats = unionFormats('pixelFormats');
  const specColorRanges = unionLower('colorRanges');
  const specFieldOrders = unionFormats('fieldOrders');
  const specChannelOptions = unionFormats('channelOptions');
  const specSampleRates = unionFormats('sampleRates');
  const specDefaultAudioBitrates = uniq(Object.values(formats).map(v => v?.defaultAudioBitrate).filter(Boolean));

  const report = {
    counts: {
      formats: Object.keys(formats).length,
      audioCodecs: Object.keys(audio).length
    },
    ui,
    missingUiCoverage: {
      containers: diff('containers', ui.containers, specContainers.map(v => (v === 'image2' ? 'image_sequence' : v))),
      resolutions: diff('resolutions', ui.resolutions, specResolutions),
      frameRates: diff('frameRates', ui.frameRates, specFrameRates),
      pixelFormats: diff('pixelFormats', ui.pixelFormats, specPixelFormats),
      colorRanges: diff('colorRanges', ui.colorRanges, specColorRanges),
      fieldOrders: diff('fieldOrders', ui.fieldOrders, specFieldOrders),
      channels: diff('channels', ui.channels, specChannelOptions),
      sampleRates: diff('sampleRates', ui.sampleRates, specSampleRates),
      audioBitrates: diff('audioBitrates', ui.audioBitrates, specDefaultAudioBitrates)
    },
    specSanity: {
      defaultsNotInAllowed: [],
      defaultsSetButListEmpty: []
    },
    runtime: {
      unsupportedFormats: [],
      noMuxableContainers: [],
      unsupportedAudioCodecs: [],
      pixelFormatMismatches: []
    }
  };

  // Spec sanity: defaults must be in their corresponding allowed lists
  for (const [key, v] of Object.entries(formats)) {
    if (!v || typeof v !== 'object') continue;

    const checkDefault = (defKey, listKey, normalize = (x) => String(x)) => {
      const def = v?.[defKey];
      if (!def) return;
      const list = Array.isArray(v?.[listKey]) ? v[listKey] : [];
      if (!list.length) {
        report.specSanity.defaultsSetButListEmpty.push({
          format: key,
          issue: `${defKey}=${def} but ${listKey} is empty`
        });
        return;
      }
      const nDef = normalize(def);
      const nList = list.map(normalize);
      if (!nList.includes(nDef)) {
        report.specSanity.defaultsNotInAllowed.push({
          format: key,
          issue: `${defKey}=${def} not present in ${listKey}=[${nList.join(', ')}]`
        });
      }
    };

    checkDefault('defaultContainer', 'containers', (x) => (String(x) === 'image2' ? 'image_sequence' : String(x)));
    checkDefault('defaultResolution', 'resolutions', String);
    checkDefault('defaultFrameRate', 'frameRates', String);
    checkDefault('defaultPixelFormat', 'pixelFormats', String);
    checkDefault('defaultColorRange', 'colorRanges', (x) => String(x).toLowerCase());
    checkDefault('defaultFieldOrder', 'fieldOrders', String);
    checkDefault('defaultAudio', 'audio', String);
    checkDefault('defaultChannels', 'channelOptions', String);
    checkDefault('defaultSampleRate', 'sampleRates', String);
  }

  // Runtime feasibility: encoder + muxer checks using the bundled FFmpeg build
  const ffmpegPath = args.ffmpeg || getBinaryPaths().ffmpegPath;
  const hasFfmpeg = safeExists(ffmpegPath);
  const muxerSet = hasFfmpeg ? getAvailableMuxerSet(ffmpegPath) : new Set();
  const encSet = hasFfmpeg ? getAvailableEncoderSet(ffmpegPath) : new Set();

  const audioAlias = {
    opus: ['opus', 'libopus'],
    vorbis: ['vorbis', 'libvorbis'],
    aac: ['aac', 'libfdk_aac']
  };

  if (hasFfmpeg) {
    for (const fmt of Object.keys(formats)) {
      const caps = getFormatCapabilities(fmt, ffmpegPath);
      if (!caps || !caps.encoderAvailable) {
        report.runtime.unsupportedFormats.push({
          format: fmt,
          videoEncoder: caps?.videoEncoder || null
        });
        continue;
      }

      const compat = codex.getCompatibility(fmt) || {};
      const containers = Array.isArray(compat?.containers) ? compat.containers : [];
      const filtered = muxerSet.size ? filterContainersByMuxers(containers, muxerSet) : containers;
      if (!filtered.length) {
        report.runtime.noMuxableContainers.push({ format: fmt, containers });
      }

      // Flag spec pixel formats that the resolved encoder cannot accept.
      const enc = caps?.videoEncoder;
      const specPix = Array.isArray(compat?.pixelFormats) ? compat.pixelFormats : [];
      const pixSet = enc ? getEncoderPixelFormatSet(ffmpegPath, enc) : new Set();
      if (enc && pixSet.size && specPix.length) {
        const unsupported = specPix.filter(p => !pixSet.has(String(p)));
        const intersection = specPix.filter(p => pixSet.has(String(p)));
        if (unsupported.length) {
          report.runtime.pixelFormatMismatches.push({
            format: fmt,
            encoder: enc,
            unsupported: uniq(unsupported).sort(),
            intersectionEmpty: intersection.length === 0
          });
        }
      }
    }

    const specAudioCodecs = Object.keys(audio || {}).map(String).filter(Boolean);
    for (const codec of specAudioCodecs) {
      const key = String(codec || '').toLowerCase().trim();
      const candidates = audioAlias[key] || [key];
      const ok = candidates.some(name => encSet.has(name));
      if (!ok) report.runtime.unsupportedAudioCodecs.push(codec);
    }
    report.runtime.unsupportedAudioCodecs = uniq(report.runtime.unsupportedAudioCodecs).sort();
  }

  if (args.json) {
    process.stdout.write(JSON.stringify(report, null, 2));
    return;
  }

  const say = (...xs) => { if (!args.quiet) console.log(...xs); };

  say('--- Codex Phase 0 audit ---');
  say('Formats:', report.counts.formats, 'Audio codecs:', report.counts.audioCodecs);
  say('FFmpeg:', ffmpegPath, hasFfmpeg ? '' : '(not found)');

  const missing = report.missingUiCoverage;
  const anyMissing = Object.values(missing).some(arr => Array.isArray(arr) && arr.length);
  if (anyMissing) {
    say('\n❌ UI coverage gaps (Codex can return values the UI cannot represent):');
    for (const [k, arr] of Object.entries(missing)) {
      if (!arr.length) continue;
      say(`  - ${k}:`);
      arr.forEach(v => say('      •', v));
    }
  } else {
    say('\n✅ UI coverage: Transcode dropdowns cover all values referenced by Codex spec.');
  }

  if (report.specSanity.defaultsSetButListEmpty.length || report.specSanity.defaultsNotInAllowed.length) {
    say('\n⚠️  Spec sanity issues:');
    report.specSanity.defaultsSetButListEmpty.forEach(p => say('  -', p.format + ':', p.issue));
    report.specSanity.defaultsNotInAllowed.forEach(p => say('  -', p.format + ':', p.issue));
  } else {
    say('\n✅ Spec sanity: defaults appear inside their allowed lists.');
  }

  if (!hasFfmpeg) {
    say('\n⚠️  Skipping runtime checks (FFmpeg not found). Use --ffmpeg /path/to/ffmpeg if needed.');
  } else {
    if (report.runtime.unsupportedFormats.length) {
      say('\n❌ Formats in spec that are not encodable in this FFmpeg build:');
      report.runtime.unsupportedFormats.forEach(r => {
        say(`  - ${r.format} (resolved encoder: ${r.videoEncoder || 'none'})`);
      });
    } else {
      say('\n✅ All spec formats resolve to an available encoder in this FFmpeg build.');
    }

    if (report.runtime.noMuxableContainers.length) {
      say('\n❌ Formats whose containers are not muxable in this FFmpeg build:');
      report.runtime.noMuxableContainers.forEach(r => {
        say(`  - ${r.format} (containers: ${(r.containers || []).join(', ') || 'none'})`);
      });
    } else {
      say('✅ All spec formats have at least one muxable container.');
    }

    if (report.runtime.unsupportedAudioCodecs.length) {
      say('\n⚠️  Audio codec entries in spec not present in FFmpeg encoder list:');
      report.runtime.unsupportedAudioCodecs.forEach(c => say('  -', c));
    }

    if (report.runtime.pixelFormatMismatches.length) {
      say('\n⚠️  Pixel format mismatches (spec lists pix_fmts not supported by resolved encoder):');
      report.runtime.pixelFormatMismatches.forEach(r => {
        const note = r.intersectionEmpty ? ' (NO OVERLAP — format will be unusable until spec is fixed)' : '';
        say(`  - ${r.format} -> ${r.encoder}${note}`);
        (r.unsupported || []).forEach(pf => say('      •', pf));
      });
    }
  }

  say('\nDone.');
}

main();
