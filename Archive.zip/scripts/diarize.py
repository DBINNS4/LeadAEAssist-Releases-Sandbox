# scripts/diarize.py

import sys, os, json

# Make project root importable
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from tokenless_diarizer import diarize


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python diarize.py /path/to/audio.[wav|mp3|mov] [num_speakers]")
        sys.exit(1)

    audio_path = sys.argv[1]
    try:
        num_speakers = int(sys.argv[2]) if len(sys.argv) > 2 else None
    except ValueError:
        num_speakers = None

    result = diarize(audio_path, num_speakers=num_speakers)
    print(json.dumps(result, indent=2))

