/*
  scripts/build-help.js

  Phase B: Build bundled offline help assets.

  Input:
    - help/ (markdown docs)
    - help/_meta/ (nav + manifest)
    - help/_ui/ (help window HTML/CSS/JS)

  Output (generated; safe to delete/regenerate):
    - resources/help/*

  Design goals:
    - No network access.
    - No runtime markdown parsing in Electron.
    - No external npm deps (keeps install simple and build deterministic).
    - Strict CSP compatible: no inline scripts.
*/

'use strict';

const fs = require('fs');
const path = require('path');

function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}

function copyFile(src, dst) {
  ensureDir(path.dirname(dst));
  fs.copyFileSync(src, dst);
}

function copyDirRecursive(src, dst) {
  if (!fs.existsSync(src)) return;
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    ensureDir(dst);
    for (const entry of fs.readdirSync(src)) {
      copyDirRecursive(path.join(src, entry), path.join(dst, entry));
    }
    return;
  }
  copyFile(src, dst);
}

function stripFrontmatter(md) {
  const raw = String(md || '').replace(/^\uFEFF/, '');
  const lines = raw.split(/\r?\n/);
  if (lines.length < 3) return raw;
  if (lines[0].trim() !== '---') return raw;
  let endIdx = -1;
  for (let i = 1; i < lines.length; i++) {
    if (lines[i].trim() === '---') {
      endIdx = i;
      break;
    }
  }
  if (endIdx === -1) return raw;
  return lines.slice(endIdx + 1).join('\n');
}

function escapeHtml(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function escapeAttr(s) {
  // Enough for href/title etc.
  return escapeHtml(s).replace(/\n/g, ' ');
}

function normalizeRoute(route) {
  const raw = String(route || '').trim();
  if (!raw) return '/';
  let r = raw;
  if (!r.startsWith('/')) r = `/${r}`;
  r = r.replace(/\/+/g, '/');
  if (!r.endsWith('/')) r += '/';
  return r;
}

function slugify(text) {
  const t = String(text || '')
    .toLowerCase()
    .replace(/&[a-z]+;/g, ' ') // entities (already escaped sometimes)
    .replace(/[^a-z0-9\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!t) return 'section';
  return t.replace(/\s+/g, '-').replace(/-+/g, '-');
}

function stripInlineMarkers(text) {
  let s = String(text || '');
  // [text](url) => text
  s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1');
  // `code` => code
  s = s.replace(/`([^`]+)`/g, '$1');
  // **bold** => bold
  s = s.replace(/\*\*([^*]+)\*\*/g, '$1');
  // *italic* => italic
  s = s.replace(/\*([^*]+)\*/g, '$1');
  return s;
}

function rewriteLink(hrefRaw, currentRoute) {
  const href = String(hrefRaw || '').trim();
  if (!href) return href;

  // Same-page anchors: "#something" => deep link with ?a=
  if (href.startsWith('#')) {
    const anchor = href.slice(1).trim();
    if (!anchor) return `#${normalizeRoute(currentRoute)}`;
    return `#${normalizeRoute(currentRoute)}?a=${encodeURIComponent(anchor)}`;
  }

  // Internal routes: "/panels/ingest/" => "#/panels/ingest/"
  if (href.startsWith('/') && !href.startsWith('//')) {
    const [p, anchor] = href.split('#');
    const route = normalizeRoute(p);
    if (anchor) return `#${route}?a=${encodeURIComponent(anchor)}`;
    return `#${route}`;
  }

  return href;
}

function renderPlainText(rawText) {
  // Escape then apply lightweight emphasis.
  let s = escapeHtml(rawText);
  // Bold first
  s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  // Then italics
  s = s.replace(/\*([^*]+)\*/g, '<em>$1</em>');
  return s;
}

function renderInlines(text, currentRoute) {
  const raw = String(text || '');
  // Split by `code` spans (keep delimiters)
  const parts = raw.split(/(`[^`]+`)/g);
  const out = [];

  for (const part of parts) {
    if (part.startsWith('`') && part.endsWith('`') && part.length >= 2) {
      out.push(`<code>${escapeHtml(part.slice(1, -1))}</code>`);
      continue;
    }

    // Links: [text](href)
    const linkRe = /\[([^\]]+)\]\(([^)]+)\)/g;
    let last = 0;
    let match;
    while ((match = linkRe.exec(part)) !== null) {
      const [full, linkText, linkHref] = match;
      const start = match.index;
      const end = start + full.length;

      if (start > last) out.push(renderPlainText(part.slice(last, start)));

      const safeText = renderPlainText(linkText);
      const rewritten = rewriteLink(linkHref, currentRoute);
      out.push(`<a href="${escapeAttr(rewritten)}">${safeText}</a>`);

      last = end;
    }
    if (last < part.length) out.push(renderPlainText(part.slice(last)));
  }

  return out.join('');
}

function markdownToHtml(md, { route }) {
  const content = stripFrontmatter(md).replace(/\r\n/g, '\n');
  const lines = content.split('\n');

  const out = [];
  const paragraph = [];
  let listType = null; // 'ul' | 'ol'
  let listItems = [];
  const headingIds = new Map();

  function flushParagraph() {
    if (!paragraph.length) return;
    const joined = paragraph.join(' ').replace(/\s+/g, ' ').trim();
    if (joined) out.push(`<p>${renderInlines(joined, route)}</p>`);
    paragraph.length = 0;
  }

  function flushList() {
    if (!listType || !listItems.length) {
      listType = null;
      listItems = [];
      return;
    }
    out.push(`<${listType}>`);
    out.push(listItems.join('\n'));
    out.push(`</${listType}>`);
    listType = null;
    listItems = [];
  }

  function makeHeadingId(rawText) {
    const base = slugify(stripInlineMarkers(rawText));
    const prev = headingIds.get(base) || 0;
    const next = prev + 1;
    headingIds.set(base, next);
    return next === 1 ? base : `${base}-${next}`;
  }

  for (const lineRaw of lines) {
    const line = String(lineRaw || '').replace(/\s+$/g, '');
    const trimmed = line.trim();

    // Blank line: end paragraph/list.
    if (!trimmed) {
      flushParagraph();
      flushList();
      continue;
    }

    // Horizontal rule
    if (trimmed === '---' || trimmed === '***') {
      flushParagraph();
      flushList();
      out.push('<hr>');
      continue;
    }

    // Headings
    const h = /^(#{1,6})\s+(.*)$/.exec(trimmed);
    if (h) {
      flushParagraph();
      flushList();
      const level = h[1].length;
      const text = h[2].trim();
      const id = makeHeadingId(text);
      out.push(`<h${level} id="${escapeAttr(id)}">${renderInlines(text, route)}</h${level}>`);
      continue;
    }

    // Unordered list item
    const ul = /^[-*]\s+(.*)$/.exec(trimmed);
    if (ul) {
      flushParagraph();
      const itemText = ul[1].trim();
      if (listType && listType !== 'ul') flushList();
      listType = 'ul';
      listItems.push(`<li>${renderInlines(itemText, route)}</li>`);
      continue;
    }

    // Ordered list item
    const ol = /^\d+\.\s+(.*)$/.exec(trimmed);
    if (ol) {
      flushParagraph();
      const itemText = ol[1].trim();
      if (listType && listType !== 'ol') flushList();
      listType = 'ol';
      listItems.push(`<li>${renderInlines(itemText, route)}</li>`);
      continue;
    }

    // Otherwise: paragraph line
    if (listType) flushList();
    paragraph.push(trimmed);
  }

  flushParagraph();
  flushList();
  return out.join('\n');
}

function mdToPlainText(md) {
  let s = stripFrontmatter(md);
  s = s.replace(/\r\n/g, '\n');
  // Remove heading markers
  s = s.replace(/^#{1,6}\s+/gm, '');
  // Inline code
  s = s.replace(/`([^`]+)`/g, '$1');
  // Links -> text
  s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1');
  // Bold / italic markers
  s = s.replace(/\*\*([^*]+)\*\*/g, '$1');
  s = s.replace(/\*([^*]+)\*/g, '$1');
  // List markers
  s = s.replace(/^\s*[-*]\s+/gm, '');
  s = s.replace(/^\s*\d+\.\s+/gm, '');
  // Collapse whitespace
  s = s.replace(/\n+/g, ' ');
  s = s.replace(/\s+/g, ' ').trim();
  return s;
}

function routeFromHelpPath(relPath) {
  // relPath is path relative to help/ root
  const unix = relPath.split(path.sep).join('/');
  if (!unix.endsWith('.md')) return null;
  const withoutExt = unix.slice(0, -3);

  // Root index.md => '/'
  if (withoutExt === 'index') return '/';

  const parts = withoutExt.split('/');
  const base = parts[parts.length - 1];
  const dir = parts.slice(0, -1).join('/');

  if (base === 'index') {
    return normalizeRoute(`/${dir}/`);
  }
  if (!dir) {
    return normalizeRoute(`/${base}/`);
  }
  return normalizeRoute(`/${dir}/${base}/`);
}

function docTypeFromRoute(route) {
  const r = normalizeRoute(route);
  if (r === '/') return 'index';
  if (r === '/search/') return 'search';
  if (r.startsWith('/panels/')) return 'panel';
  if (r.startsWith('/troubleshooting/')) return 'troubleshooting';
  if (r.startsWith('/workflows/')) return 'workflow';
  if (r.startsWith('/reference/')) return 'reference';
  return 'index';
}

function walkFiles(rootDir, { ignoreDirs = new Set(), extensions = new Set() } = {}) {
  const out = [];
  function walk(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const ent of entries) {
      const abs = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        if (ignoreDirs.has(ent.name)) continue;
        walk(abs);
        continue;
      }
      const ext = path.extname(ent.name).toLowerCase();
      if (extensions.size && !extensions.has(ext)) continue;
      out.push(abs);
    }
  }
  walk(rootDir);
  return out;
}

function writeJsData(dstPath, globalName, dataObj) {
  const payload = JSON.stringify(dataObj);
  const js = `// AUTO-GENERATED. DO NOT EDIT.\nwindow.${globalName} = ${payload};\n`;
  ensureDir(path.dirname(dstPath));
  fs.writeFileSync(dstPath, js, 'utf8');
}

function readJsonSafe(p) {
  try {
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch {
    return null;
  }
}

function main() {
  const projectRoot = path.resolve(__dirname, '..');
  const helpRoot = path.join(projectRoot, 'help');
  const uiRoot = path.join(helpRoot, '_ui');
  const metaRoot = path.join(helpRoot, '_meta');
  const outRoot = path.join(projectRoot, 'resources', 'help');

  if (!fs.existsSync(helpRoot)) {
    console.warn('[build-help] help/ directory not found. Skipping.');
    return;
  }

  // Clean output
  fs.rmSync(outRoot, { recursive: true, force: true });
  ensureDir(outRoot);

  // Copy static UI shell
  copyDirRecursive(uiRoot, outRoot);

  // Copy meta files (manifest/nav) for runtime use
  ensureDir(path.join(outRoot, '_meta'));
  const manifestSrc = path.join(metaRoot, 'help-manifest.json');
  const navSrc = path.join(metaRoot, 'nav.json');
  if (fs.existsSync(manifestSrc)) copyFile(manifestSrc, path.join(outRoot, '_meta', 'help-manifest.json'));
  if (fs.existsSync(navSrc)) copyFile(navSrc, path.join(outRoot, '_meta', 'nav.json'));

  // Read nav for titles
  const nav = readJsonSafe(navSrc) || { defaultRoute: '/', sections: [] };
  const titleBySlug = new Map();
  const addTitles = (node) => {
    if (!node || typeof node !== 'object') return;
    if (node.slug && node.title) titleBySlug.set(normalizeRoute(node.slug), String(node.title));
    if (Array.isArray(node.children)) node.children.forEach(addTitles);
    if (Array.isArray(node.items)) node.items.forEach(addTitles);
  };
  if (Array.isArray(nav.sections)) nav.sections.forEach(addTitles);

  // Build pages
  const mdFiles = walkFiles(helpRoot, {
    ignoreDirs: new Set(['_meta', '_ui']),
    extensions: new Set(['.md'])
  });

  const pages = {};
  const searchIndex = [];

  for (const abs of mdFiles) {
    const rel = path.relative(helpRoot, abs);
    const route = routeFromHelpPath(rel);
    if (!route) continue;

    const md = fs.readFileSync(abs, 'utf8');
    const title = titleBySlug.get(normalizeRoute(route)) || ''; // fallback later
    const html = markdownToHtml(md, { route });

    // Fallback title from first H1 if nav didn't have it
    let finalTitle = title;
    if (!finalTitle) {
      const m = /<h1[^>]*>([\s\S]*?)<\/h1>/i.exec(html);
      if (m) finalTitle = m[1].replace(/<[^>]+>/g, '').trim();
    }
    if (!finalTitle) finalTitle = route;

    const docType = docTypeFromRoute(route);
    pages[normalizeRoute(route)] = {
      title: finalTitle,
      docType,
      html
    };

    const plain = mdToPlainText(md);
    const excerpt = plain.length > 220 ? `${plain.slice(0, 217)}…` : plain;
    searchIndex.push({
      slug: normalizeRoute(route),
      title: finalTitle,
      docType,
      excerpt,
      body: plain
    });
  }

  // Deterministic order for stable diffs
  searchIndex.sort((a, b) => a.slug.localeCompare(b.slug));

  // Write data bundles
  writeJsData(path.join(outRoot, 'nav-data.js'), '__HELP_NAV__', nav);
  writeJsData(path.join(outRoot, 'pages-data.js'), '__HELP_PAGES__', pages);
  writeJsData(path.join(outRoot, 'search-data.js'), '__HELP_SEARCH_INDEX__', searchIndex);

  console.log(`[build-help] Built ${Object.keys(pages).length} pages -> ${outRoot}`);
}

if (require.main === module) {
  try {
    main();
  } catch (err) {
    console.error('[build-help] Failed:', err);
    process.exit(1);
  }
}
