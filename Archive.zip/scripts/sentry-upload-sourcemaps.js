#!/usr/bin/env node
'use strict';

// NOTE: sentry-cli v3 removed `releases files ...` commands; use `sourcemaps upload` instead.

/*
  scripts/sentry-upload-sourcemaps.js

  Uploads JS sourcemaps (and their corresponding minified JS files) to Sentry.

  Release naming rule (enforced):
    release = package.json "version" (matches app.getVersion() at runtime)

  This script intentionally does NOT try to guess CI semantics like build numbers.
  If you want per-build releases, you can bump package.json version in CI.

  Typical CI usage:
    1) npm ci
    2) npm run package   (generates dist-obfuscated/*.map)
    3) npm run sentry:upload-sourcemaps

  Required env vars (recommended for CI):
    - SENTRY_AUTH_TOKEN
    - SENTRY_ORG
    - SENTRY_PROJECT
    - (optional) SENTRY_URL (self-hosted)

  Options:
    --dry-run                 Print commands, do not call sentry-cli
    --release <value>         Override release (default: package.json version)
    --dir <path>              Directory containing JS + .map files (default: dist-obfuscated)
    --url-prefix <prefix>     URL prefix used by frames (default: app:///dist-obfuscated)
    --no-finalize             Do not finalize the Sentry release

  Notes on url-prefix:
    Sentry Electron events commonly contain filenames like:
      app:///dist-obfuscated/renderer.js

    Therefore we upload artifacts with the same prefix by default.
    sentry-cli gained explicit support for app:/// prefixes (see sentry-cli PR #599).
*/

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

function readJsonFile(p) {
  try {
    const raw = fs.readFileSync(p, 'utf8');
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function projectRoot() {
  return path.resolve(__dirname, '..');
}

function parseArgs(argv) {
  const opts = {
    dryRun: false,
    release: null,
    dir: 'dist-obfuscated',
    urlPrefix: process.env.SENTRY_URL_PREFIX || 'app:///dist-obfuscated',
    finalize: true,
  };

  const args = [...argv];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];

    if (a === '--dry-run') {
      opts.dryRun = true;
      continue;
    }

    if (a === '--no-finalize') {
      opts.finalize = false;
      continue;
    }

    if (a === '--release') {
      opts.release = args[i + 1];
      i++;
      continue;
    }
    if (a.startsWith('--release=')) {
      opts.release = a.slice('--release='.length);
      continue;
    }

    if (a === '--dir') {
      opts.dir = args[i + 1];
      i++;
      continue;
    }
    if (a.startsWith('--dir=')) {
      opts.dir = a.slice('--dir='.length);
      continue;
    }

    if (a === '--url-prefix') {
      opts.urlPrefix = args[i + 1];
      i++;
      continue;
    }
    if (a.startsWith('--url-prefix=')) {
      opts.urlPrefix = a.slice('--url-prefix='.length);
      continue;
    }

    throw new Error(`Unknown argument: ${a}`);
  }

  if (typeof opts.urlPrefix === 'string') {
    opts.urlPrefix = opts.urlPrefix.trim();
    // Avoid accidental trailing slash behavior that can surprise users.
    // (sentry-cli historically trimmed a single trailing slash.)
    opts.urlPrefix = opts.urlPrefix.replace(/\/+$/, '');
  }

  return opts;
}

function getRelease(projectRootDir, overrideRelease) {
  const r = (overrideRelease || '').trim();
  if (r) return r;

  const pkg = readJsonFile(path.join(projectRootDir, 'package.json'));
  const version = pkg && typeof pkg.version === 'string' ? pkg.version.trim() : '';
  if (!version) {
    throw new Error('Unable to determine release: package.json "version" is missing.');
  }
  return version;
}

function findSentryCli(projectRootDir) {
  const binName = process.platform === 'win32' ? 'sentry-cli.cmd' : 'sentry-cli';
  const local = path.join(projectRootDir, 'node_modules', '.bin', binName);
  if (fs.existsSync(local)) return local;

  // Fall back to PATH. This is the most common CI setup.
  return 'sentry-cli';
}

function collectFiles(dir, predicate, out = []) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return out;
  }

  for (const ent of entries) {
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) {
      collectFiles(p, predicate, out);
    } else if (ent.isFile()) {
      if (predicate(p)) out.push(p);
    }
  }
  return out;
}

function run(cli, args, { allowNonZero = false, allowAlreadyExists = false, dryRun = false } = {}) {
  const printable = [cli, ...args].map(s => {
    const str = String(s);
    // Basic quoting for readability in logs.
    return str.includes(' ') ? JSON.stringify(str) : str;
  });

   
  console.log(`\n$ ${printable.join(' ')}`);

  if (dryRun) return { status: 0, stdout: '', stderr: '' };

  const res = spawnSync(cli, args, {
    cwd: projectRoot(),
    env: process.env,
    encoding: 'utf8',
  });

  if (res.stdout) process.stdout.write(res.stdout);
  if (res.stderr) process.stderr.write(res.stderr);

  if (res.error) {
    throw res.error;
  }

  const status = typeof res.status === 'number' ? res.status : 1;
  if (status === 0) return { status, stdout: res.stdout || '', stderr: res.stderr || '' };

  const stderr = (res.stderr || '').toLowerCase();
  if (allowAlreadyExists && stderr.includes('already exists')) {
     
    console.log('↳ Release already exists (continuing).');
    return { status: 0, stdout: res.stdout || '', stderr: res.stderr || '' };
  }

  if (allowNonZero) return { status, stdout: res.stdout || '', stderr: res.stderr || '' };

  throw new Error(`Command failed with exit code ${status}`);
}

function warnIfMissingEnv() {
  const missing = [];
  if (!process.env.SENTRY_AUTH_TOKEN) missing.push('SENTRY_AUTH_TOKEN');

  if (missing.length > 0) {
     
    console.warn(
      `\n[warn] Missing recommended env vars (${missing.join(', ')}). ` +
        'If sentry-cli is not preconfigured via .sentryclirc, uploads will fail.'
    );
  }

  // These are required for non-interactive CI usage.
  // In sentry-cli v3, it’s safest to provide org+project explicitly.
  const missingTarget = [];
  if (!process.env.SENTRY_ORG) missingTarget.push('SENTRY_ORG');
  if (!process.env.SENTRY_PROJECT) missingTarget.push('SENTRY_PROJECT');
  if (missingTarget.length > 0) {
     
    console.warn(
      `\n[warn] Missing required target env vars (${missingTarget.join(', ')}). ` +
        'Set these to your org slug and project slug, e.g. SENTRY_ORG="lead-ae" SENTRY_PROJECT="lead-ae-assist".'
    );
  }
}

function main() {
  const root = projectRoot();
  const opts = parseArgs(process.argv.slice(2));

  const release = getRelease(root, opts.release);
  const dirAbs = path.resolve(root, opts.dir);

  if (!fs.existsSync(dirAbs)) {
    throw new Error(`Sourcemap directory not found: ${dirAbs}`);
  }

  const mapFiles = collectFiles(dirAbs, p => p.toLowerCase().endsWith('.map'));
  if (mapFiles.length === 0) {
    throw new Error(
      `No .map files found under ${dirAbs}.\n` +
        'Generate them first (run `node obfuscate-all.js` or `npm run package`).'
    );
  }

   
  console.log(`\nSentry release: ${release}`);
   
  console.log(`Sourcemap dir:   ${dirAbs}`);
   
  console.log(`URL prefix:      ${opts.urlPrefix}`);

  // Hard fail if the user is trying to do a real upload without org/project.
  if (!opts.dryRun) {
    if (!process.env.SENTRY_ORG || !process.env.SENTRY_PROJECT) {
      throw new Error(
        'Missing SENTRY_ORG and/or SENTRY_PROJECT. ' +
          'Set SENTRY_ORG to your org slug and SENTRY_PROJECT to your project slug before uploading.'
      );
    }
  }

  warnIfMissingEnv();

  const cli = findSentryCli(root);

  // 1) Create the release (idempotent)
  run(cli, ['releases', 'new', release], {
    allowAlreadyExists: true,
    dryRun: opts.dryRun,
  });

  // 2) Upload sourcemaps (sentry-cli v3+)
  //    Use Debug IDs + artifact bundles. Provide --release to associate artifacts with the release name.
  //    Docs: `sentry-cli sourcemaps upload --release=<release_name> /path/to/directory`
  run(cli, [
    'sourcemaps',
    'upload',
    '--org', process.env.SENTRY_ORG,
    '--project', process.env.SENTRY_PROJECT,
    '--release', release,
    '--url-prefix', opts.urlPrefix,
    '--validate',
    dirAbs,
  ], { dryRun: opts.dryRun });

  // 3) Finalize the release (optional)
  if (opts.finalize) {
    run(cli, ['releases', 'finalize', '--org', process.env.SENTRY_ORG, '--project', process.env.SENTRY_PROJECT, release], { dryRun: opts.dryRun });
  }

   
  console.log('\n✅ Sentry sourcemap upload complete.');
}

try {
  main();
} catch (err) {
   
  console.error('\n❌ Sentry sourcemap upload failed:', err?.message || err);
  process.exit(1);
}
