#!/usr/bin/env bash
set -euo pipefail

ROOT="/Users/davidbinnsmini/LeadAI"
VENV_BIN="$ROOT/venv/bin"
FFMPEG_DIR="$ROOT/extra/ffmpeg"

exec env -i \
  HOME="$HOME" \
  LANG="en_US.UTF-8" \
  LC_ALL="en_US.UTF-8" \
  PATH="$VENV_BIN:$FFMPEG_DIR:/usr/bin:/bin:/usr/sbin:/sbin" \
  PYTHONNOUSERSITE=1 \
  PYTHONPATH="" \
  "$VENV_BIN/python3.11" "$@"
