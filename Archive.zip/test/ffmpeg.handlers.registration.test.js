const registerFfmpegHandlers = require('../ipc/ffmpeg.handlers');

describe('registerFfmpegHandlers', () => {
  test('registers each FFmpeg IPC channel exactly once', () => {
    const calls = [];
    const ipcMain = {
      handle: jest.fn((channel, handler) => {
        calls.push({ channel, handler });
      })
    };

    registerFfmpegHandlers(ipcMain);

    const channels = calls.map((c) => c.channel);
    expect(channels).toEqual([
      'exec-ffmpeg',
      'exec-ffprobe',
      'ffprobe-json',
      'probe-media',
      'ffmpeg:get-capabilities',
      'get-ffmpeg-formats'
    ]);

    expect(new Set(channels).size).toBe(channels.length);
    expect(ipcMain.handle).toHaveBeenCalledTimes(6);

    for (const call of calls) {
      expect(typeof call.handler).toBe('function');
    }
  });
});
