const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

function readPreload() {
  return fs.readFileSync(path.join(__dirname, '..', 'preload.js'), 'utf8');
}

test('preload allowlists runtime asset IPC channels and progress subscription helper', () => {
  const src = readPreload();

  assert.match(src, /'assets:getStatus'/);
  assert.match(src, /'assets:prefetch'/);
  assert.match(src, /'assets:cancel'/);
  assert.match(src, /'assets:progress'/);
  assert.match(src, /assets:\s*\{[\s\S]*?getStatus:\s*\(request = \{\}\) => invokeAllowed\('assets:getStatus', request\)/);
  assert.match(src, /assets:\s*\{[\s\S]*?prefetch:\s*\(request = \{\}, options = \{\}\) => invokeAllowed\('assets:prefetch', request, options\)/);
  assert.match(src, /assets:\s*\{[\s\S]*?cancel:\s*\(request = \{\}\) => invokeAllowed\('assets:cancel', request\)/);
  assert.match(src, /assets:\s*\{[\s\S]*?onProgress:\s*\(cb\) => \{[\s\S]*?onAllowed\('assets:progress', listener\)/);
});
