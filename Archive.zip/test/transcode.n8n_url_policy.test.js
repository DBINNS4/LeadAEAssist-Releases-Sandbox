/** @jest-environment node */

jest.mock('electron', () => ({}));

describe('validateN8nUrl (transcode) — n8n URL policy', () => {
  const { validateN8nUrl } = require('../modules/transcode');

  test('rejects http webhook URL in packaged builds', () => {
    const result = validateN8nUrl('http://hooks.example.com/transcode', {
      allowPrivate: true,
      isPackaged: true,
      allowInsecureHttp: false
    });

    expect(result.valid).toBe(false);
    expect(result.message).toContain('must use https:// in packaged builds');
  });

  test('accepts https webhook URL in packaged builds', () => {
    const result = validateN8nUrl('https://hooks.example.com/transcode', {
      allowPrivate: true,
      isPackaged: true
    });

    expect(result.valid).toBe(true);
  });

  test('rejects webhook host not on allowlist', () => {
    const result = validateN8nUrl('https://hooks.example.com/transcode', {
      allowPrivate: true,
      isPackaged: true,
      allowlist: ['trusted.example.com']
    });

    expect(result.valid).toBe(false);
    expect(result.message).toContain('host not allowed');
  });

  test('accepts webhook host on allowlist', () => {
    const result = validateN8nUrl('https://hooks.example.com/transcode', {
      allowPrivate: true,
      isPackaged: true,
      allowlist: ['hooks.example.com', 'trusted.example.com']
    });

    expect(result.valid).toBe(true);
  });
});
