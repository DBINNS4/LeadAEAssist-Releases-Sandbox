/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');

jest.mock('electron', () => ({
  BrowserWindow: {
    getFocusedWindow: () => ({ webContents: { send: jest.fn() }, isDestroyed: () => false }),
    getAllWindows: () => [{ webContents: { send: jest.fn() }, isDestroyed: () => false }]
  },
  app: {
    isPackaged: false,
    getAppPath: () => '/mock/app/path'
  }
}));

jest.mock('../progressBridge', () => ({
  bindProgressManager: () => () => {}
}));

jest.mock('../utils/ffmpeg', () => ({
  ffmpegPath: '/bin/echo',
  ffprobePath: '/bin/echo'
}));

jest.mock('../modules/logUtils', () => ({
  sendLogMessage: jest.fn(),
  writeLogToFile: jest.fn(),
  writeJobLogToFile: jest.fn(() => null),
  writeJobTextToFile: jest.fn(() => null),
  createJobLogger: () => ({
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    setStage: jest.fn(),
    getEntries: jest.fn(() => []),
    getStructuredLogPath: jest.fn(() => null),
    close: jest.fn()
  }),
  createJobUserLog: () => {
    const lines = [];
    return {
      lines,
      push: jest.fn((msg) => {
        lines.push(String(msg || ''));
      })
    };
  }
}));

jest.mock('child_process', () => {
  const { EventEmitter } = require('events');
  const fs = require('fs');

  const execFile = jest.fn((bin, args, opts, cb) => {
    const callback = typeof opts === 'function' ? opts : cb;
    const payload = {
      format: { duration: '1.0' },
      streams: [{ width: 1920, height: 1080, nb_frames: '24', avg_frame_rate: '24/1', r_frame_rate: '24/1' }]
    };
    callback(null, Buffer.from(JSON.stringify(payload)));
  });

  const spawn = jest.fn((bin, args) => {
    const proc = new EventEmitter();
    proc.stderr = new EventEmitter();
    proc.stdout = new EventEmitter();
    proc.kill = jest.fn();
    proc.exitCode = null;
    proc.signalCode = null;

    const outputPath = args[args.length - 1];
    fs.writeFileSync(outputPath, Buffer.alloc(64));

    setImmediate(() => {
      proc.emit('close', 0, null);
      proc.emit('exit', 0, null);
    });

    return proc;
  });

  return {
    spawn,
    execFile,
    execFileSync: jest.fn(() => Buffer.from('Encoders:\n V..... libx264\n'))
  };
});

describe('runTranscode multi-file progress harness', () => {
  let tmpRoot;
  const prevNodeEnv = process.env.NODE_ENV;

  beforeEach(() => {
    jest.resetModules();
    tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-multi-progress-'));
  });

  afterEach(() => {
    delete global.queue;
    fs.rmSync(tmpRoot, { recursive: true, force: true });
    process.env.NODE_ENV = prevNodeEnv;
  });

  test('emits queue progress through completion for multi-file jobs', async () => {
    process.env.NODE_ENV = 'development';
    const inA = path.join(tmpRoot, 'a.mov');
    const inB = path.join(tmpRoot, 'b.mov');
    const outDir = path.join(tmpRoot, 'out');

    fs.writeFileSync(inA, Buffer.alloc(256));
    fs.writeFileSync(inB, Buffer.alloc(512));
    fs.mkdirSync(outDir);

    const events = [];
    global.queue = new EventEmitter();
    global.queue.on('job-progress', (evt) => events.push(evt));

    const { runTranscode } = require('../modules/transcode');
    const result = await runTranscode({
      jobId: 'multi-file-progress-job',
      inputFiles: [inA, inB],
      outputFormat: 'h264',
      containerFormat: 'mov',
      outputFolder: outDir,
      resolution: 'source',
      frameRate: 'source',
      audioCodec: 'aac',
      channels: 'stereo',
      sampleRate: '48000',
      audioBitrate: '192k',
      pixelFormat: 'default',
      colorRange: '',
      fieldOrder: 'progressive',
      audioOnly: false,
      enableQualityCheck: false
    });

    expect(result.success).toBe(true);
    expect(events.length).toBeGreaterThan(0);

    const completionEvt = events.find((evt) => evt.completed === 2 && evt.total === 2 && evt.percent === 100);
    expect(completionEvt).toBeTruthy();

    const doneStatusEvents = events.filter((evt) => typeof evt.status === 'string' && evt.status.startsWith('✅ Done:'));
    expect(doneStatusEvents).toHaveLength(2);
  });
});
