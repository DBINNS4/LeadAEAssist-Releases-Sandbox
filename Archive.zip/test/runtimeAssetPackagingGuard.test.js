const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const projectRoot = path.resolve(__dirname, '..');

test('runtime asset packaging guard: package.json no longer exposes legacy fetch:chrome', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(projectRoot, 'package.json'), 'utf8'));
  assert.equal(Object.prototype.hasOwnProperty.call(pkg.scripts || {}, 'fetch:chrome'), false);
});

test('runtime asset packaging guard: verify-package-config-files passes in sandbox mode', () => {
  const result = spawnSync(process.execPath, ['scripts/verify-package-config-files.js'], {
    cwd: projectRoot,
    encoding: 'utf8',
    env: {
      ...process.env,
      LEADAE_BUILD_ENV: 'sandbox'
    }
  });

  assert.equal(
    result.status,
    0,
    `verify-package-config-files.js failed\nstdout:\n${result.stdout || ''}\nstderr:\n${result.stderr || ''}`
  );
});
