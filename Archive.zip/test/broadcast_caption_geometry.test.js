const {
  _calcBroadcastSafeTitleGeometry,
  _rowToYPx15,
  _nearestRow15
} = require('../renderer.subtitleEditor.js');

describe('Broadcast caption geometry (SCC/MCC: CEA-608 + CTA-708)', () => {
  test('CEA-608: 32 columns span the 4:3 safe-title area (inner 80% of centered 4:3)', () => {
    const g = _calcBroadcastSafeTitleGeometry({ width: 1920, height: 1080 }, '608');

    // Centered 4:3 inside 16:9: min(1920, 1080*(4/3)=1440) => 1440.
    expect(g.activeW).toBeCloseTo(1440, 6);
    expect(g.activeLeft).toBeCloseTo(240, 6);

    // Safe-title is inner 80% of activeW => 1152, centered => left 384.
    expect(g.safeWidth).toBeCloseTo(1152, 6);
    expect(g.safeLeft).toBeCloseTo(384, 6);

    // Regression guard: grid must match safe-title (NOT the full active aperture).
    expect(g.gridW).toBeCloseTo(g.safeWidth, 6);
    expect(g.gridLeft).toBeCloseTo(g.safeLeft, 6);
    expect(g.gridW).toBeLessThan(g.activeW);
    expect(g.gridLeft).toBeGreaterThan(g.activeLeft);

    // 32 columns across safe-title.
    expect(g.cols).toBe(32);
    expect(g.cellW).toBeCloseTo(36, 6);

    // Vertical safe-title: inner 80% of height.
    expect(g.safeTop).toBeCloseTo(108, 6);
    expect(g.safeH).toBeCloseTo(864, 6);
  });

  test('CEA-608: 4:3 preview still uses inner-80% safe-title grid', () => {
    const g = _calcBroadcastSafeTitleGeometry({ width: 640, height: 480 }, '608');

    expect(g.activeW).toBeCloseTo(640, 6);
    expect(g.activeLeft).toBeCloseTo(0, 6);

    expect(g.safeWidth).toBeCloseTo(512, 6);
    expect(g.safeLeft).toBeCloseTo(64, 6);

    expect(g.cols).toBe(32);
    expect(g.cellW).toBeCloseTo(16, 6);
  });

  test('CTA-708: 42 columns span the 16:9 safe-title area (inner 80% of full preview)', () => {
    const g = _calcBroadcastSafeTitleGeometry({ width: 1920, height: 1080 }, '708');

    expect(g.activeW).toBeCloseTo(1920, 6);
    expect(g.activeLeft).toBeCloseTo(0, 6);

    expect(g.safeWidth).toBeCloseTo(1536, 6);
    expect(g.safeLeft).toBeCloseTo(192, 6);

    expect(g.gridW).toBeCloseTo(g.safeWidth, 6);
    expect(g.gridLeft).toBeCloseTo(g.safeLeft, 6);

    expect(g.cols).toBe(42);
    expect(g.cellW).toBeCloseTo(1536 / 42, 6);

    expect(g.safeTop).toBeCloseTo(108, 6);
    expect(g.safeH).toBeCloseTo(864, 6);
  });

  test('Row mapping: _nearestRow15 is the inverse of _rowToYPx15', () => {
    const h = 1080;
    for (const row of [1, 2, 7, 14, 15]) {
      const y = _rowToYPx15(row, h);
      expect(_nearestRow15(y, h)).toBe(row);
    }
  });
});
