/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');

describe('fsAccessControl userData allowlist and sensitive denylist', () => {
  let tmpRoot;
  let userDataPath;
  let fsAccessControl;

  const loadControl = () => {
    jest.resetModules();
    process.env.USER_DATA_PATH = userDataPath;
     
    fsAccessControl = require('../utils/fsAccessControl');
  };

  beforeEach(() => {
    tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'fs-access-policy-'));
    userDataPath = path.join(tmpRoot, 'userData');
    fs.mkdirSync(userDataPath, { recursive: true });

    [
      'presets',
      'logs',
      'previews',
      'temp',
      'cache',
      path.join('config'),
      path.join('bridge'),
      path.join('license'),
    ].forEach(p => fs.mkdirSync(path.join(userDataPath, p), { recursive: true }));

    fs.writeFileSync(path.join(userDataPath, 'config', 'secrets.bin'), 'secret');
    fs.writeFileSync(path.join(userDataPath, 'config', 'secrets.fallback.key'), 'secret-key');
    fs.writeFileSync(path.join(userDataPath, 'bridge', 'bridge.json'), '{}');
    fs.writeFileSync(path.join(userDataPath, 'license', 'token.txt'), 'tok');

    loadControl();
  });

  afterEach(() => {
    delete process.env.USER_DATA_PATH;
    fs.rmSync(tmpRoot, { recursive: true, force: true });
  });

  test('allows only selected app-managed subdirectories under userData', () => {
    const senderId = 101;

    expect(fsAccessControl.isPathAllowed(senderId, path.join(userDataPath, 'presets', 'preset.json'))).toBe(true);
    expect(fsAccessControl.isPathAllowed(senderId, path.join(userDataPath, 'logs', 'app.log'))).toBe(true);
    expect(fsAccessControl.isPathAllowed(senderId, path.join(userDataPath, 'previews', 'thumb.mp4'))).toBe(true);
    expect(fsAccessControl.isPathAllowed(senderId, path.join(userDataPath, 'temp', 'work.tmp'))).toBe(true);
    expect(fsAccessControl.isPathAllowed(senderId, path.join(userDataPath, 'cache', 'index.db'))).toBe(true);

    expect(fsAccessControl.isPathAllowed(senderId, path.join(userDataPath, 'config', 'prefs.json'))).toBe(true);
  });

  test('denies sensitive paths before subpath checks even with approved userData root', () => {
    const senderId = 202;
    fsAccessControl.approveRoot(senderId, userDataPath, 'dir');

    const secrets = path.join(userDataPath, 'config', 'secrets.bin');
    const fallbackKey = path.join(userDataPath, 'config', 'secrets.fallback.key');
    const bridgeJson = path.join(userDataPath, 'bridge', 'bridge.json');

    expect(fsAccessControl.evaluatePathAccess(senderId, secrets)).toEqual(
      expect.objectContaining({ allowed: false, reason: 'sensitive_path_denied' })
    );
    expect(fsAccessControl.isPathAllowed(senderId, fallbackKey)).toBe(false);
    expect(fsAccessControl.isPathAllowed(senderId, bridgeJson)).toBe(false);
  });

  test('keeps dialog-approved external roots functional', () => {
    const senderId = 303;
    const external = path.join(tmpRoot, 'external-media');
    fs.mkdirSync(path.join(external, 'clips'), { recursive: true });
    const clip = path.join(external, 'clips', 'A001.mov');
    fs.writeFileSync(clip, 'x');

    fsAccessControl.approveRoot(senderId, external, 'dir');

    expect(fsAccessControl.isPathAllowed(senderId, clip)).toBe(true);
    expect(fsAccessControl.evaluatePathAccess(senderId, clip)).toEqual(
      expect.objectContaining({ allowed: true, reason: 'approved_dir' })
    );
  });
});
