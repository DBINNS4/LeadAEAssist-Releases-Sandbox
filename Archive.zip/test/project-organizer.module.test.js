const fs = require('fs');
const os = require('os');
const path = require('path');

const { createProjectStructure } = require('../modules/project-organizer');

describe('project-organizer module hardening', () => {
  test('createProjectStructure rejects reserved meta key folder names', async () => {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'organizer-meta-'));

    const result = await createProjectStructure({
      jobId: `test-${Date.now()}`,
      rootName: 'ShowA',
      selectedFolders: ['__proto__'],
      prependNumbers: false,
      outputPath: tmp,
      folderAssets: Object.create(null)
    });

    expect(result.success).toBe(false);
    expect(result.logText).toMatch(/reserved object meta keys/i);
  });

  test('createProjectStructure supports normal folderAssets mapping keys', async () => {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'organizer-assets-'));
    const srcDir = fs.mkdtempSync(path.join(os.tmpdir(), 'organizer-src-'));
    const srcFile = path.join(srcDir, 'clip.mov');
    fs.writeFileSync(srcFile, 'test-bytes');

    const result = await createProjectStructure({
      jobId: `test-${Date.now()}`,
      rootName: 'ShowB',
      selectedFolders: ['MEDIA'],
      prependNumbers: false,
      outputPath: tmp,
      folderAssets: {
        MEDIA: [srcFile]
      }
    });

    expect(result.success).toBe(true);
    expect(fs.existsSync(path.join(tmp, 'ShowB', 'MEDIA', 'clip.mov'))).toBe(true);
  });

  test('createProjectStructure does not throw when folderAssets has malicious keys', async () => {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'organizer-malicious-'));

    await expect(createProjectStructure({
      jobId: `test-${Date.now()}`,
      rootName: 'ShowC',
      selectedFolders: ['MEDIA'],
      prependNumbers: false,
      outputPath: tmp,
      folderAssets: {
        __proto__: ['/tmp/evil.mov'],
        constructor: ['/tmp/evil2.mov'],
        MEDIA: []
      }
    })).resolves.toEqual(expect.objectContaining({ success: true }));
  });

  test('cancel mid-copy with blank rootName leaves no newly created artifacts', async () => {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'organizer-cancel-'));
    const srcDir = fs.mkdtempSync(path.join(os.tmpdir(), 'organizer-cancel-src-'));
    const srcFile = path.join(srcDir, 'big.mov');
    fs.writeFileSync(srcFile, Buffer.alloc(24 * 1024 * 1024, 7));

    const initialEntries = fs.readdirSync(tmp);
    const controller = new AbortController();
    setTimeout(() => controller.abort(), 5);

    const result = await createProjectStructure({
      jobId: `test-${Date.now()}`,
      rootName: '',
      selectedFolders: ['MEDIA'],
      prependNumbers: false,
      outputPath: tmp,
      folderAssets: {
        MEDIA: [srcFile]
      },
      signal: controller.signal
    });

    expect(result.success).toBe(false);
    expect(result.cancelled).toBe(true);
    expect(fs.existsSync(path.join(tmp, 'MEDIA'))).toBe(false);
    expect(fs.readdirSync(tmp)).toEqual(initialEntries);
  });

  test('error during creation rolls back job-created artifacts only', async () => {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'organizer-error-'));

    const preExistingDir = path.join(tmp, 'A');
    fs.mkdirSync(preExistingDir);
    const preExistingFile = path.join(preExistingDir, 'B');
    fs.writeFileSync(preExistingFile, 'block-folder-create');

    const result = await createProjectStructure({
      jobId: `test-${Date.now()}`,
      rootName: '',
      selectedFolders: ['C', 'A/B'],
      prependNumbers: false,
      outputPath: tmp,
      folderAssets: Object.create(null)
    });

    expect(result.success).toBe(false);
    expect(result.cancelled).toBeFalsy();

    expect(fs.existsSync(preExistingDir)).toBe(true);
    expect(fs.existsSync(preExistingFile)).toBe(true);
    expect(fs.existsSync(path.join(tmp, 'C'))).toBe(false);
  });
});
