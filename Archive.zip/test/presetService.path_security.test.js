/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');

describe('presetService path security', () => {
  let tmpRoot;
  let userDataRoot;
  let presetsRoot;
  let presetService;

  beforeEach(() => {
    jest.resetModules();
    tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-preset-service-'));
    userDataRoot = path.join(tmpRoot, 'userdata');
    presetsRoot = path.join(userDataRoot, 'config', 'presets', 'lead-ae');
    fs.mkdirSync(presetsRoot, { recursive: true });

    jest.doMock('../platform/paths', () => ({
      getUserDataRoot: jest.fn(() => userDataRoot)
    }));

    presetService = require('../services/presetService');
  });

  afterEach(() => {
    jest.dontMock('../platform/paths');
    fs.rmSync(tmpRoot, { recursive: true, force: true });
  });

  test('readJson rejects traversal and absolute paths', async () => {
    const outsideFile = path.join(tmpRoot, 'outside.json');
    fs.writeFileSync(outsideFile, JSON.stringify({ nope: true }), 'utf8');

    await expect(presetService.readJson('../outside.json'))
      .rejects.toMatchObject({ code: 'PRESET_PATH_OUTSIDE_ROOT' });

    await expect(presetService.readJson(outsideFile))
      .rejects.toMatchObject({ code: 'PRESET_PATH_OUTSIDE_ROOT' });
  });

  test('deletePreset rejects traversal and absolute paths', async () => {
    const outsideFile = path.join(tmpRoot, 'outside-delete.json');
    fs.writeFileSync(outsideFile, JSON.stringify({ nope: true }), 'utf8');

    await expect(presetService.deletePreset('../outside-delete.json'))
      .rejects.toMatchObject({ code: 'PRESET_PATH_OUTSIDE_ROOT' });

    await expect(presetService.deletePreset(outsideFile))
      .rejects.toMatchObject({ code: 'PRESET_PATH_OUTSIDE_ROOT' });
  });

  test('readJson and deletePreset reject symlink escape', async () => {
    const outsideDir = path.join(tmpRoot, 'outside');
    const linkPath = path.join(presetsRoot, 'escape-link');
    fs.mkdirSync(outsideDir, { recursive: true });

    let symlinkReady = true;
    try {
      fs.symlinkSync(outsideDir, linkPath, 'dir');
    } catch {
      symlinkReady = false;
    }

    if (!symlinkReady) return;

    const escapedFile = path.join(outsideDir, 'evil.json');
    fs.writeFileSync(escapedFile, JSON.stringify({ escaped: true }), 'utf8');

    await expect(presetService.readJson('escape-link/evil.json'))
      .rejects.toMatchObject({ code: 'PRESET_PATH_OUTSIDE_ROOT' });

    await expect(presetService.deletePreset('escape-link/evil.json'))
      .rejects.toMatchObject({ code: 'PRESET_PATH_OUTSIDE_ROOT' });
  });
});
