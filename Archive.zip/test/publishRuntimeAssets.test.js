const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const {
  parseCliArgs,
  resolvePublishContext,
  collectRuntimeAssetUploadFiles,
  buildGhReleaseViewArgs,
  buildGhReleaseCreateArgs,
  buildGhReleaseUploadArgs,
  publishRuntimeAssets
} = require('../scripts/publish-runtime-assets');

function makeTempDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'leadae-publish-runtime-assets-'));
}

function writeJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

test('publish runtime assets resolves release context and upload file list from release manifest', () => {
  const projectRoot = makeTempDir();
  const releaseDir = path.join(projectRoot, 'release', 'runtime-assets');
  fs.mkdirSync(releaseDir, { recursive: true });
  fs.writeFileSync(path.join(releaseDir, 'ggml-base.en.bin'), 'model', 'utf8');
  fs.writeFileSync(path.join(releaseDir, 'runtime.assets.manifest.json'), '{}\n', 'utf8');

  writeJson(path.join(releaseDir, 'runtime.assets.manifest.json'), {
    schemaVersion: 1,
    release: {
      provider: 'github',
      owner: 'DBINNS4',
      repo: 'LeadAEAssist-Releases',
      tag: 'v2.0.0',
      baseUrl: 'https://github.com/DBINNS4/LeadAEAssist-Releases/releases/download/v2.0.0'
    },
    assets: {
      'whisper.model.base.en': {
        type: 'file',
        relativeUrl: 'ggml-base.en.bin',
        downloadUrl: 'https://github.com/DBINNS4/LeadAEAssist-Releases/releases/download/v2.0.0/ggml-base.en.bin'
      }
    }
  });

  const context = resolvePublishContext({ projectRoot });
  assert.equal(context.repoRef, 'DBINNS4/LeadAEAssist-Releases');
  assert.equal(context.tag, 'v2.0.0');

  const files = collectRuntimeAssetUploadFiles(context);
  assert.deepEqual(
    files.map((filePath) => path.basename(filePath)).sort(),
    ['ggml-base.en.bin', 'runtime.assets.manifest.json']
  );

  assert.deepEqual(buildGhReleaseViewArgs(context), ['release', 'view', 'v2.0.0', '--repo', 'DBINNS4/LeadAEAssist-Releases']);
  assert.deepEqual(buildGhReleaseCreateArgs(context), ['release', 'create', 'v2.0.0', '--repo', 'DBINNS4/LeadAEAssist-Releases', '--title', 'v2.0.0', '--notes', '']);
  assert.deepEqual(
    buildGhReleaseUploadArgs(context, files, { clobber: true }),
    ['release', 'upload', 'v2.0.0', ...files, '--repo', 'DBINNS4/LeadAEAssist-Releases', '--clobber']
  );
});

test('publish runtime assets dry-run returns gh command plan without uploading', () => {
  const projectRoot = makeTempDir();
  const releaseDir = path.join(projectRoot, 'release', 'runtime-assets');
  fs.mkdirSync(releaseDir, { recursive: true });
  fs.writeFileSync(path.join(releaseDir, 'ggml-base.en.bin'), 'model', 'utf8');

  writeJson(path.join(releaseDir, 'runtime.assets.manifest.json'), {
    schemaVersion: 1,
    release: {
      provider: 'github',
      owner: 'DBINNS4',
      repo: 'LeadAEAssist-Releases-Sandbox',
      tag: 'v3.1.4',
      baseUrl: 'https://github.com/DBINNS4/LeadAEAssist-Releases-Sandbox/releases/download/v3.1.4'
    },
    assets: {
      'whisper.model.base.en': {
        type: 'file',
        relativeUrl: 'ggml-base.en.bin',
        downloadUrl: 'https://github.com/DBINNS4/LeadAEAssist-Releases-Sandbox/releases/download/v3.1.4/ggml-base.en.bin'
      }
    }
  });

  const result = publishRuntimeAssets({ projectRoot, dryRun: true, clobber: true, createIfMissing: true });
  assert.equal(result.repoRef, 'DBINNS4/LeadAEAssist-Releases-Sandbox');
  assert.equal(result.tag, 'v3.1.4');
  assert.equal(result.files.length, 2);
  assert.deepEqual(result.commands.view, ['release', 'view', 'v3.1.4', '--repo', 'DBINNS4/LeadAEAssist-Releases-Sandbox']);
  assert.deepEqual(result.commands.create, ['release', 'create', 'v3.1.4', '--repo', 'DBINNS4/LeadAEAssist-Releases-Sandbox', '--title', 'v3.1.4', '--notes', '']);
  assert.equal(result.commands.upload.includes('--clobber'), true);
});

test('parseCliArgs handles publish flags and paths', () => {
  const options = parseCliArgs([
    '--dry-run',
    '--clobber',
    '--create-if-missing',
    '--manifest', 'release/runtime-assets/runtime.assets.manifest.json',
    '--owner', 'DBINNS4',
    '--repo', 'LeadAEAssist-Releases',
    '--tag', 'v9.9.9'
  ]);

  assert.equal(options.dryRun, true);
  assert.equal(options.clobber, true);
  assert.equal(options.createIfMissing, true);
  assert.equal(options.owner, 'DBINNS4');
  assert.equal(options.repo, 'LeadAEAssist-Releases');
  assert.equal(options.tag, 'v9.9.9');
  assert.match(options.releaseManifestPath, /runtime\.assets\.manifest\.json$/);
});
