const test = require('node:test');
const assert = require('node:assert/strict');
const Module = require('module');

function buildIpcMain() {
  const handlers = new Map();
  return {
    handlers,
    ipcMain: {
      handle(channel, fn) {
        handlers.set(channel, fn);
      }
    }
  };
}

function createSender(id) {
  const sent = [];
  const destroyedHandlers = new Map();
  return {
    id,
    sent,
    send(channel, payload) {
      sent.push({ channel, payload });
    },
    isDestroyed() {
      return false;
    },
    once(eventName, handler) {
      destroyedHandlers.set(eventName, handler);
    },
    destroy() {
      const handler = destroyedHandlers.get('destroyed');
      if (handler) handler();
    }
  };
}

function flush() {
  return new Promise(resolve => setImmediate(resolve));
}

function makeAbortError(message = 'cancelled') {
  const error = new Error(message);
  error.name = 'AbortError';
  error.code = 'ABORT_ERR';
  return error;
}

function loadAssetHandlers(mocks) {
  const target = require.resolve('../ipc/assets.handlers');
  delete require.cache[target];
  const originalLoad = Module._load;
  Module._load = function patchedLoad(request, parent, isMain) {
    if (Object.prototype.hasOwnProperty.call(mocks, request)) {
      return mocks[request];
    }
    return originalLoad.call(this, request, parent, isMain);
  };

  try {
    return require('../ipc/assets.handlers');
  } finally {
    Module._load = originalLoad;
  }
}

test('assets handlers: shared prefetch emits progress and installed completion', async () => {
  const runtimeAssetRequestService = {
    normalizeAssetRequest(request) {
      return request && typeof request === 'object' ? { ...request } : {};
    },
    resolveRuntimeAssetRequest() {
      return {
        assetId: 'puppeteer.cache.darwin.arm64',
        kind: 'chromium',
        feature: 'chromium',
        platform: 'darwin',
        arch: 'arm64',
        descriptorSummary: { type: 'archive', installDir: 'puppeteer/cache/chrome/darwin-arm64' }
      };
    },
    resolveInstalledRuntimeAssetSnapshot() {
      return {
        assetId: 'puppeteer.cache.darwin.arm64',
        kind: 'chromium',
        feature: 'chromium',
        platform: 'darwin',
        arch: 'arm64',
        descriptor: { type: 'archive', installDir: 'puppeteer/cache/chrome/darwin-arm64' },
        expectedPath: '/tmp/assets/chrome-root',
        path: null,
        installed: false,
        ready: false,
        executablePath: null,
        modelPath: null,
        offline: false
      };
    },
    ensureResolvedRuntimeAsset(_resolved, options) {
      runtimeAssetRequestService._options = options;
      return runtimeAssetRequestService._deferred.promise;
    },
    _deferred: (() => {
      let resolve;
      const promise = new Promise(res => { resolve = res; });
      return { promise, resolve };
    })(),
    _options: null
  };

  const assetHandlers = loadAssetHandlers({
    electron: { app: { isPackaged: true } },
    '../utils/trustedIpcSender': { assertTrustedIpcSender() {} },
    '../services/runtimeAssetRequestService': runtimeAssetRequestService
  });
  assetHandlers.__private.resetForTests();

  const { ipcMain, handlers } = buildIpcMain();
  assetHandlers(ipcMain, {});

  const senderA = createSender(1);
  const senderB = createSender(2);
  const eventA = { sender: senderA, senderFrame: { url: 'app://index.html' } };
  const eventB = { sender: senderB, senderFrame: { url: 'app://index.html' } };

  const first = await handlers.get('assets:prefetch')(eventA, { feature: 'chromium' });
  const second = await handlers.get('assets:prefetch')(eventB, { feature: 'chromium' });

  assert.equal(first.started, true);
  assert.equal(second.joined, true);
  assert.equal(second.requestId, first.requestId);

  runtimeAssetRequestService._options.onProgress({
    phase: 'download',
    status: 'progress',
    progress: 0.25,
    bytesReceived: 25,
    bytesTotal: 100,
    source: 'download'
  });

  assert.equal(senderA.sent.at(-1).channel, 'assets:progress');
  assert.equal(senderA.sent.at(-1).payload.state, 'running');
  assert.equal(senderA.sent.at(-1).payload.progress.progress, 0.25);
  assert.equal(senderB.sent.at(-1).channel, 'assets:progress');
  assert.equal(senderB.sent.at(-1).payload.requestId, first.requestId);

  runtimeAssetRequestService._deferred.resolve({
    ok: true,
    assetId: 'puppeteer.cache.darwin.arm64',
    assetRoot: '/tmp/assets/chrome-root',
    executablePath: '/tmp/assets/chrome-root/chrome',
    source: 'download'
  });
  await flush();

  assert.equal(assetHandlers.__private.getActiveOperationCount(), 0);
  assert.equal(senderA.sent.at(-1).payload.state, 'installed');
  assert.equal(senderA.sent.at(-1).payload.executablePath, '/tmp/assets/chrome-root/chrome');
  assert.equal(senderB.sent.at(-1).payload.state, 'installed');
});

test('assets handlers: cancelling the last subscriber aborts the operation and getStatus reports cancelled', async () => {
  const runtimeAssetRequestService = {
    normalizeAssetRequest(request) {
      return request && typeof request === 'object' ? { ...request } : {};
    },
    resolveRuntimeAssetRequest() {
      return {
        assetId: 'whisper.model.base.en',
        kind: 'whisper',
        feature: 'whisper',
        language: 'en',
        modelFile: 'ggml-base.en.bin',
        descriptorSummary: { type: 'file', installPath: 'whisper/models/ggml-base.en.bin' }
      };
    },
    resolveInstalledRuntimeAssetSnapshot() {
      return {
        assetId: 'whisper.model.base.en',
        kind: 'whisper',
        feature: 'whisper',
        language: 'en',
        modelFile: 'ggml-base.en.bin',
        descriptor: { type: 'file', installPath: 'whisper/models/ggml-base.en.bin' },
        expectedPath: '/tmp/assets/whisper/models/ggml-base.en.bin',
        path: null,
        installed: false,
        ready: false,
        executablePath: null,
        modelPath: null,
        offline: false
      };
    },
    ensureResolvedRuntimeAsset(_resolved, options) {
      runtimeAssetRequestService._signal = options.signal;
      return new Promise((resolve, reject) => {
        if (options.signal.aborted) return reject(makeAbortError());
        options.signal.addEventListener('abort', () => reject(makeAbortError()), { once: true });
      });
    },
    _signal: null
  };

  const assetHandlers = loadAssetHandlers({
    electron: { app: { isPackaged: true } },
    '../utils/trustedIpcSender': { assertTrustedIpcSender() {} },
    '../services/runtimeAssetRequestService': runtimeAssetRequestService
  });
  assetHandlers.__private.resetForTests();

  const { ipcMain, handlers } = buildIpcMain();
  assetHandlers(ipcMain, {});

  const sender = createSender(3);
  const event = { sender, senderFrame: { url: 'app://index.html' } };
  const started = await handlers.get('assets:prefetch')(event, { feature: 'whisper', language: 'en' });
  const cancelled = await handlers.get('assets:cancel')(event, { requestId: started.requestId });
  await flush();
  const status = await handlers.get('assets:getStatus')(event, { feature: 'whisper', language: 'en' });

  assert.equal(cancelled.abortRequested, true);
  assert.equal(runtimeAssetRequestService._signal.aborted, true);
  assert.equal(status.state, 'cancelled');
  assert.equal(status.installed, false);
});
