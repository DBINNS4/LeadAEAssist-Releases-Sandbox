/** @jest-environment node */

jest.mock('electron', () => ({
  app: { isPackaged: true }
}));

jest.mock('../utils/trustedIpcSender', () => ({
  assertTrustedIpcSender: jest.fn()
}));

jest.mock('../services/runtimeAssetRequestService', () => ({
  normalizeAssetRequest: jest.fn((request) => {
    if (typeof request === 'string') return { assetId: request };
    return request && typeof request === 'object' ? { ...request } : {};
  }),
  resolveRuntimeAssetRequest: jest.fn(),
  resolveInstalledRuntimeAssetSnapshot: jest.fn(),
  ensureResolvedRuntimeAsset: jest.fn()
}));

const registerAssetHandlers = require('../ipc/assets.handlers');
const assetHandlersModule = require('../ipc/assets.handlers');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const runtimeAssetRequestService = require('../services/runtimeAssetRequestService');

function buildIpcMain() {
  const handlers = new Map();
  return {
    handlers,
    ipcMain: {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn))
    }
  };
}

function createSender(id) {
  const destroyedHandlers = {};
  return {
    id,
    send: jest.fn(),
    isDestroyed: jest.fn(() => false),
    once: jest.fn((eventName, handler) => {
      destroyedHandlers[eventName] = handler;
    }),
    __destroyedHandlers: destroyedHandlers
  };
}

function flush() {
  return new Promise(resolve => setImmediate(resolve));
}

function makeAbortError(message = 'cancelled') {
  const error = new Error(message);
  error.name = 'AbortError';
  error.code = 'ABORT_ERR';
  return error;
}

describe('ipc asset handlers', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    assetHandlersModule.__private.resetForTests();
    assertTrustedIpcSender.mockImplementation(() => {});
  });

  test('getStatus returns idle missing snapshot for resolved whisper asset', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerAssetHandlers(ipcMain, {});

    runtimeAssetRequestService.resolveRuntimeAssetRequest.mockReturnValue({
      assetId: 'whisper.model.base.en',
      kind: 'whisper',
      feature: 'whisper',
      language: 'en',
      modelFile: 'ggml-base.en.bin',
      descriptorSummary: { type: 'file', installPath: 'whisper/models/ggml-base.en.bin' }
    });
    runtimeAssetRequestService.resolveInstalledRuntimeAssetSnapshot.mockReturnValue({
      assetId: 'whisper.model.base.en',
      kind: 'whisper',
      feature: 'whisper',
      language: 'en',
      modelFile: 'ggml-base.en.bin',
      descriptor: { type: 'file', installPath: 'whisper/models/ggml-base.en.bin' },
      expectedPath: '/tmp/userData/assets/whisper/models/ggml-base.en.bin',
      path: null,
      installed: false,
      ready: false,
      executablePath: null,
      modelPath: null,
      offline: false
    });

    const sender = createSender(1);
    const event = { sender, senderFrame: { url: 'app://index.html' } };
    const result = await handlers.get('assets:getStatus')(event, { feature: 'whisper', language: 'en' });

    expect(assertTrustedIpcSender).toHaveBeenCalledWith(event, 'assets:getStatus');
    expect(result).toEqual(expect.objectContaining({
      ok: true,
      assetId: 'whisper.model.base.en',
      feature: 'whisper',
      state: 'missing',
      active: false,
      installed: false,
      expectedPath: '/tmp/userData/assets/whisper/models/ggml-base.en.bin'
    }));
  });

  test('prefetch starts one shared operation, replays progress to joined callers, and emits installed completion', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerAssetHandlers(ipcMain, {});

    const resolved = {
      assetId: 'puppeteer.cache.darwin.arm64',
      kind: 'chromium',
      feature: 'chromium',
      platform: 'darwin',
      arch: 'arm64',
      descriptorSummary: { type: 'archive', installDir: 'puppeteer/cache/chrome/darwin-arm64', entrypoint: 'chrome/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing' }
    };
    let installedSnapshot = {
      assetId: 'puppeteer.cache.darwin.arm64',
      kind: 'chromium',
      feature: 'chromium',
      platform: 'darwin',
      arch: 'arm64',
      descriptor: resolved.descriptorSummary,
      expectedPath: '/tmp/userData/assets/puppeteer/cache/chrome/darwin-arm64',
      path: null,
      installed: false,
      ready: false,
      executablePath: null,
      modelPath: null,
      offline: false
    };
    runtimeAssetRequestService.resolveRuntimeAssetRequest.mockReturnValue(resolved);
    runtimeAssetRequestService.resolveInstalledRuntimeAssetSnapshot.mockImplementation(() => installedSnapshot);

    let ensureOptions = null;
    let resolveEnsure;
    const ensurePromise = new Promise((resolve) => { resolveEnsure = resolve; });
    runtimeAssetRequestService.ensureResolvedRuntimeAsset.mockImplementation((_resolved, options) => {
      ensureOptions = options;
      return ensurePromise;
    });

    const sender1 = createSender(10);
    const sender2 = createSender(11);
    const event1 = { sender: sender1, senderFrame: { url: 'app://index.html' } };
    const event2 = { sender: sender2, senderFrame: { url: 'app://index.html' } };

    const first = await handlers.get('assets:prefetch')(event1, { feature: 'chromium' });
    expect(first.started).toBe(true);
    expect(first.joined).toBe(false);
    expect(first.requestId).toMatch(/^asset-1-/);
    expect(runtimeAssetRequestService.ensureResolvedRuntimeAsset).toHaveBeenCalledTimes(1);

    const second = await handlers.get('assets:prefetch')(event2, { feature: 'chromium' });
    expect(second.started).toBe(false);
    expect(second.joined).toBe(true);
    expect(second.requestId).toBe(first.requestId);
    expect(runtimeAssetRequestService.ensureResolvedRuntimeAsset).toHaveBeenCalledTimes(1);

    ensureOptions.onProgress({
      phase: 'download',
      status: 'progress',
      progress: 0.5,
      bytesReceived: 50,
      bytesTotal: 100,
      source: 'download'
    });

    expect(sender1.send).toHaveBeenCalledWith('assets:progress', expect.objectContaining({
      requestId: first.requestId,
      assetId: 'puppeteer.cache.darwin.arm64',
      state: 'running',
      progress: expect.objectContaining({ phase: 'download', progress: 0.5, bytesReceived: 50, bytesTotal: 100 })
    }));
    expect(sender2.send).toHaveBeenCalledWith('assets:progress', expect.objectContaining({
      requestId: first.requestId,
      assetId: 'puppeteer.cache.darwin.arm64',
      state: 'running'
    }));

    installedSnapshot = {
      ...installedSnapshot,
      path: '/tmp/userData/assets/puppeteer/cache/chrome/darwin-arm64',
      installed: true,
      ready: true,
      executablePath: '/tmp/userData/assets/puppeteer/cache/chrome/darwin-arm64/chrome/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
    };

    resolveEnsure({
      ok: true,
      assetId: 'puppeteer.cache.darwin.arm64',
      assetRoot: installedSnapshot.path,
      executablePath: installedSnapshot.executablePath,
      source: 'download'
    });
    await flush();

    expect(assetHandlersModule.__private.getActiveOperationCount()).toBe(0);
    expect(sender1.send).toHaveBeenLastCalledWith('assets:progress', expect.objectContaining({
      requestId: first.requestId,
      state: 'installed',
      active: false,
      installed: true,
      path: installedSnapshot.path,
      executablePath: installedSnapshot.executablePath
    }));
    expect(sender2.send).toHaveBeenLastCalledWith('assets:progress', expect.objectContaining({
      requestId: first.requestId,
      state: 'installed',
      installed: true
    }));
  });

  test('cancel detaches one caller without aborting shared work, then aborts when the last caller cancels', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerAssetHandlers(ipcMain, {});

    const resolved = {
      assetId: 'puppeteer.cache.darwin.arm64',
      kind: 'chromium',
      feature: 'chromium',
      platform: 'darwin',
      arch: 'arm64',
      descriptorSummary: { type: 'archive', installDir: 'puppeteer/cache/chrome/darwin-arm64' }
    };
    runtimeAssetRequestService.resolveRuntimeAssetRequest.mockReturnValue(resolved);
    runtimeAssetRequestService.resolveInstalledRuntimeAssetSnapshot.mockReturnValue({
      assetId: 'puppeteer.cache.darwin.arm64',
      kind: 'chromium',
      feature: 'chromium',
      platform: 'darwin',
      arch: 'arm64',
      descriptor: resolved.descriptorSummary,
      expectedPath: '/tmp/userData/assets/puppeteer/cache/chrome/darwin-arm64',
      path: null,
      installed: false,
      ready: false,
      executablePath: null,
      modelPath: null,
      offline: false
    });

    let ensureOptions = null;
    runtimeAssetRequestService.ensureResolvedRuntimeAsset.mockImplementation((_resolved, options) => {
      ensureOptions = options;
      return new Promise((resolve, reject) => {
        if (options.signal.aborted) return reject(makeAbortError());
        options.signal.addEventListener('abort', () => reject(makeAbortError()), { once: true });
      });
    });

    const sender1 = createSender(20);
    const sender2 = createSender(21);
    const event1 = { sender: sender1, senderFrame: { url: 'app://index.html' } };
    const event2 = { sender: sender2, senderFrame: { url: 'app://index.html' } };

    const started = await handlers.get('assets:prefetch')(event1, { feature: 'chromium' });
    await handlers.get('assets:prefetch')(event2, { feature: 'chromium' });

    const cancelSecond = await handlers.get('assets:cancel')(event2, { requestId: started.requestId });
    expect(cancelSecond.detached).toBe(true);
    expect(cancelSecond.abortRequested).toBe(false);
    expect(ensureOptions.signal.aborted).toBe(false);

    const cancelFirst = await handlers.get('assets:cancel')(event1, { requestId: started.requestId });
    expect(cancelFirst.detached).toBe(true);
    expect(cancelFirst.abortRequested).toBe(true);
    await flush();

    const status = await handlers.get('assets:getStatus')(event1, { feature: 'chromium' });
    expect(status).toEqual(expect.objectContaining({
      ok: true,
      assetId: 'puppeteer.cache.darwin.arm64',
      state: 'cancelled',
      active: false,
      installed: false
    }));
  });

  test('returns structured failure when trusted sender gate blocks the request', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerAssetHandlers(ipcMain, {});
    assertTrustedIpcSender.mockImplementation(() => {
      throw new Error('Blocked assets:prefetch');
    });

    const sender = createSender(30);
    const event = { sender, senderFrame: { url: 'https://evil.example' } };
    const result = await handlers.get('assets:prefetch')(event, { feature: 'chromium' });

    expect(result).toEqual({
      ok: false,
      code: 'IPC_UNTRUSTED',
      error: 'Blocked assets:prefetch'
    });
  });
});
