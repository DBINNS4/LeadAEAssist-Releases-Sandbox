const fs = require('fs');
const path = require('path');

const flushPromises = () => new Promise(resolve => setImmediate(resolve));

function createMockI18next() {
  const state = {
    resources: {},
    language: 'en',
  };

  return {
    state,
    use: jest.fn().mockReturnThis(),
    init: jest.fn(config => {
      state.resources = config.resources || {};
      return Promise.resolve();
    }),
    on: jest.fn(),
    t: jest.fn(key => {
      const languagePack = state.resources[state.language] || {};
      const translation = languagePack.translation || {};
      return translation[key] || key;
    }),
    get language() {
      return state.language;
    },
    set language(nextLanguage) {
      state.language = nextLanguage;
    },
  };
}

describe('i18n bootstrap', () => {
  beforeEach(() => {
    jest.resetModules();
    document.body.innerHTML = '<button data-i18n="hello"></button>';
    document.documentElement.removeAttribute('lang');
    window.translatePage = undefined;
    window.i18n = undefined;
  });

  test('continues bootstrapping when one locale file is missing', async () => {
    const localeData = {
      en: { hello: 'Hello fallback' },
      es: { hello: 'Hola' },
      de: { hello: 'Hallo' },
      ja: { hello: 'こんにちは' },
      zh: { hello: '你好' },
    };

    global.fetch = jest.fn(url => {
      const lang = url.match(/\/([a-z]{2})\.json$/)?.[1];
      if (lang === 'fr') {
        return Promise.reject(new Error('Missing locale: fr'));
      }
      return Promise.resolve({
        json: () => Promise.resolve(localeData[lang] || {}),
      });
    });

    const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});
    const i18next = createMockI18next();

    window.i18next = i18next;
    window.i18nextBrowserLanguageDetector = { name: 'detector' };

    require('../i18n.js');
    await flushPromises();
    await flushPromises();

    expect(window.i18n).toBe(i18next);
    expect(typeof window.translatePage).toBe('function');
    expect(i18next.init).toHaveBeenCalledTimes(1);

    const initConfig = i18next.init.mock.calls[0][0];
    expect(initConfig.resources.en.translation.hello).toBe('Hello fallback');
    expect(initConfig.resources.fr.translation).toEqual({});

    expect(document.querySelector('[data-i18n="hello"]').textContent).toBe('Hello fallback');
    expect(document.documentElement.getAttribute('lang')).toBe('en');

    expect(warnSpy).toHaveBeenCalledWith(
      expect.stringContaining('Failed to load locale "fr"'),
      expect.any(Error)
    );

    warnSpy.mockRestore();
  });

  test('includes all transcribe renderer keys in en locale', () => {
    const transcribeRendererPath = path.join(__dirname, '..', 'renderer.transcribe.js');
    const enLocalePath = path.join(__dirname, '..', 'locales', 'en.json');

    const transcribeRendererSource = fs.readFileSync(transcribeRendererPath, 'utf8');
    const enLocale = JSON.parse(fs.readFileSync(enLocalePath, 'utf8'));
    const trKeyPattern = /\btr\(\s*['"]([^'"]+)['"]/g;
    const transcribeKeys = new Set();
    let match = null;

    while ((match = trKeyPattern.exec(transcribeRendererSource)) !== null) {
      transcribeKeys.add(match[1]);
    }

    const missingKeys = [...transcribeKeys].filter(key => !(key in enLocale));
    expect(missingKeys).toEqual([]);
  });
});
