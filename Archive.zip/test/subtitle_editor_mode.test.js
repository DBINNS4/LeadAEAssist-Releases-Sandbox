const {
  resolveSubtitleEditorMode,
  isWebCaptionDoc,
  isSccDoc,
  isMccDoc,
  isSrtDoc,
  isVttDoc,
} = require('../utils/subtitleEditorMode');

describe('utils/subtitleEditorMode', () => {
  test('routes SRT docs to web mode (by kind)', () => {
    expect(resolveSubtitleEditorMode({ kind: 'srt' })).toBe('web');
    expect(isSrtDoc({ kind: 'srt' })).toBe(true);
    expect(isWebCaptionDoc({ kind: 'srt' })).toBe(true);
  });

  test('routes SRT docs to web mode (by extension)', () => {
    expect(resolveSubtitleEditorMode({ sourcePath: '/x/FOO.SRT' })).toBe('web');
    expect(isSrtDoc({ sourcePath: '/x/FOO.SRT' })).toBe(true);
    expect(isWebCaptionDoc({ sourcePath: '/x/FOO.SRT' })).toBe(true);
  });

  test('routes VTT docs to web mode (by kind and extension)', () => {
    expect(resolveSubtitleEditorMode({ kind: 'webvtt' })).toBe('web');
    expect(isVttDoc({ kind: 'webvtt' })).toBe(true);

    expect(resolveSubtitleEditorMode({ sourcePath: '/x/foo.vtt' })).toBe('web');
    expect(isVttDoc({ sourcePath: '/x/foo.vtt' })).toBe(true);
  });

  test('routes SCC docs to broadcast mode (by kind and extension)', () => {
    expect(resolveSubtitleEditorMode({ kind: 'scc' })).toBe('broadcast');
    expect(isSccDoc({ kind: 'scc' })).toBe(true);
    expect(isWebCaptionDoc({ kind: 'scc' })).toBe(false);

    expect(resolveSubtitleEditorMode({ sourcePath: '/x/foo.SCC' })).toBe('broadcast');
    expect(isSccDoc({ sourcePath: '/x/foo.SCC' })).toBe(true);
  });

  test('routes MCC docs to broadcast mode (by kind and extension)', () => {
    expect(resolveSubtitleEditorMode({ kind: 'mcc' })).toBe('broadcast');
    expect(isMccDoc({ kind: 'mcc' })).toBe(true);
    expect(isWebCaptionDoc({ kind: 'mcc' })).toBe(false);

    expect(resolveSubtitleEditorMode({ displayName: 'foo.mcc' })).toBe('broadcast');
    expect(isMccDoc({ displayName: 'foo.mcc' })).toBe(true);
  });

  test('prefers SRT/VTT routing when doc kind is stale but the filename is web-caption', () => {
    // This is a real-world footgun: session state can carry stale doc.kind/doc.format
    // when switching documents inside the same editor window.
    const staleSccButActuallySrt = { kind: 'scc', sourcePath: '/x/stale.srt' };
    expect(isSccDoc(staleSccButActuallySrt)).toBe(true);
    expect(isSrtDoc(staleSccButActuallySrt)).toBe(true);
    expect(isWebCaptionDoc(staleSccButActuallySrt)).toBe(true);
    expect(resolveSubtitleEditorMode(staleSccButActuallySrt)).toBe('web');
  });

  test('defaults unknown docs to broadcast mode (conservative fallback)', () => {
    expect(resolveSubtitleEditorMode({})).toBe('broadcast');
    expect(resolveSubtitleEditorMode({ kind: 'unknown', sourcePath: '/x/file.unknown' })).toBe('broadcast');
  });
});
