'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { resolveVttOptions, generateVTT } = require('../ai/vttWriter');

test('Phase 4 VTT profiles: strict profile supplies QC defaults (maxCps + overlaps)', () => {
  const opts = resolveVttOptions({
    formats: { vtt: { profile: 'strict' } }
  });

  assert.equal(opts.profileKey, 'strict');
  assert.equal(opts.maxCps, 17);
  assert.equal(opts.preventOverlaps, true);
  // strict profile should keep style metadata off by default
  assert.equal(opts.includeStyleMetadata, false);
});

test('Phase 4 VTT profiles: styled profile enables WebVTT style metadata by default', () => {
  const vtt = generateVTT(
    [{ start: 0, end: 2, text: 'Hello world' }],
    { formats: { vtt: { profile: 'styled' } } }
  );

  assert.equal(vtt.startsWith('WEBVTT'), true);
  assert.equal(vtt.includes('\nSTYLE\n'), true);
});

test('Phase 4 VTT profiles: web profile relaxes max lines and max chars', () => {
  const opts = resolveVttOptions({
    formats: { vtt: { profile: 'web' } }
  });

  assert.equal(opts.profileKey, 'web');
  assert.equal(opts.maxCharsPerLine, 52);
  assert.equal(opts.maxLinesPerBlock, 3);
});
