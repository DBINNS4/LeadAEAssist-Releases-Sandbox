/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');
const { fsp } = require('../utils/nativeFs');

jest.mock('electron', () => ({}));

describe('validateIngestConfig — writability checks', () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  test('blocks existing destination directories that are not writable', async () => {
    const { validateIngestConfig } = require('../modules/ingest');

    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-writable-'));
    try {
      const sourceFolder = path.join(tmpRoot, 'source');
      const destFolder = path.join(tmpRoot, 'dest');
      fs.mkdirSync(sourceFolder, { recursive: true });
      fs.mkdirSync(destFolder, { recursive: true });

      jest.spyOn(fsp, 'access').mockImplementation(async (targetPath, mode) => {
        if (targetPath === destFolder && mode === fs.constants.W_OK) {
          const error = new Error('EACCES: permission denied');
          error.code = 'EACCES';
          throw error;
        }
      });

      const errors = await validateIngestConfig({
        source: sourceFolder,
        destination: destFolder,
      });

      expect(errors.join('\n')).toContain('Destination folder is not writable');
    } finally {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });

  test('blocks existing backup directories that are not writable when dual copy is enabled', async () => {
    const { validateIngestConfig } = require('../modules/ingest');

    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-writable-'));
    try {
      const sourceFolder = path.join(tmpRoot, 'source');
      const destFolder = path.join(tmpRoot, 'dest');
      const backupFolder = path.join(tmpRoot, 'backup');
      fs.mkdirSync(sourceFolder, { recursive: true });
      fs.mkdirSync(destFolder, { recursive: true });
      fs.mkdirSync(backupFolder, { recursive: true });

      jest.spyOn(fsp, 'access').mockImplementation(async (targetPath, mode) => {
        if (targetPath === backupFolder && mode === fs.constants.W_OK) {
          const error = new Error('EACCES: permission denied');
          error.code = 'EACCES';
          throw error;
        }
      });

      const errors = await validateIngestConfig({
        source: sourceFolder,
        destination: destFolder,
        dualCopy: true,
        backupPath: backupFolder,
      });

      expect(errors.join('\n')).toContain('Backup folder is not writable');
    } finally {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });
});
