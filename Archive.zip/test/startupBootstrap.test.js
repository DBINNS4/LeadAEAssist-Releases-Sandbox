const { loadStartupDependencies } = require('../utils/startupBootstrap');

describe('startup bootstrap dependency loading', () => {
  function makeRequire({ failIngest = false, failGpu = false } = {}) {
    return (name) => {
      if (name === './modules/fileUtils') {
        return { waitForStableFile: jest.fn(), getAllFilesRecursively: jest.fn() };
      }
      if (name === './modules/ingest') {
        if (failIngest) throw new Error('ingest exploded');
        return { runIngest: jest.fn(), cancelIngest: jest.fn(), validateIngestConfig: jest.fn() };
      }
      if (name === './modules/transcode') {
        return { runTranscode: jest.fn(), cancelTranscode: jest.fn() };
      }
      if (name === './modules/transcribe') {
        return { runTranscribe: jest.fn(), cancelTranscribe: jest.fn() };
      }
      if (name === './modules/logUtils') {
        return { archivePanelSessionLog: jest.fn() };
      }
      if (name === './utils/gpuEncoder') {
        if (failGpu) throw new Error('gpu optional fail');
        return { detectBestGPUEncoder: jest.fn() };
      }
      if (name === 'chokidar') {
        return { watch: jest.fn() };
      }
      if (name === './modules/adobe-utilities') {
        return {
          runAdobeUtilities: jest.fn(),
          cancelAdobeUtilities: jest.fn(),
          validateAdobeConfig: jest.fn()
        };
      }
      throw new Error(`Unexpected require: ${name}`);
    };
  }

  const importFn = async () => ({ default: class PQueueMock {} });

  it('fails fast health when a critical dependency fails', async () => {
    const { health } = await loadStartupDependencies({
      requireFn: makeRequire({ failIngest: true }),
      importFn,
      cloneCore: { cancelClone: jest.fn() }
    });

    expect(health.ok).toBe(false);
    expect(health.ingestReady).toBe(false);
    expect(health.criticalFailures.some((entry) => entry.key === 'ingest')).toBe(true);
    expect(health.transcodeReady).toBe(true);
    expect(health.queueReady).toBe(true);
  });

  it('enters degraded mode when an optional dependency fails', async () => {
    const { health } = await loadStartupDependencies({
      requireFn: makeRequire({ failGpu: true }),
      importFn,
      cloneCore: { cancelClone: jest.fn() }
    });

    expect(health.ok).toBe(true);
    expect(health.optionalFailures.some((entry) => entry.key === 'gpuEncoder')).toBe(true);
    expect(health.ingestReady).toBe(true);
    expect(health.transcodeReady).toBe(true);
    expect(health.transcribeReady).toBe(true);
  });
});
