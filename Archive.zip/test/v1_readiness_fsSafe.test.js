/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');

const { renameReplaceSync, atomicWriteJson, uniqueTempPath } = require('../utils/fsSafe');

describe('Phase 2 filesystem hardening (fsSafe)', () => {
  test('renameReplaceSync replaces existing destination', () => {
    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-fsSafe-'));
    try {
      const src = path.join(tmpRoot, 'src.txt');
      const dest = path.join(tmpRoot, 'dest.txt');
      fs.writeFileSync(src, 'new');
      fs.writeFileSync(dest, 'old');

      renameReplaceSync(src, dest);

      expect(fs.existsSync(src)).toBe(false);
      expect(fs.readFileSync(dest, 'utf8')).toBe('new');
    } finally {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });

  test('atomicWriteJson writes and overwrites safely without leaving temp files', async () => {
    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-atomicJson-'));
    try {
      const filePath = path.join(tmpRoot, 'state.json');

      await atomicWriteJson(filePath, { a: 1 });
      const first = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      expect(first).toEqual({ a: 1 });

      await atomicWriteJson(filePath, { a: 2, b: 'x' });
      const second = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      expect(second).toEqual({ a: 2, b: 'x' });

      // Best-effort: ensure we didn't leave obvious temp siblings behind.
      const siblings = fs.readdirSync(tmpRoot);
      const tmpSiblings = siblings.filter(n => n.includes('state.json') && n !== 'state.json');
      expect(tmpSiblings.length).toBe(0);
    } finally {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });

  test('uniqueTempPath generates distinct paths', () => {
    const base = path.join(os.tmpdir(), 'lead-ae-temp-base.txt');
    const a = uniqueTempPath(base, '.tmp');
    const b = uniqueTempPath(base, '.tmp');
    expect(a).not.toEqual(b);
  });
});

describe('state persistence hardening', () => {
  let tmpRoot;

  beforeEach(() => {
    jest.resetModules();
    tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-state-'));

    jest.doMock('../utils/appPaths', () => ({
      ensureUserDataSubdir: jest.fn((...segments) => {
        const dir = path.join(tmpRoot, ...segments);
        fs.mkdirSync(dir, { recursive: true });
        return dir;
      })
    }));
  });

  afterEach(() => {
    fs.rmSync(tmpRoot, { recursive: true, force: true });
  });

  test('writeState uses atomic persistence and leaves no temp files', () => {
    const { writeState } = require('../utils/state');
    const configDir = path.join(tmpRoot, 'config');
    const statePath = path.join(configDir, 'state.json');

    expect(writeState({ ui: { theme: 'dark' }, version: 2 })).toEqual({ ok: true });

    expect(JSON.parse(fs.readFileSync(statePath, 'utf8'))).toEqual({ ui: { theme: 'dark' }, version: 2 });
    expect(JSON.parse(fs.readFileSync(`${statePath}.bak`, 'utf8'))).toEqual({ ui: { theme: 'dark' }, version: 2 });

    const leftovers = fs.readdirSync(configDir).filter(name => name.includes('.tmp'));
    expect(leftovers).toEqual([]);
  });

  test('writeState exposes ENOTDIR failures when config path is malformed', () => {
    const blockingPath = path.join(tmpRoot, 'config');
    fs.writeFileSync(blockingPath, 'not-a-directory', 'utf8');

    jest.resetModules();
    jest.doMock('../utils/appPaths', () => ({
      ensureUserDataSubdir: jest.fn((...segments) => path.join(tmpRoot, ...segments))
    }));

    const { writeState } = require('../utils/state');
    const res = writeState({ willFail: true });

    expect(res.ok).toBe(false);
    expect(res.error).toBeInstanceOf(Error);
    expect(res.error.code).toBe('ENOTDIR');
  });

  test('writeState exposes permission-denied failures from disk writes', () => {
    const { writeState } = require('../utils/state');

    const originalWriteFileSync = fs.writeFileSync;
    const permissionErr = Object.assign(new Error('permission denied'), { code: 'EACCES' });
    const spy = jest.spyOn(fs, 'writeFileSync').mockImplementation((...args) => {
      const target = String(args[0] || '');
      if (target.includes('state.json')) throw permissionErr;
      return originalWriteFileSync.apply(fs, args);
    });

    try {
      const res = writeState({ blocked: true });
      expect(res.ok).toBe(false);
      expect(res.error).toBe(permissionErr);
      expect(res.error.code).toBe('EACCES');
    } finally {
      spy.mockRestore();
    }
  });

  test('readState falls back to backup when primary JSON is corrupted', () => {
    const { writeState, readState } = require('../utils/state');
    const statePath = path.join(tmpRoot, 'config', 'state.json');

    expect(writeState({ ok: true, nested: { v: 1 } })).toEqual({ ok: true });
    fs.writeFileSync(statePath, '{"ok":', 'utf8');

    expect(readState()).toEqual({ ok: true, nested: { v: 1 } });
    expect(JSON.parse(fs.readFileSync(statePath, 'utf8'))).toEqual({ ok: true, nested: { v: 1 } });
  });
});

describe('fsync durability hardening (fsSafe)', () => {
  afterEach(() => {
    jest.resetModules();
    jest.restoreAllMocks();
    jest.dontMock('../utils/nativeFs');
  });

  test('atomicWriteFile performs temp write sync, rename, then directory sync in order', async () => {
    const calls = [];
    const tmpHandle = {
      writeFile: jest.fn(async () => calls.push('tmp.writeFile')),
      datasync: jest.fn(async () => calls.push('tmp.datasync')),
      close: jest.fn(async () => calls.push('tmp.close'))
    };
    const dirHandle = {
      sync: jest.fn(async () => calls.push('dir.sync')),
      close: jest.fn(async () => calls.push('dir.close'))
    };

    const fspMock = {
      mkdir: jest.fn(async () => calls.push('mkdir')),
      open: jest.fn(async (targetPath, flags) => {
        if (flags === 'w') {
          calls.push('open.tmp');
          return tmpHandle;
        }
        calls.push('open.dir');
        return dirHandle;
      }),
      rename: jest.fn(async () => calls.push('rename')),
      unlink: jest.fn(async () => calls.push('unlink')),
      chmod: jest.fn(async () => calls.push('chmod'))
    };

    await jest.isolateModulesAsync(async () => {
      jest.doMock('../utils/nativeFs', () => ({
        fs: require('fs'),
        fsp: fspMock
      }));

      const { atomicWriteFile } = require('../utils/fsSafe');
      await atomicWriteFile('/tmp/lead-ae/durable.json', '{"a":1}');
    });

    expect(calls).toEqual([
      'mkdir',
      'open.tmp',
      'tmp.writeFile',
      'tmp.datasync',
      'tmp.close',
      'rename',
      'open.dir',
      'dir.sync',
      'dir.close',
      'chmod'
    ]);
    expect(fspMock.unlink).not.toHaveBeenCalled();
  });

  test('atomicWriteFile falls back to handle.sync when datasync is unavailable', async () => {
    const calls = [];
    const tmpHandle = {
      writeFile: jest.fn(async () => calls.push('tmp.writeFile')),
      sync: jest.fn(async () => calls.push('tmp.sync')),
      close: jest.fn(async () => calls.push('tmp.close'))
    };

    const fspMock = {
      mkdir: jest.fn(async () => {}),
      open: jest.fn(async (_targetPath, flags) => {
        if (flags === 'w') return tmpHandle;
        return {
          sync: jest.fn(async () => calls.push('dir.sync')),
          close: jest.fn(async () => calls.push('dir.close'))
        };
      }),
      rename: jest.fn(async () => calls.push('rename')),
      unlink: jest.fn(async () => {}),
      chmod: jest.fn(async () => {})
    };

    await jest.isolateModulesAsync(async () => {
      jest.doMock('../utils/nativeFs', () => ({
        fs: require('fs'),
        fsp: fspMock
      }));

      const { atomicWriteFile } = require('../utils/fsSafe');
      await atomicWriteFile('/tmp/lead-ae/datasync-fallback.json', 'ok');
    });

    expect(calls).toEqual(['tmp.writeFile', 'tmp.sync', 'tmp.close', 'rename', 'dir.sync', 'dir.close']);
  });

  test('atomicWriteFile ignores unsupported directory sync errors (Windows/best-effort)', async () => {
    const calls = [];
    const fspMock = {
      mkdir: jest.fn(async () => {}),
      open: jest.fn(async (_targetPath, flags) => {
        if (flags === 'w') {
          return {
            writeFile: jest.fn(async () => {}),
            datasync: jest.fn(async () => {}),
            close: jest.fn(async () => calls.push('tmp.close'))
          };
        }
        const err = Object.assign(new Error('dir fsync unsupported'), { code: 'EINVAL' });
        throw err;
      }),
      rename: jest.fn(async () => calls.push('rename')),
      unlink: jest.fn(async () => {}),
      chmod: jest.fn(async () => calls.push('chmod'))
    };

    await jest.isolateModulesAsync(async () => {
      jest.doMock('../utils/nativeFs', () => ({
        fs: require('fs'),
        fsp: fspMock
      }));

      const { atomicWriteFile } = require('../utils/fsSafe');
      await expect(atomicWriteFile('/tmp/lead-ae/dir-fsync-best-effort.json', 'ok')).resolves.toBeUndefined();
    });
    expect(calls).toEqual(['tmp.close', 'rename', 'chmod']);
  });

  test('atomicWriteFileSync uses fdatasync/fsync ordering and best-effort directory sync', () => {
    const realFs = require('fs');
    const calls = [];
    const fsMock = {
      ...realFs,
      mkdirSync: jest.fn(() => calls.push('mkdirSync')),
      openSync: jest.fn((_targetPath, flags) => {
        if (flags === 'w') {
          calls.push('openSync.tmp');
          return 11;
        }
        calls.push('openSync.dir');
        return 22;
      }),
      writeFileSync: jest.fn(() => calls.push('writeFileSync.tmp')),
      fdatasyncSync: jest.fn(() => calls.push('fdatasyncSync.tmp')),
      fsyncSync: jest.fn(fd => {
        if (fd === 22) {
          calls.push('fsyncSync.dir');
          const err = Object.assign(new Error('unsupported'), { code: 'EINVAL' });
          throw err;
        }
        calls.push('fsyncSync.tmp');
      }),
      closeSync: jest.fn(fd => calls.push(fd === 11 ? 'closeSync.tmp' : 'closeSync.dir')),
      renameSync: jest.fn(() => calls.push('renameSync')),
      chmodSync: jest.fn(() => calls.push('chmodSync')),
      unlinkSync: jest.fn(() => calls.push('unlinkSync'))
    };

    jest.isolateModules(() => {
      jest.doMock('../utils/nativeFs', () => ({
        fs: fsMock,
        fsp: realFs.promises
      }));

      const { atomicWriteFileSync } = require('../utils/fsSafe');
      atomicWriteFileSync('/tmp/lead-ae/sync-durable.json', 'ok');
    });

    expect(calls).toEqual([
      'mkdirSync',
      'openSync.tmp',
      'writeFileSync.tmp',
      'fdatasyncSync.tmp',
      'closeSync.tmp',
      'renameSync',
      'openSync.dir',
      'fsyncSync.dir',
      'closeSync.dir',
      'chmodSync'
    ]);
    expect(fsMock.unlinkSync).not.toHaveBeenCalled();
  });
});
