'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

test('External validation pack: SCC DF uses HH:MM:SS;FF (not HH;MM;SS;FF)', () => {
  const repoRoot = path.resolve(__dirname, '..');
  const outRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-external-pack-'));
  const script = path.join(repoRoot, 'tools', 'validation', 'generateExternalValidationPack.js');

  try {
    execFileSync(process.execPath, [script, outRoot], {
      cwd: repoRoot,
      stdio: 'pipe'
    });

    const manifestPath = path.join(outRoot, 'manifest.json');
    assert.equal(fs.existsSync(manifestPath), true, 'manifest.json should exist');

    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    assert.ok(Array.isArray(manifest.projects) && manifest.projects.length > 0, 'projects should exist');

    const dfRe = /^\d{2}:\d{2}:\d{2};\d{2}$/;
    const ndfRe = /^\d{2}:\d{2}:\d{2}:\d{2}$/;

    for (const proj of manifest.projects) {
      const outs = Array.isArray(proj.outputs) ? proj.outputs : [];
      const sccOuts = outs.filter(o => o && o.format === 'scc');
      assert.ok(sccOuts.length > 0, `project ${proj.name} should include SCC outputs`);

      for (const o of sccOuts) {
        assert.equal(o.ok, true, `SCC output should be ok (${proj.name} / ${o.key})`);
        assert.equal(fs.existsSync(o.outPath), true, `SCC file should exist (${o.outPath})`);

        const startTc = o?.config?.startTc;
        assert.ok(typeof startTc === 'string' && startTc.length > 0, 'startTc must be present');

        if (o.key === 'scc_df') {
          assert.match(startTc, dfRe, `DF startTc must be HH:MM:SS;FF, got ${startTc}`);
          assert.equal(o?.config?.dropFrame, true);
        }
        if (o.key === 'scc_ndf') {
          assert.match(startTc, ndfRe, `NDF startTc must be HH:MM:SS:FF, got ${startTc}`);
          assert.equal(o?.config?.dropFrame, false);
        }

        const vs = String(o.verifySummary || '');
        assert.equal(vs.includes('Illegal drop-frame'), false, `Should not contain illegal DF error: ${vs}`);
      }
    }
  } finally {
    fs.rmSync(outRoot, { recursive: true, force: true });
  }
});
