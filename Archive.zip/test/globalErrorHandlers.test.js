/** @jest-environment node */

const { registerGlobalErrorHandlers } = require('../utils/globalErrorHandlers');

describe('globalErrorHandlers', () => {
  function createProcessStub() {
    const listeners = new Map();
    return {
      listeners,
      on: jest.fn((event, handler) => listeners.set(event, handler))
    };
  }

  test('registers handlers and routes non-fatal unhandledRejection through telemetry/log/status', () => {
    const processRef = createProcessStub();
    const captureException = jest.fn();
    const captureMessage = jest.fn();
    const sendLog = jest.fn();
    const sendStatus = jest.fn();
    const onFatal = jest.fn();

    registerGlobalErrorHandlers({
      processRef,
      telemetry: { captureException, captureMessage },
      sendLog,
      sendStatus,
      onFatal
    });

    expect(processRef.on).toHaveBeenCalledWith('unhandledRejection', expect.any(Function));
    expect(processRef.on).toHaveBeenCalledWith('uncaughtException', expect.any(Function));

    processRef.listeners.get('unhandledRejection')(new Error('boom'));

    expect(captureException).not.toHaveBeenCalled();
    expect(captureMessage).toHaveBeenCalledWith('boom', expect.objectContaining({
      level: 'warning'
    }));
    expect(sendLog).toHaveBeenCalledWith(expect.objectContaining({
      kind: 'unhandledRejection',
      fatal: false,
      level: 'warn'
    }));
    expect(sendStatus).toHaveBeenCalledWith(expect.objectContaining({ status: 'degraded' }));
    expect(onFatal).not.toHaveBeenCalled();
  });

  test('marks uncaught heap OOM exception as fatal', () => {
    const processRef = createProcessStub();
    const onFatal = jest.fn();
    const sendStatus = jest.fn();

    registerGlobalErrorHandlers({
      processRef,
      telemetry: { captureException: jest.fn() },
      sendLog: jest.fn(),
      sendStatus,
      onFatal
    });

    processRef.listeners.get('uncaughtException')(
      new Error('FATAL ERROR: Reached heap limit Allocation failed - JavaScript heap out of memory'),
      'uncaughtException'
    );

    expect(sendStatus).toHaveBeenCalledWith(expect.objectContaining({ status: 'fatal' }));
    expect(onFatal).toHaveBeenCalled();
  });
});
