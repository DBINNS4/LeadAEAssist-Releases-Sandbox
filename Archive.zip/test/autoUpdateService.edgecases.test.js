/** @jest-environment node */

const mockCheckForUpdates = jest.fn();
const mockDownloadUpdate = jest.fn();
const mockOn = jest.fn();

jest.mock('electron', () => ({
  app: {
    whenReady: jest.fn(() => Promise.resolve())
  }
}));

jest.mock('electron-log', () => ({
  info: jest.fn(),
  warn: jest.fn()
}));

jest.mock('electron-updater', () => ({
  autoUpdater: {
    on: (...args) => mockOn(...args),
    checkForUpdates: (...args) => mockCheckForUpdates(...args),
    downloadUpdate: (...args) => mockDownloadUpdate(...args),
    quitAndInstall: jest.fn(),
    autoDownload: false,
    logger: null
  }
}));

jest.mock('../utils/state', () => ({
  readState: jest.fn(() => ({
    preferences: {
      autoUpdateCheckOnLaunch: true,
      autoUpdateAutoDownload: false,
      offlineMode: false
    }
  }))
}));

describe('autoUpdateService updater edge cases', () => {
  beforeEach(() => {
    jest.resetModules();
    mockCheckForUpdates.mockReset();
    mockDownloadUpdate.mockReset();
    mockOn.mockReset();
  });

  test('treats ERR_UPDATER_NO_PUBLISHED_VERSIONS as informational none status', async () => {
    const svc = require('../services/autoUpdateService');

    mockCheckForUpdates.mockRejectedValueOnce(Object.assign(new Error('No published versions on GitHub'), {
      code: 'ERR_UPDATER_NO_PUBLISHED_VERSIONS'
    }));

    const result = await svc.checkForUpdates();

    expect(result.ok).toBe(true);
    expect(result.status).toBe('none');
    expect(result.error).toBeNull();

    const last = svc.getLastStatus();
    expect(last.status).toBe('none');
    expect(last.info).toMatchObject({ reason: 'emptyFeed' });
  });

  test('returns structured failure for non-empty-feed updater errors', async () => {
    const svc = require('../services/autoUpdateService');

    mockCheckForUpdates.mockRejectedValueOnce(new Error('network down'));

    const result = await svc.checkForUpdates();

    expect(result).toEqual({ ok: false, error: 'network down' });
    expect(svc.getLastStatus()).toMatchObject({ status: 'error' });
  });
});
