/** @jest-environment node */

jest.mock('child_process', () => ({
  execFile: jest.fn()
}));

jest.mock('electron', () => {
  const path = require('path');
  const os = require('os');
  const baseDir = path.join(os.tmpdir(), 'lead-ae-assist-test');
  return {
    dialog: { showMessageBox: jest.fn(async () => ({ response: 1 })) },
    BrowserWindow: {
      fromWebContents: jest.fn((wc) => (wc ? { id: wc.id ?? 'mock-window' } : null))
    },
    app: {
      isPackaged: false,
      getAppPath: jest.fn(() => '/app'),
      getPath: jest.fn((key) => {
        if (key === 'userData') return path.join(baseDir, 'userData');
        if (key === 'appData') return path.join(baseDir, 'appData');
        return baseDir;
      })
    },
    shell: {},
    session: {}
  };
});

jest.mock('../modules/diskBenchmark', () => ({ runSequentialDriveTest: jest.fn(), SEQUENTIAL_BENCHMARK_TEMP_FILE_COUNT: 3 }));
jest.mock('../modules/speedUtils', () => ({ estimateDiskWriteSpeed: jest.fn() }));
jest.mock('check-disk-space', () => ({ default: jest.fn() }));
jest.mock('../utils/metadata', () => ({ getSourceMetadata: jest.fn() }));
jest.mock('../modules/project-organizer', () => ({ createProjectStructure: jest.fn() }));
jest.mock('../modules/pathExpander', () => ({ expandPaths: jest.fn((v) => v) }));
jest.mock('../modules/secureStore', () => ({}));
jest.mock('../services/licenseService', () => ({ isFeatureEnabled: jest.fn(() => true) }));
jest.mock('../modules/logUtils', () => ({
  readLogFiles: jest.fn(),
  createJobLogger: jest.fn(),
  writeJobLogToFile: jest.fn(),
  writeJobTextToFile: jest.fn()
}));
jest.mock('../utils/appPaths', () => ({ ensureUserDataSubdir: jest.fn(() => '/tmp') }));
jest.mock('../utils/fsAccessControl', () => ({ approveRoot: jest.fn(), approveMany: jest.fn() }));
jest.mock('../utils/trustedIpcSender', () => ({ assertTrustedIpcSender: jest.fn() }));
jest.mock('../utils/maintenance', () => ({ clearTempFiles: jest.fn(), clearCacheFiles: jest.fn() }));

const fs = require('fs');
const os = require('os');
const path = require('path');
const { app, dialog, BrowserWindow } = require('electron');
const checkDiskSpace = require('check-disk-space').default;
const { runSequentialDriveTest } = require('../modules/diskBenchmark');

const mockAutoUpdateService = {
  getLastStatus: jest.fn(() => ({ status: 'idle', info: null })),
  checkForUpdates: jest.fn(),
  downloadUpdate: jest.fn(),
  quitAndInstall: jest.fn()
};
jest.mock('../services/autoUpdateService', () => mockAutoUpdateService);


jest.mock('../ai/transcribeEngine', () => ({
  generateSRT: jest.fn((segments, cfg = {}) => `SRT:${Array.isArray(segments) ? segments.length : 0}:${cfg?.tag || ''}`),
  generateVTT: jest.fn((segments, cfg = {}) => `VTT:${Array.isArray(segments) ? segments.length : 0}:${cfg?.tag || ''}`),
  generateSCC: jest.fn((segments, cfg = {}) => ({ scc: `SCC:${Array.isArray(segments) ? segments.length : 0}:${cfg?.tag || ''}`, stats: { lateEocCount: 0 } })),
  generateSegmentTextWithTokenTiming: jest.fn((segments) => `TOK:${Array.isArray(segments) ? segments.length : 0}`),
  validateMccContentQc: jest.fn((segments) => ({ ok: true, byCue: new Array(Array.isArray(segments) ? segments.length : 0).fill({ ok: true }) })),
  validateSccContentQc: jest.fn((segments) => ({ ok: true, byCue: new Array(Array.isArray(segments) ? segments.length : 0).fill({ ok: true }) }))
}));

jest.mock('../utils/ipcPathGuards', () => ({
  assertNoNetworkSchemes: jest.fn(),
  toLocalPathIfFileUrl: jest.fn((v) => v),
  assertApprovedPath: jest.fn(),
  assertApprovedPaths: jest.fn(),
  extractAbsolutePathsFromObject: jest.fn(() => [])
}));

const miscHandlersModule = require('../ipc/misc.handlers');
const registerMiscHandlers = miscHandlersModule;
const { execFile } = require('child_process');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const { assertApprovedPath } = require('../utils/ipcPathGuards');
const licenseService = require('../services/licenseService');
const { createJobLogger, writeJobLogToFile, writeJobTextToFile } = require('../modules/logUtils');

function setAppPaths(baseDir) {
  app.getPath.mockImplementation((key) => {
    if (key === 'userData') return path.join(baseDir, 'userData');
    if (key === 'appData') return path.join(baseDir, 'appData');
    return baseDir;
  });
}

function buildIpcMain() {
  const handlers = new Map();
  const listeners = new Map();
  return {
    handlers,
    listeners,
    ipcMain: {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn)),
      on: jest.fn((channel, fn) => listeners.set(channel, fn))
    }
  };
}

describe('ipc misc update handlers', () => {
  const untrustedEvent = { senderFrame: { url: 'https://evil.example' }, sender: { id: 77 } };

  beforeEach(() => {
    jest.clearAllMocks();
    miscHandlersModule.setSpeedtestLockStrategyForTests({
      acquireMarker: jest.fn(async () => ({ markerPath: null, runId: 'test-run' })),
      releaseMarker: jest.fn(async () => {})
    });
    setAppPaths(path.join(os.tmpdir(), 'lead-ae-assist-test'));
    licenseService.isFeatureEnabled.mockReturnValue(true);
    assertApprovedPath.mockImplementation((senderId, inputPath) => inputPath);
    createJobLogger.mockReturnValue({
      info: jest.fn(),
      warn: jest.fn(),
      error: jest.fn(),
      setStage: jest.fn(),
      close: jest.fn(),
      getEntries: jest.fn(() => []),
      getStructuredLogPath: jest.fn(() => null)
    });
    writeJobLogToFile.mockReturnValue('/tmp/speed-test.json');
    writeJobTextToFile.mockReturnValue('/tmp/speed-test.txt');
    checkDiskSpace.mockResolvedValue({ free: 100 * 1024 * 1024 * 1024, size: 200 * 1024 * 1024 * 1024 });
    assertTrustedIpcSender.mockImplementation((event, action) => {
      if (event?.senderFrame?.url === 'https://evil.example') {
        throw new Error(`Blocked ${action}`);
      }
    });
  });

  afterEach(() => {
    miscHandlersModule.resetSpeedtestLockStrategyForTests();
  });

  test('returns structured { ok, error } and strips stack details', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    mockAutoUpdateService.checkForUpdates.mockRejectedValueOnce(
      new Error('Update failed\nError: stack line one\n    at internal')
    );

    const result = await handlers.get('updates:check')({ sender: { id: 1 } });

    expect(result).toEqual({ ok: false, error: 'Update failed' });
  });

  test('normalizes successful update check response shape', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    mockAutoUpdateService.checkForUpdates.mockResolvedValueOnce({ ok: true, status: 'none' });

    const result = await handlers.get('updates:check')({ sender: { id: 1 } });

    expect(result).toEqual({ ok: true, status: 'none', error: null });
  });

  test('blocks untrusted sender for channels hardened in __appendmiscHandlers', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    expect(handlers.get('list-panel-presets')(untrustedEvent, 'ingest')).toEqual([]);
    expect(handlers.get('delete-panel-preset')(untrustedEvent, { panel: 'ingest', presetName: 'x' })).toBe(false);
    await expect(handlers.get('write-panel-preset')(untrustedEvent, { panel: 'ingest', presetName: 'x', contents: '{}' })).resolves.toBeNull();
    await expect(handlers.get('read-panel-preset')(untrustedEvent, { panel: 'ingest', presetName: 'x' })).resolves.toBeNull();
  });

  test('rejects panel traversal attempts for preset handlers', () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-presets-'));
    setAppPaths(tempRoot);

    const result = handlers.get('list-panel-presets')({ sender: { id: 1 } }, '../..');

    expect(result).toEqual([]);
  });

  test('rejects preset traversal attempts on delete-panel-preset', () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-presets-'));
    setAppPaths(tempRoot);

    const externalSecret = path.join(tempRoot, 'secret.json');
    fs.writeFileSync(externalSecret, 'nope', 'utf8');

    const result = handlers.get('delete-panel-preset')(
      { sender: { id: 1 } },
      { panel: 'ingest', presetName: '../secret' }
    );

    expect(result).toBe(false);
    expect(fs.existsSync(externalSecret)).toBe(true);
  });

  test('media composer check remains async and fails safe on process command errors', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    execFile.mockImplementationOnce((cmd, args, options, callback) => {
      callback(new Error('process list command failed'));
    });

    const resultPromise = handlers.get('is-media-composer-running')({ sender: { id: 1 } });

    expect(resultPromise).toBeInstanceOf(Promise);
    await expect(resultPromise).resolves.toBe(false);
    expect(execFile).toHaveBeenCalledTimes(1);
  });

  test('show-message-dialog returns structured results through the shared native dialog path', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    dialog.showMessageBox.mockResolvedValueOnce({ response: 0, checkboxChecked: true });

    const sender = { id: 91 };
    const result = await handlers.get('show-message-dialog')({ sender, senderFrame: { url: 'app://lead-ae' } }, {
      type: 'warning',
      title: 'Delete preset',
      message: 'Delete the selected preset?',
      detail: 'This action cannot be undone.',
      buttons: ['Cancel', 'Delete'],
      defaultId: 1,
      cancelId: 0,
      checkboxLabel: 'Do not ask again'
    });

    expect(BrowserWindow.fromWebContents).toHaveBeenCalledWith(sender);
    expect(dialog.showMessageBox).toHaveBeenCalledWith(
      expect.objectContaining({ id: 91 }),
      expect.objectContaining({
        type: 'warning',
        title: 'Delete preset',
        message: 'Delete the selected preset?',
        detail: 'This action cannot be undone.',
        buttons: ['Cancel', 'Delete'],
        defaultId: 1,
        cancelId: 0,
        checkboxLabel: 'Do not ask again',
        noLink: true
      })
    );
    expect(result).toEqual({ response: 0, checkboxChecked: true });
  });

  test('show-confirm-dialog accepts structured options via the shared dialog layer', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    dialog.showMessageBox.mockResolvedValueOnce({ response: 1 });

    const result = await handlers.get('show-confirm-dialog')(
      { sender: { id: 42 }, senderFrame: { url: 'app://lead-ae' } },
      {
        title: 'Confirm preset deletion',
        message: 'Delete the selected preset?',
        detail: 'This action cannot be undone.',
        okLabel: 'Delete',
        cancelLabel: 'Cancel',
        type: 'warning'
      }
    );

    expect(result).toBe(true);
    expect(dialog.showMessageBox).toHaveBeenCalledWith(
      expect.objectContaining({ id: 42 }),
      expect.objectContaining({
        type: 'warning',
        title: 'Confirm preset deletion',
        message: 'Delete the selected preset?',
        detail: 'This action cannot be undone.',
        buttons: ['Cancel', 'Delete'],
        defaultId: 1,
        cancelId: 0,
        noLink: true
      })
    );
  });

  test('blocks untrusted sender for directly registered misc handlers', async () => {
    const { ipcMain, handlers, listeners } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    await expect(handlers.get('is-media-composer-running')(untrustedEvent)).resolves.toBe(false);
    await expect(handlers.get('show-message-dialog')(untrustedEvent, { message: 'Delete?' })).resolves.toEqual({ response: 0, checkboxChecked: false });
    await expect(handlers.get('show-confirm-dialog')(untrustedEvent, 'Delete?')).resolves.toBe(false);
    await expect(handlers.get('app:get-version')(untrustedEvent)).resolves.toBe('');
    await expect(handlers.get('path-exists')(untrustedEvent, '/tmp/x')).resolves.toBe(false);
    await expect(handlers.get('normalize-path')(untrustedEvent, '/tmp/x')).resolves.toBe('/tmp/x');
    await expect(handlers.get('stat-path')(untrustedEvent, '/tmp/x')).resolves.toEqual(expect.objectContaining({ ok: false }));
    await expect(handlers.get('path-stat')(untrustedEvent, '/tmp/x')).resolves.toEqual(expect.objectContaining({ ok: false }));
    await expect(handlers.get('expand-paths')(untrustedEvent, ['/tmp/x'])).resolves.toEqual(expect.objectContaining({ success: false }));
    await expect(handlers.get('log-viewer:read-log-files')(untrustedEvent, '/tmp')).resolves.toEqual([]);

    expect(() => listeners.get('ui:set-collapsed')(untrustedEvent, true)).toThrow('Blocked ui:set-collapsed');
  });
});

describe('drive test disk-space preflight', () => {
  beforeEach(() => {
    miscHandlersModule.setSpeedtestLockStrategyForTests({
      acquireMarker: jest.fn(async () => ({ markerPath: null, runId: 'test-run' })),
      releaseMarker: jest.fn(async () => {})
    });
    createJobLogger.mockReturnValue({
      info: jest.fn(),
      warn: jest.fn(),
      error: jest.fn(),
      setStage: jest.fn(),
      close: jest.fn(),
      getEntries: jest.fn(() => []),
      getStructuredLogPath: jest.fn(() => null)
    });
    writeJobLogToFile.mockReturnValue('/tmp/speed-test.json');
    writeJobTextToFile.mockReturnValue('/tmp/speed-test.txt');
    licenseService.isFeatureEnabled.mockReturnValue(true);
    checkDiskSpace.mockResolvedValue({ free: 100 * 1024 * 1024 * 1024, size: 200 * 1024 * 1024 * 1024 });
    assertTrustedIpcSender.mockImplementation(() => {});
    assertApprovedPath.mockImplementation((senderId, inputPath) => inputPath);
  });

  afterEach(() => {
    miscHandlersModule.resetSpeedtestLockStrategyForTests();
  });

  test('sequential preflight fails when free space is between 2x and 3x test size', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    const drivePath = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-drive-test-'));
    const testSizeMiB = 512;
    const fileSizeBytes = testSizeMiB * 1024 * 1024;
    const freeBetween2xAnd3x = Math.floor(2.5 * fileSizeBytes);
    checkDiskSpace.mockImplementationOnce(async () => ({ free: freeBetween2xAnd3x, size: 10 * 1024 * 1024 * 1024 }));

    const result = await handlers.get('run-drive-test')({ sender: { id: 9, isDestroyed: () => false, send: jest.fn() } }, drivePath, testSizeMiB);

    expect(checkDiskSpace).toHaveBeenCalled();
    expect(result).toEqual(expect.objectContaining({
      success: false,
      code: 'INSUFFICIENT_DISK_SPACE',
      mode: 'sequential'
    }));
    expect(result.peakTempBytes).toBe(3 * fileSizeBytes);
    expect(result.error).toContain('peak temp 1.5 GiB');
    expect(runSequentialDriveTest).not.toHaveBeenCalled();
  });
});


describe('ipc misc transcribe engine async parity', () => {
  test('registers async transcribe handlers and matches sync outputs', async () => {
    const { ipcMain, handlers, listeners } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    const event = { sender: { id: 11 } };
    const segments = [{ start: 0, end: 1, text: 'hello' }, { start: 1, end: 2, text: 'world' }];
    const cfg = { tag: 'parity' };

    const syncSrtEvent = { sender: { id: 11 }, returnValue: undefined };
    listeners.get('transcribeEngine:generateSRTSync')(syncSrtEvent, segments, cfg);
    const syncSrt = syncSrtEvent.returnValue.value;
    const asyncSrt = await handlers.get('transcribeEngine:generateSRT')(event, segments, cfg);

    const syncVttEvent = { sender: { id: 11 }, returnValue: undefined };
    listeners.get('transcribeEngine:generateVTTSync')(syncVttEvent, segments, cfg);
    const syncVtt = syncVttEvent.returnValue.value;
    const asyncVtt = await handlers.get('transcribeEngine:generateVTT')(event, segments, cfg);

    expect(asyncSrt).toBe(syncSrt);
    expect(asyncVtt).toBe(syncVtt);
    expect(typeof handlers.get('transcribeEngine:generateSCC')).toBe('function');
    expect(typeof handlers.get('transcribeEngine:generateSegmentTextWithTokenTiming')).toBe('function');
    expect(typeof handlers.get('transcribeEngine:validateMccContentQc')).toBe('function');
    expect(typeof handlers.get('transcribeEngine:validateSccContentQc')).toBe('function');
  });

  test('large payload workflow uses async handler return (no event.returnValue dependency)', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    const bigSegments = Array.from({ length: 4000 }, (_, i) => ({ start: i, end: i + 0.5, text: `line-${i}` }));
    const event = { sender: { id: 22 }, returnValue: 'unchanged' };

    const out = await handlers.get('transcribeEngine:generateSegmentTextWithTokenTiming')(event, bigSegments, {});

    expect(out).toBe(`TOK:${bigSegments.length}`);
    expect(event.returnValue).toBe('unchanged');
  });
});

describe('ipc misc random drive test cache mitigation', () => {
  beforeEach(() => {
    miscHandlersModule.setSpeedtestLockStrategyForTests({
      acquireMarker: jest.fn(async () => ({ markerPath: null, runId: 'test-run' })),
      releaseMarker: jest.fn(async () => {})
    });
    licenseService.isFeatureEnabled.mockReturnValue(true);
    assertApprovedPath.mockImplementation((senderId, inputPath) => inputPath);
    createJobLogger.mockReturnValue({
      info: jest.fn(),
      warn: jest.fn(),
      error: jest.fn(),
      setStage: jest.fn(),
      close: jest.fn(),
      getEntries: jest.fn(() => []),
      getStructuredLogPath: jest.fn(() => null)
    });
    writeJobLogToFile.mockReturnValue('/tmp/speed-test.json');
    writeJobTextToFile.mockReturnValue('/tmp/speed-test.txt');
    checkDiskSpace.mockResolvedValue({ free: 100 * 1024 * 1024 * 1024, size: 200 * 1024 * 1024 * 1024 });
  });

  afterEach(() => {
    miscHandlersModule.resetSpeedtestLockStrategyForTests();
  });

  test('keeps cacheMitigation metadata without emitting read-cache mitigation warnings', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-random-drive-'));
    const warnings = [];
    const event = {
      sender: {
        id: 99,
        send: jest.fn((channel, payload) => {
          if (channel === 'drive-test-warning') warnings.push(payload);
        }),
        once: jest.fn(),
        isDestroyed: jest.fn(() => false)
      }
    };

    const result = await handlers.get('run-drive-test-random')(event, tempRoot, 1);
    expect(result.success).toBe(true);
    expect(result.cacheMitigation).toEqual(expect.objectContaining({
      strategy: 'expanded_working_set_with_lagged_random_reads',
      handleReopenBetweenPhases: true,
      fullyApplied: false
    }));
    expect(warnings).toEqual([]);
    expect(result.warning).toBeUndefined();
  });

  test('uses staged random write/read phases with lagged reads and reopened handles', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-random-drive-'));
    const openModes = [];
    const openFilesByMode = { write: [], read: [] };
    const openSpy = jest.spyOn(fs.promises, 'open').mockImplementation(async (filePath, flags) => {
      const mode = String(flags);
      openModes.push(mode);
      if (mode.includes('w')) openFilesByMode.write.push(filePath);
      if (mode === 'r') openFilesByMode.read.push(filePath);

      return {
        truncate: jest.fn(async () => undefined),
        write: jest.fn(async () => ({ bytesWritten: 4096 })),
        read: jest.fn(async () => ({ bytesRead: 4096 })),
        sync: jest.fn(async () => undefined),
        close: jest.fn(async () => undefined)
      };
    });

    const event = {
      sender: {
        id: 100,
        send: jest.fn(),
        once: jest.fn(),
        isDestroyed: jest.fn(() => false)
      }
    };

    const result = await handlers.get('run-drive-test-random')(event, tempRoot, 1);

    expect(result.success).toBe(true);
    expect(openFilesByMode.write.length).toBe(5);
    expect(openFilesByMode.read.length).toBe(5);

    const firstReadIdx = openModes.indexOf('r');
    expect(firstReadIdx).toBeGreaterThanOrEqual(3);

    const uniqueWriteFiles = new Set(openFilesByMode.write);
    expect(uniqueWriteFiles.size).toBe(3);
    expect(new Set(openFilesByMode.read)).toEqual(uniqueWriteFiles);

    openSpy.mockRestore();
  });

  test('fails random drive test with SHORT_WRITE when fs write returns zero bytes', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-random-drive-'));
    const openSpy = jest.spyOn(fs.promises, 'open').mockImplementation(async (_filePath, flags) => {
      if (String(flags).includes('w')) {
        return {
          truncate: jest.fn(async () => undefined),
          write: jest.fn(async () => ({ bytesWritten: 0 })),
          read: jest.fn(async () => ({ bytesRead: 4096 })),
          sync: jest.fn(async () => undefined),
          close: jest.fn(async () => undefined)
        };
      }

      return {
        truncate: jest.fn(async () => undefined),
        write: jest.fn(async () => ({ bytesWritten: 4096 })),
        read: jest.fn(async () => ({ bytesRead: 4096 })),
        sync: jest.fn(async () => undefined),
        close: jest.fn(async () => undefined)
      };
    });

    const event = {
      sender: {
        id: 101,
        send: jest.fn(),
        once: jest.fn(),
        isDestroyed: jest.fn(() => false)
      }
    };

    const result = await handlers.get('run-drive-test-random')(event, tempRoot, 1);

    expect(checkDiskSpace).toHaveBeenCalled();
    expect(result).toEqual(expect.objectContaining({
      success: false,
      code: 'SHORT_WRITE'
    }));
    expect(result.error).toContain('Short write');

    openSpy.mockRestore();
  });

  test('fails random drive test with SHORT_READ when fs read returns partial bytes', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-random-drive-'));
    const openSpy = jest.spyOn(fs.promises, 'open').mockImplementation(async (_filePath, flags) => {
      if (String(flags).includes('w')) {
        return {
          truncate: jest.fn(async () => undefined),
          write: jest.fn(async () => ({ bytesWritten: 4096 })),
          read: jest.fn(async () => ({ bytesRead: 4096 })),
          sync: jest.fn(async () => undefined),
          close: jest.fn(async () => undefined)
        };
      }

      return {
        truncate: jest.fn(async () => undefined),
        write: jest.fn(async () => ({ bytesWritten: 4096 })),
        read: jest.fn(async () => ({ bytesRead: 1024 })),
        sync: jest.fn(async () => undefined),
        close: jest.fn(async () => undefined)
      };
    });

    const event = {
      sender: {
        id: 102,
        send: jest.fn(),
        once: jest.fn(),
        isDestroyed: jest.fn(() => false)
      }
    };

    const result = await handlers.get('run-drive-test-random')(event, tempRoot, 1);

    expect(checkDiskSpace).toHaveBeenCalled();
    expect(result).toEqual(expect.objectContaining({
      success: false,
      code: 'SHORT_READ'
    }));
    expect(result.error).toContain('Short read');

    openSpy.mockRestore();
  });
});
