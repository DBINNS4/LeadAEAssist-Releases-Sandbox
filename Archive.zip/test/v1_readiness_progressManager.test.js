/** @jest-environment node */

const ProgressManager = require('../utils/progressManager');

describe('Phase 3 progress throttling (no per-chunk IPC flood)', () => {
  test('updateStream does not emit per chunk; ticker emits at interval', () => {
    jest.useFakeTimers();

    const pm = new ProgressManager(0, 1000, 'files'); // 1s tick for predictable test
    pm.setTotalFiles(1);

    let streamEvents = 0;
    let overallEvents = 0;

    pm.on('stream-progress', () => { streamEvents += 1; });
    pm.on('overall-progress', () => { overallEvents += 1; });

    pm.startFile('s1', '/tmp/file.mov', 1000);

    // startFile emits once
    expect(streamEvents).toBe(1);

    // Reset counters to isolate updateStream behavior
    streamEvents = 0;
    overallEvents = 0;

    // Many chunk updates should not emit immediately
    for (let i = 0; i < 200; i++) {
      pm.updateStream('s1', 1);
    }
    expect(streamEvents).toBe(0);
    expect(overallEvents).toBe(0);

    // Advance to just before the tick; still no emit
    jest.advanceTimersByTime(999);
    expect(streamEvents).toBe(0);

    // Next ms triggers the interval tick → emits once
    jest.advanceTimersByTime(1);
    expect(streamEvents).toBeGreaterThanOrEqual(1);

    pm.dispose();
    jest.useRealTimers();
  });
});
