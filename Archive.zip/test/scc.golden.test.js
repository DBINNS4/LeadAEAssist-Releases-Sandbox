'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const scc = require('../modules/sccEncoder');
const { decodeSccText } = require('../modules/sccDecoder');
const { secondsToFrames } = require('../utils/timeUtils');

function normalizeScc(raw) {
  let s = String(raw || '').replace(/\uFEFF/g, '').replace(/\r/g, '');
  // Strip /* */ and // comments (verifySCC does something similar internally)
  s = s.replace(/\/\*[\s\S]*?\*\//g, '');
  const out = [];
  for (const line of s.split('\n')) {
    const cleaned = line.replace(/\/\/.*$/, '').trimEnd();
    if (!cleaned.trim()) continue;
    out.push(cleaned);
  }
  return out.join('\n') + '\n';
}


function cueComparable(cue, fps) {
  const lines = (Array.isArray(cue?.lines) && cue.lines.length)
    ? cue.lines
    : String(cue?.text || '').split(/\r?\n/);

  const placement = Array.isArray(cue?.sccPlacement) ? cue.sccPlacement : [];

  return {
    // Compare at the frame level (more stable than raw seconds).
    startF: secondsToFrames(cue?.start ?? 0, fps, 'nearest'),
    endF: secondsToFrames(cue?.end ?? 0, fps, 'nearest'),
    lines,
    placement: placement.map(p => ({
      row: Number.isFinite(p?.row) ? p.row : null,
      col: Number.isFinite(p?.col) ? p.col : null
    }))
  };
}

function assertCuesSemanticallyEqual(aCues, bCues, fps) {
  assert.equal(bCues.length, aCues.length, 'cue count differs');
  for (let i = 0; i < aCues.length; i++) {
    const a = cueComparable(aCues[i], fps);
    const b = cueComparable(bCues[i], fps);
    assert.deepEqual(b.lines, a.lines, `cue ${i + 1} lines differ`);
    assert.deepEqual(b.placement, a.placement, `cue ${i + 1} placement differs`);
    assert.ok(Math.abs(b.startF - a.startF) <= 1, `cue ${i + 1} start differs by >1 frame (${a.startF} vs ${b.startF})`);
    assert.ok(Math.abs(b.endF - a.endF) <= 1, `cue ${i + 1} end differs by >1 frame (${a.endF} vs ${b.endF})`);
  }
}

function cueToSegmentForRoundTrip(c) {
  const lines = Array.isArray(c?.lines) && c.lines.length
    ? c.lines
    : String(c?.text || '').split(/\r?\n/).slice(0, 2);

  if (Array.isArray(c?.sccPlacement) && c.sccPlacement.length) {
    const tagged = lines.map((ln, i) => {
      const p = c.sccPlacement[i] || {};
      const rowTag = Number.isFinite(p.row) ? `{row:${p.row}}` : '';
      const colTag = Number.isFinite(p.col) ? `{col:${p.col}}` : '';
      return `${rowTag}${colTag}${ln}`;
    }).join('\n');
    return { start: c.start, end: c.end, text: tagged };
  }
  return { start: c.start, end: c.end, text: lines.join('\n') };
}

test('SCC golden: encode → verifySCC → decode → re-encode stability (extended glyphs + mid-row tags)', () => {
  const segments = [
    {
      start: 0.0,
      end: 2.4,
      text: '{row:15}{col:0}{Wh}HELLO ®\n{row:14}{col:0}{I}WORLD{WhU} ♪'
    },
    {
      start: 2.6,
      end: 4.6,
      text: '{row:15}{col:0}FAST {Cy}STYLE{Wh} SHIFT'
    }
  ];

  const encCfg = {
    fps: 29.97,
    dropFrame: true,
    maxCharsPerLine: 28,
    maxLinesPerBlock: 2,
    startTc: '01:00:00;00',
    sccOptions: {
      channel: 1,
      rowPolicy: 'bottom2',
      safeMargins: { left: 0, right: 0 },
      repeatControlCodes: true,
      repeatPreambleCodes: true,
      strictCharacterEncoding: true,
      overflowPolicy: 'error',
      startResetAt: 'auto'
    }
  };

  const scc1 = scc.generateSCC(segments, encCfg);
  const rep1 = scc.verifySCC(scc1, {
    fps: 29.97,
    checkDropFrameLabels: true,
    checkMonotonic: true,
    checkOverlap: false
  });
  assert.equal(rep1.ok, true, rep1.summary);

  const dec = decodeSccText(scc1, { fps: 29.97, dropFrame: true, shiftToZero: true });
  assert.ok(dec && Array.isArray(dec.cues) && dec.cues.length >= 2, 'decoder produced cues');

  const roundTripSegments = dec.cues.map(cueToSegmentForRoundTrip);
  const scc2 = scc.generateSCC(roundTripSegments, encCfg);
  const rep2 = scc.verifySCC(scc2, {
    fps: 29.97,
    checkDropFrameLabels: true,
    checkMonotonic: true,
    checkOverlap: false
  });
  assert.equal(rep2.ok, true, rep2.summary);

  const dec2 = decodeSccText(scc2, { fps: 29.97, dropFrame: true, shiftToZero: true });
  assert.ok(dec2 && Array.isArray(dec2.cues) && dec2.cues.length >= 2, 'decoder produced cues (round-trip)');
  assertCuesSemanticallyEqual(dec.cues, dec2.cues, 29.97);
});

test('verifySCC catches illegal DF labels (drop-frame skips ;00 and ;01 on most minute boundaries)', () => {
  const bad = [
    'Scenarist_SCC V1.0',
    // 00:01:00;00 is illegal in DF (frames 00 and 01 are dropped at 1:00)
    '00:01:00;00\t9420',
    ''
  ].join('\n');

  const rep = scc.verifySCC(bad, { fps: 29.97, checkDropFrameLabels: true });
  assert.equal(rep.ok, false);
  assert.ok(rep.timecodeErrors > 0);
});

test('strictCharacterEncoding enforces deliverable-safe behavior (errors on unsupported glyphs)', () => {
  const segments = [{ start: 0, end: 2, text: 'Hello 😀' }];

  assert.throws(() => {
    scc.generateSCC(segments, {
      fps: 29.97,
      dropFrame: true,
      startTc: '01:00:00;00',
      sccOptions: { strictCharacterEncoding: true }
    });
  });

  const out = scc.generateSCC(segments, {
    fps: 29.97,
    dropFrame: true,
    startTc: '01:00:00;00',
    sccOptions: { strictCharacterEncoding: false }
  });
  const rep = scc.verifySCC(out, {
    fps: 29.97,
    checkMonotonic: true,
    checkOverlap: false
  });
  assert.equal(rep.ok, true, rep.summary);
});

test('rapid-fire cues remain SCC-line-monotonic (encoder schedule sanity)', () => {
  const segments = [];
  for (let i = 0; i < 10; i++) {
    const start = i * 0.50;
    segments.push({
      start,
      end: start + 0.45,
      text: `CAP ${i + 1}`
    });
  }

  const out = scc.generateSCC(segments, {
    fps: 29.97,
    dropFrame: true,
    startTc: '01:00:00;00',
    maxCharsPerLine: 28,
    maxLinesPerBlock: 2,
    sccOptions: {
      channel: 1,
      rowPolicy: 'bottom2',
      repeatControlCodes: true,
      repeatPreambleCodes: true
    }
  });

  const rep = scc.verifySCC(out, {
    fps: 29.97,
    checkMonotonic: true,
    checkOverlap: false
  });
  assert.equal(rep.ok, true, rep.summary);
});
