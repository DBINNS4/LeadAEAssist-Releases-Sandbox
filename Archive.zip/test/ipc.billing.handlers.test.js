'use strict';

describe('ipc/billing.handlers portal URL validation', () => {
  const ORIGINAL_ENV = process.env;

  beforeEach(() => {
    jest.resetModules();
    process.env = { ...ORIGINAL_ENV };
    delete global.fetch;
  });

  afterAll(() => {
    process.env = ORIGINAL_ENV;
  });

  function loadPrivate({ isPackaged = false, publicCfg = {}, token = 'tok_123' } = {}) {
    const shellOpenExternal = jest.fn().mockResolvedValue(true);

    jest.doMock('electron', () => ({
      app: { isPackaged, on: jest.fn() },
      shell: { openExternal: shellOpenExternal }
    }));

    jest.doMock('../utils/publicRuntimeConfig', () => ({
      loadPublicRuntimeConfig: jest.fn(() => ({
        entitlementUrl: 'https://entitlement-service.fly.dev',
        portalAllowedHosts: [],
        billingHosts: [],
        entitlementHosts: [],
        paddle: {},
        ...publicCfg
      }))
    }));

    jest.doMock('../modules/secureStore', () => ({
      loadSecret: jest.fn((k) => (k === 'licenseToken' ? token : '')),
      saveSecret: jest.fn()
    }));

    jest.doMock('../services/licenseService', () => ({ getEntitlement: jest.fn(() => ({})) }));
    jest.doMock('../utils/trustedIpcSender', () => ({ assertTrustedIpcSender: jest.fn() }));

    const mod = require('../ipc/billing.handlers');
    return { privateApi: mod._private, shellOpenExternal };
  }

  test('accepts https portal URL on allowlisted host in packaged mode', async () => {
    const { privateApi, shellOpenExternal } = loadPrivate({
      isPackaged: true,
      publicCfg: { portalAllowedHosts: ['billing.example.com'] }
    });

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ url: 'https://billing.example.com/portal/session' })
    });

    const result = await privateApi.openPortalWindow({});

    expect(result).toEqual({ ok: true });
    expect(shellOpenExternal).toHaveBeenCalledWith('https://billing.example.com/portal/session');
  });

  test('openPortalWindow returns ok true when shell.openExternal resolves', async () => {
    const { privateApi, shellOpenExternal } = loadPrivate({
      isPackaged: true,
      publicCfg: { portalAllowedHosts: ['billing.example.com'] }
    });

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ url: 'https://billing.example.com/portal/session' })
    });

    const result = await privateApi.openPortalWindow({});

    expect(result).toEqual({ ok: true });
    expect(shellOpenExternal).toHaveBeenCalledWith('https://billing.example.com/portal/session');
  });

  test('openPortalWindow returns browser error when shell.openExternal throws', async () => {
    const { privateApi, shellOpenExternal } = loadPrivate({
      isPackaged: true,
      publicCfg: { portalAllowedHosts: ['billing.example.com'] }
    });
    shellOpenExternal.mockRejectedValueOnce(new Error('browser launch failed'));

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ url: 'https://billing.example.com/portal/session' })
    });

    const result = await privateApi.openPortalWindow({});

    expect(result).toEqual({ ok: false, error: 'Failed to open browser: browser launch failed' });
  });

  test('rejects malformed portal URL response', async () => {
    const { privateApi, shellOpenExternal } = loadPrivate({
      isPackaged: true,
      publicCfg: { portalAllowedHosts: ['billing.example.com'] }
    });

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ url: 'not a valid url' })
    });

    const result = await privateApi.openPortalWindow({});

    expect(result).toEqual({ ok: false, error: 'Portal URL invalid' });
    expect(shellOpenExternal).not.toHaveBeenCalled();
  });

  test('rejects non-allowlisted host in packaged mode', async () => {
    const { privateApi, shellOpenExternal } = loadPrivate({
      isPackaged: true,
      publicCfg: { portalAllowedHosts: ['billing.example.com'] }
    });

    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ url: 'https://evil.example.net/phish' })
    });

    const result = await privateApi.openPortalWindow({});

    expect(result).toEqual({ ok: false, error: 'Portal URL invalid' });
    expect(shellOpenExternal).not.toHaveBeenCalled();
  });

  test('allows http only in dev when host is allowlisted', async () => {
    const { privateApi } = loadPrivate({
      isPackaged: false,
      publicCfg: { portalAllowedHosts: ['127.0.0.1'] }
    });

    expect(privateApi.validatePortalUrl('http://127.0.0.1:8787/portal')).toBe('http://127.0.0.1:8787/portal');
  });

  test('rejects http in packaged mode', async () => {
    const { privateApi } = loadPrivate({
      isPackaged: true,
      publicCfg: { portalAllowedHosts: ['billing.example.com'] }
    });

    expect(privateApi.validatePortalUrl('http://billing.example.com/portal')).toBeNull();
  });

  test('openCheckoutWindow returns ok true when shell.openExternal resolves', async () => {
    const { privateApi, shellOpenExternal } = loadPrivate({ isPackaged: false });

    const result = await privateApi.openCheckoutWindow({ plan: 'monthly' });

    expect(result).toEqual({ ok: true });
    expect(shellOpenExternal).toHaveBeenCalledTimes(1);
    const firstCheckoutUrl = new URL(shellOpenExternal.mock.calls[0][0]);
    expect(firstCheckoutUrl.pathname).toBe('/checkout');
    expect(firstCheckoutUrl.searchParams.get('plan')).toBe('monthly');
    const nonce = firstCheckoutUrl.searchParams.get('nonce');
    expect(nonce).toMatch(/^[a-f0-9]{48}$/);

    const secondResult = await privateApi.openCheckoutWindow({ plan: 'monthly' });
    expect(secondResult).toEqual({ ok: true });
    const secondCheckoutUrl = new URL(shellOpenExternal.mock.calls[1][0]);
    expect(secondCheckoutUrl.searchParams.get('nonce')).not.toBe(nonce);
  });

  test('openCheckoutWindow returns browser error when shell.openExternal throws', async () => {
    const { privateApi, shellOpenExternal } = loadPrivate({ isPackaged: false });
    shellOpenExternal.mockRejectedValueOnce(new Error('no browser available'));

    const result = await privateApi.openCheckoutWindow({ plan: 'monthly' });

    expect(result).toEqual({ ok: false, error: 'Failed to open browser: no browser available' });
  });

  test('checkout routes require valid nonce and return 403 otherwise', async () => {
    const { privateApi, shellOpenExternal } = loadPrivate({ isPackaged: false });

    await privateApi.openCheckoutWindow({ plan: 'monthly' });
    const checkoutUrl = new URL(shellOpenExternal.mock.calls[0][0]);
    const nonce = checkoutUrl.searchParams.get('nonce');

    const makeRes = () => {
      const res = {
        statusCode: 0,
        headers: {},
        body: '',
        ended: false,
        writeHead(code, headers) {
          this.statusCode = code;
          this.headers = headers;
          return this;
        },
        end(chunk = '') {
          this.body += chunk;
          this.ended = true;
          return this;
        }
      };
      return res;
    };

    const unauthorized = makeRes();
    privateApi.handleBillingRequest({ url: '/checkout?plan=monthly' }, unauthorized);
    expect(unauthorized.statusCode).toBe(403);

    const invalid = makeRes();
    privateApi.handleBillingRequest({ url: '/checkout.js?nonce=invalid' }, invalid);
    expect(invalid.statusCode).toBe(403);

    const authorizedCheckout = makeRes();
    privateApi.handleBillingRequest({ url: `/checkout?plan=monthly&nonce=${nonce}` }, authorizedCheckout);
    expect(authorizedCheckout.statusCode).toBe(200);

    const authorizedScript = makeRes();
    privateApi.handleBillingRequest({ url: `/checkout.js?plan=monthly&nonce=${nonce}` }, authorizedScript);
    expect(authorizedScript.statusCode).toBe(200);
    expect(authorizedScript.body).toContain('/complete?nonce=');
  });
});
