const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const runtimeAssetService = require('../services/runtimeAssetService');
const { sha256DirectoryTreeHex } = require('../utils/runtimeAssetIntegrity');
const {
  setupRuntimeAssetTest,
  writeFile,
  sha256Hex
} = require('./helpers/runtimeAssetTestUtils');

function createChromeTree(rootDir, label) {
  writeFile(path.join(rootDir, 'chrome', 'Google Chrome for Testing.app', 'Contents', 'MacOS', 'Google Chrome for Testing'), label);
  writeFile(path.join(rootDir, 'chrome', 'locales', 'en-US.pak'), `${label}-locale`);
}

test('runtime asset service: prune old asset versions', async (t) => {
  await t.test('removes obsolete version siblings, stale downloads, and stale state entries', async () => {
    const manifest = {
      schemaVersion: 1,
      assets: {
        'chrome.current': {
          type: 'archive',
          archiveFormat: 'zip',
          installDir: 'puppeteer/cache/chrome-127.0.6533.88/darwin-arm64',
          sha256: sha256Hex(Buffer.from('unused chrome zip', 'utf8'))
        },
        'whisper.current': {
          type: 'file',
          installPath: 'whisper/models/ggml-base.en.bin',
          sha256: sha256Hex(Buffer.from('current whisper model', 'utf8'))
        }
      }
    };

    const ctx = setupRuntimeAssetTest(runtimeAssetService, manifest);
    try {
      const { assetsRoot, downloadsRoot } = runtimeAssetService.computeAssetPaths();
      const currentChromeRoot = path.join(assetsRoot, 'puppeteer/cache/chrome-127.0.6533.88');
      const currentChromePath = path.join(currentChromeRoot, 'darwin-arm64');
      const oldChromeRoot = path.join(assetsRoot, 'puppeteer/cache/chrome-126.0.6478.114');
      const oldChromePath = path.join(oldChromeRoot, 'darwin-arm64');
      const unrelatedRoot = path.join(assetsRoot, 'puppeteer/cache/not-a-version');
      const whisperPath = path.join(assetsRoot, 'whisper/models/ggml-base.en.bin');

      createChromeTree(currentChromePath, 'current-chrome');
      createChromeTree(oldChromePath, 'old-chrome');
      createChromeTree(unrelatedRoot, 'keep-me');
      writeFile(whisperPath, 'current whisper model');
      writeFile(path.join(downloadsRoot, 'legacy.asset.zip'), 'old download');

      runtimeAssetService.writeInstalledState({
        schemaVersion: 1,
        installed: {
          'chrome.current': {
            path: currentChromePath,
            source: 'installed',
            installedAt: Date.now()
          },
          'chrome.legacy': {
            path: oldChromePath,
            source: 'download',
            installedAt: Date.now() - 1000
          },
          'ghost.asset': {
            path: path.join(assetsRoot, 'ghost/does-not-exist.bin'),
            source: 'seed',
            installedAt: Date.now() - 2000
          }
        }
      });

      const result = runtimeAssetService.pruneOldAssetVersions({
        gracePeriodMs: 0,
        processUsageDetector() {
          return { checked: true, inUse: false, method: 'test' };
        }
      });

      assert.equal(fs.existsSync(currentChromeRoot), true);
      assert.equal(fs.existsSync(currentChromePath), true);
      assert.equal(fs.existsSync(oldChromeRoot), false);
      assert.equal(fs.existsSync(oldChromePath), false);
      assert.equal(fs.existsSync(unrelatedRoot), true);
      assert.equal(fs.existsSync(whisperPath), true);
      assert.equal(fs.existsSync(path.join(downloadsRoot, 'legacy.asset.zip')), false);

      assert.ok(result.removedPaths.some(candidate => candidate.endsWith(path.join('puppeteer', 'cache', 'chrome-126.0.6478.114'))));
      assert.ok(result.removedPaths.some(candidate => candidate.endsWith(path.join('downloads', 'legacy.asset.zip'))));
      assert.deepEqual(result.removedStateAssetIds.sort(), ['chrome.legacy', 'ghost.asset']);

      const nextState = runtimeAssetService.readInstalledState();
      assert.deepEqual(Object.keys(nextState.installed).sort(), ['chrome.current']);
    } finally {
      ctx.restore();
    }
  });

  await t.test('skips pruning version roots that are still in use', async () => {
    const manifest = {
      schemaVersion: 1,
      assets: {
        'chrome.current': {
          type: 'archive',
          archiveFormat: 'zip',
          installDir: 'puppeteer/cache/chrome-127.0.6533.88/darwin-arm64',
          sha256: sha256Hex(Buffer.from('unused chrome zip', 'utf8'))
        }
      }
    };

    const ctx = setupRuntimeAssetTest(runtimeAssetService, manifest);
    try {
      const { assetsRoot } = runtimeAssetService.computeAssetPaths();
      const oldChromeRoot = path.join(assetsRoot, 'puppeteer/cache/chrome-126.0.6478.114');
      const oldChromePath = path.join(oldChromeRoot, 'darwin-arm64');
      createChromeTree(oldChromePath, 'old-chrome');

      const result = runtimeAssetService.pruneOldAssetVersions({
        gracePeriodMs: 0,
        processUsageDetector(candidatePath) {
          return {
            checked: true,
            inUse: candidatePath === oldChromeRoot,
            method: 'test'
          };
        }
      });

      assert.equal(fs.existsSync(oldChromeRoot), true);
      assert.ok(result.skipped.some(entry => entry.path === oldChromeRoot && entry.reason === 'in-use'));
    } finally {
      ctx.restore();
    }
  });

  await t.test('ensureAsset prunes obsolete version siblings after installing the current archive asset', async () => {
    const seedDirName = 'chrome-127.0.6533.88';
    const manifest = {
      schemaVersion: 1,
      assets: {
        'chrome.current': {
          type: 'archive',
          archiveFormat: 'zip',
          installDir: 'puppeteer/cache/chrome-127.0.6533.88/darwin-arm64',
          seedPaths: [path.join('seed', seedDirName)],
          seedSha256: null,
          sha256: sha256Hex(Buffer.from('unused chrome zip', 'utf8')),
          entrypoint: 'chrome/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
        }
      }
    };

    const ctx = setupRuntimeAssetTest(runtimeAssetService, manifest);
    try {
      const seedRoot = path.join(ctx.root, 'seed', seedDirName);
      createChromeTree(seedRoot, 'current-seed');

      manifest.assets['chrome.current'].seedSha256 = sha256DirectoryTreeHex(path.join(seedRoot, 'chrome'), { rootName: 'chrome' });
      const manifestPath = ctx.manifestPath;
      fs.writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
      runtimeAssetService.__private?.resetForTests?.();

      const { assetsRoot } = runtimeAssetService.computeAssetPaths();
      const oldChromeRoot = path.join(assetsRoot, 'puppeteer/cache/chrome-126.0.6478.114');
      const oldChromePath = path.join(oldChromeRoot, 'darwin-arm64');
      createChromeTree(oldChromePath, 'old-chrome');

      const installed = await runtimeAssetService.ensureAsset('chrome.current', {
        processUsageDetector() {
          return { checked: true, inUse: false, method: 'test' };
        },
        pruneGracePeriodMs: 0
      });

      assert.equal(installed.source, 'seed');
      assert.equal(fs.existsSync(installed.path), true);
      assert.equal(fs.existsSync(oldChromeRoot), false);
    } finally {
      ctx.restore();
    }
  });
});
