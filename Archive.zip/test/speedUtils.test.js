/** @jest-environment node */

describe('speedUtils estimateDiskWriteSpeed return-shape handling', () => {
  beforeEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
  });

  test('floors finite numeric speed and returns it', async () => {
    const benchMock = jest.fn().mockResolvedValue(123.9);
    jest.doMock('../modules/diskBenchmark', () => ({
      estimateSequentialWriteSpeedMiBps: benchMock
    }));

    const { estimateDiskWriteSpeed } = require('../modules/speedUtils');
    const result = await estimateDiskWriteSpeed('/tmp', 25, { useCache: false });

    expect(result).toBe(123);
    expect(benchMock).toHaveBeenCalledTimes(1);
  });

  test('throws error using message field for benchmark failure payload', async () => {
    const failurePayload = {
      success: false,
      code: 'MARKER_CREATE_FAILED',
      details: { reason: 'lock marker write denied' },
      message: 'Could not create speed test marker lock'
    };

    jest.doMock('../modules/diskBenchmark', () => ({
      estimateSequentialWriteSpeedMiBps: jest.fn().mockResolvedValue(failurePayload)
    }));

    const { estimateDiskWriteSpeed } = require('../modules/speedUtils');

    await expect(estimateDiskWriteSpeed('/tmp', 25, { useCache: false })).rejects.toMatchObject({
      message: failurePayload.message,
      code: failurePayload.code,
      details: failurePayload.details
    });
  });

  test('throws error using error field when message is missing', async () => {
    const failurePayload = {
      success: false,
      code: 'WRITE_FAILED',
      details: { reason: 'write denied' },
      error: 'Disk write test failed due to permissions'
    };

    jest.doMock('../modules/diskBenchmark', () => ({
      estimateSequentialWriteSpeedMiBps: jest.fn().mockResolvedValue(failurePayload)
    }));

    const { estimateDiskWriteSpeed } = require('../modules/speedUtils');

    await expect(estimateDiskWriteSpeed('/tmp', 25, { useCache: false })).rejects.toMatchObject({
      message: failurePayload.error,
      code: failurePayload.code,
      details: failurePayload.details
    });
  });

  test('throws generic error for unexpected non-numeric payload', async () => {
    jest.doMock('../modules/diskBenchmark', () => ({
      estimateSequentialWriteSpeedMiBps: jest.fn().mockResolvedValue({ success: true, speed: 111 })
    }));

    const { estimateDiskWriteSpeed } = require('../modules/speedUtils');

    await expect(estimateDiskWriteSpeed('/tmp', 25, { useCache: false })).rejects.toThrow(
      'Unexpected disk benchmark return payload'
    );
  });

  test('does not cache non-finite results', async () => {
    const benchMock = jest.fn()
      .mockResolvedValueOnce(Infinity)
      .mockResolvedValueOnce(77.2);

    jest.doMock('../modules/diskBenchmark', () => ({
      estimateSequentialWriteSpeedMiBps: benchMock
    }));

    const { estimateDiskWriteSpeed } = require('../modules/speedUtils');

    await expect(estimateDiskWriteSpeed('/tmp', 25)).rejects.toThrow('Unexpected disk benchmark return payload');
    await expect(estimateDiskWriteSpeed('/tmp', 25)).resolves.toBe(77);
    expect(benchMock).toHaveBeenCalledTimes(2);
  });
});
