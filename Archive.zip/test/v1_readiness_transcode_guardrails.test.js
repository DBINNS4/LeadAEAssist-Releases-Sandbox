/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');

// Mocks must be defined before importing the module under test.
jest.mock('electron', () => ({}));

jest.mock('../progressBridge', () => ({
  bindProgressManager: () => () => {}
}));

jest.mock('../utils/ffmpeg', () => ({
  ffmpegPath: '/usr/bin/ffmpeg',
  ffprobePath: '/usr/bin/ffprobe'
}));

jest.mock('../modules/logUtils', () => ({
  sendLogMessage: jest.fn(),
  writeLogToFile: jest.fn(),
  archivePanelSessionLog: jest.fn(),
  writeJobLogToFile: jest.fn(),
  writeJobTextToFile: jest.fn(),
  createJobLogger: () => ({
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    setStage: jest.fn(),
    getEntries: jest.fn(() => []),
    getStructuredLogPath: jest.fn(() => null),
    close: jest.fn()
  }),
  createJobUserLog: () => ({ lines: [], push: jest.fn() })
}));

jest.mock('child_process', () => ({
  spawn: jest.fn(),
  execFile: jest.fn((...args) => {
    const cb = args[args.length - 1];
    const payload = {
      format: { duration: '10.0' },
      streams: [{ width: 1920, height: 1080, nb_frames: '300' }]
    };
    cb(null, Buffer.from(JSON.stringify(payload)));
  })
}));

describe('Phase 1 guardrails + Phase 1 disk preflight correctness', () => {
  test('preflightTranscodeDisk uses SUM of batch estimates (not max single)', async () => {
    const { preflightTranscodeDisk } = require('../modules/transcode');

    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-preflight-'));
    try {
      const outFolder = path.join(tmpRoot, 'out');
      fs.mkdirSync(outFolder);

      const f1 = path.join(tmpRoot, 'a.mov');
      const f2 = path.join(tmpRoot, 'b.mov');
      fs.writeFileSync(f1, Buffer.alloc(1000));
      fs.writeFileSync(f2, Buffer.alloc(2000));

      const baseConfig = {
        inputFiles: [],
        outputFormat: 'h264',
        containerFormat: 'mp4',
        outputFolder: outFolder,
        resolution: 'source',
        frameRate: 'source',
        pixelFormat: 'default',
        audioCodec: 'aac',
        channels: 'stereo',
        sampleRate: '48000',
        audioBitrate: '192k',
        audioOnly: false
      };

      const r1 = await preflightTranscodeDisk({ ...baseConfig, inputFiles: [f1] });
      const r2 = await preflightTranscodeDisk({ ...baseConfig, inputFiles: [f2] });
      const rBoth = await preflightTranscodeDisk({ ...baseConfig, inputFiles: [f1, f2] });

      expect(typeof r1.estimateBytes).toBe('bigint');
      expect(typeof r2.estimateBytes).toBe('bigint');
      expect(typeof rBoth.estimateBytes).toBe('bigint');

      expect(rBoth.estimateBytes).toBe(r1.estimateBytes + r2.estimateBytes);
      expect(String(rBoth.estimateMethod || '')).toMatch(/^sum_/);
      expect(rBoth.estimatedFiles).toBe(2);
      expect(rBoth.totalFiles).toBe(2);
    } finally {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });

  test('runTranscode rejects sequence/container mismatches before spawning FFmpeg', async () => {
    const prevEnv = process.env.NODE_ENV;
    process.env.NODE_ENV = 'development';
    try {
      const { runTranscode } = require('../modules/transcode');
      const { spawn } = require('child_process');

      const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-mismatch-'));
      const outFolder = path.join(tmpRoot, 'out');
      fs.mkdirSync(outFolder);

      const res = await runTranscode({
        jobId: 'test-mismatch',
        inputFiles: [path.join(tmpRoot, 'nonexistent.mov')],
        outputFormat: 'png_sequence',
        containerFormat: 'mov',
        outputFolder: outFolder,
        audioOnly: false
      });

      expect(res && res.success).toBe(false);
      expect(spawn).not.toHaveBeenCalled();
    } finally {
      process.env.NODE_ENV = prevEnv;
    }
  });

  test('preflightTranscodeDisk aggregates deterministically with concurrent file probing', async () => {
    jest.resetModules();
    const childProcess = require('child_process');
    childProcess.execFile.mockImplementation((...args) => {
      const targetFile = String(args[args.length - 2] || '');
      const cb = args[args.length - 1];
      const payload = {
        format: { duration: '10.0' },
        streams: [{ width: 1920, height: 1080, nb_frames: '300' }]
      };
      const delay = targetFile.includes('a.mov') ? 30 : (targetFile.includes('b.mov') ? 5 : 15);
      setTimeout(() => cb(null, Buffer.from(JSON.stringify(payload))), delay);
    });

    const { preflightTranscodeDisk } = require('../modules/transcode');

    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-preflight-concurrent-'));
    try {
      const outFolder = path.join(tmpRoot, 'out');
      fs.mkdirSync(outFolder);

      const f1 = path.join(tmpRoot, 'a.mov');
      const f2 = path.join(tmpRoot, 'b.mov');
      const missing = path.join(tmpRoot, 'missing.mov');
      fs.writeFileSync(f1, Buffer.alloc(1000));
      fs.writeFileSync(f2, Buffer.alloc(2000));

      const baseConfig = {
        inputFiles: [],
        outputFormat: 'h264',
        containerFormat: 'mp4',
        outputFolder: outFolder,
        resolution: 'source',
        frameRate: 'source',
        pixelFormat: 'default',
        audioCodec: 'aac',
        channels: 'stereo',
        sampleRate: '48000',
        audioBitrate: '192k',
        audioOnly: false
      };

      const r1 = await preflightTranscodeDisk({ ...baseConfig, inputFiles: [f1] });
      const r2 = await preflightTranscodeDisk({ ...baseConfig, inputFiles: [f2] });
      const rBatch = await preflightTranscodeDisk({ ...baseConfig, inputFiles: [f1, missing, f2] });

      expect(rBatch.status).toBe('ok');
      expect(rBatch.estimateBytes).toBe(r1.estimateBytes + r2.estimateBytes);
      expect(rBatch.estimatedFiles).toBe(2);
      expect(rBatch.totalFiles).toBe(3);
      expect(rBatch.skippedFiles).toBe(1);
      expect(String(rBatch.warning || '')).toMatch(/Skipped 1 file\(s\)/);
    } finally {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });
});
