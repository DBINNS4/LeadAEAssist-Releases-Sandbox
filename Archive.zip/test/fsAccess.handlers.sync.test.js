/** @jest-environment node */

const os = require('os');
const fs = require('fs');
const path = require('path');

jest.mock('../utils/fsAccessControl', () => ({
   evaluatePathAccess: jest.fn(),
   isPathAllowed: jest.fn()
 }));
 
 jest.mock('../utils/trustedIpcSender', () => ({
   assertTrustedIpcSender: jest.fn()
 }));
 
 const { evaluatePathAccess, isPathAllowed } = require('../utils/fsAccessControl');
 const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
 const registerFsAccessHandlers = require('../ipc/fsAccess.handlers');
 
 function buildIpcMain() {
   const handlers = new Map();
   const listeners = new Map();
   return {
     handlers,
     listeners,
     ipcMain: {
       handle: jest.fn((channel, fn) => handlers.set(channel, fn)),
       on: jest.fn((channel, fn) => listeners.set(channel, fn))
     }
   };
 }
 
describe('fsAccess async IPC handlers (throwing promise semantics)', () => {
   let tempRoot;
  let approvedRoot;
  let blockedRoot;
  let event;
  let handlers;
  let listeners;

  const denyByPolicy = async (channel, ...args) => {
    if (channel === 'fs:exists') {
      await expect(handlers.get(channel)(event, ...args)).resolves.toBe(false);
      return;
    }
    await expect(handlers.get(channel)(event, ...args)).rejects.toThrow('permission_denied');
  };
 
   beforeEach(() => {
    const { ipcMain, handlers: registeredHandlers, listeners: registeredListeners } = buildIpcMain();
    registerFsAccessHandlers(ipcMain);
    handlers = registeredHandlers;
    listeners = registeredListeners;

     tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'fs-access-async-'));
    approvedRoot = path.join(tempRoot, 'approved');
    blockedRoot = path.join(tempRoot, 'blocked');
    fs.mkdirSync(approvedRoot, { recursive: true });
    fs.mkdirSync(blockedRoot, { recursive: true });

    fs.writeFileSync(path.join(approvedRoot, 'read-me.txt'), 'approved-data', 'utf8');
    fs.writeFileSync(path.join(approvedRoot, 'delete-me.txt'), 'remove-me', 'utf8');
    fs.writeFileSync(path.join(approvedRoot, 'copy-src.txt'), 'copy-source', 'utf8');

    fs.writeFileSync(path.join(blockedRoot, 'read-me.txt'), 'blocked-data', 'utf8');
    fs.writeFileSync(path.join(blockedRoot, 'copy-src.txt'), 'blocked-copy-source', 'utf8');

     event = { sender: { id: 321 }, senderFrame: { url: 'app://renderer' } };

     isPathAllowed.mockReset();
     evaluatePathAccess.mockReset();
     assertTrustedIpcSender.mockReset();

    evaluatePathAccess.mockImplementation((senderId, targetPath) => ({
      allowed: isPathAllowed(senderId, targetPath),
      reason: 'not_approved',
    }));

    isPathAllowed.mockImplementation((_senderId, targetPath) => String(targetPath).startsWith(approvedRoot));
   });
 
   afterEach(() => {
     fs.rmSync(tempRoot, { recursive: true, force: true });
   });
 
  test('fs:exists returns true for approved path and false for denied path', async () => {
    const approved = path.join(approvedRoot, 'read-me.txt');
    const blocked = path.join(blockedRoot, 'read-me.txt');
 
    await expect(handlers.get('fs:exists')(event, approved)).resolves.toBe(true);
    await expect(handlers.get('fs:exists')(event, blocked)).resolves.toBe(false);
 
    expect(assertTrustedIpcSender).toHaveBeenCalledWith(event, 'fs:exists');
   });
 
  test('fs:readTextFile returns raw text for approved path and throws for denied path', async () => {
    const approved = path.join(approvedRoot, 'read-me.txt');
    const blocked = path.join(blockedRoot, 'read-me.txt');
 
    await expect(handlers.get('fs:readTextFile')(event, approved, 'utf8')).resolves.toBe('approved-data');
    await denyByPolicy('fs:readTextFile', blocked, 'utf8');
  });
 
  test('fs:writeTextFile writes to approved path and throws for denied path', async () => {
    const approved = path.join(approvedRoot, 'new', 'written.txt');
    const blocked = path.join(blockedRoot, 'new', 'blocked.txt');

    await expect(handlers.get('fs:writeTextFile')(event, approved, 'hello world', 'utf8')).resolves.toBe(true);
    expect(fs.readFileSync(approved, 'utf8')).toBe('hello world');

    await denyByPolicy('fs:writeTextFile', blocked, 'blocked write', 'utf8');
    expect(fs.existsSync(blocked)).toBe(false);
   });

  test('fs:mkdir creates approved directory and throws for denied path', async () => {
    const approved = path.join(approvedRoot, 'newdir', 'nested');
    const blocked = path.join(blockedRoot, 'newdir', 'nested');
 
    await expect(handlers.get('fs:mkdir')(event, approved)).resolves.toBe(true);
    expect(fs.existsSync(approved)).toBe(true);
 
    await denyByPolicy('fs:mkdir', blocked);
    expect(fs.existsSync(blocked)).toBe(false);
   });

  test('fs:readdir returns unwrapped entries for approved path and throws for denied path', async () => {
    const approved = approvedRoot;
    const blocked = blockedRoot;
 
    const names = await handlers.get('fs:readdir')(event, approved, {});
    expect(Array.isArray(names)).toBe(true);
    expect(names).toContain('read-me.txt');
    expect(typeof names[0]).toBe('string');
 
    const withTypes = await handlers.get('fs:readdir')(event, approved, { withFileTypes: true });
    expect(withTypes[0]).toEqual(expect.objectContaining({
      name: expect.any(String),
      isFile: expect.any(Boolean),
      isDirectory: expect.any(Boolean),
      isSymbolicLink: expect.any(Boolean),
    }));

    await denyByPolicy('fs:readdir', blocked, {});
   });
 
  test('fs:stat returns unwrapped stat object for approved path and throws for denied path', async () => {
    const approved = path.join(approvedRoot, 'read-me.txt');
    const blocked = path.join(blockedRoot, 'read-me.txt');

    const stat = await handlers.get('fs:stat')(event, approved);
    expect(stat).toEqual(expect.objectContaining({
      size: expect.any(Number),
      mtimeMs: expect.any(Number),
      ctimeMs: expect.any(Number),
      isFile: true,
      isDirectory: false,
    }));
    expect(stat).not.toHaveProperty('ok');

    await denyByPolicy('fs:stat', blocked);
  });
 
  test('fs:unlink deletes approved file and throws for denied path', async () => {
    const approved = path.join(approvedRoot, 'delete-me.txt');
    const blocked = path.join(blockedRoot, 'read-me.txt');
 
    await expect(handlers.get('fs:unlink')(event, approved)).resolves.toBe(true);
    expect(fs.existsSync(approved)).toBe(false);
 
    await denyByPolicy('fs:unlink', blocked);
    expect(fs.existsSync(blocked)).toBe(true);
  });
 
  test('fs:copyFile copies only when both source and destination are approved', async () => {
    const approvedSrc = path.join(approvedRoot, 'copy-src.txt');
    const approvedDst = path.join(approvedRoot, 'copied', 'copy-dst.txt');
    const blockedSrc = path.join(blockedRoot, 'copy-src.txt');
    const blockedDst = path.join(blockedRoot, 'copy-dst.txt');
 
    await expect(handlers.get('fs:copyFile')(event, approvedSrc, approvedDst)).resolves.toBe(true);
    expect(fs.readFileSync(approvedDst, 'utf8')).toBe('copy-source');

    await denyByPolicy('fs:copyFile', approvedSrc, blockedDst);
    expect(fs.existsSync(blockedDst)).toBe(false);

    await denyByPolicy('fs:copyFile', blockedSrc, approvedDst);
  });

  test('denies fs:readTextFile from untrusted sender before path checks', async () => {
    const approved = path.join(approvedRoot, 'read-me.txt');

    assertTrustedIpcSender.mockImplementation(() => {
      const err = new Error('Blocked fs:readTextFile from untrusted origin: https://evil.example');
      err.code = 'ERR_UNTRUSTED_ORIGIN';
      throw err;
    });

    await expect(handlers.get('fs:readTextFile')(event, approved, 'utf8')).rejects.toMatchObject({ code: 'ERR_UNTRUSTED_ORIGIN' });
    expect(isPathAllowed).not.toHaveBeenCalled();
   });

  test('sync channel returns sensitive permission error and logs audit details', () => {
    const sensitive = path.join(approvedRoot, 'config', 'secrets.bin');
    const syncEvent = { sender: { id: 321 }, senderFrame: { url: 'app://renderer' }, returnValue: null };
    const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});

    evaluatePathAccess.mockReturnValue({ allowed: false, reason: 'sensitive_path_denied', sensitivePath: 'config/secrets.bin' });

    listeners.get('fs:readTextFileSync')(syncEvent, sensitive, 'utf8');

    expect(syncEvent.returnValue).toEqual({
      ok: false,
      error: 'permission_denied_sensitive_path:config/secrets.bin',
    });
    expect(warnSpy).toHaveBeenCalledWith(
      '[fsAccess.handlers] filesystem access denied',
      expect.objectContaining({
        channel: 'fs:readTextFileSync',
        reason: 'sensitive_path_denied',
      })
    );
    warnSpy.mockRestore();
  });
 });
