const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');

const runtimeAssetService = require('../services/runtimeAssetService');
const {
  setupRuntimeAssetTest,
  createHttpServer,
  closeServer,
  sha256Hex,
  sleep
} = require('./helpers/runtimeAssetTestUtils');

test('runtime asset service: concurrent installs dedupe and fan out progress', async (t) => {
  await t.test('coalesces concurrent ensureAsset calls into one download and notifies joined callers', async () => {
    const payload = Buffer.alloc(12 * 1024, 'z');
    let requestCount = 0;

    const { server, origin } = await createHttpServer(async (req, res) => {
      requestCount += 1;
      res.writeHead(200, {
        'Content-Type': 'application/octet-stream',
        'Content-Length': String(payload.length)
      });

      const chunkSize = 1024;
      for (let offset = 0; offset < payload.length; offset += chunkSize) {
        if (res.destroyed || res.writableEnded) return;
        res.write(payload.slice(offset, offset + chunkSize));
        await sleep(10);
      }
      if (!res.destroyed && !res.writableEnded) res.end();
    });

    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'concurrent.file': {
          type: 'file',
          installPath: 'concurrent/asset.bin',
          downloadUrl: `${origin}/concurrent.file`,
          sha256: sha256Hex(payload)
        }
      }
    });

    try {
      const firstEvents = [];
      const secondEvents = [];

      const first = runtimeAssetService.ensureAsset('concurrent.file', {
        onProgress(event) {
          firstEvents.push({ phase: event.phase, status: event.status });
        }
      });

      await sleep(20);

      const second = runtimeAssetService.ensureAsset('concurrent.file', {
        onProgress(event) {
          secondEvents.push({ phase: event.phase, status: event.status });
        }
      });

      const [firstResult, secondResult] = await Promise.all([first, second]);

      assert.equal(firstResult.path, secondResult.path);
      assert.equal(firstResult.source, 'download');
      assert.equal(secondResult.source, 'download');
      assert.equal(requestCount, 1);
      assert.equal(fs.readFileSync(firstResult.path).length, payload.length);
      assert.ok(firstEvents.some(event => event.phase === 'download' && event.status === 'progress'));
      assert.ok(secondEvents.length > 0);
      assert.ok(secondEvents.some(event => event.phase === 'download' || event.phase === 'complete'));
    } finally {
      await closeServer(server);
      ctx.restore();
    }
  });
});
