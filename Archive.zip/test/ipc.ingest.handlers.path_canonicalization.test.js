/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');

const mockApprovedRoots = new Set();


jest.mock('../utils/trustedIpcSender', () => ({
  assertTrustedIpcSender: jest.fn()
}));

jest.mock('../services/licenseService', () => ({
  isFeatureEnabled: jest.fn(() => true)
}));

jest.mock('../modules/clone', () => ({
  calculateCloneBytes: jest.fn(async () => ({ success: true })),
  runClone: jest.fn(async () => ({ success: true })),
  cancelClone: jest.fn()
}));

jest.mock('../utils/ipcPathGuards', () => ({
  assertApprovedPath: jest.fn((_, p) => p),
  assertApprovedPaths: jest.fn((_, paths) => {
    const mockPath = require('path');
    for (const raw of (paths || [])) {
      const resolvedCandidate = mockPath.resolve(String(raw || '').trim());
      let candidate = resolvedCandidate;
      try {
        const mockFs = require('fs');
        const realpathNative = mockFs.realpathSync.native;
        candidate = typeof realpathNative === 'function'
          ? realpathNative(resolvedCandidate)
          : mockFs.realpathSync(resolvedCandidate);
      } catch {
        candidate = resolvedCandidate;
      }
      const allowed = Array.from(mockApprovedRoots).some(root => {
        const relative = mockPath.relative(root, candidate);
        return relative === '' || (!relative.startsWith('..') && !mockPath.isAbsolute(relative));
      });
      if (!allowed) {
        throw new Error(`PATH_NOT_APPROVED:${candidate}`);
      }
    }
  }),
  extractAbsolutePathsFromObject: jest.fn(() => []),
  toLocalPathIfFileUrl: jest.fn((v) => v)
}));

const registerIngestHandlers = require('../ipc/ingest.handlers');

function buildIpcMain() {
  const handlers = new Map();
  return {
    handlers,
    ipcMain: {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn))
    }
  };
}

describe('ipc/ingest.handlers canonical path validation', () => {
  let tempRoot;
  let approvedRoot;
  let outsideRoot;

  beforeEach(() => {
    tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-ingest-ipc-'));
    approvedRoot = path.join(tempRoot, 'approved');
    outsideRoot = path.join(tempRoot, 'outside');
    fs.mkdirSync(approvedRoot, { recursive: true });
    fs.mkdirSync(outsideRoot, { recursive: true });
    mockApprovedRoots.clear();

    const resolvedApprovedRoot = path.resolve(approvedRoot);
    mockApprovedRoots.add(resolvedApprovedRoot);
    try {
      const realpathNative = fs.realpathSync.native;
      const canonicalApprovedRoot = typeof realpathNative === 'function'
        ? realpathNative(resolvedApprovedRoot)
        : fs.realpathSync(resolvedApprovedRoot);
      mockApprovedRoots.add(canonicalApprovedRoot);
    } catch {
      // Ignore canonical root if filesystem cannot resolve it.
    }
  });

  afterEach(() => {
    mockApprovedRoots.clear();
    fs.rmSync(tempRoot, { recursive: true, force: true });
    jest.clearAllMocks();
  });

  test('rejects approved symlink path that canonicalizes outside approved roots', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerIngestHandlers(ipcMain);

    const outsideFile = path.join(outsideRoot, 'clip.mov');
    fs.writeFileSync(outsideFile, 'outside');

    const symlinkPath = path.join(approvedRoot, 'outside-link.mov');
    fs.symlinkSync(outsideFile, symlinkPath);

    const result = await handlers.get('calculate-ingest-bytes')(
      { sender: { id: 17 } },
      { source: symlinkPath, destination: path.join(approvedRoot, 'dest') }
    );

    expect(result.success).toBe(false);
    expect(result.error).toContain('PATH_NOT_APPROVED');
    expect(result.error).toContain(path.resolve(outsideFile));
  });

  test('allows approved non-symlink path', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerIngestHandlers(ipcMain);

    const sourceFile = path.join(approvedRoot, 'clip.mov');
    fs.writeFileSync(sourceFile, 'ok');

    const result = await handlers.get('calculate-ingest-bytes')(
      { sender: { id: 23 } },
      { source: sourceFile, destination: path.join(approvedRoot, 'dest') }
    );

    expect(result.success).toBe(true);
    expect(result.fileCount).toBe(1);
    expect(result.total).toBe(2);
  });

  test('allows non-existent destination path under approved roots', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerIngestHandlers(ipcMain);

    const sourceFile = path.join(approvedRoot, 'clip.mov');
    fs.writeFileSync(sourceFile, 'ok');
    const destinationPath = path.join(approvedRoot, 'new', 'nested', 'dest');

    const result = await handlers.get('calculate-ingest-bytes')(
      { sender: { id: 42 } },
      { source: sourceFile, destination: destinationPath }
    );

    expect(fs.existsSync(destinationPath)).toBe(false);
    expect(result.success).toBe(true);
    expect(result.fileCount).toBe(1);
  });
});
