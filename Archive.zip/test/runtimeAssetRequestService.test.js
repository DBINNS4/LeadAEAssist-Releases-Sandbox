const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const runtimeAssetRequestService = require('../services/runtimeAssetRequestService');

function makeTempDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'leadae-runtime-asset-request-'));
}

test('runtime asset request service resolves Whisper requests from language', () => {
  const resolvedEnglish = runtimeAssetRequestService.resolveRuntimeAssetRequest({ feature: 'whisper', language: 'en' }, { isPackaged: false });
  const resolvedFrench = runtimeAssetRequestService.resolveRuntimeAssetRequest({ feature: 'whisper', language: 'fr' }, { isPackaged: false });

  assert.equal(resolvedEnglish.assetId, 'whisper.model.base.en');
  assert.equal(resolvedEnglish.modelFile, 'ggml-base.en.bin');
  assert.equal(resolvedFrench.assetId, 'whisper.model.base.multi');
  assert.equal(resolvedFrench.modelFile, 'ggml-base.bin');
});

test('runtime asset request service resolves Chromium request for darwin/arm64', () => {
  const resolved = runtimeAssetRequestService.resolveRuntimeAssetRequest(
    { feature: 'chromium', platform: 'darwin', arch: 'arm64' },
    { isPackaged: false }
  );

  assert.equal(resolved.assetId, 'puppeteer.cache.darwin.arm64');
  assert.equal(resolved.kind, 'chromium');
  assert.equal(resolved.platform, 'darwin');
  assert.equal(resolved.arch, 'arm64');
  assert.match(resolved.descriptorSummary.entrypoint, /Google Chrome for Testing/);
});

test('runtime asset request service reports installed Whisper model from userData/assets', () => {
  const userDataPath = makeTempDir();
  const resolved = runtimeAssetRequestService.resolveRuntimeAssetRequest({ feature: 'whisper', language: 'en' }, { isPackaged: false });
  const installedPath = path.join(userDataPath, 'assets', 'whisper', 'models', 'ggml-base.en.bin');

  fs.mkdirSync(path.dirname(installedPath), { recursive: true });
  fs.writeFileSync(installedPath, 'model', 'utf8');

  const snapshot = runtimeAssetRequestService.resolveInstalledRuntimeAssetSnapshot(resolved, {
    isPackaged: false,
    userDataPath,
    offline: false
  });

  assert.equal(snapshot.installed, true);
  assert.equal(snapshot.ready, true);
  assert.equal(snapshot.modelPath, installedPath);
  assert.equal(snapshot.path, installedPath);
});

test('runtime asset request service reports installed Chromium executable using manifest entrypoint', () => {
  const userDataPath = makeTempDir();
  const resolved = runtimeAssetRequestService.resolveRuntimeAssetRequest(
    { feature: 'chromium', platform: 'darwin', arch: 'arm64' },
    { isPackaged: false }
  );
  const assetRoot = path.join(userDataPath, 'assets', 'puppeteer', 'cache', 'chrome-127.0.6533.88', 'darwin-arm64');
  const executablePath = path.join(
    assetRoot,
    'chrome',
    'mac_arm-127.0.6533.88',
    'chrome-mac-arm64',
    'Google Chrome for Testing.app',
    'Contents',
    'MacOS',
    'Google Chrome for Testing'
  );

  fs.mkdirSync(path.dirname(executablePath), { recursive: true });
  fs.writeFileSync(executablePath, '#!/bin/sh\nexit 0\n', { mode: 0o755 });

  const snapshot = runtimeAssetRequestService.resolveInstalledRuntimeAssetSnapshot(resolved, {
    isPackaged: false,
    userDataPath,
    offline: false
  });

  assert.equal(snapshot.installed, true);
  assert.equal(snapshot.ready, true);
  assert.equal(snapshot.path, assetRoot);
  assert.equal(snapshot.executablePath, executablePath);
});
