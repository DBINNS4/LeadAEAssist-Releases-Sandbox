// tests/mcc_derived608_queue_preserve.test.js
// Regression: derived 608 scheduling must NOT discard queued preload for the next cue
// when emitting EDM (erase displayed memory) at the previous cue's out-point.
//
// Run (Node 18+):
//   node --test tests/mcc_derived608_queue_preserve.test.js

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { generateMCC, verifyMCC } = require('../modules/sccEncoder');
const { decodeMccText } = require('../modules/mccDecoder');
const { framesToSeconds } = require('../utils/timeUtils');

function normText(s) {
  return String(s || '').replace(/\s+/g, ' ').trim();
}

test('MCC derived 608: EDM must not discard queued preload for next cue', () => {
  const fps = 29.97;
  const dropFrame = true;

  // Cue 1 is very short. Cue 2 is long (two full 32-col lines).
  // Derived 608 preload for cue 2 begins immediately after cue 1 is shown.
  // If EDM at cue 1 end resets the 608 queue, cue 2 will be truncated.
  const segments = [
    { start: framesToSeconds(30, fps), end: framesToSeconds(40, fps), text: 'Hi.' },
    { start: framesToSeconds(100, fps), end: framesToSeconds(160, fps), text: 'Long cue (708 canonical).' }
  ];

  const line1 = '01234567890123456789012345678901'; // 32 chars
  const line2 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEF'; // 32 chars

  const derived608Cues = [
    { sourceIndex: 0, startFrame: 30, endFrame: 40, text: 'Hi.', lines: ['Hi.'] },
    { sourceIndex: 1, startFrame: 100, endFrame: 160, text: `${line1}\n${line2}`, lines: [line1, line2] }
  ];

  const mcc = generateMCC(segments, {
    fps,
    dropFrame,
    include608Compatibility: true,
    authoringModel: 'true708',
    derived608Cues
  });

  const v = verifyMCC(mcc, {
    strictPayloadParse: true,
    checkAncChecksum: true,
    checkCdpChecksum: true,
    checkCdpLength: true,
    checkCcCount: true,
    checkSequence: true
  });

  assert.equal(v.ok, true, `verifyMCC failed: ${JSON.stringify(v.errors?.slice(0, 10) || [], null, 2)}`);

  const decoded608 = decodeMccText(mcc, { fps, dropFrame, force608Compatibility: true });
  assert.equal(decoded608.kind, 'cea608');

  const cues608 = (decoded608.cues || []).filter(c => normText(c.text));
  assert.equal(cues608.length, 2, `Expected 2 decoded 608 cues, got ${cues608.length}`);

  const expected = normText(`${line1} ${line2}`);
  assert.equal(normText(cues608[1].text), expected, 'Derived 608 cue[1] text was truncated (queue was reset/discarded)');
});
