/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');
const { runSequentialDriveTest } = require('../modules/diskBenchmark');

const fsp = fs.promises;

describe('runSequentialDriveTest cache mitigation metadata', () => {
  let tempRoot;

  beforeEach(async () => {
    tempRoot = await fsp.mkdtemp(path.join(os.tmpdir(), 'lead-seq-cache-'));
  });

  test('returns stable string result fields and cacheMitigation metadata', async () => {
    const result = await runSequentialDriveTest({
      drivePath: tempRoot,
      testSizeMiB: 1,
      iterations: 3,
      senderTag: 'jest'
    });

    expect(result.success).toBe(true);
    expect(typeof result.write).toBe('string');
    expect(typeof result.read).toBe('string');
    expect(result.cacheMitigation).toEqual(expect.objectContaining({
      attempted: true,
      strategy: 'expanded_working_set_with_platform_drop',
      platform: process.platform,
      fullyApplied: expect.any(Boolean)
    }));
    expect(result.cacheMitigation.workingSetFiles).toBeGreaterThanOrEqual(3);
  });
});
