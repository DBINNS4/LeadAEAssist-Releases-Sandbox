'use strict';

const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');

function encryptWithKey(key, text) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, encrypted]);
}

describe('modules/secureStore fallback key behavior', () => {
  const ORIGINAL_ENV = process.env;

  beforeEach(() => {
    jest.resetModules();
    process.env = { ...ORIGINAL_ENV };
  });

  afterAll(() => {
    process.env = ORIGINAL_ENV;
  });

  function setupStore(userDataDir) {
    process.env.USER_DATA_PATH = userDataDir;
    jest.doMock('electron', () => ({
      safeStorage: {
        isEncryptionAvailable: jest.fn(() => false),
        encryptString: jest.fn((text) => Buffer.from(text, 'utf8')),
        decryptString: jest.fn((buf) => Buffer.from(buf).toString('utf8'))
      }
    }));
    return require('../modules/secureStore');
  }

  test('writes and reads fallback secrets with persisted key and FB2 tag', () => {
    const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'secure-store-test-'));
    const store = setupStore(userDataDir);

    expect(store.saveSecret('api', 'value-1')).toBe(true);
    expect(store.loadSecret('api')).toBe('value-1');

    const secretsPath = path.join(userDataDir, 'config', 'secrets.bin');
    const keyPath = path.join(userDataDir, 'config', 'secrets.fallback.key');
    const payload = fs.readFileSync(secretsPath, 'utf8');
    const keyBytes = Buffer.from(fs.readFileSync(keyPath, 'utf8').trim(), 'base64');

    expect(payload.startsWith('FB2:')).toBe(true);
    expect(keyBytes.length).toBe(32);
  });

  test('migrates FB1 fallback payloads to FB2 on first successful read', () => {
    const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'secure-store-test-'));
    const store = setupStore(userDataDir);

    expect(store.saveSecret('seed', 'ok')).toBe(true);

    const keyPath = path.join(userDataDir, 'config', 'secrets.fallback.key');
    const secretsPath = path.join(userDataDir, 'config', 'secrets.bin');
    const key = Buffer.from(fs.readFileSync(keyPath, 'utf8').trim(), 'base64');

    const plaintext = JSON.stringify({ migratedKey: 'migrated-value' });
    const fb1Cipher = encryptWithKey(key, plaintext).toString('base64');
    fs.writeFileSync(secretsPath, `FB1:${fb1Cipher}`, 'utf8');

    expect(store.loadSecret('migratedKey')).toBe('migrated-value');
    expect(fs.readFileSync(secretsPath, 'utf8').startsWith('FB2:')).toBe(true);
  });

  test('returns null for wrong-key fallback ciphertext', () => {
    const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'secure-store-test-'));
    const store = setupStore(userDataDir);

    expect(store.saveSecret('secret', 'top-secret')).toBe(true);

    const keyPath = path.join(userDataDir, 'config', 'secrets.fallback.key');
    fs.writeFileSync(keyPath, crypto.randomBytes(32).toString('base64'), 'utf8');

    jest.resetModules();
    const reloaded = setupStore(userDataDir);
    expect(reloaded.loadSecret('secret')).toBeNull();
  });

  test('fails saveSecret when fallback key permissions cannot be set', () => {
    const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'secure-store-test-'));

    process.env.USER_DATA_PATH = userDataDir;
    jest.doMock('electron', () => ({
      safeStorage: {
        isEncryptionAvailable: jest.fn(() => false),
        encryptString: jest.fn((text) => Buffer.from(text, 'utf8')),
        decryptString: jest.fn((buf) => Buffer.from(buf).toString('utf8'))
      }
    }));

    jest.doMock('fs', () => {
      const realFs = jest.requireActual('fs');
      return {
        ...realFs,
        chmodSync: jest.fn((target) => {
          if (String(target).endsWith('secrets.fallback.key')) {
            const err = new Error('permission denied');
            err.code = 'EACCES';
            throw err;
          }
          return realFs.chmodSync(target, 0o600);
        })
      };
    });

    const secureStore = require('../modules/secureStore');
    expect(secureStore.saveSecret('api', 'blocked')).toBe(false);
  });

test('keeps legacy state intact when migration write fails and retries safely later', async () => {
  jest.dontMock('fs');

  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'secure-store-test-'));
  const statePath = path.join(userDataDir, 'config', 'state.json');
  fs.mkdirSync(path.dirname(statePath), { recursive: true });

  const initialState = {
    preferences: {
      apiKey: 'legacy-write-fail-key',
      theme: 'dark'
    }
  };
  fs.writeFileSync(statePath, JSON.stringify(initialState, null, 2), 'utf8');

  process.env.USER_DATA_PATH = userDataDir;
  jest.doMock('electron', () => ({
    safeStorage: {
      isEncryptionAvailable: jest.fn(() => false),
      encryptString: jest.fn((text) => Buffer.from(text, 'utf8')),
      decryptString: jest.fn((buf) => Buffer.from(buf).toString('utf8'))
    }
  }));

  jest.doMock('../utils/fsSafe', () => {
    const realFsSafe = jest.requireActual('../utils/fsSafe');
    return {
      ...realFsSafe,
      atomicWriteJson: jest.fn(async () => {
        const err = new Error('disk full');
        err.code = 'ENOSPC';
        throw err;
      })
    };
  });

  const warned = jest.spyOn(console, 'warn').mockImplementation(() => {});
  const storeWithWriteFailure = require('../modules/secureStore');

  await expect(storeWithWriteFailure.getAiApiKey({ statePath })).resolves.toBe('legacy-write-fail-key');

  const afterFailedMigrationState = JSON.parse(fs.readFileSync(statePath, 'utf8'));
  expect(afterFailedMigrationState).toEqual(initialState);
  expect(storeWithWriteFailure.loadSecret('aiApiKey')).toBe('legacy-write-fail-key');
  expect(warned).toHaveBeenCalledWith(
    expect.stringContaining('Failed to finalize legacy AI API key migration write; keeping legacy state for retry:'),
    expect.any(String)
  );

  warned.mockRestore();

  jest.resetModules();
  jest.dontMock('../utils/fsSafe');
  const storeRetry = setupStore(userDataDir);

  await expect(storeRetry.getAiApiKey({ statePath })).resolves.toBe('legacy-write-fail-key');

  const migratedState = JSON.parse(fs.readFileSync(statePath, 'utf8'));
  expect(migratedState.preferences.apiKey).toBeUndefined();
  expect(migratedState.preferences.apiKeyStored).toBe(true);
  expect(migratedState.preferences.theme).toBe('dark');
  expect(storeRetry.loadSecret('aiApiKey')).toBe('legacy-write-fail-key');
});

});
