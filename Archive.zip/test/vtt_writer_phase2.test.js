'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { generateVTT } = require('../ai/vttWriter');

function tsToMs(ts) {
  const m = String(ts).match(/^(\d{2}):(\d{2}):(\d{2})\.(\d{3})$/);
  if (!m) throw new Error(`bad timestamp: ${ts}`);
  const hh = parseInt(m[1], 10);
  const mm = parseInt(m[2], 10);
  const ss = parseInt(m[3], 10);
  const ms = parseInt(m[4], 10);
  return (((hh * 60 + mm) * 60) + ss) * 1000 + ms;
}

function parseCues(vtt) {
  const lines = String(vtt || '').replace(/\r\n?/g, '\n').split('\n');
  const cues = [];

  let i = 0;
  while (i < lines.length) {
    const line = lines[i].trimEnd();

    // Find a timestamp line.
    const tm = line.match(/^(\d{2}:\d{2}:\d{2}\.\d{3})\s+-->\s+(\d{2}:\d{2}:\d{2}\.\d{3})(?:\s+.*)?$/);
    if (!tm) {
      i += 1;
      continue;
    }

    const start = tsToMs(tm[1]);
    const end = tsToMs(tm[2]);

    // Collect text until blank line.
    const textLines = [];
    i += 1;
    while (i < lines.length && lines[i].trim() !== '') {
      textLines.push(lines[i]);
      i += 1;
    }

    cues.push({ start, end, textLines });
    i += 1;
  }

  return cues;
}

test('Phase 2 VTT: speaker label cohesion avoids orphan "SPEAKER:" line when space allows', () => {
  const vtt = generateVTT([
    { start: 0, end: 2, speaker: 'bob', text: 'Hello world this is a test' }
  ], {
    includeSpeakerNames: true,
    maxCharsPerLine: 14,
    maxLinesPerBlock: 2,
    maxDurationSeconds: 6.0,
    // Keep defaults for timing assist.
  });

  const cues = parseCues(vtt);
  assert.equal(cues.length >= 1, true);

  const firstLine = String(cues[0].textLines[0] || '').trim();
  assert.equal(firstLine.startsWith('Bob:'), true);
  assert.notEqual(firstLine, 'Bob:');
  assert.equal(/\bBob:\s+\S+/.test(firstLine), true);
});

test('Phase 2 VTT: strips internal tags and escapes unsafe characters', () => {
  const vtt = generateVTT([
    { start: 0, end: 2, text: '{row:15}{col:0}{Wh}HELLO < & >' }
  ], {
    maxCharsPerLine: 42,
    maxLinesPerBlock: 2,
    maxDurationSeconds: 6.0
  });

  assert.equal(vtt.includes('{row'), false);
  assert.equal(vtt.includes('{col'), false);
  assert.equal(vtt.includes('{Wh}'), false);

  // Ensure escaping happens.
  assert.equal(vtt.includes('&lt;'), true);
  assert.equal(vtt.includes('&amp;'), true);
  assert.equal(vtt.includes('&gt;'), true);
});

test('Phase 2 VTT: CPS-aware end-extension uses available gap and respects policy cap', () => {
  const dense = 'A'.repeat(40);
  const vtt = generateVTT([
    { start: 0, end: 1, text: dense },
    { start: 5, end: 6, text: 'next' }
  ], {
    maxCharsPerLine: 42,
    maxLinesPerBlock: 2,
    maxDurationSeconds: 6.0,
    // Defaults: maxCps=20, allowTimeExtension=true, maxEndExtensionSeconds=1.5
  });

  const cues = parseCues(vtt);
  assert.equal(cues.length >= 1, true);

  // First cue should extend from 1s to ~2s to satisfy 40 chars @ 20 cps.
  assert.equal(cues[0].start, 0);
  assert.equal(cues[0].end, 2000);
});

test('Phase 2 VTT: split cues maintain a minimum readable duration when total time allows', () => {
  const long = 'One two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen.';
  const vtt = generateVTT([
    { start: 0, end: 4, text: long }
  ], {
    maxCharsPerLine: 16,
    maxLinesPerBlock: 2,
    maxDurationSeconds: 6.0,
    minSplitDurationSeconds: 0.5
  });

  const cues = parseCues(vtt);
  assert.equal(cues.length >= 2, true);

  for (const c of cues.slice(0, 2)) {
    assert.equal(c.end > c.start, true);
    assert.equal((c.end - c.start) >= 500, true);
    assert.equal(c.textLines.length <= 2, true);
  }
});
