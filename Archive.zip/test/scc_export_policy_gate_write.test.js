'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { writeSCC, writeAllOutputs } = require('../ai/outputWriters');

test('SCC exportPolicy=gate_write writes SCC+report but fails the job on QC failure', async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-scc-gatewrite-'));

  // The SCC writer only uses the input path for naming.
  const fakeIn = path.join(tmp, 'input.mp4');

  const wrapped = {
    segments: [
      // Deliberately too short: duration 0.5s.
      { start: 0.0, end: 0.5, text: 'HELLO WORLD' }
    ],
    system: { fps: 29.97, dropFrame: true },
    metadata: { durationSeconds: 10 }
  };

  const cfg = {
    outputPath: tmp,
    outputFormats: { scc: true },
    dropFrame: true,
    fpsOverride: 29.97,
    startTC: '01:00:00;00',
    maxCharsPerLine: 28,
    maxLinesPerBlock: 2,
    maxDurationSeconds: 6.0,
    sccOptions: {
      exportPolicy: 'gate_write',
      startTc: '01:00:00;00',
      allowNdf: false,
      alignment: 'center',
      channel: 1,
      rowPolicy: 'bottom2',
      safeMargins: { left: 0, right: 0 },
      repeatControlCodes: true,
      repeatPreambleCodes: true,
      strictCharacterEncoding: false,
      // Draft salvage remains ON in gate_write; strict deliverable turns it off.
      draft: true,
      qc: {
        // Force a content QC failure: duration 0.5s < minDurationSec 2.0s
        minDurationSec: 2.0,
        maxCps: 20,
        maxWpm: 180,
        minGapSec: 0.1
      }
    }
  };

  // Expected filenames (first write in an empty dir).
  const expectedScc = path.join(tmp, 'input.scc');
  const expectedReport = path.join(tmp, 'input.scc.report.txt');

  try {
    await assert.rejects(
      async () => {
        await writeSCC(wrapped, fakeIn, cfg);
      },
      (err) => {
        assert.ok(err);
        assert.match(String(err.message), /output was written for editing/i);
        assert.match(String(err.message), /SCC:\s*/i);
        assert.match(String(err.message), /Report:\s*/i);
        return true;
      }
    );

    assert.equal(
      fs.existsSync(expectedScc),
      true,
      'SCC file should still be written in gate_write mode'
    );
    assert.equal(
      fs.existsSync(expectedReport),
      true,
      'SCC report should still be written in gate_write mode'
    );

    // Integration: the overall writer harness should also fail the job in gate_write mode.
    await assert.rejects(async () => {
      await writeAllOutputs(wrapped, fakeIn, cfg);
    });
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
});
