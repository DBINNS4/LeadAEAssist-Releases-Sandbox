/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');

describe('bridgeAuthService credential persistence', () => {
  let tempRoot;
  let mockGetCredentials;

  beforeEach(() => {
    jest.resetModules();
    tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-bridge-auth-'));
    mockGetCredentials = jest.fn();
  });

  afterEach(() => {
    fs.rmSync(tempRoot, { recursive: true, force: true });
  });

  test('writes bridge credentials atomically and enforces owner-only file permissions on POSIX', async () => {
    const userDataDir = path.join(tempRoot, 'userdata');
    fs.mkdirSync(userDataDir, { recursive: true });

    jest.doMock('electron', () => ({
      app: {
        getPath: jest.fn(() => userDataDir)
      }
    }));

    mockGetCredentials.mockResolvedValue({
        token: 'token-123',
        port: 3030,
        expiresAt: Date.now() + 5 * 60 * 1000
      });

    jest.doMock('../services/bridgeServerService', () => ({
      getCredentials: mockGetCredentials
    }));

    const { getBridgeInfo } = require('../services/bridgeAuthService');
    const result = await getBridgeInfo();

    const bridgeDir = path.join(userDataDir, 'bridge');
    const bridgeFile = path.join(bridgeDir, 'bridge.json');

    expect(result.filePath).toBe(bridgeFile);
    expect(fs.existsSync(bridgeFile)).toBe(true);

    const parsed = JSON.parse(fs.readFileSync(bridgeFile, 'utf8'));
    expect(parsed).toMatchObject({
      token: 'token-123',
      port: 3030
    });

    const tempArtifacts = fs.readdirSync(bridgeDir).filter(name => name.includes('.tmp'));
    expect(tempArtifacts).toEqual([]);

    if (process.platform !== 'win32') {
      const mode = fs.statSync(bridgeFile).mode & 0o777;
      expect(mode).toBe(0o600);
    }
  });

  test('rewrites bridge.json when active port changes before token expiry', async () => {
    const userDataDir = path.join(tempRoot, 'userdata');
    fs.mkdirSync(userDataDir, { recursive: true });

    jest.doMock('electron', () => ({
      app: {
        getPath: jest.fn(() => userDataDir)
      }
    }));

    const expiresAt = Date.now() + 10 * 60 * 1000;
    mockGetCredentials
      .mockResolvedValueOnce({ token: 'token-123', port: 32123, expiresAt })
      .mockResolvedValueOnce({ token: 'token-123', port: 45678, expiresAt })
      .mockResolvedValue({ token: 'token-123', port: 45678, expiresAt });

    jest.doMock('../services/bridgeServerService', () => ({
      getCredentials: mockGetCredentials
    }));

    const { getBridgeInfo } = require('../services/bridgeAuthService');
    await getBridgeInfo();
    const second = await getBridgeInfo();

    const bridgeFile = path.join(userDataDir, 'bridge', 'bridge.json');
    const parsed = JSON.parse(fs.readFileSync(bridgeFile, 'utf8'));

    expect(second.port).toBe(45678);
    expect(parsed.port).toBe(45678);
    expect(mockGetCredentials.mock.calls.length).toBeGreaterThanOrEqual(2);
  });

  test('returns structured error for undefined or malformed credentials without throwing', async () => {
    const userDataDir = path.join(tempRoot, 'userdata');
    fs.mkdirSync(userDataDir, { recursive: true });

    jest.doMock('electron', () => ({
      app: {
        getPath: jest.fn(() => userDataDir)
      }
    }));

    mockGetCredentials
      .mockResolvedValueOnce(undefined)
      .mockResolvedValueOnce({ token: 'token-only' });

    jest.doMock('../services/bridgeServerService', () => ({
      getCredentials: mockGetCredentials
    }));

    const { getBridgeInfo } = require('../services/bridgeAuthService');

    await expect(getBridgeInfo()).resolves.toMatchObject({
      ok: false,
      error: 'bridge_credentials_invalid_payload'
    });

    await expect(getBridgeInfo()).resolves.toMatchObject({
      ok: false,
      error: 'bridge_credentials_invalid_payload'
    });

    const bridgeFile = path.join(userDataDir, 'bridge', 'bridge.json');
    expect(fs.existsSync(bridgeFile)).toBe(false);
  });

});
