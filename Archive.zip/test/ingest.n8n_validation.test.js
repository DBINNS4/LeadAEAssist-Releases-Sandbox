/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');

jest.mock('electron', () => ({}));

describe('validateIngestConfig — n8n scoped IPv6 handling', () => {
  const scopedHosts = ['fe80::1%en0', 'fd00::1%lo0'];

  test.each(scopedHosts)('rejects scoped IPv6 host %s when private targets are not allowed', async host => {
    const { validateIngestConfig } = require('../modules/ingest');

    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-n8n-'));
    try {
      const source = path.join(tmpRoot, 'source');
      const destination = path.join(tmpRoot, 'dest');
      fs.mkdirSync(source, { recursive: true });
      fs.mkdirSync(destination, { recursive: true });

      const errors = await validateIngestConfig({
        source,
        destination,
        enableN8N: true,
        n8nUrl: `http://[${host}]/hook`,
        n8nAllowPrivate: false,
      });

      expect(errors.join('\n')).toContain('n8n URL cannot target localhost or private networks');
    } finally {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });

  test.each(scopedHosts)('allows scoped IPv6 host %s when private targets are allowed', async host => {
    const { validateIngestConfig } = require('../modules/ingest');

    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-n8n-'));
    try {
      const source = path.join(tmpRoot, 'source');
      const destination = path.join(tmpRoot, 'dest');
      fs.mkdirSync(source, { recursive: true });
      fs.mkdirSync(destination, { recursive: true });

      const errors = await validateIngestConfig({
        source,
        destination,
        enableN8N: true,
        n8nUrl: `http://[${host}]/hook`,
        n8nAllowPrivate: true,
      });

      expect(errors).toHaveLength(0);
    } finally {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });
});
