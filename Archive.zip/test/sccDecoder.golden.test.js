'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

const { decodeSccFile } = require('../modules/sccDecoder');
const { SCC_MODEL } = require('../modules/sccEncoder');

const FIXTURE = (name) => path.join(__dirname, 'fixtures', name);
const LF = String.fromCharCode(10);

function frames(sec, fps) {
  return Math.floor(sec * fps);
}

test('SCC pop-on: EOC swaps non-displayed into displayed and yields a cue', () => {
  const fps = 30;
  const doc = decodeSccFile(FIXTURE('popup_hi.scc'), {
    fps,
    model: SCC_MODEL,
    modelOverflowPolicy: 'warn',
    shiftToZero: true
  });

  assert.equal(doc.cues.length, 1);
  assert.equal(doc.cues[0].lines.join(LF), 'HI');
  assert.equal(frames(doc.cues[0].start, fps), 30);
  assert.equal(frames(doc.cues[0].end, fps), 60);
  assert.ok(!doc.modelIssues || doc.modelIssues.length === 0);
});

test('SCC pop-on: 3-row grid exceeds model maxLinesPerCue=2 and truncates with warning', () => {
  const fps = 30;
  const doc = decodeSccFile(FIXTURE('popup_overflow_three_lines.scc'), {
    fps,
    model: SCC_MODEL,
    modelOverflowPolicy: 'warn',
    shiftToZero: true
  });

  assert.equal(doc.cues.length, 1);
  assert.deepEqual(doc.cues[0].lines, ['LINE2', 'LINE3']);
  assert.ok(Array.isArray(doc.modelIssues) && doc.modelIssues.length >= 1);
  assert.ok(doc.modelIssues.some((i) => i.code === 'MODEL_MAX_LINES_EXCEEDED'));
  assert.ok(Array.isArray(doc.importWarnings) && doc.importWarnings.some((w) => String(w).includes('maxLinesPerCue')));
});

test('SCC pop-on: modelOverflowPolicy=error throws on model overflow', () => {
  const fps = 30;
  assert.throws(() => {
    decodeSccFile(FIXTURE('popup_overflow_three_lines.scc'), {
      fps,
      model: SCC_MODEL,
      modelOverflowPolicy: 'error',
      shiftToZero: true
    });
  }, /MODEL_MAX_LINES_EXCEEDED/);
});
