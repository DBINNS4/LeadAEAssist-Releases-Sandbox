function buildTranscribeDOM() {
  document.body.innerHTML = `
    <div id="transcribe">
      <button id="transcribe-select-files"></button>
      <textarea id="transcribe-files"></textarea>
      <input id="transcribe-watch-folder-path" />
      <button id="transcribe-output-select"></button>
      <input id="transcribe-output-path" value="" />
      <button id="start-transcribe"></button>
      <button id="reset-transcribe"></button>
      <pre id="transcribe-log-output"></pre>
      <textarea id="transcribe-job-preview-box"></textarea>
      <button id="transcribe-save-config"></button>
      <button id="transcribe-load-config"></button>
      <input type="checkbox" id="transcribe-enable-n8n" />
      <input id="transcribe-n8n-url" />
      <input type="checkbox" id="transcribe-n8n-allow-private" />
      <input type="checkbox" id="transcribe-n8n-log" />
      <input type="checkbox" id="transcribe-watch-mode" />
      <button id="cancel-transcribe"></button>
      <select id="transcribe-preset"></select>
      <textarea id="transcribe-notes"></textarea>
      <div id="transcribe-loader-inline"></div>
      <div id="transcribe-job-status"></div>
      <div id="transcribe-status-text"></div>
      <select id="transcribe-language"><option value="en">en</option></select>
      <select id="transcribe-engine"><option value="whisperx">whisperx</option></select>
      <select id="transcribe-accuracy-mode"><option value="auto">auto</option></select>
      <select id="translate-target"><option value="en">en</option></select>
      <input type="checkbox" id="translate-enable" />
      <select id="transcribe-output-formats"><option value="txt">txt</option><option value="srt">srt</option><option value="scc">scc</option></select>
      <input id="out-timecodes" type="checkbox" />
      <input id="out-speaker-names" type="checkbox" />
      <input id="fmt-txt-include-speaker-names" type="checkbox" />
      <input id="fmt-txt-group-by-speaker" type="checkbox" />
      <select id="fmt-txt-timecode-format"><option value="ndf">ndf</option><option value="df">df</option></select>
      <select id="fmt-txt-timestamp-placement"><option value="none">none</option><option value="start_end">start_end</option></select>
      <input id="fmt-txt-fps" />
      <input id="fmt-txt-tc-start" />
      <input id="transcribe-fps" />
      <input id="transcribe-tc-start" />
      <input id="fmt-scc-tc-start" />
      <input id="fmt-scc-timecode-offset" />
      <select id="scc-channel"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option></select>
      <select id="scc-alignment"><option value="left">left</option><option value="center">center</option><option value="right">right</option></select>
      <input id="fmt-scc-max-chars" />
      <input id="fmt-scc-max-lines" />
      <input id="fmt-scc-max-duration" />
      <input id="fmt-scc-safe-left" />
      <input id="fmt-scc-safe-right" />
      <input id="fmt-scc-repeat-control" type="checkbox" />
      <input id="fmt-scc-repeat-preamble" type="checkbox" />
      <input id="fmt-scc-strict-encoding" type="checkbox" />
      <input id="fmt-scc-pad-even" type="checkbox" />
      <input id="fmt-scc-allow-ndf" type="checkbox" />
      <input id="fmt-scc-strip-leading-dashes" type="checkbox" />
      <input id="fmt-scc-prestart-roll" />
      <select id="fmt-scc-time-source"><option value="auto">auto</option><option value="start">start</option></select>
      <select id="fmt-scc-start-reset-at"><option value="auto">auto</option><option value="both">both</option></select>
      <select id="fmt-scc-start-reset-op"><option value="edm">edm</option><option value="rdc">rdc</option></select>
      <select id="fmt-scc-export-policy"><option value="warn">warn</option><option value="gate_write">gate_write</option></select>
      <input id="fmt-scc-prefix-words" />
      <select id="fmt-scc-placement-mode"><option value="custom">custom</option><option value="auto">auto</option></select>
      <input id="fmt-scc-placement-bottom-row" />
      <input id="fmt-scc-placement-left-col" />
      <select id="fmt-scc-shape-mode"><option value="off">off</option><option value="conservative">conservative</option></select>
      <input id="fmt-scc-shape-micro-dur" />
      <input id="fmt-scc-shape-micro-gap" />
      <input id="fmt-scc-shape-max-shift" />
      <input id="fmt-scc-shape-fix-starttc" type="checkbox" />
      <input id="fmt-scc-qc-max-cps" />
      <input id="fmt-scc-qc-max-wpm" />
      <input id="fmt-scc-qc-min-duration" />
      <input id="fmt-scc-qc-min-gap" />
      <input id="fmt-scc-qc-max-late-eoc" />
      <input id="fmt-scc-qc-max-late-eoc-count" />
      <input id="transcribe-filter-nonspeech" type="checkbox" />
      <input id="transcribe-remove-fillers" type="checkbox" />
      <input id="transcribe-remove-leading-chars" type="checkbox" />
      <input id="transcribe-naming-template" />
      <input id="verbose-qc-logs" type="checkbox" />
      <input id="acc-redact" type="checkbox" />
      <input id="transcribe-send-subtitle" type="checkbox" />
      <input id="transcribe-open-on-complete" type="checkbox" />
      <input id="transcribe-open-folder-on-complete" type="checkbox" />
      <input id="transcribe-overwrite-existing" type="checkbox" />
    </div>
  `;

  Object.defineProperty(document, 'readyState', {
    configurable: true,
    get: () => 'complete'
  });

  window.loadPanelScript = jest.fn();
}

describe('Transcribe preset output path round-trip', () => {
  beforeEach(() => {
    jest.resetModules();
    buildTranscribeDOM();
  });

  test('gatherConfig saves outputPath and applyTranscribePreset restores it with change event', async () => {
    const outputPathEl = document.getElementById('transcribe-output-path');
    outputPathEl.value = '/RT/transcribe/output';

    const { gatherConfig, applyTranscribePreset } = require('../renderer.transcribe.js');

    const saved = await gatherConfig();
    expect(saved.outputPath).toBe('/RT/transcribe/output');

    let changeCount = 0;
    outputPathEl.addEventListener('change', () => {
      changeCount += 1;
    });

    outputPathEl.value = '/current/value';
    applyTranscribePreset({
      outputPath: saved.outputPath,
      formats: { scc: {}, mcc: {} }
    });

    expect(outputPathEl.value).toBe('/RT/transcribe/output');
    expect(changeCount).toBe(1);
  });


  test('SCC channel/alignment restore from preset and survive gather round-trip', async () => {
    const { applyTranscribePreset, gatherConfig } = require('../renderer.transcribe.js');

    applyTranscribePreset({
      outputFormats: { scc: true },
      sccOptions: {
        channel: 3,
        alignment: 'right'
      },
      formats: { scc: {}, mcc: {} }
    });

    expect(document.getElementById('scc-channel').value).toBe('3');
    expect(document.getElementById('scc-alignment').value).toBe('right');

    const gathered = await gatherConfig();
    expect(gathered.sccOptions.channel).toBe(3);
    expect(gathered.sccOptions.alignment).toBe('right');
  });

  test('blank or omitted outputPath leaves current destination untouched', () => {
    const outputPathEl = document.getElementById('transcribe-output-path');
    const { applyTranscribePreset } = require('../renderer.transcribe.js');

    outputPathEl.value = '/keep/this/path';
    applyTranscribePreset({ outputPath: '   ', formats: { scc: {}, mcc: {} } });
    expect(outputPathEl.value).toBe('/keep/this/path');

    applyTranscribePreset({ notes: 'preset without output path', formats: { scc: {}, mcc: {} } });
    expect(outputPathEl.value).toBe('/keep/this/path');
  });

  test('Watch Mode survives preset save/load round-trip', async () => {
    const { gatherConfig, applyTranscribePreset } = require('../renderer.transcribe.js');
    const watchModeEl = document.getElementById('transcribe-watch-mode');

    watchModeEl.checked = true;
    const saved = await gatherConfig();
    const serialized = JSON.stringify(saved);
    const loaded = JSON.parse(serialized);

    let changeCount = 0;
    watchModeEl.addEventListener('change', () => {
      changeCount += 1;
    });

    watchModeEl.checked = false;
    applyTranscribePreset({ ...loaded, formats: { scc: {}, mcc: {} } });

    expect(loaded.watchMode).toBe(true);
    expect(watchModeEl.checked).toBe(true);
    expect(changeCount).toBeGreaterThan(0);
  });

  test('SCC advanced controls round-trip via gatherConfig/applyTranscribePreset', async () => {
    const { gatherConfig, applyTranscribePreset } = require('../renderer.transcribe.js');

    document.getElementById('transcribe-output-formats').value = 'scc';
    document.getElementById('scc-channel').value = '4';
    document.getElementById('scc-alignment').value = 'left';
    document.getElementById('fmt-scc-max-chars').value = '31';
    document.getElementById('fmt-scc-max-lines').value = '2';
    document.getElementById('fmt-scc-max-duration').value = '8.5';
    document.getElementById('fmt-scc-safe-left').value = '3';
    document.getElementById('fmt-scc-safe-right').value = '4';
    document.getElementById('fmt-scc-repeat-control').checked = true;
    document.getElementById('fmt-scc-repeat-preamble').checked = true;
    document.getElementById('fmt-scc-strict-encoding').checked = true;
    document.getElementById('fmt-scc-pad-even').checked = true;
    document.getElementById('fmt-scc-allow-ndf').checked = true;
    document.getElementById('fmt-scc-strip-leading-dashes').checked = true;
    document.getElementById('fmt-scc-prestart-roll').value = '1.5';
    document.getElementById('fmt-scc-time-source').value = 'start';
    document.getElementById('fmt-scc-start-reset-at').value = 'both';
    document.getElementById('fmt-scc-start-reset-op').value = 'rdc';
    document.getElementById('fmt-scc-export-policy').value = 'gate_write';
    document.getElementById('fmt-scc-prefix-words').value = 'BREAKING, ALERT';
    document.getElementById('fmt-scc-placement-mode').value = 'custom';
    document.getElementById('fmt-scc-placement-bottom-row').value = '12';
    document.getElementById('fmt-scc-placement-left-col').value = '5';
    document.getElementById('fmt-scc-shape-mode').value = 'conservative';
    document.getElementById('fmt-scc-shape-micro-dur').value = '0.5';
    document.getElementById('fmt-scc-shape-micro-gap').value = '0.2';
    document.getElementById('fmt-scc-shape-max-shift').value = '0.4';
    document.getElementById('fmt-scc-shape-fix-starttc').checked = false;
    document.getElementById('fmt-scc-qc-max-cps').value = '24';
    document.getElementById('fmt-scc-qc-max-wpm').value = '220';
    document.getElementById('fmt-scc-qc-min-duration').value = '1.1';
    document.getElementById('fmt-scc-qc-min-gap').value = '0.25';
    document.getElementById('fmt-scc-qc-max-late-eoc').value = '0.3';
    document.getElementById('fmt-scc-qc-max-late-eoc-count').value = '2';

    const saved = await gatherConfig();

    expect(saved.sccOptions.safeMargins).toEqual({ left: 3, right: 4 });
    expect(saved.sccOptions.qc).toMatchObject({
      maxCps: 24,
      maxWpm: 220,
      minDurationSec: 1.1,
      minGapSec: 0.25,
      maxLateEocSec: 0.3,
      maxLateEocCount: 2
    });
    expect(saved.sccOptions.prefixWords).toEqual(['BREAKING', 'ALERT']);

    document.getElementById('fmt-scc-safe-left').value = '0';
    document.getElementById('fmt-scc-safe-right').value = '0';
    document.getElementById('fmt-scc-repeat-control').checked = false;
    document.getElementById('fmt-scc-export-policy').value = 'warn';
    document.getElementById('fmt-scc-prefix-words').value = '';

    applyTranscribePreset({ ...saved, formats: { scc: {}, mcc: {} } });

    expect(document.getElementById('fmt-scc-safe-left').value).toBe('3');
    expect(document.getElementById('fmt-scc-safe-right').value).toBe('4');
    expect(document.getElementById('fmt-scc-repeat-control').checked).toBe(true);
    expect(document.getElementById('fmt-scc-export-policy').value).toBe('gate_write');
    expect(document.getElementById('fmt-scc-prefix-words').value).toBe('BREAKING,ALERT');

    const regathered = await gatherConfig();
    expect(regathered.sccOptions).toMatchObject({
      channel: 4,
      alignment: 'left',
      safeMargins: { left: 3, right: 4 },
      repeatControlCodes: true,
      repeatPreambleCodes: true,
      strictCharacterEncoding: true,
      padEven: true,
      allowNdf: true,
      stripLeadingDashes: true,
      preStartTransmitSec: 1.5,
      timeSource: 'start',
      startResetAt: 'both',
      startResetOp: 'rdc',
      exportPolicy: 'gate_write',
      placementMode: 'custom',
      placementBottomRow: 12,
      placementLeftCol: 5
    });
    expect(regathered.sccOptions.prefixWords).toEqual(['BREAKING', 'ALERT']);
    expect(regathered.sccOptions.shaping).toMatchObject({
      enabled: true,
      mode: 'conservative',
      microCueSec: 0.5,
      microGapSec: 0.2,
      maxShiftSec: 0.4,
      fixStartTcClamp: false
    });
    expect(regathered.sccOptions.qc).toMatchObject({
      maxCps: 24,
      maxWpm: 220,
      minDurationSec: 1.1,
      minGapSec: 0.25,
      maxLateEocSec: 0.3,
      maxLateEocCount: 2
    });
  });
  test('legacy out-timecodes preset fallback restores checkbox when txt timestamp placement is absent', () => {
    const { applyTranscribePreset } = require('../renderer.transcribe.js');
    const legacyEl = document.getElementById('out-timecodes');
    const placementEl = document.getElementById('fmt-txt-timestamp-placement');

    let legacyChangeCount = 0;
    legacyEl.addEventListener('change', () => {
      legacyChangeCount += 1;
    });

    legacyEl.checked = false;
    placementEl.value = 'none';

    applyTranscribePreset({
      legacyOutTimecodes: true,
      outputFormats: { txt: true },
      txtOptions: {},
      formats: { txt: {}, scc: {}, mcc: {} }
    });

    expect(legacyEl.checked).toBe(true);
    expect(legacyChangeCount).toBe(1);
    expect(placementEl.value).toBe('start_end');
  });

  test('explicit formats.txt.timestampPlacement remains canonical over legacy out-timecodes', () => {
    const { applyTranscribePreset } = require('../renderer.transcribe.js');
    const legacyEl = document.getElementById('out-timecodes');
    const placementEl = document.getElementById('fmt-txt-timestamp-placement');

    let legacyChangeCount = 0;
    legacyEl.addEventListener('change', () => {
      legacyChangeCount += 1;
    });

    legacyEl.checked = false;

    applyTranscribePreset({
      legacyOutTimecodes: true,
      outputFormats: { txt: true },
      formats: {
        txt: { timestampPlacement: 'none' },
        scc: {},
        mcc: {}
      }
    });

    expect(placementEl.value).toBe('none');
    expect(legacyEl.checked).toBe(false);
    expect(legacyChangeCount).toBe(0);
  });

  test('gatherConfig persists legacyOutTimecodes when legacy checkbox exists', async () => {
    const { gatherConfig } = require('../renderer.transcribe.js');
    const legacyEl = document.getElementById('out-timecodes');

    legacyEl.checked = true;

    const gathered = await gatherConfig();

    expect(gathered.legacyOutTimecodes).toBe(true);
    expect(gathered.formats.txt.timestampPlacement).toBe('none');
  });

});
