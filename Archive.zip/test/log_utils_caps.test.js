/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');

const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

describe('logUtils capped in-memory buffers', () => {
  let tmpRoot;

  beforeEach(() => {
    jest.resetModules();
    tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-logutils-'));
    jest.doMock('../utils/appPaths', () => ({
      ensureUserDataSubdir: (name) => {
        const p = path.join(tmpRoot, name);
        fs.mkdirSync(p, { recursive: true });
        return p;
      }
    }));
  });

  test('createJobLogger caps entries and trims FIFO', () => {
    const { createJobLogger } = require('../modules/logUtils');
    const logger = createJobLogger({ panel: 'transcode', jobId: 'job-a', maxEntries: 3 });

    logger.info('line-1');
    logger.info('line-2');
    logger.info('line-3');
    logger.info('line-4');

    const messages = logger.getEntries().map(e => e.message);
    expect(messages).toEqual(['line-2', 'line-3', 'line-4']);
    expect(messages.length).toBeLessThanOrEqual(3);
  });

  test('createJobUserLog caps lines/bytes and trims FIFO', () => {
    const { createJobLogger, createJobUserLog } = require('../modules/logUtils');
    const logger = createJobLogger({ panel: 'ingest', jobId: 'job-b' });
    const userLog = createJobUserLog(logger, { maxLines: 2, maxBytes: 25 });

    userLog.push('1111111111');
    userLog.push('2222222222');
    userLog.push('3333333333');

    expect(userLog.lines).toEqual(['2222222222', '3333333333']);
    const bytes = Buffer.byteLength(`${userLog.lines.join('\n')}\n`, 'utf8');
    expect(bytes).toBeLessThanOrEqual(25);
  });

  test('JSONL stream keeps full fidelity while in-memory entries are capped', async () => {
    const { createJobLogger } = require('../modules/logUtils');
    const logger = createJobLogger({
      panel: 'transcode',
      jobId: 'job-c',
      streamToFile: true,
      streamFlushEvery: 1,
      maxEntries: 2
    });

    logger.info('a');
    logger.info('b');
    logger.info('c');
    const structuredPath = logger.getStructuredLogPath();
    logger.close();
    await wait(50);

    const inMemory = logger.getEntries().map(e => e.message);
    expect(inMemory).toEqual(['b', 'c']);

    const diskLines = fs.readFileSync(structuredPath, 'utf8').trim().split(/\r?\n/);
    expect(diskLines).toHaveLength(3);
    const diskMessages = diskLines.map(line => JSON.parse(line).message);
    expect(diskMessages).toEqual(['a', 'b', 'c']);
  });
});
