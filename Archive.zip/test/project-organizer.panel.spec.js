const flushPromises = () => new Promise(resolve => setImmediate(resolve));

function buildProjectOrganizerDOM() {
  document.body.innerHTML = `
    <div id="project-organizer">
      <div id="project-organizer-lock-wrapper">
        <ul id="folder-list">
          <li class="draggable-item selected" data-id="PROJECT" data-root="true">
            <div class="folder-actions"></div>
          </li>
          <li class="draggable-item" data-id="MEDIA" data-root="true">
            <div class="folder-actions"></div>
          </li>
        </ul>
        <button id="add-custom-folder"></button>
        <button id="organizer-add-subfolder"></button>
        <input id="custom-folder-name" />
        <button id="reset-project-organizer"></button>
        <button id="generate-project-folders"></button>
        <button id="cancel-project-organizer"></button>
        <pre id="project-summary"></pre>
        <input id="output-location-path" />
        <button id="select-output-location"></button>
        <input id="root-folder-name" />
        <input type="checkbox" id="prepend-numbers" />
        <select id="organizer-preset"></select>
        <button id="organizer-save-config"></button>
        <button id="organizer-load-config"></button>
        <div id="project-organizer-job-status"><div class="wheel-and-hamster"></div></div>
      </div>
    </div>
  `;

  Object.defineProperty(document, 'readyState', {
    configurable: true,
    get: () => 'complete',
  });

  window.logPanel = { log: jest.fn() };

  global.CSS = global.CSS || {
    escape: value => String(value).replace(/[^a-zA-Z0-9_-]/g, ch => `\${ch}`)
  };

  // Renderer validation expects a directory-like statSync result for the output path
  window.electron = window.electron || {};
  const directoryStat = { isDirectory: () => true };
  window.electron.statSync = jest.fn(() => directoryStat);
  window.electron.fsStat = jest.fn(async () => directoryStat);
  window.electron.approvePaths = jest.fn(async paths => paths);
}

describe('Project Organizer panel behaviors', () => {
  function emitIpc(channel, ...args) {
    const handler = ipc.on.mock.calls.find(([name]) => name === channel)?.[1];
    if (!handler) throw new Error(`Missing IPC handler for ${channel}`);
    handler({}, ...args);
  }

  beforeEach(() => {
    jest.resetModules();
    ipc.invoke.mockReset();
    ipc.on.mockReset();
    ipc.removeAllListeners = jest.fn();
    buildProjectOrganizerDOM();
    window.rendererDialogs = {
      showMessageDialog: jest.fn(async () => ({ response: 1 })),
    };
    require('../renderer.project-organizer.js');
  });

  test('queues organizer jobs when the project name is omitted', async () => {
    ipc.invoke.mockImplementation(async channel => {
      if (channel === 'queue-add-project-organizer') return 'org-123';
      if (channel === 'queue-start') return undefined;
      return undefined;
    });

    const summary = document.getElementById('project-summary');
    document.getElementById('output-location-path').value = '/projects/output';

    document.getElementById('generate-project-folders').click();
    await flushPromises();

    expect(ipc.invoke).toHaveBeenCalledWith(
      'queue-add-project-organizer',
      expect.objectContaining({
        rootName: '',
        outputPath: '/projects/output',
      })
    );
    expect(ipc.invoke).toHaveBeenCalledWith('queue-start');
    expect(summary.textContent).toContain('Generating structure...');
  });

  test('blocks generation when the output path is missing', async () => {
    const summary = document.getElementById('project-summary');
    document.getElementById('root-folder-name').value = 'Example Project';

    document.getElementById('generate-project-folders').click();
    await flushPromises();

    expect(summary.textContent).toContain('Please set an Output Path before generating.');
    expect(ipc.invoke).not.toHaveBeenCalledWith('queue-add-project-organizer', expect.anything());
  });

  test('queues organizer jobs when validation succeeds', async () => {
    ipc.invoke.mockImplementation(async channel => {
      if (channel === 'queue-add-project-organizer') return 'org-123';
      if (channel === 'queue-start') return undefined;
      return undefined;
    });

    const summary = document.getElementById('project-summary');
    document.getElementById('root-folder-name').value = 'Example Project';
    document.getElementById('output-location-path').value = '/projects/output';

    document.getElementById('generate-project-folders').click();
    await flushPromises();

    expect(ipc.invoke).toHaveBeenCalledWith(
      'queue-add-project-organizer',
      expect.objectContaining({
        rootName: 'Example Project',
        outputPath: '/projects/output',
      })
    );
    expect(ipc.invoke).toHaveBeenCalledWith('queue-start');
    expect(summary.textContent).toContain('Generating structure...');
  });

  test('blocks adding invalid custom root folder names', () => {
    const folderList = document.getElementById('folder-list');
    const initialCount = folderList.querySelectorAll('li.draggable-item').length;

    document.getElementById('custom-folder-name').value = 'Bad/Name';
    document.getElementById('add-custom-folder').click();

    expect(folderList.querySelectorAll('li.draggable-item').length).toBe(initialCount);
    expect(folderList.querySelector('[data-id="Bad/Name"]')).toBeNull();
    expect(window.logPanel.log).toHaveBeenCalledWith(
      'project-organizer',
      expect.stringContaining('Folder names cannot contain path separators.'),
      expect.objectContaining({ isError: true })
    );
    const validation = document.getElementById('project-organizer-folder-status');
    expect(validation).not.toBeNull();
    expect(validation.textContent).toContain('Folder names cannot contain path separators.');
    expect(document.getElementById('custom-folder-name').getAttribute('aria-invalid')).toBe('true');
  });

  test('blocks adding invalid custom subfolder names', () => {
    const folderList = document.getElementById('folder-list');
    const initialCount = folderList.querySelectorAll('li.draggable-item').length;

    folderList.querySelectorAll('li.draggable-item').forEach(li => li.classList.remove('selected'));
    const projectFolder = folderList.querySelector('li[data-id="PROJECT"]');
    projectFolder.classList.add('selected');

    document.getElementById('custom-folder-name').value = '..';
    document.getElementById('organizer-add-subfolder').click();

    expect(folderList.querySelectorAll('li.draggable-item').length).toBe(initialCount);
    expect(folderList.querySelector('[data-id="PROJECT/.."]')).toBeNull();
    expect(window.logPanel.log).toHaveBeenCalledWith(
      'project-organizer',
      expect.stringContaining('Folder names cannot contain "..".'),
      expect.objectContaining({ isError: true })
    );
    const validation = document.getElementById('project-organizer-folder-status');
    expect(validation).not.toBeNull();
    expect(validation.textContent).toContain('Folder names cannot contain "..".');
    expect(document.getElementById('custom-folder-name').getAttribute('aria-invalid')).toBe('true');
  });

  test('preset round-trip restores #custom-folder-name', async () => {
    const organizer = require('../renderer.project-organizer.js');

    const customFolderInput = document.getElementById('custom-folder-name');
    customFolderInput.value = 'Review Selects';
    const config = organizer.gatherOrganizerConfig();

    customFolderInput.value = '';
    await organizer.applyOrganizerPreset(config, 'config');

    expect(customFolderInput.value).toBe('Review Selects');
  });

  test('preset round-trip restores all project organizer panel options', async () => {
    const organizer = require('../renderer.project-organizer.js');

    const rootNameInput = document.getElementById('root-folder-name');
    const customFolderInput = document.getElementById('custom-folder-name');
    const prependNumbersInput = document.getElementById('prepend-numbers');
    const outputPathInput = document.getElementById('output-location-path');

    rootNameInput.value = 'Commercial_2026';
    customFolderInput.value = 'Review Selects';
    prependNumbersInput.checked = false;
    outputPathInput.value = '/projects/output';

    organizer.customFolders = [
      { id: 'EXTRAS', label: 'EXTRAS', groupId: 'EXTRAS' },
      { id: 'PROJECT/GRAPHICS', label: 'GRAPHICS', groupId: 'PROJECT' }
    ];
    organizer.folderOrder = ['PROJECT', 'PROJECT/GRAPHICS', 'MEDIA', 'EXTRAS'];
    organizer.selectedFolders = ['PROJECT/GRAPHICS', 'EXTRAS'];
    organizer.folderAssets = {
      'PROJECT/GRAPHICS': ['/assets/graphics/slug.png'],
      EXTRAS: ['/assets/extras/notes.txt']
    };

    const config = organizer.gatherOrganizerConfig();

    rootNameInput.value = '';
    customFolderInput.value = '';
    prependNumbersInput.checked = true;
    outputPathInput.value = '';
    organizer.customFolders = [];
    organizer.folderOrder = ['PROJECT', 'MEDIA'];
    organizer.selectedFolders = [];
    organizer.folderAssets = {};

    await organizer.applyOrganizerPreset(config, 'config');

    expect(rootNameInput.value).toBe('Commercial_2026');
    expect(customFolderInput.value).toBe('Review Selects');
    expect(prependNumbersInput.checked).toBe(false);
    expect(outputPathInput.value).toBe('/projects/output');
    expect(organizer.customFolders).toEqual(expect.arrayContaining([
      expect.objectContaining({ id: 'EXTRAS', label: 'EXTRAS', groupId: 'EXTRAS' }),
      expect.objectContaining({ id: 'PROJECT/GRAPHICS', label: 'GRAPHICS', groupId: 'PROJECT' })
    ]));
    expect(organizer.folderOrder).toEqual(['PROJECT', 'PROJECT/GRAPHICS', 'MEDIA', 'EXTRAS']);
    expect(organizer.selectedFolders).toEqual(['PROJECT/GRAPHICS', 'EXTRAS']);
    expect(organizer.folderAssets).toEqual(expect.objectContaining({
      'PROJECT/GRAPHICS': ['/assets/graphics/slug.png'],
      EXTRAS: ['/assets/extras/notes.txt']
    }));
  });


  test('preset validation warnings localize the custom folders field label', async () => {
    const organizer = require('../renderer.project-organizer.js');

    window.i18n = {
      t: jest.fn((key, opts = {}) => {
        if (key === 'projectOrganizerFieldCustomFoldersLabel') return 'Localized Custom Folders';
        if (key === 'projectOrganizerPresetInvalidEntriesRemoved') {
          return `${opts.label} contained invalid entries that were removed`;
        }
        if (key === 'projectOrganizerInvalidDataIgnoredWarning') {
          return `⚠️ Organizer ${opts.sourceLabel} contained invalid data that was ignored: ${opts.errors}`;
        }
        return key;
      })
    };

    await organizer.applyOrganizerPreset({
      customFolders: [{ nope: true }]
    }, 'config');

    expect(window.logPanel.log).toHaveBeenCalledWith(
      'project-organizer',
      expect.stringContaining('Localized Custom Folders contained invalid entries that were removed'),
      expect.objectContaining({ isWarning: true })
    );
  });

  test('prevents folder selection changes while the panel is locked', () => {
    const folderList = document.getElementById('folder-list');
    const lockWrapper = document.getElementById('project-organizer-lock-wrapper');

    const media = folderList.querySelector('li[data-id="MEDIA"]');
    expect(media).not.toBeNull();
    expect(media.classList.contains('selected')).toBe(false);

    lockWrapper.classList.add('locked');
    media.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    expect(media.classList.contains('selected')).toBe(false);

    lockWrapper.classList.remove('locked');
    media.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    expect(media.classList.contains('selected')).toBe(true);
  });

  test('queue-job-complete prefers localized code payloads over raw summary/log text', () => {
    const summary = document.getElementById('project-summary');

    emitIpc('queue-job-complete', {
      panel: 'project-organizer',
      id: 'job-1',
      result: {
        summaryCode: 'project-structure-created',
        summaryParams: { folderCount: 2, assetCount: 0 },
        summary: 'RAW SUMMARY SHOULD NOT BE SHOWN',
        logText: 'RAW LOG SHOULD NOT BE SHOWN'
      }
    });

    expect(summary.textContent).toContain('project-structure-created');
    expect(summary.textContent).not.toContain('RAW SUMMARY SHOULD NOT BE SHOWN');
    expect(summary.textContent).not.toContain('RAW LOG SHOULD NOT BE SHOWN');
  });

  test('queue-job-failed uses localized runtime payload and hides raw backend text by default', () => {
    const summary = document.getElementById('project-summary');

    emitIpc('queue-job-failed', {
      panel: 'project-organizer',
      id: 'job-2',
      result: {
        runtimeError: {
          code: 'project-organizer-uncaught-error',
          params: { reasonCode: 'projectOrganizerUncaughtError' },
          message: 'RAW BACKEND ERROR MESSAGE'
        },
        summary: 'RAW SUMMARY',
        logText: 'RAW LOG TEXT'
      },
      error: { message: 'UNTRANSLATED ERROR MESSAGE' }
    });

    expect(summary.textContent).toContain('project-organizer-uncaught-error');
    expect(summary.textContent).not.toContain('RAW BACKEND ERROR MESSAGE');
    expect(summary.textContent).not.toContain('RAW SUMMARY');
    expect(summary.textContent).not.toContain('RAW LOG TEXT');
  });
});
