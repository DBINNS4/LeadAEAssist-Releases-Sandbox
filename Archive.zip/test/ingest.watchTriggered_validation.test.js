/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');

// The module under test imports Electron APIs at module scope.
// In Jest/node, we mock them out so we can unit-test pure validation logic.
jest.mock('electron', () => ({}));

describe('validateIngestConfig — watch mode triggered jobs', () => {
  test('allows watch-triggered ingest jobs to include a sourceFiles list', async () => {
    const { validateIngestConfig } = require('../modules/ingest');

    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-watch-'));
    try {
      const watchFolder = path.join(tmpRoot, 'watch');
      const destFolder = path.join(tmpRoot, 'dest');
      fs.mkdirSync(watchFolder, { recursive: true });
      fs.mkdirSync(destFolder, { recursive: true });

      const fp = path.join(watchFolder, 'LeadAI.zip');
      fs.writeFileSync(fp, Buffer.from('test'));

      const errors = await validateIngestConfig({
        watchMode: true,
        watchTriggered: true,
        watchFolder,
        source: watchFolder,
        sourceFiles: [fp],
        destination: destFolder,
      });

      expect(Array.isArray(errors)).toBe(true);
      expect(errors).toHaveLength(0);
    } finally {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });

  test('still blocks manual file lists when watch mode is enabled but not watch-triggered', async () => {
    const { validateIngestConfig } = require('../modules/ingest');

    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-watch-'));
    try {
      const watchFolder = path.join(tmpRoot, 'watch');
      const destFolder = path.join(tmpRoot, 'dest');
      fs.mkdirSync(watchFolder, { recursive: true });
      fs.mkdirSync(destFolder, { recursive: true });

      const fp = path.join(watchFolder, 'LeadAI.zip');
      fs.writeFileSync(fp, Buffer.from('test'));

      const errors = await validateIngestConfig({
        watchMode: true,
        watchFolder,
        source: watchFolder,
        sourceFiles: [fp],
        destination: destFolder,
      });

      expect(errors.join('\n')).toContain('Watch mode requires a folder path');
    } finally {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });
});

describe('validateIngestConfig — file list sources', () => {
  test('ignores empty source values when validating overlap with destination', async () => {
    const { validateIngestConfig } = require('../modules/ingest');

    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-filelist-'));
    try {
      const sourceFolder = path.join(tmpRoot, 'source');
      fs.mkdirSync(sourceFolder, { recursive: true });

      const fp = path.join(sourceFolder, 'clip.mov');
      fs.writeFileSync(fp, Buffer.from('test'));

      const errors = await validateIngestConfig({
        source: '   ',
        sourceFiles: [fp],
        destination: process.cwd(),
      });

      expect(errors.join('\n')).not.toContain('Destination cannot be the same as the source');
      expect(errors.join('\n')).not.toContain('Source cannot be the same as or located inside the destination');
    } finally {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });
});
