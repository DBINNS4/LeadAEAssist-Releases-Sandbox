/** @jest-environment node */

jest.mock('../utils/trustedIpcSender', () => ({
  assertTrustedIpcSender: jest.fn()
}));

jest.mock('../modules/transcribe', () => ({
  cancelTranscribe: jest.fn()
}));

const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const { cancelTranscribe } = require('../modules/transcribe');
const registerTranscribeHandlers = require('../ipc/transcribe.handlers');

function buildIpcMain() {
  const handlers = new Map();
  return {
    handlers,
    ipcMain: {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn))
    }
  };
}

describe('ipc/transcribe.handlers compatibility cancellation', () => {
  beforeEach(() => {
    delete global.queue;
    jest.clearAllMocks();
  });

  test('cancel-transcribe bridges to queue-cancel-job semantics when queue is available', async () => {
    const cancelJob = jest.fn();
    global.queue = { cancelJob };

    const { ipcMain, handlers } = buildIpcMain();
    registerTranscribeHandlers(ipcMain);

    const event = { senderFrame: { url: 'app://local' } };
    const result = await handlers.get('cancel-transcribe')(event, 'job-123');

    expect(assertTrustedIpcSender).toHaveBeenCalledWith(event, 'cancel-transcribe');
    expect(cancelJob).toHaveBeenCalledWith('job-123');
    expect(cancelTranscribe).not.toHaveBeenCalled();
    expect(result).toEqual({ key: 'transcribeCancelRequestedViaQueueBridge' });
  });

  test('cancel-transcribe falls back to direct transcribe cancel when queue is unavailable', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerTranscribeHandlers(ipcMain);

    const event = { senderFrame: { url: 'app://local' } };
    const result = await handlers.get('cancel-transcribe')(event, 'job-456');

    expect(assertTrustedIpcSender).toHaveBeenCalledWith(event, 'cancel-transcribe');
    expect(cancelTranscribe).toHaveBeenCalledWith('job-456');
    expect(result).toEqual({ key: 'transcribeCancelRequestedDirectFallback' });
  });
});
