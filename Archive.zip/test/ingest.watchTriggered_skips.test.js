/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');

jest.mock('electron', () => ({
  dialog: { showMessageBox: jest.fn().mockResolvedValue({ response: 1 }) },
  BrowserWindow: { getAllWindows: () => [{ isDestroyed: () => false }] },
  app: { isPackaged: false }
}), { virtual: true });

let runIngest;

beforeAll(() => {
  jest.isolateModules(() => {
    runIngest = require('../modules/ingest').runIngest;
  });
});

describe('runIngest — watch-triggered missing-path skips', () => {
  let tmpRoot;

  beforeEach(() => {
    tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-watch-skip-'));
    global.queue = new EventEmitter();
  });

  afterEach(() => {
    fs.rmSync(tmpRoot, { recursive: true, force: true });
    delete global.queue;
    jest.clearAllMocks();
  });

  test('returns structured skip status when watch-triggered source path is missing', async () => {
    const watchFolder = path.join(tmpRoot, 'watch');
    const destination = path.join(tmpRoot, 'destination');
    fs.mkdirSync(watchFolder, { recursive: true });
    fs.mkdirSync(destination, { recursive: true });

    const result = await runIngest({
      watchMode: true,
      watchTriggered: true,
      watchFolder,
      source: path.join(tmpRoot, 'missing-source'),
      destination,
      backup: false,
      verification: { useChecksum: false, method: 'none' }
    });

    expect(result.success).toBe(false);
    expect(result.skipped).toBe(true);
    expect(result.reason).toBe('missing-source');
    expect(result.status).toBe('watch-skipped-missing-source');
    expect(result.logText).toContain('Watch-triggered job skipped: source missing');
  });

  test('returns structured skip status when watch-triggered destination path is missing', async () => {
    const watchFolder = path.join(tmpRoot, 'watch');
    const sourceFile = path.join(watchFolder, 'clip.mov');
    const destination = path.join(tmpRoot, 'missing-destination');
    fs.mkdirSync(watchFolder, { recursive: true });
    fs.writeFileSync(sourceFile, 'x');

    const result = await runIngest({
      watchMode: true,
      watchTriggered: true,
      watchFolder,
      source: watchFolder,
      sourceFiles: [sourceFile],
      destination,
      backup: false,
      verification: { useChecksum: false, method: 'none' }
    });

    expect(result.success).toBe(false);
    expect(result.skipped).toBe(true);
    expect(result.reason).toBe('missing-destination');
    expect(result.status).toBe('watch-skipped-missing-destination');
    expect(result.logText).toContain('Watch-triggered job skipped: destination missing');
  });

  test('returns structured skip status when watch-triggered backup path is missing', async () => {
    const watchFolder = path.join(tmpRoot, 'watch');
    const sourceFile = path.join(watchFolder, 'clip.mov');
    const destination = path.join(tmpRoot, 'destination');
    const backupPath = path.join(tmpRoot, 'missing-backup');
    fs.mkdirSync(watchFolder, { recursive: true });
    fs.mkdirSync(destination, { recursive: true });
    fs.writeFileSync(sourceFile, 'x');

    const result = await runIngest({
      watchMode: true,
      watchTriggered: true,
      watchFolder,
      source: watchFolder,
      sourceFiles: [sourceFile],
      destination,
      backup: true,
      backupPath,
      verification: { useChecksum: false, method: 'none' }
    });

    expect(result.success).toBe(false);
    expect(result.skipped).toBe(true);
    expect(result.reason).toBe('missing-backup');
    expect(result.status).toBe('watch-skipped-missing-backup');
    expect(result.logText).toContain('Watch-triggered job skipped: backup path missing');
  });
});
