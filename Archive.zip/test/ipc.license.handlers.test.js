'use strict';

describe('ipc/license.handlers sync entitlement retries and timeout handling', () => {
  const ORIGINAL_ENV = process.env;

  beforeEach(() => {
    jest.resetModules();
    jest.useFakeTimers();
    process.env = { ...ORIGINAL_ENV, LEADAE_ENTITLEMENT_URL: 'https://entitlement.example.com' };
  });

  afterEach(() => {
    jest.useRealTimers();
    jest.restoreAllMocks();
  });

  afterAll(() => {
    process.env = ORIGINAL_ENV;
  });

  function loadSubject({ installResult } = {}) {
    const handlers = {};
    const ipcMain = { handle: jest.fn((name, fn) => { handlers[name] = fn; }) };
    const sendLogMessage = jest.fn();
    const installLicenseFromFile = jest.fn().mockResolvedValue(installResult || {
      tier: 'studio',
      valid: true,
      deviceId: 'secret-device-id'
    });

    jest.doMock('electron', () => ({
      app: { isPackaged: true },
      dialog: { showOpenDialog: jest.fn() },
      BrowserWindow: {
        fromWebContents: jest.fn(() => null),
        getAllWindows: jest.fn(() => [])
      }
    }));

    jest.doMock('../utils/publicRuntimeConfig', () => ({
      loadPublicRuntimeConfig: jest.fn(() => ({ entitlementUrl: 'https://entitlement.example.com' }))
    }));

    jest.doMock('../modules/secureStore', () => ({
      loadSecret: jest.fn(() => 'device-123'),
      saveSecret: jest.fn()
    }));

    jest.doMock('../services/licenseService', () => ({
      getEntitlement: jest.fn(() => ({ deviceId: 'device-123' })),
      isFeatureEnabled: jest.fn(() => true),
      clearLicense: jest.fn(() => ({})),
      installLicenseFromFile
    }));

    jest.doMock('../utils/trustedIpcSender', () => ({ assertTrustedIpcSender: jest.fn() }));
    jest.doMock('../modules/logUtils', () => ({ sendLogMessage }));

    const registerLicenseHandlers = require('../ipc/license.handlers');
    registerLicenseHandlers(ipcMain);

    return {
      syncEntitlement: handlers['license:sync-entitlement'],
      sendLogMessage,
      installLicenseFromFile
    };
  }

  test('returns timeout failure metadata after retry attempts and logs timeout events', async () => {
    const { syncEntitlement, sendLogMessage, installLicenseFromFile } = loadSubject();

    global.fetch = jest.fn((url, init) => new Promise((resolve, reject) => {
      init.signal.addEventListener('abort', () => {
        const err = new Error('Aborted');
        err.name = 'AbortError';
        reject(err);
      });
    }));

    const resultPromise = syncEntitlement({ sender: { id: 1 } }, {});
    await jest.advanceTimersByTimeAsync(40000);
    const result = await resultPromise;

    expect(result).toMatchObject({
      ok: false,
      code: 'entitlement_timeout',
      retryable: true
    });
    expect(global.fetch).toHaveBeenCalledTimes(3);
    expect(sendLogMessage).toHaveBeenCalledWith(
      'system',
      '[license:sync-entitlement] request timeout',
      expect.any(String),
      false,
      '',
      'warn'
    );
    expect(installLicenseFromFile).not.toHaveBeenCalled();
  }, 15000);

  test('retries 503 once and succeeds on the next attempt', async () => {
    const { syncEntitlement, sendLogMessage, installLicenseFromFile } = loadSubject();
    jest.spyOn(Math, 'random').mockReturnValue(0);

    global.fetch = jest
      .fn()
      .mockResolvedValueOnce({ ok: false, status: 503 })
      .mockResolvedValueOnce({ ok: true, text: async () => 'signed-token' });

    const resultPromise = syncEntitlement({ sender: { id: 2 } }, {});
    await jest.advanceTimersByTimeAsync(1000);
    const result = await resultPromise;

    expect(global.fetch).toHaveBeenCalledTimes(2);
    expect(sendLogMessage).toHaveBeenCalledWith(
      'system',
      '[license:sync-entitlement] transient HTTP failure, retrying',
      expect.any(String),
      false,
      '',
      'warn'
    );
    expect(result).toMatchObject({ ok: true, entitlement: { tier: 'studio', valid: true } });
    expect(result.entitlement.deviceId).toBeUndefined();
    expect(installLicenseFromFile).toHaveBeenCalledTimes(1);
  });

  test('does not retry deterministic auth failures', async () => {
    const { syncEntitlement } = loadSubject();

    global.fetch = jest.fn().mockResolvedValue({ ok: false, status: 401 });

    const result = await syncEntitlement({ sender: { id: 3 } }, {});

    expect(global.fetch).toHaveBeenCalledTimes(1);
    expect(result).toEqual({
      ok: false,
      error: 'Entitlement fetch failed (401)',
      code: 'entitlement_http_401',
      retryable: false,
      message: 'Entitlement fetch failed (401)'
    });
  });
});
