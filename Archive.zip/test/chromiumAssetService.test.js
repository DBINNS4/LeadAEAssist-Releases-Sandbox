const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const runtimeAssetService = require('../services/runtimeAssetService');
const chromiumAssetService = require('../services/chromiumAssetService');

function makeTempDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'leadae-chromium-asset-'));
}

function touchFile(filePath) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, '', 'utf8');
}

test('chromium asset service: resolves a manifest entrypoint relative to the installed asset root', () => {
  const root = makeTempDir();
  const binary = path.join(root, 'chrome', 'custom-browser', 'chrome');
  touchFile(binary);

  const resolved = chromiumAssetService.resolveChromiumExecutableFromAssetRoot(
    root,
    { entrypoint: 'chrome/custom-browser/chrome' },
    { platform: 'linux' }
  );

  assert.equal(resolved, binary);
});

test('chromium asset service: falls back to macOS app bundle discovery when entrypoint is absent', () => {
  const root = makeTempDir();
  const binary = path.join(
    root,
    'chrome',
    'mac_arm-127.0.6533.88',
    'chrome-mac-arm64',
    'Google Chrome for Testing.app',
    'Contents',
    'MacOS',
    'Google Chrome for Testing'
  );
  touchFile(binary);

  const resolved = chromiumAssetService.resolveChromiumExecutableFromAssetRoot(root, {}, { platform: 'darwin' });
  assert.equal(resolved, binary);
});

test('chromium asset service: ensureChromiumExecutablePath returns both asset root and executable path', async () => {
  const root = makeTempDir();
  const binary = path.join(
    root,
    'chrome',
    'mac_arm-127.0.6533.88',
    'chrome-mac-arm64',
    'Google Chrome for Testing.app',
    'Contents',
    'MacOS',
    'Google Chrome for Testing'
  );
  touchFile(binary);

  const originalEnsureAsset = runtimeAssetService.ensureAsset;
  const originalGetAssetDescriptor = runtimeAssetService.getAssetDescriptor;

  runtimeAssetService.ensureAsset = async () => ({ ok: true, assetId: 'puppeteer.cache.darwin.arm64', path: root, source: 'seed' });
  runtimeAssetService.getAssetDescriptor = () => ({
    entrypoint: 'chrome/mac_arm-127.0.6533.88/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
  });

  try {
    const ensured = await chromiumAssetService.ensureChromiumExecutablePath({
      assetId: 'puppeteer.cache.darwin.arm64',
      isPackaged: true,
      platform: 'darwin',
      arch: 'arm64'
    });

    assert.equal(ensured.assetRoot, root);
    assert.equal(ensured.executablePath, binary);
    assert.equal(ensured.source, 'seed');
  } finally {
    runtimeAssetService.ensureAsset = originalEnsureAsset;
    runtimeAssetService.getAssetDescriptor = originalGetAssetDescriptor;
  }
});
