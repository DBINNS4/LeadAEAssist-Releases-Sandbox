const flushPromises = () => new Promise(resolve => setImmediate(resolve));

const buildFixturePreset = (overrides = {}) => ({
  outputFormat: 'h264',
  containerFormat: 'mp4',
  resolution: 'source',
  frameRate: 'source',
  pixelFormat: 'default',
  colorRange: '',
  fieldOrder: 'progressive',
  lutPath: '/tmp/luts/show-look.cube',
  audioCodec: 'aac',
  channels: 'stereo',
  sampleRate: '48000',
  audioBitrate: '192k',
  audioDelay: '125',
  normalizeAudio: true,
  captionSidecarPath: '/tmp/captions/scene01.srt',
  verificationMethod: 'metadata',
  saveLog: true,
  enableN8N: true,
  n8nUrl: 'https://example.com/webhook/transcode',
  n8nAllowPrivate: true,
  n8nLog: true,
  notes: 'Preset notes for parity checks',
  watchMode: true,
  watchProcessExisting: true,
  matchSource: true,
  preserveMetadata: false,
  audioOnly: false,
  outputPath: '/tmp/output/master',
  inputFiles: ['/tmp/input/A001.mov', '/tmp/input/A002.mov'],
  ...overrides
});

function ensureOption(selectId, value) {
  const select = document.getElementById(selectId);
  if (!select || value == null || value === '') return;
  if ([...select.options].some(opt => opt.value === value)) return;
  const opt = document.createElement('option');
  opt.value = value;
  opt.textContent = value;
  select.appendChild(opt);
}

function setupPresetOptions(preset) {
  ensureOption('outputFormat', preset.outputFormat);
  ensureOption('containerFormat', preset.containerFormat);
  ensureOption('resolution', preset.resolution);
  ensureOption('frameRate', preset.frameRate);
  ensureOption('pixelFormat', preset.pixelFormat);
  ensureOption('colorRange', preset.colorRange);
  ensureOption('fieldOrder', preset.fieldOrder);
  ensureOption('audioCodec', preset.audioCodec);
  ensureOption('channels', preset.channels);
  ensureOption('sampleRate', preset.sampleRate);
  ensureOption('audioBitrate', preset.audioBitrate);
  ensureOption('transcode-verification-method', preset.verificationMethod);
}

function getControls() {
  return {
    inputFiles: document.getElementById('inputFiles'),
    watchFolderPath: document.getElementById('transcode-watch-folder-path'),
    audioOnly: document.getElementById('transcode-audio-only'),
    outputFormat: document.getElementById('outputFormat'),
    containerFormat: document.getElementById('containerFormat'),
    outputPath: document.getElementById('outputPath'),
    resolution: document.getElementById('resolution'),
    frameRate: document.getElementById('frameRate'),
    pixelFormat: document.getElementById('pixelFormat'),
    colorRange: document.getElementById('colorRange'),
    fieldOrder: document.getElementById('fieldOrder'),
    audioCodec: document.getElementById('audioCodec'),
    channels: document.getElementById('channels'),
    sampleRate: document.getElementById('sampleRate'),
    audioBitrate: document.getElementById('audioBitrate'),
    audioDelay: document.getElementById('audioDelay'),
    normalizeAudio: document.getElementById('normalizeAudio'),
    saveLog: document.getElementById('transcode-save-log'),
    enableN8N: document.getElementById('transcode-enable-n8n'),
    n8nUrl: document.getElementById('transcode-n8n-url'),
    n8nAllowPrivate: document.getElementById('transcode-n8n-allow-private'),
    n8nLog: document.getElementById('transcode-n8n-log'),
    notes: document.getElementById('transcode-notes'),
    watchMode: document.getElementById('transcode-watch-mode'),
    watchProcessExisting: document.getElementById('transcode-watch-process-existing'),
    matchSource: document.getElementById('transcode-match-source'),
    preserveMetadata: document.getElementById('transcode-preserve-metadata'),
    ['transcode-verification-method']: document.getElementById('transcode-verification-method'),
    summary: document.getElementById('transcode-job-preview-box'),
    captionSidecarPath: document.getElementById('transcode-captions-path')
  };
}

function buildTranscodeDOM() {
  document.body.innerHTML = `
    <div id="transcode">
      <div class="transcode-input-row">
        <button id="selectInputFiles" class="button"><span class="button_text">Select Source</span></button>
      </div>
      <textarea id="inputFiles" data-file-list="[]"></textarea>
      <input id="transcode-watch-folder-path" class="hidden" />
      <div class="file-info-scroll"><div id="transcode-file-info"></div></div>
      <select id="outputFormat"><option value="h264">h264</option></select>
      <select id="containerFormat"><option value="mp4">mp4</option></select>
      <input id="outputPath" value="/tmp/out" />
      <button id="selectOutput"></button>
      <select id="resolution"><option value="source">source</option></select>
      <select id="frameRate"><option value="source">source</option></select>
      <select id="audioCodec"><option value="aac">aac</option></select>
      <select id="channels"><option value="stereo">stereo</option></select>
      <select id="pixelFormat"><option value="default">default</option></select>
      <select id="colorRange"><option value=""></option></select>
      <input id="transcode-lut-display" />
      <input id="transcode-lut-path" />
      <button id="transcode-lut-drop"></button>
      <select id="fieldOrder"><option value="progressive">progressive</option></select>
      <select id="sampleRate"><option value="48000">48000</option></select>
      <select id="audioBitrate"><option value="192k">192k</option></select>
      <input type="checkbox" id="normalizeAudio" />
      <input id="audioDelay" />
      <button id="startTranscode" class="button"><span class="button_text">Start</span></button>
      <button id="cancelTranscode" class="button"><span class="button_text">Cancel</span></button>
      <button id="resetTranscode"></button>
      <progress id="transcode-progress"></progress>
      <pre id="transcode-log-output"></pre>
      <textarea id="transcode-job-preview-box"></textarea>
      <select id="transcode-preset"></select>
      <button id="saveTranscodePreset"></button>
      <button id="loadTranscodePreset"></button>
      <select id="transcode-verification-method"><option value="metadata">metadata</option></select>
      <input type="checkbox" id="transcode-save-log" />
      <input type="checkbox" id="transcode-enable-n8n" />
      <input id="transcode-n8n-url" />
      <input type="checkbox" id="transcode-n8n-allow-private" />
      <input type="checkbox" id="transcode-n8n-log" />
      <textarea id="transcode-notes"></textarea>
      <input type="checkbox" id="transcode-watch-mode" />
      <input type="checkbox" id="transcode-watch-process-existing" />
      <input type="checkbox" id="transcode-match-source" />
      <input type="checkbox" id="transcode-preserve-metadata" />
      <input type="checkbox" id="transcode-audio-only" />
      <details id="transcode-audio-details"><summary>Audio</summary></details>
      <button id="transcode-select-captions"></button>
      <input id="transcode-captions-display" />
      <input id="transcode-captions-path" />
      <button id="transcode-clear-captions"></button>
      <div id="transcode-job-status"></div>
      <input type="checkbox" id="transcode-hide-log" />
    </div>
  `;

  Object.defineProperty(document, 'readyState', {
    configurable: true,
    get: () => 'complete'
  });

  window.codex = {
    getFormatCapabilities: jest.fn(async () => ({ encoderAvailable: true }))
  };

  window.electron.selectFolder = jest.fn(async () => null);
  window.electron.selectFiles = jest.fn(async () => []);
  window.electron.statSync = jest.fn(() => ({ isDirectory: () => true }));
  window.electron.dirname = jest.fn((p) => p.split('/').slice(0, -1).join('/') || '/');
  window.electron.extname = jest.fn(() => '.mov');
  window.electron.normalizePath = jest.fn((p) => p);
}

describe('Transcode panel preset watch-mode sync', () => {
  async function savePresetAndReadPayload({ watchMode = false, useAtomicWrite = true } = {}) {
    jest.resetModules();
    buildTranscodeDOM();

    const deterministicPath = '/tmp/presets/transcode-preset.json';
    const writeCapture = { path: '', text: '' };

    window.electron.joinPath = jest.fn((...parts) => parts.join('/').replace(/\/+/g, '/'));
    window.electron.basename = jest.fn((p) => String(p).split('/').pop());
    window.electron.saveFile = jest.fn(async () => deterministicPath);
    window.electron.writeTextFile = jest.fn();
    window.electron.writeTextFileAsync = useAtomicWrite
      ? undefined
      : jest.fn(async (filePath, payload) => {
        writeCapture.path = filePath;
        writeCapture.text = payload;
      });
    window.electron.writeTextFileAtomicAsync = useAtomicWrite
      ? jest.fn(async (filePath, payload) => {
        writeCapture.path = filePath;
        writeCapture.text = payload;
      })
      : undefined;

    require('../renderer.transcode.js');
    const baseInputFiles = ['/tmp/input/A001.mov', '/tmp/input/A002.mov'];
    const controls = getControls();
    ensureOption('outputFormat', 'prores_ks');
    ensureOption('containerFormat', 'mov');
    ensureOption('resolution', '3840x2160');
    ensureOption('frameRate', '23.976');
    ensureOption('pixelFormat', 'yuv422p10le');
    ensureOption('colorRange', 'tv');
    ensureOption('fieldOrder', 'tt');
    ensureOption('audioCodec', 'pcm_s24le');
    ensureOption('channels', '5.1');
    ensureOption('sampleRate', '96000');
    ensureOption('audioBitrate', '320k');

    controls.outputPath.value = '/tmp/output/transcodes';
    controls.outputFormat.value = 'prores_ks';
    controls.containerFormat.value = 'mov';
    controls.resolution.value = '3840x2160';
    controls.frameRate.value = '23.976';
    controls.pixelFormat.value = 'yuv422p10le';
    controls.colorRange.value = 'tv';
    controls.fieldOrder.value = 'tt';
    document.getElementById('transcode-lut-path').value = '/tmp/luts/creative.cube';

    controls.audioCodec.value = 'pcm_s24le';
    controls.channels.value = '5.1';
    controls.sampleRate.value = '96000';
    controls.audioBitrate.value = '320k';
    controls.audioDelay.value = '-48';
    controls.normalizeAudio.checked = true;
    controls.captionSidecarPath.value = '/tmp/captions/scene10.srt';

    controls['transcode-verification-method'].value = 'metadata';
    controls.saveLog.checked = true;
    controls.enableN8N.checked = true;
    controls.n8nUrl.value = 'https://example.com/hooks/transcode';
    controls.n8nAllowPrivate.checked = true;
    controls.n8nLog.checked = true;
    controls.notes.value = 'Nightly preset snapshot';

    controls.watchMode.checked = watchMode;
    controls.watchProcessExisting.checked = true;
    controls.matchSource.checked = true;
    controls.preserveMetadata.checked = true;
    controls.inputFiles.value = baseInputFiles.join('\n');
    controls.inputFiles.dataset.fileList = JSON.stringify(baseInputFiles);

    controls.audioOnly.checked = false;
    controls.audioOnly.dispatchEvent(new Event('change'));
    document.getElementById('saveTranscodePreset').click();
    await flushPromises();

    return {
      path: writeCapture.path,
      payload: JSON.parse(writeCapture.text),
      deterministicPath,
      baseInputFiles
    };
  }

  beforeEach(() => {
    jest.resetModules();
    window.setupStyledDropdown = (id, options = []) => {
      const select = document.getElementById(id);
      if (!select) return;
      select.innerHTML = '<option value=""></option>';
      options.forEach((opt) => {
        const normalized = typeof opt === 'string'
          ? { value: opt, label: opt }
          : opt;
        const option = document.createElement('option');
        option.value = normalized?.value ?? '';
        option.textContent = normalized?.label ?? String(normalized?.value ?? '');
        select.appendChild(option);
      });
    };
    window.setDropdownValue = (id, value) => {
      const select = document.getElementById(id);
      if (select) select.value = value;
    };
    global.setupStyledDropdown = window.setupStyledDropdown;
    global.setDropdownValue = window.setDropdownValue;
    ipc.on.mockReset();
    ipc.invoke.mockReset();
    ipc.invoke.mockImplementation(async (channel, arg) => {
      if (channel === 'normalize-path') return String(arg ?? '').trim();
      if (channel === 'path-exists') return true;
      if (channel === 'codex:list-formats') {
        return [
          { id: 'h264', label: 'h264' },
          { id: 'dnxhr_hq', label: 'dnxhr_hq' },
          { id: 'prores_ks', label: 'prores_ks' }
        ];
      }
      if (channel === 'codex:list-audio-codecs') {
        return ['aac', 'mp3', 'wav', 'pcm_s24le'];
      }
      if (channel === 'codex:get-compatibility') {
        return {
          containers: ['mp4', 'mov', 'mxf', 'image_sequence'],
          resolutions: ['source', '1920x1080', '3840x2160'],
          frameRates: ['source', '23.976', '24', '29.97'],
          pixelFormats: ['default', 'yuv422p10le'],
          audioCodecs: ['aac', 'wav', 'pcm_s24le'],
          sampleRates: ['48000', '96000'],
          channels: ['mono', 'stereo', '5.1']
        };
      }
      if (channel === 'transcode-validate-paths') {
        const list = Array.isArray(arg) ? arg : [];
        const results = Object.fromEntries(list.map((item) => [item, {
          exists: true,
          isDirectory: true,
          isFile: false,
          writable: true,
          writeReason: ''
        }]));
        return { success: true, results };
      }
      if (channel === 'codex:get-format-capabilities') return { encoderAvailable: true };
      return undefined;
    });
    buildTranscodeDOM();
  });

  test('loading a watch-mode preset syncs watch button labels and selector wording', async () => {
    const { applyPresetToFields } = require('../renderer.transcode.js');
    const controls = getControls();

    await applyPresetToFields({ watchMode: true, watchProcessExisting: true }, controls);
    await flushPromises();

    expect(document.querySelector('#startTranscode .button_text').textContent).toBe('Start Watching');
    expect(document.querySelector('#cancelTranscode .button_text').textContent).toBe('Stop Watching');
    expect(document.querySelector('#selectInputFiles .button_text').textContent).toBe('Select Watch Folder');
  });

  test('loading a non-audio-only preset restores all persisted field values', async () => {
    const { applyPresetToFields } = require('../renderer.transcode.js');
    const fixturePreset = buildFixturePreset({
      audioOnly: false,
      watchMode: false,
      watchProcessExisting: false,
      captionSidecarPath: ''
    });
    setupPresetOptions(fixturePreset);
    const controls = getControls();

    await applyPresetToFields(fixturePreset, controls);
    await flushPromises();
    await applyPresetToFields(fixturePreset, controls);
    await flushPromises();

    expect(controls.outputFormat.value).toBe(fixturePreset.outputFormat);
    expect(controls.containerFormat.value).toBe(fixturePreset.containerFormat);
    expect(controls.resolution.value).toBe(fixturePreset.resolution);
    expect(controls.frameRate.value).toBe(fixturePreset.frameRate);
    expect(controls.pixelFormat.value).toBe(fixturePreset.pixelFormat);
    expect(controls.colorRange.value).toBe(fixturePreset.colorRange);
    expect(controls.fieldOrder.value).toBe(fixturePreset.fieldOrder);
    expect(document.getElementById('transcode-lut-path').value).toBe(fixturePreset.lutPath);

    expect(controls.audioCodec.value).toBe(fixturePreset.audioCodec);
    expect(controls.channels.value).toBe(fixturePreset.channels);
    expect(controls.sampleRate.value).toBe(fixturePreset.sampleRate);
    expect(controls.audioBitrate.value).toBe(fixturePreset.audioBitrate);
    expect(controls.audioDelay.value).toBe(fixturePreset.audioDelay);
    expect(controls.normalizeAudio.checked).toBe(true);

    expect(controls.captionSidecarPath.value).toBe('');
    expect(controls['transcode-verification-method'].value).toBe(fixturePreset.verificationMethod);
    expect(controls.saveLog.checked).toBe(true);
    expect(controls.enableN8N.checked).toBe(true);
    expect(controls.n8nUrl.value).toBe(fixturePreset.n8nUrl);
    expect(controls.n8nAllowPrivate.checked).toBe(true);
    expect(controls.n8nLog.checked).toBe(true);
    expect(controls.notes.value).toBe(fixturePreset.notes);
    expect(controls.watchMode.checked).toBe(false);
    expect(controls.watchProcessExisting.checked).toBe(false);
    expect(controls.matchSource.checked).toBe(false);
    expect(controls.preserveMetadata.checked).toBe(false);
    expect(controls.audioOnly.checked).toBe(false);
    expect(controls.outputPath.value).toBe(fixturePreset.outputPath);
    expect(controls.inputFiles.value).toBe(fixturePreset.inputFiles.join('\n'));
    expect(controls.inputFiles.dataset.fileList).toBe(JSON.stringify(fixturePreset.inputFiles));
  });

  test('loading an audio-only preset preserves saved video selections when toggled back off', async () => {
    const { applyPresetToFields } = require('../renderer.transcode.js');
    const fixturePreset = buildFixturePreset({
      audioOnly: true,
      watchMode: false,
      audioCodec: 'pcm_s24le',
      inputFiles: ['/tmp/input/B001.mov']
    });
    setupPresetOptions(fixturePreset);
    ensureOption('audioCodec', 'wav');
    ensureOption('outputFormat', 'dnxhr_hq');
    ensureOption('containerFormat', 'mov');
    const controls = getControls();

    controls.outputFormat.value = 'dnxhr_hq';
    controls.containerFormat.value = 'mov';
    controls.resolution.value = 'source';
    controls.frameRate.value = 'source';
    controls.pixelFormat.value = 'default';
    controls.colorRange.value = '';
    controls.fieldOrder.value = 'progressive';
    document.getElementById('transcode-lut-path').value = '/tmp/luts/ui-state-before-load.cube';

    await applyPresetToFields(fixturePreset, controls);
    await flushPromises();

    expect(controls.audioOnly.checked).toBe(true);
    expect(controls.audioCodec.value).toBe('wav');
    expect(controls.captionSidecarPath.value).toBe(fixturePreset.captionSidecarPath);

    controls.audioOnly.checked = false;
    controls.audioOnly.dispatchEvent(new Event('change'));
    await flushPromises();

    expect(controls.outputFormat.value).toBe(fixturePreset.outputFormat);
    expect(controls.containerFormat.value).toBe(fixturePreset.containerFormat);
    expect(controls.resolution.value).toBe(fixturePreset.resolution);
    expect(controls.frameRate.value).toBe(fixturePreset.frameRate);
    expect(controls.pixelFormat.value).toBe(fixturePreset.pixelFormat);
    expect(controls.colorRange.value).toBe(fixturePreset.colorRange);
    expect(controls.fieldOrder.value).toBe(fixturePreset.fieldOrder);
    expect(document.getElementById('transcode-lut-path').value).toBe(fixturePreset.lutPath);
  });

  test('save preset serializes all transcode panel fields including alias keys and source-path variants', async () => {
    const nonWatch = await savePresetAndReadPayload({ watchMode: false, useAtomicWrite: true });

    expect(nonWatch.path).toBe(nonWatch.deterministicPath);
    expect(nonWatch.payload.outputPath).toBe('/tmp/output/transcodes');
    expect(nonWatch.payload.outputFormat).toBe('prores_ks');
    expect(nonWatch.payload.containerFormat).toBe('mov');
    expect(nonWatch.payload.resolution).toBe('3840x2160');
    expect(nonWatch.payload.frameRate).toBe('23.976');
    expect(nonWatch.payload.pixelFormat).toBe('yuv422p10le');
    expect(nonWatch.payload.colorRange).toBe('tv');
    expect(nonWatch.payload.fieldOrder).toBe('tt');
    expect(nonWatch.payload.lutPath).toBe('/tmp/luts/creative.cube');
    expect(nonWatch.payload.audioOnly).toBe(false);
    expect(nonWatch.payload.audioCodec).toBe('pcm_s24le');
    expect(nonWatch.payload.channels).toBe('5.1');
    expect(nonWatch.payload.sampleRate).toBe('96000');
    expect(nonWatch.payload.audioBitrate).toBe('320k');
    expect(nonWatch.payload.audioDelay).toBe('-48');
    expect(nonWatch.payload.normalizeAudio).toBe(true);
    expect(nonWatch.payload.captionSidecarPath).toBe('/tmp/captions/scene10.srt');
    expect(nonWatch.payload.verificationMethod).toBe('metadata');
    expect(nonWatch.payload.verification).toEqual({ method: 'metadata', saveLog: true });
    expect(nonWatch.payload.saveLog).toBe(true);
    expect(nonWatch.payload.enableN8N).toBe(true);
    expect(nonWatch.payload.n8nUrl).toBe('https://example.com/hooks/transcode');
    expect(nonWatch.payload.n8nAllowPrivate).toBe(true);
    expect(nonWatch.payload.n8nLog).toBe(true);
    expect(nonWatch.payload.notes).toBe('Nightly preset snapshot');
    expect(nonWatch.payload.watchMode).toBe(false);
    expect(nonWatch.payload.watchProcessExisting).toBe(true);
    expect(nonWatch.payload.processExistingOnStart).toBe(true);
    expect(nonWatch.payload.watchFolder).toBe('');
    expect(nonWatch.payload.watchFolderPath).toBe('');
    expect(nonWatch.payload.inputFiles).toEqual(nonWatch.baseInputFiles);
    expect(nonWatch.payload.sourcePaths).toEqual(nonWatch.baseInputFiles);
    expect(nonWatch.payload.matchSource).toBe(true);
    expect(nonWatch.payload.preserveMetadata).toBe(true);

    const watchMode = await savePresetAndReadPayload({ watchMode: true, useAtomicWrite: false });
    expect(watchMode.path).toBe(watchMode.deterministicPath);
    expect(watchMode.payload.watchMode).toBe(true);
    expect(watchMode.payload.watchFolder).toBe(watchMode.baseInputFiles[0]);
    expect(watchMode.payload.watchFolderPath).toBe(watchMode.baseInputFiles[0]);
    expect(watchMode.payload.inputFiles).toEqual([]);
    expect(watchMode.payload.sourcePaths).toEqual([]);
    expect(watchMode.payload.watchProcessExisting).toBe(true);
    expect(watchMode.payload.processExistingOnStart).toBe(true);
  });
});
