'use strict';

jest.mock('../modules/transcode', () => ({
  runTranscode: jest.fn(),
  cancelTranscode: jest.fn(),
  preflightTranscodeDisk: jest.fn(),
  formatBytes: jest.fn((n) => `${n}B`)
}));

jest.mock('../services/licenseService', () => ({
  isFeatureEnabled: jest.fn(() => true)
}));

jest.mock('../utils/trustedIpcSender', () => ({
  assertTrustedIpcSender: jest.fn()
}));

jest.mock('../utils/ipcPathGuards', () => ({
  assertApprovedPaths: jest.fn(),
  extractAbsolutePathsFromObject: jest.fn(() => []),
  toLocalPathIfFileUrl: jest.fn((v) => v)
}));

const registerTranscodeHandlers = require('../ipc/transcode.handlers');
const { preflightTranscodeDisk } = require('../modules/transcode');
const licenseService = require('../services/licenseService');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const { assertApprovedPaths } = require('../utils/ipcPathGuards');

function buildIpcMain() {
  const handlers = new Map();
  return {
    handlers,
    ipcMain: {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn))
    }
  };
}

describe('ipc/transcode.handlers preflight warning propagation', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('returns localized i18n payload when transcode feature is unlicensed', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerTranscodeHandlers(ipcMain);
    licenseService.isFeatureEnabled.mockReturnValueOnce(false);

    const result = await handlers.get('transcode-preflight')(
      { sender: { id: 1 } },
      { inputFiles: ['/tmp/a.mov'], outputFolder: '/tmp/out' }
    );

    expect(result).toEqual({
      status: 'unknown',
      message: {
        key: 'transcodePreflightLicenseRequired',
        params: {}
      },
      error: {
        key: 'transcodePreflightLicenseRequired',
        params: {}
      }
    });
    expect(preflightTranscodeDisk).not.toHaveBeenCalled();
  });

  test('appends explicit partial-estimate warning for ok responses', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerTranscodeHandlers(ipcMain);

    preflightTranscodeDisk.mockResolvedValueOnce({
      status: 'ok',
      estimateBytes: 1000,
      estimateMethod: 'sum_source',
      freeBytes: 5000,
      requiredBytes: 1100,
      warning: 'Skipped 2 file(s) due to stat/metadata errors.',
      skippedFiles: 2,
      estimatedFiles: 3,
      totalFiles: 5
    });

    const result = await handlers.get('transcode-preflight')(
      { sender: { id: 1 } },
      { inputFiles: ['/tmp/a.mov'], outputFolder: '/tmp/out' }
    );

    expect(result.status).toBe('ok');
    expect(result.message).toEqual({
      key: 'transcodePreflightEstimatedSizeSummary',
      params: {
        estimateText: '1000B',
        estimateMethod: 'sum_source',
        estimatedFiles: 3,
        totalFiles: 5,
        requiredText: '1100B',
        freeText: '5000B',
        hasWarning: true,
        skippedCount: 2
      }
    });
  });

  test('appends explicit partial-estimate warning for unknown responses', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerTranscodeHandlers(ipcMain);

    preflightTranscodeDisk.mockResolvedValueOnce({
      status: 'unknown',
      estimateBytes: 2400,
      estimateMethod: 'sum',
      freeBytes: null,
      warning: 'Skipped 1 file(s) due to stat/metadata errors.',
      skippedFiles: 1,
      estimatedFiles: 4,
      totalFiles: 5
    });

    const result = await handlers.get('transcode-preflight')(
      { sender: { id: 1 } },
      { inputFiles: ['/tmp/a.mov'], outputFolder: '/tmp/out' }
    );

    expect(result.status).toBe('unknown');
    expect(result.message).toEqual({
      key: 'transcodePreflightSkippedUnknownFreeSpace',
      params: {
        estimateText: '2400B',
        estimateMethod: 'sum',
        estimatedFiles: 4,
        totalFiles: 5,
        hasWarning: true,
        skippedCount: 1
      }
    });
  });

  test('rejects when sender is untrusted instead of returning unknown status', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerTranscodeHandlers(ipcMain);
    assertTrustedIpcSender.mockImplementationOnce(() => {
      throw new Error('UNTRUSTED_SENDER');
    });

    await expect(
      handlers.get('transcode-preflight')(
        { sender: { id: 1 } },
        { inputFiles: ['/tmp/a.mov'], outputFolder: '/tmp/out' }
      )
    ).rejects.toThrow('UNTRUSTED_SENDER');
  });

  test('rejects on path guard failures instead of returning preflight warning response', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerTranscodeHandlers(ipcMain);
    assertApprovedPaths.mockImplementationOnce(() => {
      throw new Error('PATH_NOT_APPROVED');
    });

    await expect(
      handlers.get('transcode-preflight')(
        { sender: { id: 1 } },
        { inputFiles: ['/tmp/a.mov'], outputFolder: '/tmp/out' }
      )
    ).rejects.toThrow('PATH_NOT_APPROVED');
  });

  test('returns graceful unknown response for runtime estimator failures', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerTranscodeHandlers(ipcMain);

    preflightTranscodeDisk.mockRejectedValueOnce(new Error('stat failed'));

    const result = await handlers.get('transcode-preflight')(
      { sender: { id: 1 } },
      { inputFiles: ['/tmp/a.mov'], outputFolder: '/tmp/out' }
    );

    expect(result).toEqual({
      status: 'unknown',
      message: {
        key: 'transcodePreflightSkippedWithErrorDetail',
        params: {
          errorDetail: 'stat failed'
        }
      }
    });
  });
});
