/** @jest-environment node */

describe('main shell:show-item-in-folder hardening', () => {
  test('returns false for untrusted sender and does not reveal path', async () => {
    jest.resetModules();

    const registeredHandlers = new Map();
    const showItemInFolder = jest.fn();

    jest.doMock('electron', () => ({
      app: {
        isPackaged: false,
        getAppPath: jest.fn(() => '/workspace/LeadAEAssist'),
        setName: jest.fn(),
        setPath: jest.fn(),
        isReady: jest.fn(() => true),
        quit: jest.fn(),
        on: jest.fn(),
        whenReady: jest.fn(() => new Promise(() => {}))
      },
      BrowserWindow: jest.fn(),
      dialog: {},
      ipcMain: {
        handle: jest.fn((channel, fn) => registeredHandlers.set(channel, fn)),
        on: jest.fn()
      },
      session: { defaultSession: {} },
      screen: { getPrimaryDisplay: jest.fn(() => ({ workAreaSize: { width: 1920, height: 1080 } })) },
      shell: { showItemInFolder }
    }));

    jest.doMock('../utils/trustedIpcSender', () => ({
      assertTrustedIpcSender: jest.fn((event, action) => {
        if (event?.senderFrame?.url === 'https://evil.example') {
          const err = new Error(`Blocked ${action}`);
          err.code = 'ERR_UNTRUSTED_ORIGIN';
          throw err;
        }
      })
    }));

    jest.doMock('../utils/ipcPathGuards', () => ({
      toLocalPathIfFileUrl: jest.fn((v) => v),
      assertApprovedPath: jest.fn((_, p) => p)
    }));

    jest.doMock('../utils/ffmpegBridge', () => ({ getBinaryPaths: jest.fn(() => ({ ffmpegPath: '/ffmpeg', ffprobePath: '/ffprobe' })) }));
    jest.doMock('../utils/ffmpegPreflight', () => ({ preflightFfmpegBinaries: jest.fn(), looksLikeGatekeeperKill: jest.fn(() => false) }));
    jest.doMock('../utils/ffmpegCapabilities', () => ({ configure: jest.fn(), listEncoders: jest.fn(() => []) }));
    jest.doMock('../utils/externalNavigationGuards', () => ({ installExternalNavigationGuards: jest.fn() }));
    jest.doMock('../services/licenseService', () => ({}));
    jest.doMock('../modules/clone', () => ({}));
    jest.doMock('../modules/logUtils', () => ({ sendLogMessage: jest.fn(), createSessionLogWriter: jest.fn() }));
    jest.doMock('../modules/cepBridge', () => ({ startCEPBridge: jest.fn() }));
    jest.doMock('../services/bridgeServerService', () => ({ getCredentials: jest.fn() }));
    jest.doMock('../ipc', () => ({ registerIpcHandlers: jest.fn() }));
    jest.doMock('../services/telemetryService', () => ({ init: jest.fn() }));
    jest.doMock('../services/autoUpdateService', () => ({ initAutoUpdates: jest.fn() }));
    jest.doMock('../platform/paths', () => ({
      getUserDataRoot: jest.fn(() => '/tmp/LeadAEAssist-user-data'),
      ensureDirSync: jest.fn()
    }));
    jest.doMock('../utils/fsSafe', () => ({ atomicWriteJson: jest.fn() }));
    jest.doMock('../utils/maintenance', () => ({ runStartupMaintenance: jest.fn() }));
    jest.doMock('../utils/state', () => ({ readState: jest.fn(() => ({})) }));
    jest.doMock('../utils/startupBootstrap', () => ({
      buildStartupHealth: jest.fn(() => ({})),
      loadStartupDependencies: jest.fn()
    }));
    jest.doMock('../utils/globalErrorHandlers', () => ({ registerGlobalErrorHandlers: jest.fn() }));
    jest.doMock('../utils/watchRegistry', () => ({
      getSharedWatchRegistry: jest.fn(),
      flushSharedWatchRegistrySave: jest.fn(),
      createSessionKey: jest.fn(),
      createFileSignature: jest.fn(),
      isProcessed: jest.fn()
    }));

    jest.isolateModules(() => {
      require('../main');
    });

    const handler = registeredHandlers.get('shell:show-item-in-folder');
    expect(typeof handler).toBe('function');

    const result = await handler(
      { senderFrame: { url: 'https://evil.example' }, sender: { id: 77 } },
      '/tmp/file.mov'
    );

    expect(result).toBe(false);
    expect(showItemInFolder).not.toHaveBeenCalled();
  });
});
