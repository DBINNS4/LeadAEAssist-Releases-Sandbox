// tests/mcc_roundtrip.test.js
// Milestone 0: encode -> verify -> decode round-trip tests for MCC.
//
// Run (Node 18+):
//   node --test tests/mcc_roundtrip.test.js
//
// Or run the CLI smoke test:
//   node scripts/milestone0_mcc_roundtrip.js

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { generateMCC, verifyMCC } = require('../modules/sccEncoder');
const { decodeMccText } = require('../modules/mccDecoder');
const { framesToSeconds } = require('../utils/timeUtils');

function normText(s) {
  return String(s || '').replace(/\s+/g, ' ').trim();
}

test('MCC round-trip: generate -> verify -> decode (708 preferred, 608 available)', () => {
  const fps = 29.97;
  const dropFrame = true;

  // Use exact frame boundaries to reduce floating error noise.
  const segments = [
    {
      start: framesToSeconds(0, fps),
      end: framesToSeconds(45, fps),
      text: 'Hello world.'
    },
    {
      start: framesToSeconds(60, fps),
      end: framesToSeconds(150, fps),
      // Intentionally long-ish but still 608-safe after wrapping (<=32 cols, <=2 lines).
      text: 'This is a longer caption that stays within limits.'
    },
    {
      start: framesToSeconds(165, fps),
      end: framesToSeconds(240, fps),
      text: 'Last cue.'
    }
  ];

  const mcc = generateMCC(segments, {
    fps,
    dropFrame,
    include608Compatibility: true,
    telestreamCompression: false,
    serviceNumber: 1,
    language: 'eng'
  });

  // Phase 2: MCC encoder may apply a bounded file-start ripple shift so the
  // earliest cue has enough runway for 708 preload packets.
  const timingMeta = (mcc && typeof mcc === 'object' && mcc._mccMeta && mcc._mccMeta.timingPolicy)
    ? mcc._mccMeta.timingPolicy
    : null;
  const shiftFrames = timingMeta && Number.isFinite(timingMeta.shiftFrames) ? timingMeta.shiftFrames : 0;
  const shiftSec = shiftFrames / fps;

  const v = verifyMCC(mcc, {
    strictPayloadParse: true,
    checkAncChecksum: true,
    checkCdpChecksum: true,
    checkCdpLength: true,
    checkCcCount: true,
    checkSequence: true
  });

  assert.equal(v.ok, true, `verifyMCC failed: ${JSON.stringify(v.errors?.slice(0, 10) || [], null, 2)}`);

  // Decode 708 (preferred path)
  const decoded708 = decodeMccText(mcc, { fps, dropFrame });
  assert.equal(decoded708.format, 'mcc');
  assert.equal(decoded708.kind, 'cea708');

  // Decode 608 (compat path)
  const decoded608 = decodeMccText(mcc, { fps, dropFrame, force608Compatibility: true });
  assert.equal(decoded608.format, 'mcc');
  assert.equal(decoded608.kind, 'cea608');

  const cues708 = (decoded708.cues || []).filter((c) => normText(c.text));
  const cues608 = (decoded608.cues || []).filter((c) => normText(c.text));

  assert.equal(cues708.length, segments.length, `Expected ${segments.length} decoded 708 cues, got ${cues708.length}`);
  assert.equal(cues608.length, segments.length, `Expected ${segments.length} decoded 608 cues, got ${cues608.length}`);

  // Text parity (normalize whitespace because decoders introduce line breaks).
  for (let i = 0; i < segments.length; i++) {
    const expected = normText(segments[i].text);
    assert.equal(normText(cues708[i].text), expected, `708 cue[${i}] text mismatch`);
    assert.equal(normText(cues608[i].text), expected, `608 cue[${i}] text mismatch`);
  }

  // Timing sanity (within ~1 frame).
  const frameTol = (1 / fps) * 1.5;
  for (let i = 0; i < segments.length; i++) {
    const expStart = segments[i].start + shiftSec;
    const expEnd = segments[i].end + shiftSec;

    assert.ok(Math.abs((cues708[i].start || 0) - expStart) <= frameTol, `708 cue[${i}] start off by >1 frame`);
    assert.ok(Math.abs((cues708[i].end || 0) - expEnd) <= frameTol, `708 cue[${i}] end off by >1 frame`);

    assert.ok(Math.abs((cues608[i].start || 0) - expStart) <= frameTol, `608 cue[${i}] start off by >1 frame`);
    assert.ok(Math.abs((cues608[i].end || 0) - expEnd) <= frameTol, `608 cue[${i}] end off by >1 frame`);
  }
});
