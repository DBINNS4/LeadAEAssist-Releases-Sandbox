const { TextEncoder, TextDecoder } = require('util');

global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder;

describe('Log viewer filters and reset behavior', () => {
  const flushMicrotasks = () => new Promise(resolve => setImmediate(resolve));

  const buildDom = () => {
    document.body.innerHTML = `
      <select id="view-by-date"></select>
      <input id="log-start-date" />
      <input id="log-end-date" />
      <select id="view-by-tool"></select>
      <input type="checkbox" id="show-errors-only" />
      <input type="checkbox" id="include-system-logs" />
      <input id="log-search" />
      <button id="expand-task-details"></button>
      <div id="live-log-view"></div>
      <select id="export-format"></select>
      <button id="export-log-btn"></button>
      <input id="export-folder-path" />
      <button id="select-export-folder"></button>
      <div id="log-toast"></div>
      <button id="reset-log-viewer"></button>
    `;

    document.getElementById('view-by-date').value = 'today';
    document.getElementById('view-by-tool').value = 'all';
    document.getElementById('export-format').value = 'txt';
  };

  beforeEach(() => {
    jest.resetModules();
    buildDom();

    Object.defineProperty(document, 'readyState', {
      configurable: true,
      get: () => 'complete',
    });

    window.electron = {
      resolvePath: jest.fn(path => `/mock/${path}`),
      readLogFiles: jest.fn(),
      joinPath: (...parts) => parts.join('/'),
      writeTextFile: jest.fn(),
    };
  });

  test('system logs are excluded unless allowed by checkbox or tool filter', async () => {
    const now = Date.now();
    window.electron.readLogFiles
      .mockReturnValueOnce([
        { timestamp: now, type: 'system', message: 'sys message' },
        { timestamp: now - 1000, type: 'ingest', message: 'ingest message' },
      ])
      .mockReturnValue([]);

    const { getFilteredLogs } = require('../renderer.log-viewer.js');
    await flushMicrotasks();

    const initial = getFilteredLogs();
    expect(initial.map(l => l.type)).toEqual(['ingest']);

    const toolFilter = document.getElementById('view-by-tool');
    toolFilter.value = 'ingest';
    expect(getFilteredLogs().every(l => l.type !== 'system')).toBe(true);

    document.getElementById('include-system-logs').checked = true;
    toolFilter.value = 'all';
    expect(getFilteredLogs().some(l => l.type === 'system')).toBe(true);

    document.getElementById('include-system-logs').checked = false;
    toolFilter.value = 'system';
    expect(getFilteredLogs().every(l => l.type === 'system')).toBe(true);
  });

  test('reset repopulates the log list from disk', async () => {
    const now = Date.now();
    const initialLogs = [
      { timestamp: now - 2000, type: 'ingest', message: 'initial log' },
    ];
    const refreshedLogs = [
      { timestamp: now - 1000, type: 'system', message: 'refreshed log' },
      { timestamp: now, type: 'ingest', message: 'new ingest' },
    ];

    window.electron.readLogFiles
      .mockReturnValueOnce(initialLogs)
      .mockReturnValue(refreshedLogs);

    const { resetLogViewer } = require('../renderer.log-viewer.js');
    await flushMicrotasks();

    const container = document.getElementById('live-log-view');
    expect(container.textContent).toContain('initial log');

    resetLogViewer();
    await flushMicrotasks();

    expect(container.textContent).toContain('new ingest');
    expect(container.textContent).not.toContain('Initialized');
  });

  test('log retention trims oldest entries when cap is reached', async () => {
    window.LOG_VIEWER_RETENTION_LIMIT = 3;
    const ipcHandlers = {};
    window.ipc = {
      on: jest.fn((event, cb) => { ipcHandlers[event] = cb; }),
    };

    window.electron.readLogFiles.mockReturnValue([]);

    const now = Date.now();
    const nowSpy = jest.spyOn(Date, 'now');
    const { getFilteredLogs } = require('../renderer.log-viewer.js');

    await flushMicrotasks();

    ['msg-1', 'msg-2', 'msg-3', 'msg-4'].forEach((message, idx) => {
      nowSpy.mockReturnValue(now + idx);
      ipcHandlers['ingest-log-message']?.({}, { message });
    });

    nowSpy.mockRestore();
    delete window.LOG_VIEWER_RETENTION_LIMIT;

    const messages = getFilteredLogs().map(l => l.message);
    expect(messages).toHaveLength(3);
    expect(messages).toEqual(['msg-4', 'msg-3', 'msg-2']);
    expect(messages).not.toContain('msg-1');
  });



  test('exports logs in chronological order (oldest to newest)', async () => {
    const now = Date.now();
    document.getElementById('export-folder-path').value = '/tmp/logs';
    document.getElementById('export-format').value = 'txt';
    document.getElementById('view-by-date').value = 'all';
    window.electron.readLogFiles.mockReturnValue([]);

    const { exportLog, __setLogs } = require('../renderer.log-viewer.js');
    await flushMicrotasks();

    __setLogs([
      { timestamp: now, type: 'ingest', message: 'newest' },
      { timestamp: now - 1000, type: 'ingest', message: 'middle' },
      { timestamp: now - 2000, type: 'ingest', message: 'oldest' },
    ]);

    exportLog();

    expect(window.electron.writeTextFile).toHaveBeenCalled();
    const [, written] = window.electron.writeTextFile.mock.calls[0];
    const oldestIdx = written.indexOf('oldest');
    const middleIdx = written.indexOf('middle');
    const newestIdx = written.indexOf('newest');

    expect(oldestIdx).toBeGreaterThanOrEqual(0);
    expect(middleIdx).toBeGreaterThan(oldestIdx);
    expect(newestIdx).toBeGreaterThan(middleIdx);
  });

  test('CSV export includes extended log columns', async () => {
    document.getElementById('export-folder-path').value = '/tmp/logs';
    document.getElementById('export-format').value = 'csv';
    window.electron.readLogFiles.mockReturnValue([]);

    const { exportLog, __setLogs } = require('../renderer.log-viewer.js');
    document.getElementById('export-format').value = 'csv';
    await flushMicrotasks();

    __setLogs([
      {
        timestamp: Date.now(),
        panel: 'ingest',
        type: 'ingest',
        level: 'info',
        jobId: 'job-1',
        stage: 'copy',
        message: 'hello',
        detail: 'details',
        meta: { foo: 'bar' },
        status: 'ok',
        file: 'file.mov',
      },
    ]);

    exportLog();

    expect(window.electron.writeTextFile).toHaveBeenCalled();
    const [, written] = window.electron.writeTextFile.mock.calls[0];
    const lines = written.split('\n');
    expect(lines[0]).toBe('timestamp,panel,type,level,jobId,stage,message,detail,meta,status,file');
    expect(lines[1]).toContain('"ingest","ingest","info","job-1","copy","hello","details","{""foo"":""bar""}","ok","file.mov"');
  });
});
