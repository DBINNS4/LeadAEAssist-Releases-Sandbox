'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const runtimeAssetUi = require('../utils/runtimeAssetUi');

test('buildRuntimeAssetSummary includes progress percent and bytes for download updates', () => {
  const summary = runtimeAssetUi.buildRuntimeAssetSummary(
    {
      feature: 'chromium',
      state: 'running',
      active: true,
      progress: {
        phase: 'download',
        status: 'progress',
        progress: 0.42,
        bytesReceived: 42 * 1024 * 1024,
        bytesTotal: 100 * 1024 * 1024
      }
    },
    {}
  );

  assert.match(summary, /Downloading browser dependency/i);
  assert.match(summary, /42%/);
  assert.match(summary, /42 MiB/i);
  assert.match(summary, /100 MiB/i);
});

test('startRuntimeAssetPrefetch resolves after installed snapshot arrives', async () => {
  let progressListener = null;
  const assetsApi = {
    async prefetch() {
      return {
        ok: true,
        requestId: 'req-1',
        assetId: 'chrome-1',
        feature: 'chromium',
        state: 'running',
        active: true,
        installed: false,
        ready: false,
        progress: {
          phase: 'download',
          status: 'progress',
          progress: 0.1,
          bytesReceived: 10,
          bytesTotal: 100
        }
      };
    },
    onProgress(cb) {
      progressListener = cb;
      return () => {
        progressListener = null;
      };
    },
    async getStatus() {
      return {
        ok: true,
        requestId: 'req-1',
        assetId: 'chrome-1',
        feature: 'chromium',
        state: 'running',
        active: true,
        installed: false,
        ready: false
      };
    },
    async cancel() {
      return { ok: true, detached: true };
    }
  };

  const snapshots = [];
  const controller = await runtimeAssetUi.startRuntimeAssetPrefetch(
    assetsApi,
    { feature: 'chromium' },
    {
      onSnapshot(snapshot, currentController) {
        snapshots.push({ snapshot, ratio: currentController.lastProgressRatio });
      }
    }
  );

  assert.equal(controller.immediate, false);
  assert.equal(typeof progressListener, 'function');

  progressListener({
    ok: true,
    requestId: 'req-1',
    assetId: 'chrome-1',
    feature: 'chromium',
    state: 'installed',
    active: false,
    installed: true,
    ready: true,
    progress: {
      phase: 'install',
      status: 'complete'
    }
  });

  const result = await controller.promise;
  assert.equal(result.state, 'installed');
  assert.equal(result.ready, true);
  assert.equal(progressListener, null);
  assert.ok(snapshots.length >= 1);
});

test('startRuntimeAssetPrefetch cancel rejects with abort error', async () => {
  let progressListener = null;
  const assetsApi = {
    async prefetch() {
      return {
        ok: true,
        requestId: 'req-cancel',
        assetId: 'whisper-1',
        feature: 'whisper',
        state: 'running',
        active: true,
        installed: false,
        ready: false
      };
    },
    onProgress(cb) {
      progressListener = cb;
      return () => {
        progressListener = null;
      };
    },
    async getStatus() {
      return {
        ok: true,
        requestId: 'req-cancel',
        assetId: 'whisper-1',
        feature: 'whisper',
        state: 'running',
        active: true,
        installed: false,
        ready: false
      };
    },
    async cancel() {
      return {
        ok: true,
        requestId: 'req-cancel',
        assetId: 'whisper-1',
        detached: true,
        state: 'cancelling'
      };
    }
  };

  const controller = await runtimeAssetUi.startRuntimeAssetPrefetch(
    assetsApi,
    { feature: 'whisper', language: 'es' },
    {}
  );

  const promise = controller.promise;
  await controller.cancel();
  await assert.rejects(promise, (error) => {
    assert.equal(error.code, 'ABORT_ERR');
    return true;
  });
  assert.equal(progressListener, null);
});
