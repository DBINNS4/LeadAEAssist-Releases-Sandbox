'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { generateVTT } = require('../ai/vttWriter');

function firstTimestampLine(vtt) {
  const lines = String(vtt || '').replace(/\r\n?/g, '\n').split('\n');
  for (const ln of lines) {
    if (/^\d{2}:\d{2}:\d{2}\.\d{3}\s+-->\s+\d{2}:\d{2}:\d{2}\.\d{3}/.test(ln.trim())) {
      return ln.trim();
    }
  }
  return '';
}

test('Phase 3 VTT: does not emit cue settings without placement unless forced', () => {
  const vtt = generateVTT([
    { start: 0, end: 2, text: 'Hello world' }
  ], {
    formats: { vtt: { includeStyleMetadata: true } },
    maxCharsPerLine: 42,
    maxLinesPerBlock: 2
  });

  const ts = firstTimestampLine(vtt);
  assert.equal(ts.includes('line:'), false);
  assert.equal(ts.includes('position:'), false);
});

test('Phase 3 VTT: emits cue settings when placement tags exist', () => {
  const vtt = generateVTT([
    { start: 0, end: 2, text: '{row:15}{col:0}Hello' }
  ], {
    formats: { vtt: { includeStyleMetadata: true } },
    maxCharsPerLine: 42,
    maxLinesPerBlock: 2
  });

  const ts = firstTimestampLine(vtt);
  assert.equal(/\bline:/.test(ts), true);
  assert.equal(/\bposition:/.test(ts), true);
  assert.equal(/\balign:/.test(ts), true);
});

test('Phase 3 VTT: translates 608 italics/color tokens into safe WebVTT markup when style metadata enabled', () => {
  const vtt = generateVTT([
    { start: 0, end: 2, text: '{row:15}{col:0}{I}Hello {Gr}world' }
  ], {
    formats: { vtt: { includeStyleMetadata: true } },
    maxCharsPerLine: 42,
    maxLinesPerBlock: 2
  });

  // No raw tokens should leak.
  assert.equal(vtt.includes('{I}'), false);
  assert.equal(vtt.includes('{Gr}'), false);

  // STYLE block should include the color class rules (default behavior).
  assert.equal(vtt.includes('::cue(.c-gr)'), true);

  // Cue text should contain our generated markup.
  assert.equal(vtt.includes('<i>'), true);
  assert.equal(vtt.includes('</i>'), true);
  assert.equal(vtt.includes('<c.c-gr>'), true);
});
