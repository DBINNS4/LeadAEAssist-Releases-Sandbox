'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { generateVTT } = require('../ai/vttWriter');
const { validateVTT } = require('../ai/vttValidator');

function normNewlines(s) {
  return String(s || '').replace(/\r\n?/g, '\n');
}

test('Phase 6: WebVTT golden fixtures stay stable and validate (no errors)', () => {
  const fixturesDir = path.join(__dirname, 'fixtures', 'vtt');
  const jsonFiles = fs.readdirSync(fixturesDir).filter(f => f.endsWith('.json')).sort();

  assert.ok(jsonFiles.length > 0, 'Expected at least one .json fixture in test/fixtures/vtt');

  for (const jf of jsonFiles) {
    const fixturePath = path.join(fixturesDir, jf);
    const fixture = JSON.parse(fs.readFileSync(fixturePath, 'utf8'));

    assert.ok(fixture && fixture.segments && fixture.config && fixture.expectedVtt, `Bad fixture: ${jf}`);

    const expectedPath = path.join(fixturesDir, fixture.expectedVtt);
    const expected = normNewlines(fs.readFileSync(expectedPath, 'utf8'));

    const actual = normNewlines(generateVTT(fixture.segments, fixture.config));

    // Golden match (exact).
    assert.equal(
      actual,
      expected,
      `Golden mismatch for fixture ${fixture.name || jf} (expected file: ${fixture.expectedVtt})`
    );

    // QC: no structural errors.
    const report = validateVTT(actual, fixture.config, { fixture: fixture.name || jf });
    assert.equal(
      Array.isArray(report.errors) ? report.errors.length : -1,
      0,
      `QC errors for fixture ${fixture.name || jf}: ${JSON.stringify(report.errors, null, 2)}`
    );
  }
});
