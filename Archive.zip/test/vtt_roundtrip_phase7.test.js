'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { generateVTT } = require('../ai/vttWriter');
const { parseVTT, cuesToSegments } = require('../ai/vttParser');
const { validateVTT } = require('../ai/vttValidator');

function approx(a, b, eps = 1e-3) {
  return Math.abs(Number(a) - Number(b)) <= eps;
}

test('Phase 7 VTT: round-trip import preserves speaker (text-prefix mode) and core timings', () => {
  const segments = [
    { start: 0, end: 2, speaker: 'alice', text: 'Hello there.' }
  ];

  const cfg = {
    includeSpeakerNames: true,
    includeStyleMetadata: false,
    maxCharsPerLine: 80,
    maxLinesPerBlock: 2,
    maxDurationSeconds: 6.0,
    strictTiming: true // keep timings fixed for easier comparison
  };

  const vtt = generateVTT(segments, cfg);
  const parsed = parseVTT(vtt);
  const imported = cuesToSegments(parsed, {
    extractSpeaker: true,
    inferSpeakerFromTextPrefix: true,
    emit608Tokens: false,
    preserveLineBreaks: true
  });

  assert.equal(imported.length, 1);
  assert.equal(imported[0].speaker, 'Alice');
  assert.equal(imported[0].text.trim(), 'Hello there.');
  assert.equal(approx(imported[0].start, 0), true);
  assert.equal(approx(imported[0].end, 2), true);
});

test('Phase 7 VTT: round-trip import preserves speaker (<c.speaker>) and safe style intent via 608 tokens', () => {
  const segments = [
    { start: 10, end: 12, speaker: 'bob', text: '{I}{GrU}Styled line.' }
  ];

  const cfg = {
    includeSpeakerNames: true,
    includeStyleMetadata: true,
    translate608Styles: true,
    maxCharsPerLine: 80,
    maxLinesPerBlock: 2,
    maxDurationSeconds: 6.0,
    strictTiming: true
  };

  const vtt = generateVTT(segments, cfg);
  const parsed = parseVTT(vtt);
  const imported = cuesToSegments(parsed, {
    extractSpeaker: true,
    inferSpeakerFromTextPrefix: false,
    emit608Tokens: true,
    preserveLineBreaks: true
  });

  assert.equal(imported.length, 1);
  assert.equal(imported[0].speaker, 'Bob');
  // The exact token order we emit on import is deterministic.
  assert.equal(imported[0].text.startsWith('{I}{GrU}'), true);
  assert.equal(imported[0].text.includes('Styled line.'), true);
});

test('Phase 7 VTT: import -> export remains valid under validator (no errors)', () => {
  const segments = [
    { start: 1, end: 3, speaker: 'narrator', text: '{I}Hello & welcome <everyone>.' }
  ];

  const cfg = {
    includeSpeakerNames: true,
    includeStyleMetadata: true,
    translate608Styles: true,
    maxCharsPerLine: 80,
    maxLinesPerBlock: 2,
    strictTiming: true
  };

  const vtt1 = generateVTT(segments, cfg);
  const parsed = parseVTT(vtt1);
  const imported = cuesToSegments(parsed, {
    extractSpeaker: true,
    emit608Tokens: true,
    inferSpeakerFromTextPrefix: true
  });

  const vtt2 = generateVTT(imported, cfg);
  const report = validateVTT(vtt2, cfg);

  assert.equal(Array.isArray(report.errors), true);
  assert.equal(report.errors.length, 0);
});
