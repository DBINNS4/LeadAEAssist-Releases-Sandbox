const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const runtimeAssetService = require('../services/runtimeAssetService');
const {
  setupRuntimeAssetTest,
  createHttpServer,
  closeServer,
  sha256Hex,
  sleep
} = require('./helpers/runtimeAssetTestUtils');

test('runtime asset service: install + progress + normalized failure paths', async (t) => {
  await t.test('downloads a tiny file asset, emits progress, and reuses the installed copy', async () => {
    const payload = Buffer.from('tiny runtime asset\n', 'utf8');
    let requestCount = 0;
    const { server, origin } = await createHttpServer((req, res) => {
      requestCount += 1;
      res.writeHead(200, {
        'Content-Type': 'application/octet-stream',
        'Content-Length': String(payload.length)
      });
      res.write(payload.slice(0, 4));
      res.end(payload.slice(4));
    });

    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'tiny.file': {
          type: 'file',
          installPath: 'tiny/asset.bin',
          downloadUrl: `${origin}/tiny.file`,
          sha256: sha256Hex(payload)
        }
      }
    });

    try {
      const events = [];
      const installed = await runtimeAssetService.ensureAsset('tiny.file', {
        onProgress(event) {
          events.push({
            phase: event.phase,
            status: event.status,
            source: event.source || null,
            progress: Number.isFinite(Number(event.progress)) ? Number(event.progress) : null
          });
        }
      });

      assert.equal(installed.source, 'download');
      assert.equal(fs.readFileSync(installed.path, 'utf8'), payload.toString('utf8'));
      assert.equal(requestCount, 1);
      assert.ok(events.some(event => event.phase === 'download' && event.status === 'start'));
      assert.ok(events.some(event => event.phase === 'download' && event.status === 'progress'));
      assert.ok(events.some(event => event.phase === 'verify' && event.status === 'complete'));
      assert.ok(events.some(event => event.phase === 'install' && event.status === 'complete'));
      assert.ok(events.some(event => event.phase === 'complete' && event.status === 'complete'));

      const reuseEvents = [];
      const reused = await runtimeAssetService.ensureAsset('tiny.file', {
        onProgress(event) {
          reuseEvents.push({
            phase: event.phase,
            status: event.status,
            source: event.source || null
          });
        }
      });

      assert.equal(reused.source, 'installed');
      assert.equal(reused.path, installed.path);
      assert.equal(requestCount, 1);
      assert.ok(reuseEvents.some(event => event.phase === 'complete' && event.status === 'reused' && event.source === 'installed'));
    } finally {
      await closeServer(server);
      ctx.restore();
    }
  });

  await t.test('wraps transport failures as ASSET_DOWNLOAD_FAILED', async () => {
    let requestCount = 0;
    const { server, origin } = await createHttpServer((req, res) => {
      requestCount += 1;
      res.writeHead(503, { 'Content-Type': 'text/plain' });
      res.end('backend nap time');
    });

    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'broken.download': {
          type: 'file',
          installPath: 'broken/download.bin',
          downloadUrl: `${origin}/broken.download`,
          sha256: sha256Hex(Buffer.from('unused', 'utf8'))
        }
      }
    });

    try {
      await assert.rejects(
        runtimeAssetService.ensureAsset('broken.download'),
        (error) => {
          assert.equal(error.code, 'ASSET_DOWNLOAD_FAILED');
          assert.match(error.message, /broken\.download/);
          assert.match(error.message, /503/);
          assert.equal(requestCount, 1);
          return true;
        }
      );
    } finally {
      await closeServer(server);
      ctx.restore();
    }
  });

  await t.test('supports aborting an in-flight download via AbortSignal', async () => {
    const chunk = Buffer.alloc(1024, 'a');
    let requestCount = 0;

    const { server, origin } = await createHttpServer(async (req, res) => {
      requestCount += 1;
      res.writeHead(200, {
        'Content-Type': 'application/octet-stream',
        'Content-Length': String(chunk.length * 8)
      });

      for (let i = 0; i < 8; i += 1) {
        if (res.destroyed || res.writableEnded) return;
        res.write(chunk);
        await sleep(25);
      }
      if (!res.destroyed && !res.writableEnded) res.end();
    });

    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'cancel.file': {
          type: 'file',
          installPath: 'cancel/asset.bin',
          downloadUrl: `${origin}/cancel.file`,
          sha256: sha256Hex(Buffer.concat(Array.from({ length: 8 }, () => chunk)))
        }
      }
    });

    const controller = new AbortController();
    const events = [];

    try {
      await assert.rejects(
        runtimeAssetService.ensureAsset('cancel.file', {
          signal: controller.signal,
          onProgress(event) {
            events.push({ phase: event.phase, status: event.status, bytesReceived: event.bytesReceived || 0 });
            if (event.phase === 'download' && event.status === 'progress' && event.bytesReceived > 0) {
              controller.abort();
            }
          }
        }),
        (error) => {
          assert.equal(error.name, 'AbortError');
          assert.equal(error.code, 'ABORT_ERR');
          return true;
        }
      );

      const installedPath = runtimeAssetService.getInstalledAssetPath('cancel.file');
      const { downloadsRoot } = runtimeAssetService.computeAssetPaths();
      assert.equal(fs.existsSync(installedPath), false);
      assert.equal(fs.existsSync(path.join(downloadsRoot, 'cancel.file.download')), false);
      assert.equal(requestCount, 1);
      assert.ok(events.some(event => event.phase === 'download' && event.status === 'progress'));
      assert.ok(events.some(event => event.phase === 'cancelled' && event.status === 'cancelled'));
    } finally {
      await closeServer(server);
      ctx.restore();
    }
  });

  await t.test('wraps archive extraction failures as ASSET_EXTRACT_FAILED', async () => {
    const payload = Buffer.from('this is not a zip archive', 'utf8');
    const { server, origin } = await createHttpServer((req, res) => {
      res.writeHead(200, {
        'Content-Type': 'application/zip',
        'Content-Length': String(payload.length)
      });
      res.end(payload);
    });

    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'broken.archive': {
          type: 'archive',
          archiveFormat: 'zip',
          installDir: 'chrome/broken',
          downloadUrl: `${origin}/broken.archive.zip`,
          sha256: sha256Hex(payload)
        }
      }
    });

    try {
      await assert.rejects(
        runtimeAssetService.ensureAsset('broken.archive'),
        (error) => {
          assert.equal(error.code, 'ASSET_EXTRACT_FAILED');
          assert.match(error.message, /broken\.archive/);
          return true;
        }
      );
    } finally {
      await closeServer(server);
      ctx.restore();
    }
  });
});
