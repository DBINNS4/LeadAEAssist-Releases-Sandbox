const fs = require('fs');
const path = require('path');

describe('Project Organizer renderer i18n UI string guard', () => {
  const rendererPath = path.join(__dirname, '..', 'renderer.project-organizer.js');
  const localePath = path.join(__dirname, '..', 'locales', 'en.json');
  const source = fs.readFileSync(rendererPath, 'utf8');
  const en = JSON.parse(fs.readFileSync(localePath, 'utf8'));

  function extractUiStringKeys() {
    const blockMatch = source.match(/const PROJECT_ORGANIZER_UI_STRINGS = Object\.freeze\(\{([\s\S]*?)\}\);/);
    expect(blockMatch).toBeTruthy();
    const block = blockMatch[1];
    return [...block.matchAll(/\bkey:\s*'([^']+)'/g)].map(match => match[1]);
  }

  test('every PROJECT_ORGANIZER_UI_STRINGS key exists in locales/en.json', () => {
    const helperKeys = extractUiStringKeys();
    expect(helperKeys.length).toBeGreaterThan(0);
    for (const key of helperKeys) {
      expect(Object.prototype.hasOwnProperty.call(en, key)).toBe(true);
    }
  });

  test('helper-managed keys are not used with inline English fallback literals', () => {
    const helperKeys = extractUiStringKeys();
    for (const key of helperKeys) {
      const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const inlineTranslatePattern = new RegExp(`translate\\(\\s*'${escaped}'\\s*,\\s*['\"\\\`]`, 'm');
      const inlineTranslateCountPattern = new RegExp(`translateCount\\(\\s*'${escaped}'\\s*,[\\s\\S]*?['\"\\\`]`, 'm');
      expect(inlineTranslatePattern.test(source)).toBe(false);
      expect(inlineTranslateCountPattern.test(source)).toBe(false);
    }
  });
});
