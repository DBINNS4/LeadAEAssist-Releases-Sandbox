'use strict';

const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');

jest.mock('../modules/secureStore', () => ({
  loadSecret: jest.fn(() => null),
  saveSecret: jest.fn(),
  deleteSecret: jest.fn()
}));

function toBase64Url(input) {
  return Buffer.from(input)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function signRs256Token(privateKeyPem, payload, kid) {
  const header = { alg: 'RS256', typ: 'JWT', kid };
  const encodedHeader = toBase64Url(JSON.stringify(header));
  const encodedPayload = toBase64Url(JSON.stringify(payload));
  const signingInput = `${encodedHeader}.${encodedPayload}`;
  const signature = crypto.sign('RSA-SHA256', Buffer.from(signingInput, 'utf8'), privateKeyPem);
  return `${signingInput}.${toBase64Url(signature)}`;
}

describe('licenseService key rotation verification', () => {
  const priorEnvPath = process.env.LEADAE_LICENSE_PUBLIC_KEYS_CONFIG_PATH;
  let tempDir;

  beforeEach(() => {
    jest.resetModules();
    jest.unmock('electron');
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'license-keys-'));
  });

  afterEach(() => {
    process.env.LEADAE_LICENSE_PUBLIC_KEYS_CONFIG_PATH = priorEnvPath;
    jest.unmock('electron');
    if (tempDir && fs.existsSync(tempDir)) {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  function loadServiceWithConfig(config, { packaged = false } = {}) {
    const configPath = path.join(tempDir, 'keys.json');
    fs.writeFileSync(configPath, JSON.stringify(config), 'utf8');
    process.env.LEADAE_LICENSE_PUBLIC_KEYS_CONFIG_PATH = configPath;

    if (packaged) {
      jest.doMock('electron', () => ({ app: { isPackaged: true } }));
    }

    const service = require('../services/licenseService');
    service._internal._resetVerificationKeyConfigCache();
    return service;
  }

  test('token verifies with active kid', () => {
    const kp1 = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
    const service = loadServiceWithConfig({
      defaultKid: 'k-active',
      keys: {
        'k-active': { publicKeyPem: kp1.publicKey.export({ type: 'spki', format: 'pem' }), status: 'active' }
      }
    });

    const token = signRs256Token(
      kp1.privateKey.export({ type: 'pkcs8', format: 'pem' }),
      { sub: 'acct_1', exp: Math.floor(Date.now() / 1000) + 3600 },
      'k-active'
    );

    const payload = service._internal._verifyJws(token);
    expect(payload.sub).toBe('acct_1');
  });

  test('old kid still accepted during overlap window', () => {
    const kpOld = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
    const kpNew = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
    const acceptUntil = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

    const service = loadServiceWithConfig({
      defaultKid: 'k-new',
      keys: {
        'k-old': {
          publicKeyPem: kpOld.publicKey.export({ type: 'spki', format: 'pem' }),
          status: 'deprecated',
          acceptUntil
        },
        'k-new': {
          publicKeyPem: kpNew.publicKey.export({ type: 'spki', format: 'pem' }),
          status: 'active'
        }
      }
    });

    const token = signRs256Token(
      kpOld.privateKey.export({ type: 'pkcs8', format: 'pem' }),
      { sub: 'acct_overlap', exp: Math.floor(Date.now() / 1000) + 3600 },
      'k-old'
    );

    const payload = service._internal._verifyJws(token);
    expect(payload.sub).toBe('acct_overlap');
  });

  test('unknown kid fails closed', () => {
    const kpActive = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
    const kpUnknown = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });

    const service = loadServiceWithConfig({
      defaultKid: 'k-active',
      keys: {
        'k-active': {
          publicKeyPem: kpActive.publicKey.export({ type: 'spki', format: 'pem' }),
          status: 'active'
        }
      }
    });

    const token = signRs256Token(
      kpUnknown.privateKey.export({ type: 'pkcs8', format: 'pem' }),
      { sub: 'acct_bad', exp: Math.floor(Date.now() / 1000) + 3600 },
      'k-unknown'
    );

    expect(() => service._internal._verifyJws(token)).toThrow('Entitlement public key is invalid or missing');
  });

  test('packaged build ignores env key config path override', () => {
    const kp1 = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });

    const service = loadServiceWithConfig({
      defaultKid: 'k-active',
      keys: {
        'k-active': { publicKeyPem: kp1.publicKey.export({ type: 'spki', format: 'pem' }), status: 'active' }
      }
    }, { packaged: true });

    const token = signRs256Token(
      kp1.privateKey.export({ type: 'pkcs8', format: 'pem' }),
      { sub: 'acct_packaged', exp: Math.floor(Date.now() / 1000) + 3600 },
      'k-active'
    );

    expect(() => service._internal._verifyJws(token)).toThrow('Entitlement public key is invalid or missing');
  });
});
