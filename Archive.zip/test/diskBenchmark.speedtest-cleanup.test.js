/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');
const { __private } = require('../modules/diskBenchmark');

const fsp = fs.promises;

async function setFileMtime(filePath, mtimeMs) {
  const atime = new Date(mtimeMs);
  const mtime = new Date(mtimeMs);
  await fsp.utimes(filePath, atime, mtime);
}

describe('diskBenchmark speedtest cleanup concurrency safety', () => {
  let tempRoot;
  let speedtestDir;

  beforeEach(async () => {
    tempRoot = await fsp.mkdtemp(path.join(os.tmpdir(), 'lead-speedtest-cleanup-'));
    speedtestDir = await __private.ensureSpeedtestDir(tempRoot);
  });

  test('stale cleanup is marker-aware and age-gated across concurrent run IDs', async () => {
    const oldFile = path.join(speedtestDir, 'lead_speedtest_senderA_runA_seq_a.tmp');
    const freshFile = path.join(speedtestDir, 'lead_speedtest_senderB_runB_seq_a.tmp');
    await fsp.writeFile(oldFile, 'old');
    await fsp.writeFile(freshFile, 'fresh');

    const oldMtime = Date.now() - (__private.SPEEDTEST_STALE_MIN_AGE_MS + 5 * 60 * 1000);
    await setFileMtime(oldFile, oldMtime);

    const markerA = await __private.createSpeedtestActiveMarker(speedtestDir, { runId: 'runA', senderTag: 'senderA' });
    const markerB = await __private.createSpeedtestActiveMarker(speedtestDir, { runId: 'runB', senderTag: 'senderB' });

    await __private.cleanupStaleSpeedtestFiles(speedtestDir);

    expect(fs.existsSync(oldFile)).toBe(true);
    expect(fs.existsSync(freshFile)).toBe(true);

    const markerData = JSON.parse(await fsp.readFile(markerA.markerPath, 'utf8'));
    expect(markerData).toEqual(expect.objectContaining({ runId: 'runA', senderTag: 'senderA' }));

    await fsp.unlink(markerA.markerPath);
    await fsp.unlink(markerB.markerPath);

    await __private.cleanupStaleSpeedtestFiles(speedtestDir);

    expect(fs.existsSync(oldFile)).toBe(false);
    expect(fs.existsSync(freshFile)).toBe(true);
  });



  test('cleanup prunes malformed or stale marker files before idle checks', async () => {
    const oldTmpFile = path.join(speedtestDir, '.__speedtest_orphaned.tmp');
    const malformedMarker = path.join(speedtestDir, '.__lead_speedtest_active_bad.lock');
    await fsp.writeFile(oldTmpFile, 'stale');
    await fsp.writeFile(malformedMarker, '{not-json');

    const oldMtime = Date.now() - (__private.SPEEDTEST_STALE_MIN_AGE_MS + 5 * 60 * 1000);
    await setFileMtime(oldTmpFile, oldMtime);

    await __private.cleanupStaleSpeedtestFiles(speedtestDir);

    expect(fs.existsSync(malformedMarker)).toBe(false);
    expect(fs.existsSync(oldTmpFile)).toBe(false);
  });

  test('cleanup reclaims stale writecheck temp artifacts and removes idle directory', async () => {
    const staleWritecheckFile = path.join(speedtestDir, '.__lead_speedtest_writecheck_stale.tmp');
    await fsp.writeFile(staleWritecheckFile, 'stale');

    const oldMtime = Date.now() - (__private.SPEEDTEST_STALE_MIN_AGE_MS + 5 * 60 * 1000);
    await setFileMtime(staleWritecheckFile, oldMtime);

    await __private.cleanupStaleSpeedtestFiles(speedtestDir);
    expect(fs.existsSync(staleWritecheckFile)).toBe(false);

    await fsp.writeFile(staleWritecheckFile, 'fresh');
    await __private.cleanupSpeedtestDirIfIdle(speedtestDir);

    expect(fs.existsSync(staleWritecheckFile)).toBe(false);
    expect(fs.existsSync(speedtestDir)).toBe(false);
  });

  test('idle cleanup never removes temp files while any marker exists', async () => {

    const tmpFile = path.join(speedtestDir, '.__speedtest_runA.tmp');
    await fsp.writeFile(tmpFile, 'tmp');

    const marker = await __private.createSpeedtestActiveMarker(speedtestDir, { runId: 'runA' });

    await __private.cleanupSpeedtestDirIfIdle(speedtestDir);

    expect(fs.existsSync(tmpFile)).toBe(true);
    expect(fs.existsSync(speedtestDir)).toBe(true);

    await fsp.unlink(marker.markerPath);
    await __private.cleanupSpeedtestDirIfIdle(speedtestDir);

    expect(fs.existsSync(tmpFile)).toBe(false);
    expect(fs.existsSync(speedtestDir)).toBe(false);
  });
});


describe('diskBenchmark marker creation failure handling', () => {
  let tempRoot;

  beforeEach(async () => {
    tempRoot = await fsp.mkdtemp(path.join(os.tmpdir(), 'lead-speedtest-marker-failure-'));
  });

  test('runSequentialDriveTest aborts safely when lock marker cannot be created', async () => {
    const { runSequentialDriveTest } = require('../modules/diskBenchmark');
    const unlinkSpy = jest.spyOn(fsp, 'unlink');
    const originalWriteFile = fsp.writeFile.bind(fsp);
    const writeSpy = jest.spyOn(fsp, 'writeFile').mockImplementation(async (filePath, data, options) => {
      if (String(filePath).includes('.__lead_speedtest_active_')) {
        const err = new Error('mock marker write failure');
        err.code = 'EACCES';
        throw err;
      }
      return originalWriteFile(filePath, data, options);
    });

    const result = await runSequentialDriveTest({
      drivePath: tempRoot,
      testSizeMiB: 1,
      iterations: 2,
      senderTag: 'jest'
    });

    expect(result).toEqual(expect.objectContaining({
      success: false,
      code: 'MARKER_CREATE_FAILED'
    }));
    expect(unlinkSpy).not.toHaveBeenCalledWith(undefined);

    writeSpy.mockRestore();
    unlinkSpy.mockRestore();
  });

  test('estimateSequentialWriteSpeedMiBps aborts safely when lock marker cannot be created', async () => {
    const { estimateSequentialWriteSpeedMiBps } = require('../modules/diskBenchmark');
    const unlinkSpy = jest.spyOn(fsp, 'unlink');
    const originalWriteFile = fsp.writeFile.bind(fsp);
    const writeSpy = jest.spyOn(fsp, 'writeFile').mockImplementation(async (filePath, data, options) => {
      if (String(filePath).includes('.__lead_speedtest_active_')) {
        const err = new Error('mock marker write failure');
        err.code = 'EACCES';
        throw err;
      }
      return originalWriteFile(filePath, data, options);
    });

    const result = await estimateSequentialWriteSpeedMiBps(tempRoot, 1);

    expect(result).toEqual(expect.objectContaining({
      success: false,
      code: 'MARKER_CREATE_FAILED'
    }));
    expect(unlinkSpy).not.toHaveBeenCalledWith(undefined);

    writeSpy.mockRestore();
    unlinkSpy.mockRestore();
  });
});
