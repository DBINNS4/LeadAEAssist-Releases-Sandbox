/** @jest-environment node */

jest.mock('../services/licenseService', () => ({
  isFeatureEnabled: () => true
}));

jest.mock('../utils/trustedIpcSender', () => ({
  assertTrustedIpcSender: jest.fn()
}));

jest.mock('../modules/logUtils', () => ({
  sendLogMessage: jest.fn()
}));

const registerQueueHandlers = require('../ipc/queue.handlers');

describe('queue path validation', () => {
  beforeEach(() => {
    global.queue = {
      addJob: jest.fn(() => ({ id: 'job-1' })),
      getContract: jest.fn(() => null)
    };
  });

  afterEach(() => {
    delete global.queue;
  });

  test('notes containing absolute paths do not fail validation', async () => {
    const handlers = new Map();
    const ipcMain = {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn)),
      on: jest.fn()
    };

    registerQueueHandlers(ipcMain);

    const handler = handlers.get('queue-add-ingest');
    const config = { notes: 'Review /Volumes/Media/clip.mov before ingest.' };

    const result = await handler({ sender: { id: 1 } }, config);

    expect(global.queue.addJob).toHaveBeenCalledWith({
      panel: 'ingest',
      config
    });
    expect(result).toEqual({ id: 'job-1' });
  });

  test('queue-add-transcode rejects relative inputFiles entries', async () => {
    const handlers = new Map();
    const ipcMain = {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn)),
      on: jest.fn()
    };

    registerQueueHandlers(ipcMain);

    const handler = handlers.get('queue-add-transcode');
    const config = {
      inputFiles: ['./clip.mov'],
      outputFolder: '/tmp/out'
    };

    await expect(handler({ sender: { id: 1 } }, config)).rejects.toThrow(
      'inputFiles[0] must be an absolute path or file:// URL'
    );
    expect(global.queue.addJob).not.toHaveBeenCalled();
  });

  test('queue-add-transcode rejects relative outputFolder values', async () => {
    const handlers = new Map();
    const ipcMain = {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn)),
      on: jest.fn()
    };

    registerQueueHandlers(ipcMain);

    const handler = handlers.get('queue-add-transcode');
    const config = {
      inputFiles: ['/tmp/clip.mov'],
      outputFolder: 'exports'
    };

    await expect(handler({ sender: { id: 1 } }, config)).rejects.toThrow(
      'outputFolder must be an absolute path or file:// URL'
    );
    expect(global.queue.addJob).not.toHaveBeenCalled();
  });
});
