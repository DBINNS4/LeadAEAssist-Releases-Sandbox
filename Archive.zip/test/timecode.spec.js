const t = require('../utils/timeUtils');

function tcDF(ms, fps)    { return t.formatTimecode(ms / 1000, true, fps, 'colon', 'floor'); }
function tcNDF(ms, fps)   { return t.formatTimecode(ms / 1000, false, fps, 'colon', 'floor'); }
function dot(ms, fps)     { return t.formatTimecode(ms / 1000, false, fps, 'dot', 'floor'); }
function msFmt(ms, fps)   { return t.formatTimecode(ms / 1000, false, fps, 'ms'); }

describe('DF formatter legality', () => {
  test('29.97: minute boundary skips ;00 and ;01 except every tenth minute', () => {
    const fps = 29.97;
    const f = t.secondsToFrames(60, fps, 'floor'); // ~1798
    const before = tcDF((t.framesToSeconds(f - 1, fps) * 1000)|0, fps);
    const after  = tcDF((t.framesToSeconds(f + 1, fps) * 1000)|0, fps);
    expect(before.endsWith(';26')).toBe(true);
    expect(after.endsWith(';28')).toBe(true);
  });

  test('59.94: minute boundary skips ;00..;03 except every tenth minute', () => {
    const fps = 59.94;
    const f = t.secondsToFrames(60, fps, 'floor');
    const after = tcDF((t.framesToSeconds(f + 1, fps) * 1000)|0, fps);
    // Next legal label starts at ;04
    expect(/;\d{2}$/.exec(after)[0]).toBe(';56');
  });
});

describe('No auto‑DF', () => {
  test('formatTimecodes respects dropFrame=false even when DF‑capable', () => {
    const ms = 123456;
    const { ndf, df } = t.formatTimecodes(ms, 29.97, false);
    expect(ndf.start.includes(':')).toBe(true);
    expect(df.start).toBe(ndf.start); // identical when dropFrame=false
  });

  test('formatTimecodes uses DF only when requested', () => {
    const ms = 123456;
    const { ndf, df } = t.formatTimecodes(ms, 29.97, true);
    expect(ndf.start.includes(':')).toBe(true);
    expect(df.start.includes(';')).toBe(true);
  });
});

describe('Round‑trip sanity', () => {
  const cases = [
    { fps: 29.97, df: true,  tc: '00:09:59;28', ms: 599933 },
    { fps: 59.94, df: true,  tc: '00:09:59;59', ms: 599983 },
    { fps: 24.00, df: false, tc: '01:00:00:00', ms: 3600000 },
    { fps: 25.00, df: false, tc: '01:00:00:00', ms: 3600000 },
    { fps: 30.00, df: false, tc: '01:00:00:00', ms: 3600000 },
    { fps: 60.00, df: false, tc: '01:00:00:00', ms: 3600000 },
  ];
  for (const c of cases) {
    test(`parse/format ${c.fps} ${c.df?'DF':'NDF'} ${c.tc}`, () => {
      const ms = t.parseTime(c.tc, c.fps, c.df);
      expect(Math.abs(ms - c.ms)).toBeLessThan(50);
      const out = t.formatTimecode(ms/1000, c.df, c.fps, 'colon', 'floor');
      expect(out).toBe(c.tc);
    });
  }
});

describe('Dot and ms styles', () => {
  test('dot uses frames, not decimals', () => {
    const s = dot(3600_000, 24);
    expect(s).toBe('01:00:00.00');
  });
  test('ms format carries over 1000th ms', () => {
    const s = msFmt(59_999.5, 30);
    expect(s).toMatch(/^00:00:59,\d{3}$/);
  });
});

describe('Strict DF intake helpers', () => {
  test('reject illegal DF labels', () => {
    expect(t.isLegalDropFrameLabel('00:01:00;00', 29.97)).toBe(false);
    expect(t.isLegalDropFrameLabel('00:10:00;00', 29.97)).toBe(true); // tenth minute ok
  });
});
