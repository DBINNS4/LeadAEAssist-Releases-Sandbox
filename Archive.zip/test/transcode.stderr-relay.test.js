/** @jest-environment node */

jest.mock('electron', () => ({ BrowserWindow: {}, app: null }));

const { createStderrLineRelay } = require('../modules/transcode');

describe('transcode stderr relay', () => {
  test('rate-limits progress-like lines and only forwards meaningful stderr', () => {
    const forwarded = [];
    const relay = createStderrLineRelay((msg, isError) => {
      forwarded.push({ msg, isError });
    }, { statusIntervalMs: 1000 });

    const nowSpy = jest.spyOn(Date, 'now').mockReturnValue(1000);

    for (let i = 0; i < 5000; i += 1) {
      relay.onData(`frame=${i} fps=25.0 time=00:00:${String(i % 60).padStart(2, '0')} speed=1.0x\n`);
    }

    relay.onData('Some incidental banner text\n');
    relay.onData('Error while opening encoder for output stream\n');
    relay.flush();

    nowSpy.mockRestore();

    expect(forwarded.length).toBeLessThan(20);
    expect(forwarded.some(x => /frame=0/.test(x.msg))).toBe(true);
    expect(forwarded.some(x => /Error while opening encoder/.test(x.msg) && x.isError)).toBe(true);
    expect(forwarded.some(x => /incidental banner text/.test(x.msg))).toBe(false);
  });

  test('flush emits trailing unterminated error line', () => {
    const forwarded = [];
    const relay = createStderrLineRelay((msg, isError) => {
      forwarded.push({ msg, isError });
    });

    relay.onData('fatal: encoder crashed');
    relay.flush();

    expect(forwarded).toEqual([
      { msg: 'fatal: encoder crashed', isError: true }
    ]);
  });
});
