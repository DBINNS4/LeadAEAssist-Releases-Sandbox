/** @jest-environment node */
'use strict';

const http = require('http');

const BRIDGE_PORT = 32123;

function closeServer(server) {
  if (!server) return Promise.resolve();
  return new Promise(resolve => {
    try {
      server.close(() => resolve());
    } catch {
      resolve();
    }
  });
}

describe('bridgeServerService startup collision handling', () => {
  let bridgeA = null;
  let bridgeB = null;
  let foreignServer = null;
  const originalBridgeToken = process.env.CEP_BRIDGE_TOKEN;

  afterEach(async () => {
    await closeServer(foreignServer);
    foreignServer = null;

    if (bridgeA?.__test?.resetState) {
      await bridgeA.__test.resetState();
    }
    if (bridgeB?.__test?.resetState) {
      await bridgeB.__test.resetState();
    }

    bridgeA = null;
    bridgeB = null;
    if (originalBridgeToken === undefined) {
      delete process.env.CEP_BRIDGE_TOKEN;
    } else {
      process.env.CEP_BRIDGE_TOKEN = originalBridgeToken;
    }
    jest.resetModules();
  });

  test('reuses a healthy existing LEAD bridge listener', async () => {
    jest.resetModules();
    bridgeA = require('../services/bridgeServerService');
    const first = await bridgeA.getCredentials();

    expect(first.ok).toBe(true);
    expect(first.status).toBe('started');

    jest.resetModules();
    bridgeB = require('../services/bridgeServerService');
    const second = await bridgeB.getCredentials();

    expect(second.ok).toBe(true);
    expect(second.status).toBe('reused_existing');
    expect(second.diagnostics).toEqual(
      expect.objectContaining({ reusedExisting: true, usingExternalBridge: true })
    );
    expect(second.token).toBe(first.token);
  });

  test('falls back to ephemeral when healthy existing bridge rejects auth token', async () => {
    process.env.CEP_BRIDGE_TOKEN = 'token-from-first-instance';
    jest.resetModules();
    bridgeA = require('../services/bridgeServerService');
    const first = await bridgeA.getCredentials();

    expect(first.ok).toBe(true);
    expect(first.status).toBe('started');
    expect(first.port).toBe(BRIDGE_PORT);

    process.env.CEP_BRIDGE_TOKEN = 'token-from-second-instance';
    jest.resetModules();
    bridgeB = require('../services/bridgeServerService');
    const second = await bridgeB.getCredentials();

    expect(second.ok).toBe(true);
    expect(second.status).toBe('started_fallback_ephemeral');
    expect(second.port).not.toBe(BRIDGE_PORT);
    expect(second.diagnostics).toEqual(
      expect.objectContaining({ reusedExisting: false, usingExternalBridge: false })
    );
  });

  test('falls back to an ephemeral port when existing bridge probe is unhealthy', async () => {
    foreignServer = http.createServer((req, res) => {
      if (req.url === '/health' || req.url === '/handshake') {
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(JSON.stringify({ ok: true, bridgeId: 'lead-ae-assist-bridge' }));
        return;
      }
      res.writeHead(404, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ ok: false }));
    });

    await new Promise((resolve, reject) => {
      foreignServer.once('error', reject);
      foreignServer.once('listening', resolve);
      foreignServer.listen(BRIDGE_PORT, '127.0.0.1');
    });

    jest.resetModules();
    bridgeA = require('../services/bridgeServerService');
    const creds = await bridgeA.getCredentials();

    expect(creds.ok).toBe(true);
    expect(creds.status).toBe('started_fallback_ephemeral');
    expect(creds.port).not.toBe(BRIDGE_PORT);
    expect(creds.port).toBeGreaterThan(0);
  });
});
