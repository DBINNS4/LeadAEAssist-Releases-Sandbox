/** @jest-environment node */

const QueueManager = require('../modules/queueManager');

describe('QueueManager.cancelJob', () => {
  test('cancelling a pending job stores a cancelled record and emits job-cancelled', () => {
    const queue = new QueueManager(
      {
        ingest: {
          run: jest.fn()
        }
      },
      { maxConcurrency: 0 }
    );

    const onCancelled = jest.fn();
    queue.on('job-cancelled', onCancelled);

    const id = queue.addJob({ id: 'pending-job-1', panel: 'ingest', config: {} });

    expect(id).toBe('pending-job-1');
    expect(queue.pending).toHaveLength(1);

    queue.cancelJob(id);

    expect(queue.pending).toHaveLength(0);
    expect(queue.failed.has(id)).toBe(true);

    const cancelled = queue.failed.get(id);
    expect(cancelled.cancelRequested).toBe(true);
    expect(cancelled.status).toBe('cancelled');
    expect(typeof cancelled.endedAt).toBe('number');

    expect(onCancelled).toHaveBeenCalledTimes(1);
    expect(onCancelled).toHaveBeenCalledWith(cancelled);
  });


  test('cancelling pending jobs emits job-cancelled for every removed pending match', () => {
    const queue = new QueueManager(
      {
        ingest: {
          run: jest.fn()
        }
      },
      { maxConcurrency: 0 }
    );

    const onCancelled = jest.fn();
    queue.on('job-cancelled', onCancelled);

    queue.pending.push(
      { id: 'dup-job', panel: 'ingest', config: {}, status: 'pending' },
      { id: 'dup-job', panel: 'ingest', config: {}, status: 'pending' },
      { id: 'other-job', panel: 'ingest', config: {}, status: 'pending' }
    );

    queue.cancelJob('dup-job');

    expect(queue.pending.map(job => job.id)).toEqual(['other-job']);
    expect(onCancelled).toHaveBeenCalledTimes(2);
    for (const [cancelled] of onCancelled.mock.calls) {
      expect(cancelled.id).toBe('dup-job');
      expect(cancelled.status).toBe('cancelled');
      expect(cancelled.cancelRequested).toBe(true);
      expect(typeof cancelled.endedAt).toBe('number');
    }
  });

  test('cancelling an in-progress job keeps cancellation flow and emits job-cancelled on completion', () => {
    const cancel = jest.fn();
    const queue = new QueueManager({
      ingest: {
        run: jest.fn(() => Promise.resolve({ success: true })),
        cancel
      }
    });

    const onCancelled = jest.fn();
    queue.on('job-cancelled', onCancelled);

    const id = queue.addJob({ id: 'active-job-1', panel: 'ingest', config: {} });
    expect(queue.inProgress.has(id)).toBe(true);

    queue.cancelJob(id);

    const activeJob = queue.inProgress.get(id);
    expect(activeJob.cancelRequested).toBe(true);
    expect(activeJob.status).toBe('cancelling');
    expect(cancel).toHaveBeenCalledWith(id);

    queue.completeJob(id, { success: true });

    expect(queue.failed.has(id)).toBe(true);
    expect(onCancelled).toHaveBeenCalledTimes(1);
    expect(onCancelled.mock.calls[0][0].id).toBe(id);
  });
});


describe('QueueManager.completeJob', () => {
  test('treats skipped non-success results as failed jobs', () => {
    const queue = new QueueManager({
      ingest: { run: jest.fn(() => Promise.resolve({ success: true })) }
    });

    const onFailed = jest.fn();
    queue.on('job-failed', onFailed);

    const id = queue.addJob({ id: 'watch-skip-1', panel: 'ingest', config: {} });
    expect(queue.inProgress.has(id)).toBe(true);

    queue.completeJob(id, {
      success: false,
      skipped: true,
      reason: 'missing-destination',
      status: 'watch-skipped-missing-destination',
      logText: '⏭️ Watch-triggered job skipped: destination missing (/missing)'
    });

    expect(queue.failed.has(id)).toBe(true);
    expect(queue.completed.has(id)).toBe(false);
    expect(onFailed).toHaveBeenCalledTimes(1);
    const failedJob = onFailed.mock.calls[0][0];
    expect(failedJob.result).toMatchObject({
      success: false,
      skipped: true,
      reason: 'missing-destination',
      status: 'watch-skipped-missing-destination'
    });
  });
});


describe('QueueManager.failJob error normalization', () => {
  test('normalizes thrown Error into structured job.error', async () => {
    const queue = new QueueManager({
      ingest: { run: jest.fn(async () => { throw new Error('Boom'); }) }
    });

    const failedJob = await new Promise(resolve => {
      queue.on('job-failed', resolve);
      queue.addJob({ id: 'err-obj', panel: 'ingest', config: {} });
    });

    expect(failedJob.error).toMatchObject({
      message: 'Boom',
      name: 'Error'
    });
    expect(typeof failedJob.error.stack).toBe('string');
  });

  test('normalizes string throws into structured job.error', async () => {
    const queue = new QueueManager({
      ingest: { run: jest.fn(async () => { throw 'plain failure'; }) }
    });

    const failedJob = await new Promise(resolve => {
      queue.on('job-failed', resolve);
      queue.addJob({ id: 'err-string', panel: 'ingest', config: {} });
    });

    expect(failedJob.error).toEqual({
      message: 'plain failure',
      stack: undefined,
      code: undefined,
      name: 'Error',
      details: undefined
    });
  });

  test('normalizes validation error arrays into details.validationErrors', async () => {
    const queue = new QueueManager({
      ingest: {
        validate: () => ['Missing source path', 'Missing destination path'],
        run: jest.fn()
      }
    });

    const failedJob = await new Promise(resolve => {
      queue.on('job-failed', resolve);
      queue.addJob({ id: 'err-validation', panel: 'ingest', config: {} });
    });

    expect(failedJob.error).toMatchObject({
      message: `Missing source path\nMissing destination path`,
      name: 'Error',
      details: {
        validationErrors: ['Missing source path', 'Missing destination path']
      }
    });
  });
});
