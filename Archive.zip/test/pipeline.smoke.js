const assert = require('assert');
const { prepareTranscription } = require('../ai/prepareTranscription');

function sampleSegments(n = 2) {
  return Array.from({ length: n }).map((_, i) => ({
    start: i * 2,
    end: i * 2 + 1.5,
    text: `hello ${i}`
  }));
}

async function testDiarizationMerge() {
  const raw = { segments: sampleSegments(3) };
  const diarized = [
    { start: 0.0, end: 2.0, speaker: 'Speaker 1' },
    { start: 2.0, end: 4.0, speaker: 'Speaker 2' },
    { start: 4.0, end: 6.0, speaker: 'Speaker 3' }
  ];
  const cfg = { timecodeStyle: 'ndf', fps: 30, dropFrame: false };
  const wrapped = await prepareTranscription(raw, '/tmp/a.wav', cfg, { engine: 'lead', diarized });
  assert.ok(wrapped.segments.every(s => typeof s.speaker === 'string' && s.speaker.length > 0),
    'speakers should be injected');
  assert.ok(wrapped.segments[0].timecodes?.ndf?.start, 'ndf timecodes should be present');
  console.log('✓ diarization merge + timecodes');
}


async function testRemoveLeadingChars() {
  const raw = {
    segments: [
      { start: 0, end: 1, text: '- Five, four, three.' },
      { start: 1, end: 2, text: '— Welcome back.' },
      { start: 2, end: 3, text: '>> Give it up!' },
      { start: 3, end: 4, text: '[APPLAUSE]' }
    ]
  };

  const cfg = { timecodeStyle: 'ndf', fps: 30, dropFrame: false, removeLeadingChars: true };
  const wrapped = await prepareTranscription(raw, '/tmp/a.wav', cfg, { engine: 'lead', diarized: [] });

  assert.strictEqual(wrapped.segments[0].text, 'Five, four, three.');
  assert.strictEqual(wrapped.segments[1].text, 'Welcome back.');
  assert.strictEqual(wrapped.segments[2].text, 'Give it up!');
  assert.strictEqual(wrapped.segments[3].text, '[APPLAUSE]');
  console.log('✓ removeLeadingChars strips common dialogue/bullet prefixes');
}

function testArgBuilders() {
  const cfgTx = { language: 'es', translation: { enabled: true }, whisperTask: 'translate', diarization: true, localSpeakerDetection: true };
  const outDir = '/tmp';
  const file = '/tmp/in.wav';
  const args = ['-m', 'whisperx', file, '--output_dir', outDir, '--output_format', 'json'];
  if (cfgTx.language) args.push('--language', cfgTx.language);
  if (cfgTx.diarization || cfgTx.localSpeakerDetection) args.push('--diarize');
  if ((cfgTx.whisperTask === 'translate') || !!cfgTx.translation?.enabled) args.push('--task', 'translate');
  assert.ok(args.includes('--task') && args.includes('translate'), 'WhisperX should request translate');

  const wantsTranslate = (cfgTx.whisperTask === 'translate') || !!cfgTx.translation?.enabled;
  const params = {
    file: '[stream]',
    model: 'whisper-1',
    response_format: 'verbose_json',
    language: cfgTx.language,
    task: wantsTranslate ? 'translate' : 'transcribe'
  };
  assert.equal(params.task, 'translate', 'OpenAI call should set task=translate');
  console.log('✓ arg builders for translate');
}

(async function main() {
  await testDiarizationMerge();
  await testRemoveLeadingChars();
  testArgBuilders();
  console.log('All smoke tests passed.');
})();
