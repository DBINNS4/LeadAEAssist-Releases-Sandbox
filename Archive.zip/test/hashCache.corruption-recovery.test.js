/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');

describe('hashCache corruption recovery', () => {
  let tmpRoot;

  beforeEach(() => {
    jest.resetModules();
    tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-hash-cache-'));

    jest.doMock('../utils/appPaths', () => ({
      ensureUserDataSubdir: jest.fn((...segments) => {
        const dir = path.join(tmpRoot, ...segments);
        fs.mkdirSync(dir, { recursive: true });
        return dir;
      })
    }));
  });

  afterEach(() => {
    fs.rmSync(tmpRoot, { recursive: true, force: true });
  });

  test('loadCache recovers from truncated JSON, falls back cleanly, and keeps operating', () => {
    const {
      loadCache,
      saveCache,
      updateCacheEntry,
      isDuplicate
    } = require('../utils/hashCache');

    const cachePath = path.join(tmpRoot, 'config', 'cache', 'hash-cache.json');
    const backupPath = `${cachePath}.bak`;

    // Seed valid cache + backup.
    saveCache({
      abc123: { file: 'clipA.mov', timestamp: Date.now() }
    });

    // Simulate corruption/truncation of primary cache file.
    fs.writeFileSync(cachePath, '{"abc123":', 'utf8');

    const recovered = loadCache();
    expect(recovered).toHaveProperty('abc123');
    expect(JSON.parse(fs.readFileSync(cachePath, 'utf8'))).toHaveProperty('abc123');
    expect(JSON.parse(fs.readFileSync(backupPath, 'utf8'))).toHaveProperty('abc123');

    // Ensure continued normal operation after recovery.
    updateCacheEntry(recovered, 'def456', 'clipB.mov');
    saveCache(recovered);

    const reloaded = loadCache();
    expect(isDuplicate(reloaded, 'abc123')).toBe(true);
    expect(isDuplicate(reloaded, 'def456')).toBe(true);

    const leftovers = fs.readdirSync(path.dirname(cachePath)).filter(name => name.includes('.tmp'));
    expect(leftovers).toEqual([]);
  });


  test('loadCache migrates legacy logs hash cache into config/cache', () => {
    const { loadCache } = require('../utils/hashCache');

    const legacyPath = path.join(tmpRoot, 'logs', 'hash-cache.json');
    const legacyBackupPath = `${legacyPath}.bak`;
    const newPath = path.join(tmpRoot, 'config', 'cache', 'hash-cache.json');
    const newBackupPath = `${newPath}.bak`;

    fs.mkdirSync(path.dirname(legacyPath), { recursive: true });
    fs.writeFileSync(legacyPath, JSON.stringify({ abc123: { file: 'clipA.mov', timestamp: Date.now() } }, null, 2));
    fs.writeFileSync(legacyBackupPath, JSON.stringify({ abc123: { file: 'clipA.mov', timestamp: Date.now() } }, null, 2));

    const loaded = loadCache();

    expect(loaded).toHaveProperty('abc123');
    expect(fs.existsSync(newPath)).toBe(true);
    expect(fs.existsSync(newBackupPath)).toBe(true);
    expect(fs.existsSync(legacyPath)).toBe(false);
    expect(fs.existsSync(legacyBackupPath)).toBe(false);
  });

  test('loadCache recreates defaults when both primary and backup are invalid', () => {
    const { loadCache } = require('../utils/hashCache');

    const cachePath = path.join(tmpRoot, 'config', 'cache', 'hash-cache.json');
    const backupPath = `${cachePath}.bak`;
    fs.mkdirSync(path.dirname(cachePath), { recursive: true });
    fs.writeFileSync(cachePath, '{"broken":', 'utf8');
    fs.writeFileSync(backupPath, '{"stillBroken":', 'utf8');

    const loaded = loadCache();
    expect(loaded).toEqual({});
    expect(JSON.parse(fs.readFileSync(cachePath, 'utf8'))).toEqual({});
    expect(JSON.parse(fs.readFileSync(backupPath, 'utf8'))).toEqual({});
  });
});
