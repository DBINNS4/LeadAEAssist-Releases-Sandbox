/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');

const { getAllItemsRecursively } = require('../modules/fileUtils');
const { approveRoot, isPathAllowed, resetApproved } = require('../utils/fsAccessControl');

describe('getAllItemsRecursively symlink policy', () => {
  test('skips symlink loops and out-of-root symlinks', async () => {
    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-symlink-'));
    const root = path.join(tmpRoot, 'root');
    const outside = path.join(tmpRoot, 'outside');
    fs.mkdirSync(root);
    fs.mkdirSync(outside);

    const realDir = path.join(root, 'real');
    fs.mkdirSync(realDir);
    fs.writeFileSync(path.join(realDir, 'file.txt'), 'ok');
    fs.writeFileSync(path.join(outside, 'outside.txt'), 'nope');

    let symlinksReady = true;
    try {
      fs.symlinkSync(root, path.join(root, 'loop'), 'dir');
      fs.symlinkSync(outside, path.join(root, 'outside-link'), 'dir');
      fs.symlinkSync(path.join(outside, 'outside.txt'), path.join(root, 'outside-file-link'));
    } catch (err) {
      symlinksReady = false;
    }

    try {
      if (!symlinksReady) return;

      const items = [];
      for await (const item of getAllItemsRecursively(root, root, { includeHidden: true })) {
        items.push(item);
      }
      const itemPaths = items.map(item => item.fullPath);

      expect(itemPaths).toContain(path.join(root, 'real'));
      expect(itemPaths).toContain(path.join(root, 'real', 'file.txt'));

      expect(itemPaths).not.toContain(path.join(root, 'loop'));
      expect(itemPaths).not.toContain(path.join(root, 'outside-link'));
      expect(itemPaths).not.toContain(path.join(root, 'outside-file-link'));
      expect(itemPaths.some(p => p.startsWith(outside))).toBe(false);
    } finally {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });
});

describe('fsAccessControl symlink policy', () => {
  test('rejects paths that traverse approved roots via symlink', () => {
    const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-fsaccess-'));
    const approvedRoot = path.join(tmpRoot, 'approved');
    const outside = path.join(tmpRoot, 'outside');
    fs.mkdirSync(approvedRoot);
    fs.mkdirSync(outside);

    let symlinksReady = true;
    try {
      fs.symlinkSync(outside, path.join(approvedRoot, 'outside-link'), 'dir');
      fs.writeFileSync(path.join(outside, 'outside.txt'), 'nope');
    } catch (err) {
      symlinksReady = false;
    }

    try {
      if (!symlinksReady) return;

      const senderId = 42;
      approveRoot(senderId, approvedRoot, 'dir');

      const throughSymlink = path.join(approvedRoot, 'outside-link', 'outside.txt');
      const throughSymlinkMissing = path.join(approvedRoot, 'outside-link', 'missing.txt');

      expect(isPathAllowed(senderId, throughSymlink)).toBe(false);
      expect(isPathAllowed(senderId, throughSymlinkMissing)).toBe(false);
    } finally {
      resetApproved(42);
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    }
  });
});
