const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const runtimeAssetService = require('../services/runtimeAssetService');
const stateStore = require('../utils/state');
const whisperAssetService = require('../services/whisperAssetService');

const originalEnsureAsset = runtimeAssetService.ensureAsset;
const originalGetInstalledAssetPath = runtimeAssetService.getInstalledAssetPath;
const originalReadState = stateStore.readState;

function makeTempDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'leadae-whisper-asset-'));
}

function touchFile(filePath) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, '', 'utf8');
}

function restore() {
  runtimeAssetService.ensureAsset = originalEnsureAsset;
  runtimeAssetService.getInstalledAssetPath = originalGetInstalledAssetPath;
  stateStore.readState = originalReadState;
}

test.afterEach(() => {
  restore();
});

test('whisper asset service: chooses English and multilingual asset IDs from language', () => {
  assert.equal(
    whisperAssetService.getWhisperModelAssetId({ language: 'en' }),
    'whisper.model.base.en'
  );
  assert.equal(
    whisperAssetService.getWhisperModelAssetId({ language: 'fr' }),
    'whisper.model.base.multi'
  );
  assert.equal(
    whisperAssetService.getWhisperModelFileName({ language: 'EN' }),
    'ggml-base.en.bin'
  );
  assert.equal(
    whisperAssetService.getWhisperModelFileName({ language: 'ja' }),
    'ggml-base.bin'
  );
});

test('whisper asset service: packaged acquisition forwards offline mode from canonical preferences by default', async () => {
  const root = makeTempDir();
  const modelPath = path.join(root, 'whisper', 'models', 'ggml-base.bin');
  let captured = null;

  touchFile(modelPath);
  stateStore.readState = () => ({ preferences: { offlineMode: true } });
  runtimeAssetService.ensureAsset = async (assetId, options) => {
    captured = { assetId, options };
    return { ok: true, assetId, path: modelPath, source: 'download' };
  };

  const ensured = await whisperAssetService.ensureWhisperModelPath({
    language: 'fr',
    isPackaged: true
  });

  assert.equal(captured.assetId, 'whisper.model.base.multi');
  assert.equal(captured.options.isPackaged, true);
  assert.equal(captured.options.offline, true);
  assert.equal(ensured.modelPath, modelPath);
  assert.equal(ensured.modelFile, 'ggml-base.bin');
});

test('whisper asset service: explicit offline option overrides stored preference', async () => {
  const root = makeTempDir();
  const modelPath = path.join(root, 'whisper', 'models', 'ggml-base.en.bin');
  let captured = null;

  touchFile(modelPath);
  stateStore.readState = () => ({ preferences: { offlineMode: true } });
  runtimeAssetService.ensureAsset = async (assetId, options) => {
    captured = { assetId, options };
    return { ok: true, assetId, path: modelPath, source: 'seed' };
  };

  const ensured = await whisperAssetService.ensureWhisperModelPath({
    language: 'en',
    isPackaged: true,
    offline: false
  });

  assert.equal(captured.assetId, 'whisper.model.base.en');
  assert.equal(captured.options.offline, false);
  assert.equal(ensured.modelPath, modelPath);
  assert.equal(ensured.source, 'seed');
});

test('whisper asset service: formats offline-mode failures without manual install instructions', async () => {
  stateStore.readState = () => ({ preferences: { offlineMode: true } });
  runtimeAssetService.getInstalledAssetPath = () => '/tmp/userData/assets/whisper/models/ggml-base.bin';
  runtimeAssetService.ensureAsset = async () => {
    const err = new Error('Offline mode: cannot download asset whisper.model.base.multi');
    err.code = 'ASSET_OFFLINE_BLOCKED';
    throw err;
  };

  await assert.rejects(
    whisperAssetService.ensureWhisperModelPath({ language: 'fr', isPackaged: true }),
    err => {
      assert.equal(err.code, 'ASSET_OFFLINE_BLOCKED');
      assert.match(err.message, /Offline Mode is enabled/);
      assert.match(err.message, /pre-seed the runtime asset whisper\.model\.base\.multi/);
      assert.match(err.message, /Expected installed path: \/tmp\/userData\/assets\/whisper\/models\/ggml-base\.bin/);
      assert.doesNotMatch(err.message, /download-ggml-model\.sh/);
      return true;
    }
  );
});

test('whisper asset service: formats checksum failures as runtime-asset corruption, not manual setup', async () => {
  stateStore.readState = () => ({ preferences: { offlineMode: false } });
  runtimeAssetService.getInstalledAssetPath = () => '/tmp/userData/assets/whisper/models/ggml-base.en.bin';
  runtimeAssetService.ensureAsset = async () => {
    const err = new Error('Downloaded checksum mismatch for whisper.model.base.en');
    err.code = 'ASSET_CHECKSUM_MISMATCH';
    throw err;
  };

  await assert.rejects(
    whisperAssetService.ensureWhisperModelPath({ language: 'en', isPackaged: true }),
    err => {
      assert.equal(err.code, 'ASSET_CHECKSUM_MISMATCH');
      assert.match(err.message, /failed checksum verification/);
      assert.match(err.message, /fresh manifest or asset build/);
      assert.doesNotMatch(err.message, /Place ggml-base\.en\.bin/);
      return true;
    }
  );
});
