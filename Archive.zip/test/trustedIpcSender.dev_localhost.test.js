/** @jest-environment node */

function loadTrustedIpcSender({ isPackaged = false, appPath = '/workspace/LeadAEAssist' } = {}) {
  jest.resetModules();
  jest.doMock('electron', () => ({
    app: {
      isPackaged,
      getAppPath: jest.fn(() => appPath)
    }
  }));
  return require('../utils/trustedIpcSender');
}

function eventForUrl(url) {
  return {
    senderFrame: { url }
  };
}

describe('trustedIpcSender localhost URL parsing hardening', () => {
  test('allows http://localhost:3000 in development', () => {
    const { isTrustedIpcSender } = loadTrustedIpcSender({ isPackaged: false });
    expect(isTrustedIpcSender(eventForUrl('http://localhost:3000'))).toBe(true);
  });

  test('allows https://127.0.0.1:5173 in development', () => {
    const { isTrustedIpcSender } = loadTrustedIpcSender({ isPackaged: false });
    expect(isTrustedIpcSender(eventForUrl('https://127.0.0.1:5173'))).toBe(true);
  });

  test('denies https://localhost.attacker.tld in development', () => {
    const { isTrustedIpcSender } = loadTrustedIpcSender({ isPackaged: false });
    expect(isTrustedIpcSender(eventForUrl('https://localhost.attacker.tld'))).toBe(false);
  });

  test('denies https://127.0.0.1.attacker.tld in development', () => {
    const { isTrustedIpcSender } = loadTrustedIpcSender({ isPackaged: false });
    expect(isTrustedIpcSender(eventForUrl('https://127.0.0.1.attacker.tld'))).toBe(false);
  });

  test('allows IPv6 loopback [::1] in development', () => {
    const { isTrustedIpcSender } = loadTrustedIpcSender({ isPackaged: false });
    expect(isTrustedIpcSender(eventForUrl('http://[::1]:3000'))).toBe(true);
  });

  test('denies localhost dev URL when app is packaged', () => {
    const { isTrustedIpcSender } = loadTrustedIpcSender({ isPackaged: true });
    expect(isTrustedIpcSender(eventForUrl('http://localhost:3000'))).toBe(false);
  });
});

describe('trustedIpcSender file:// behavior', () => {
  test('allows file URL inside app path', () => {
    const { isTrustedIpcSender } = loadTrustedIpcSender({ isPackaged: true });
    expect(isTrustedIpcSender(eventForUrl('file:///workspace/LeadAEAssist/index.html'))).toBe(true);
  });

  test('denies file URL outside app path', () => {
    const { isTrustedIpcSender } = loadTrustedIpcSender({ isPackaged: true });
    expect(isTrustedIpcSender(eventForUrl('file:///tmp/evil.html'))).toBe(false);
  });
});
