/** @jest-environment node */

jest.mock('../utils/trustedIpcSender', () => ({
  assertTrustedIpcSender: jest.fn((event, action) => {
    if (event?.senderFrame?.url === 'https://evil.example') {
      const err = new Error(`Blocked ${action}`);
      err.code = 'ERR_UNTRUSTED_ORIGIN';
      throw err;
    }
  })
}));

jest.mock('../services/telemetryService', () => ({
  getState: jest.fn(() => ({ enabled: true })),
  setEnabled: jest.fn(() => ({ enabled: true, persisted: true }))
}));

jest.mock('../utils/state', () => ({
  readState: jest.fn(() => ({ qcDelivery: { storage: {}, version: 1 } })),
  writeState: jest.fn()
}));

jest.mock('../utils/codex', () => ({
  listFormats: jest.fn(() => ['mp4']),
  listAudioCodecs: jest.fn(() => ['aac']),
  getCompatibility: jest.fn(() => ({ ok: true })),
  getAudioConstraints: jest.fn(() => ({ ok: true })),
  isAudioContainerValid: jest.fn(() => true),
  loadSpec: jest.fn(() => ({ version: 1 }))
}));

jest.mock('../utils/formatCapabilities', () => ({
  getFormatCapabilities: jest.fn(() => ({ encoderAvailable: true }))
}));

jest.mock('../utils/ffmpegBridge', () => ({
  getBinaryPaths: jest.fn(() => ({ ffmpegPath: '/ffmpeg' }))
}));

jest.mock('../utils/gpuEncoder', () => ({
  getAvailableEncoderSet: jest.fn(() => new Set(['aac']))
}));

jest.mock('../utils/metadata', () => ({
  validateInputAgainstCodex: jest.fn(() => true)
}));

jest.mock('../services/licenseService', () => ({
  isFeatureEnabled: jest.fn(() => true)
}));

jest.mock('../utils/ipcPathGuards', () => ({
  assertApprovedPath: jest.fn((_, p) => p),
  assertApprovedPaths: jest.fn(),
  extractAbsolutePathsFromObject: jest.fn(() => []),
  toLocalPathIfFileUrl: jest.fn((v) => v)
}));

jest.mock('../modules/transcribe', () => ({
  openSubtitleDocument: jest.fn(async () => ({ ok: true })),
  exportCorrectedSubtitles: jest.fn(async () => ({ ok: true })),
  exportSccFromEditor: jest.fn(async () => ({ ok: true })),
  exportMccFromEditor: jest.fn(async () => ({ ok: true })),
  previewMccFromEditor: jest.fn(async () => ({ ok: true })),
  burnInCorrectedSubtitles: jest.fn(async () => ({ ok: true })),
  findLatestSubtitleSource: jest.fn(async () => ({})),
  getSccGlyphs: jest.fn(() => ({}))
}));

jest.mock('../utils/externalNavigationGuards', () => ({
  installExternalNavigationGuards: jest.fn()
}));

jest.mock('../services/ffmpegService', () => ({
  runFfmpeg: jest.fn(async () => ({ ok: true })),
  runFfprobe: jest.fn(async () => ({ ok: true })),
  runFfprobeJson: jest.fn(async () => ({ ok: true })),
  probeMedia: jest.fn(async () => ({ ok: true })),
  getCapabilities: jest.fn(() => ({ ok: true })),
  getMuxerFormats: jest.fn(() => ([]))
}));

jest.mock('../utils/fsAccessControl', () => ({
  isPathAllowed: jest.fn(() => true)
}));

jest.mock('../utils/nativeFs', () => ({
  fsp: {
    stat: jest.fn(async () => ({ isDirectory: () => false, isFile: () => true })),
    realpath: jest.fn(async (p) => p),
    lstat: jest.fn(async () => ({ isSymbolicLink: () => false })),
    readdir: jest.fn(async () => [])
  }
}));

jest.mock('../modules/clone', () => ({
  calculateCloneBytes: jest.fn(async () => ({ success: true })),
  runClone: jest.fn(async () => ({ success: true })),
  cancelClone: jest.fn()
}));

jest.mock('electron', () => ({
  BrowserWindow: jest.fn(),
  screen: { getPrimaryDisplay: jest.fn(() => ({ workAreaSize: { height: 1080 } })) }
}));

const registerTelemetryHandlers = require('../ipc/telemetry.handlers');
const registerPrefsHandlers = require('../ipc/prefs.handlers');
const registerCodexHandlers = require('../ipc/codex.handlers');
const registerSubtitleEditorHandlers = require('../ipc/subtitleEditor.handlers');
const registerFfmpegHandlers = require('../ipc/ffmpeg.handlers');
const registerFsAccessHandlers = require('../ipc/fsAccess.handlers');
const registerIngestHandlers = require('../ipc/ingest.handlers');

function buildIpcMain() {
  const handlers = new Map();
  const listeners = new Map();
  return {
    handlers,
    listeners,
    ipcMain: {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn)),
      on: jest.fn((channel, fn) => listeners.set(channel, fn))
    }
  };
}

describe('IPC trusted sender hardening', () => {
  const untrustedEvent = { senderFrame: { url: 'https://evil.example' }, sender: { id: 77 } };

  test('rejects untrusted sender for telemetry:set-enabled', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerTelemetryHandlers(ipcMain);

    await expect(handlers.get('telemetry:set-enabled')(untrustedEvent, { enabled: true }))
      .rejects.toMatchObject({ code: 'ERR_UNTRUSTED_ORIGIN' });
  });


  test('rejects untrusted sender for prefs:get-preferences', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    await expect(handlers.get('prefs:get-preferences')(untrustedEvent))
      .rejects.toMatchObject({ code: 'ERR_UNTRUSTED_ORIGIN' });
  });

  test('rejects untrusted sender for prefs:set-preferences', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    await expect(handlers.get('prefs:set-preferences')(untrustedEvent, { preferences: { theme: 'dark' } }))
      .rejects.toMatchObject({ code: 'ERR_UNTRUSTED_ORIGIN' });
  });
  test('rejects untrusted sender for prefs:get-qc-delivery', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    await expect(handlers.get('prefs:get-qc-delivery')(untrustedEvent))
      .rejects.toMatchObject({ code: 'ERR_UNTRUSTED_ORIGIN' });
  });

  test('rejects untrusted sender for prefs:set-qc-delivery fire-and-forget listener', () => {
    const { ipcMain, listeners } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    expect(() => listeners.get('prefs:set-qc-delivery')(untrustedEvent, { key: 'mcc-profile', value: 'x' }))
      .toThrow(expect.objectContaining({ code: 'ERR_UNTRUSTED_ORIGIN' }));
  });

  test('rejects untrusted sender for codex:get-spec', () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerCodexHandlers(ipcMain);

    expect(() => handlers.get('codex:get-spec')(untrustedEvent))
      .toThrow(expect.objectContaining({ code: 'ERR_UNTRUSTED_ORIGIN' }));
  });

  test('rejects untrusted sender for subtitle-editor-export', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerSubtitleEditorHandlers(ipcMain);

    await expect(handlers.get('subtitle-editor-export')(untrustedEvent, { doc: {} }))
      .rejects.toMatchObject({ code: 'ERR_UNTRUSTED_ORIGIN' });
  });

  test('rejects untrusted sender for exec-ffmpeg', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerFfmpegHandlers(ipcMain);

    await expect(handlers.get('exec-ffmpeg')(untrustedEvent, []))
      .rejects.toMatchObject({ code: 'ERR_UNTRUSTED_ORIGIN' });
  });

  test('rejects untrusted sender for fs:existsSync listener', () => {
    const { ipcMain, listeners } = buildIpcMain();
    registerFsAccessHandlers(ipcMain);

    expect(() => listeners.get('fs:existsSync')(untrustedEvent, '/tmp/file.txt'))
      .toThrow(expect.objectContaining({ code: 'ERR_UNTRUSTED_ORIGIN' }));
  });

  test('rejects untrusted sender for calculate-ingest-bytes', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerIngestHandlers(ipcMain);

    await expect(handlers.get('calculate-ingest-bytes')(untrustedEvent, {}))
      .rejects.toMatchObject({ code: 'ERR_UNTRUSTED_ORIGIN' });
  });
});
