/** @jest-environment node */

jest.mock('../utils/trustedIpcSender', () => ({
  assertTrustedIpcSender: jest.fn()
}));

const stateModule = {
  current: {
    preferences: { language: 'en' },
    qcDelivery: { storage: { 'mcc-profile': 'safe' }, version: 1 },
    license: { tier: 'pro' }
  }
};

jest.mock('../utils/state', () => ({
  readState: jest.fn(() => JSON.parse(JSON.stringify(stateModule.current))),
  writeState: jest.fn((nextState) => {
    stateModule.current = JSON.parse(JSON.stringify(nextState || {}));
    return { ok: true };
  })
}));

const registerPrefsHandlers = require('../ipc/prefs.handlers');
const { readState, writeState } = require('../utils/state');

function buildIpcMain() {
  const handlers = new Map();
  const listeners = new Map();
  return {
    handlers,
    listeners,
    ipcMain: {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn)),
      on: jest.fn((channel, fn) => listeners.set(channel, fn))
    }
  };
}

describe('ipc prefs handlers - preferences persistence', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    stateModule.current = {
      preferences: { language: 'en' },
      qcDelivery: { storage: { 'mcc-profile': 'safe' }, version: 1 },
      license: { tier: 'pro' }
    };
  });

  test('prefs:get-preferences returns sanitized preferences subtree from canonical state', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    const result = await handlers.get('prefs:get-preferences')({ sender: { id: 1 } });

    expect(result).toEqual({ ok: true, preferences: { language: 'en' } });
    expect(readState).toHaveBeenCalled();
  });

  test('prefs:set-preferences merges only preferences subtree and preserves other domains', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    const result = await handlers.get('prefs:set-preferences')(
      { sender: { id: 1 } },
      { preferences: { theme: 'dark' } }
    );

    expect(result).toEqual({
      ok: true,
      preferences: { language: 'en', theme: 'dark' }
    });

    expect(stateModule.current).toEqual({
      preferences: { language: 'en', theme: 'dark' },
      qcDelivery: { storage: { 'mcc-profile': 'safe' }, version: 1 },
      license: { tier: 'pro' }
    });

    expect(writeState).toHaveBeenCalledTimes(1);
  });

  test('serializes concurrent prefs:set-preferences writes so both key changes survive', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    const eventA = { sender: { id: 100 } };
    const eventB = { sender: { id: 101 } };

    await Promise.all([
      handlers.get('prefs:set-preferences')(eventA, { preferences: { language: 'fr' } }),
      handlers.get('prefs:set-preferences')(eventB, { preferences: { theme: 'dark' } })
    ]);

    expect(stateModule.current.preferences).toEqual({
      language: 'fr',
      theme: 'dark'
    });
    expect(stateModule.current.qcDelivery).toEqual({ storage: { 'mcc-profile': 'safe' }, version: 1 });
    expect(stateModule.current.license).toEqual({ tier: 'pro' });
    expect(writeState).toHaveBeenCalledTimes(2);
  });
});
