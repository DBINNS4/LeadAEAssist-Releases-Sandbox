const { parseSRT } = require('../ai/srtParser');

describe('ai/srtParser.parseSRT', () => {
  test('parses basic SRT with comma milliseconds', () => {
    const srt = [
      '1',
      '00:00:00,498 --> 00:00:02,827',
      "Here's what I love most",
      'about food and diet.',
      '',
      '2',
      '00:00:02,827 --> 00:00:06,383',
      'We all eat several times a day,',
      "and we're totally in charge",
      ''
    ].join('\n');

    const { cues, errors } = parseSRT(srt);
    expect(errors).toHaveLength(0);
    expect(cues).toHaveLength(2);
    expect(cues[0].start).toBeCloseTo(0.498, 3);
    expect(cues[0].end).toBeCloseTo(2.827, 3);
    expect(cues[0].textLines).toEqual(["Here's what I love most", 'about food and diet.']);
  });

  test('tolerates dot milliseconds and 1-2 digit fractions on ingest', () => {
    const srt = [
      '00:00:10.5 --> 00:00:12.05',
      'Hello',
      '',
      '00:00:12.005 --> 00:00:13.5',
      'World',
      ''
    ].join('\n');

    const { cues, errors } = parseSRT(srt);
    expect(errors).toHaveLength(0);
    expect(cues).toHaveLength(2);
    expect(cues[0].start).toBeCloseTo(10.5, 3);
    expect(cues[0].end).toBeCloseTo(12.05, 3);
  });
});
