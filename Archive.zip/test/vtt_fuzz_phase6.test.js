'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { generateVTT } = require('../ai/vttWriter');
const { validateVTT } = require('../ai/vttValidator');

function lcg(seed) {
  let s = (seed >>> 0) || 1;
  return function rand() {
    s = (Math.imul(1664525, s) + 1013904223) >>> 0;
    return s / 0x100000000;
  };
}

function randInt(rng, lo, hi) {
  return lo + Math.floor(rng() * (hi - lo + 1));
}

function randChoice(rng, arr) {
  return arr[randInt(rng, 0, arr.length - 1)];
}

function randWord(rng, minLen = 2, maxLen = 10) {
  const len = randInt(rng, minLen, maxLen);
  const letters = 'abcdefghijklmnopqrstuvwxyz';
  let out = '';
  for (let i = 0; i < len; i++) out += letters[randInt(rng, 0, letters.length - 1)];
  return out;
}

function maybe(rng, p) {
  return rng() < p;
}

function randomCaptionText(rng) {
  const words = [];
  const n = randInt(rng, 3, 18);

  // Occasionally inject internal-ish tokens to ensure stripping/translation is robust.
  const prefix = [];
  if (maybe(rng, 0.10)) prefix.push(`{row:${randInt(rng, 1, 15)}}{col:${randInt(rng, 0, 31)}}`);
  if (maybe(rng, 0.08)) prefix.push(randChoice(rng, ['{I}', '{IU}', '{Gr}', '{Wh}', '{Y}', '{MaU}']));

  for (let i = 0; i < n; i++) {
    let w = randWord(rng);
    if (maybe(rng, 0.05)) w += '&';
    if (maybe(rng, 0.05)) w = '<' + w + '>';
    if (maybe(rng, 0.03)) w += '.'; // punctuation
    words.push(w);
  }

  // Sometimes force explicit line breaks.
  if (maybe(rng, 0.15) && words.length > 8) {
    const cut = randInt(rng, 3, Math.min(words.length - 3, 10));
    return prefix.join('') + words.slice(0, cut).join(' ') + '\n' + words.slice(cut).join(' ');
  }

  return prefix.join('') + words.join(' ');
}

test('Phase 6: fuzz — writer never throws and validator finds no errors', () => {
  const seeds = [1, 2, 3, 1337, 9001];

  for (const seed of seeds) {
    const rng = lcg(seed);

    const includeStyleMetadata = maybe(rng, 0.5);

    const config = {
      fpsOverride: 30,
      formats: {
        vtt: {
          profile: maybe(rng, 0.3) ? 'strict' : 'streaming',
          includeStyleMetadata,
          // Keep deterministic behavior for fuzz: no timeline extension beyond provided gaps.
          allowTimeExtension: false,
          // Exercise both overlap modes.
          preventOverlaps: maybe(rng, 0.5)
        }
      }
    };

    const segments = [];
    let t = 0;

    const N = 180;

    for (let i = 0; i < N; i++) {
      // Build a somewhat plausible timeline with some jitter and occasional overlap.
      const jump = rng() * 1.2; // up to 1.2s forward
      t += jump;

      const jitter = (rng() - 0.5) * 0.25; // +/- 0.125s
      const start = Math.max(0, t + jitter);

      // Durations: include some invalid values to force repairs.
      const dur = (rng() * 3.0) - 0.6; // -0.6 .. 2.4
      const end = start + dur;

      // Speaker occasionally
      const speaker = maybe(rng, 0.15) ? randChoice(rng, ['alex', 'sam', 'taylor', 'jordan']) : undefined;

      segments.push({
        start,
        end,
        speaker,
        text: randomCaptionText(rng)
      });

      // Occasionally add a truly invalid segment (writer should skip cleanly).
      if (maybe(rng, 0.03)) {
        segments.push({ start: NaN, end: NaN, text: 'bad' });
      }
    }

    let vtt;
    assert.doesNotThrow(() => { vtt = generateVTT(segments, config); }, `generateVTT threw (seed=${seed})`);

    assert.ok(typeof vtt === 'string' && vtt.startsWith('WEBVTT'), `Output not WebVTT (seed=${seed})`);

    const report = validateVTT(vtt, config, { seed });
    assert.equal(report.errors.length, 0, `QC errors in fuzz run seed=${seed}: ${JSON.stringify(report.errors, null, 2)}`);
  }
});
