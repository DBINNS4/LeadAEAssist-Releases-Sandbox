'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const crypto = require('crypto');

function makeTempDir(prefix = 'leadae-runtime-asset-') {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

function writeJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

function writeFile(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, value);
}

function sha256Hex(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function setupRuntimeAssetTest(runtimeAssetService, manifest) {
  const root = makeTempDir();
  const previousCwd = process.cwd();
  const previousUserData = process.env.LEADAE_USERDATA;
  const previousManifestPath = process.env.LEADAE_RUNTIME_ASSET_MANIFEST;
  const userDataPath = path.join(root, 'userData');
  const manifestPath = path.join(root, 'config', 'runtime.assets.manifest.json');

  writeJson(manifestPath, manifest);
  process.chdir(root);
  process.env.LEADAE_USERDATA = userDataPath;
  process.env.LEADAE_RUNTIME_ASSET_MANIFEST = manifestPath;
  runtimeAssetService.__private?.resetForTests?.();

  return {
    root,
    userDataPath,
    manifestPath,
    restore() {
      process.chdir(previousCwd);
      if (previousUserData === undefined) delete process.env.LEADAE_USERDATA;
      else process.env.LEADAE_USERDATA = previousUserData;
      if (previousManifestPath === undefined) delete process.env.LEADAE_RUNTIME_ASSET_MANIFEST;
      else process.env.LEADAE_RUNTIME_ASSET_MANIFEST = previousManifestPath;
      runtimeAssetService.__private?.resetForTests?.();
    }
  };
}

function createHttpServer(handler) {
  return new Promise((resolve, reject) => {
    const server = http.createServer(handler);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      if (!address || typeof address !== 'object') {
        reject(new Error('Failed to bind test HTTP server.'));
        return;
      }
      resolve({
        server,
        origin: `http://127.0.0.1:${address.port}`
      });
    });
    server.on('error', reject);
  });
}

function closeServer(server) {
  return new Promise((resolve, reject) => {
    if (!server) {
      resolve();
      return;
    }
    server.close(error => {
      if (error) reject(error);
      else resolve();
    });
  });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = {
  makeTempDir,
  writeJson,
  writeFile,
  sha256Hex,
  setupRuntimeAssetTest,
  createHttpServer,
  closeServer,
  sleep
};
