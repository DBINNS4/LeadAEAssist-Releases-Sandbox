const flushPromises = () => new Promise(resolve => setImmediate(resolve));

function createDeferred() {
  let resolve;
  let reject;
  const promise = new Promise((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

function buildSpeedTestDOM() {
  document.body.innerHTML = `
    <div id="speed-test">
      <div id="speed-test-overview-tooltip"></div>
      <div id="speedtest-info-tooltip"></div>
      <button id="start-network-test">Test Speed</button>
      <button id="reset-network-test"></button>
      <button id="cancel-network-test"></button>
      <div id="network-test-inline-status"></div>
      <div id="network-test-results"></div>
      <div id="drive-test-results"></div>
      <div id="speedtest-job-status"></div>
      <div id="speedtest-network-job-status"></div>
      <div id="drive-path-1"></div>
      <div id="drive-path-2"></div>
      <div id="drive-path-3"></div>
      <button id="test-selected-drives"></button>
      <div class="dropdown-wrapper">
        <input class="chosen-value" type="text">
        <ul class="value-list"></ul>
        <input type="hidden" id="test-size">
      </div>
      <div class="dropdown-wrapper">
        <input class="chosen-value" type="text">
        <ul class="value-list"></ul>
        <input type="hidden" id="io-mode">
      </div>
      <div id="speedtest-loader-inline">
        <progress id="speedtest-progress"></progress>
        <output id="speedtest-progress-output"></output>
      </div>
      <button id="reset-speedtest"></button>
      <button id="cancel-speedtest"></button>
      <button id="select-drive-1"></button>
      <button id="select-drive-2"></button>
      <button id="select-drive-3"></button>
    </div>
  `;

  Object.defineProperty(document, 'readyState', {
    configurable: true,
    get: () => 'complete',
  });
}

describe('Speed Test panel behaviors', () => {
  let listeners;

  const addListener = (channel, handler) => {
    if (!listeners.has(channel)) listeners.set(channel, new Set());
    listeners.get(channel).add(handler);
  };

  const removeListener = (channel, handler) => {
    const handlers = listeners.get(channel);
    if (!handlers) return;
    handlers.delete(handler);
    if (handlers.size === 0) listeners.delete(channel);
  };

  const getLatestListener = (channel) => {
    const handlers = listeners.get(channel);
    if (!handlers || handlers.size === 0) return null;
    return Array.from(handlers).at(-1);
  };

  beforeEach(() => {
    jest.resetModules();
    ipc.invoke.mockReset();
    ipc.on.mockReset();
    ipc.off = jest.fn();
    ipc.removeListener = jest.fn();
    ipc.removeAllListeners = jest.fn();
    listeners = new Map();
    ipc.on.mockImplementation((channel, handler) => {
      addListener(channel, handler);
      return ipc;
    });
    ipc.off.mockImplementation((channel, handler) => {
      removeListener(channel, handler);
      return ipc;
    });
    ipc.removeListener.mockImplementation((channel, handler) => {
      removeListener(channel, handler);
      return ipc;
    });
    ipc.selectFolder = jest.fn();
    Object.assign(window.electron, {
      invoke: ipc.invoke,
      on: ipc.on,
      off: ipc.off,
      removeListener: ipc.removeListener,
      removeAllListeners: ipc.removeAllListeners,
      selectFolder: ipc.selectFolder,
    });
    window.i18n = {
      t: jest.fn(key => key),
    };
    window.translatePage = jest.fn();
    buildSpeedTestDOM();
    require('../renderer.speed-test.js');
  });

  test('runs a network test and restores the button label after completion', async () => {
    ipc.invoke.mockImplementation(async channel => {
      if (channel === 'run-network-test') {
        return { success: true, download: 100, upload: 40, ping: 9 };
      }
      return undefined;
    });

    const runBtn = document.getElementById('start-network-test');
    const results = document.getElementById('network-test-results');

    runBtn.click();
    expect(runBtn.disabled).toBe(true);

    await flushPromises();

    expect(results.textContent).toContain('Download: 100 Mbps');
    expect(results.textContent).toContain('Upload: 40 Mbps');
    expect(results.textContent).toContain('Ping: 9 ms');
    expect(runBtn.disabled).toBe(false);
    expect(runBtn.textContent).toBe('Test Speed');
  });

  test('runs drive tests with the selected drive and clears selections afterwards', async () => {
    ipc.selectFolder.mockResolvedValue('/Volumes/FastDrive');
    ipc.invoke.mockImplementation(async channel => {
      if (channel === 'reset-drive-test-cancel') return undefined;
      if (channel === 'run-drive-test') {
        return {
          success: true,
          write: 800,
          writeMin: 780,
          writeMax: 820,
          read: 900,
          readMin: 880,
          readMax: 930,
        };
      }
      return undefined;
    });

    const selectBtn = document.getElementById('select-drive-1');
    const runBtn = document.getElementById('test-selected-drives');
    const results = document.getElementById('drive-test-results');
    const drivePath1 = document.getElementById('drive-path-1');
    const drivePath2 = document.getElementById('drive-path-2');
    const drivePath3 = document.getElementById('drive-path-3');

    selectBtn.click();
    await flushPromises();

    expect(drivePath1.textContent).toBe('/Volumes/FastDrive');

    runBtn.click();
    await flushPromises();

    expect(results.textContent).toContain('Drive 1 (/Volumes/FastDrive) Results');
    expect(results.textContent).toContain('Write: 800 MiB/s');
    expect(results.textContent).toContain('Read:  900 MiB/s');

    expect(drivePath1.textContent).toBe('No drive selected');
    expect(drivePath2.textContent).toBe('No drive selected');
    expect(drivePath3.textContent).toBe('No drive selected');
  });

  test('shows localized license error for drive test failures', async () => {
    const localizedMessage = 'Localized license required message';
    window.i18n.t.mockImplementation(key => (
      key === 'speedTestLicenseRequired' ? localizedMessage : key
    ));
    ipc.selectFolder.mockResolvedValue('/Volumes/FastDrive');
    ipc.invoke.mockImplementation(async channel => {
      if (channel === 'reset-drive-test-cancel') return undefined;
      if (channel === 'run-drive-test') {
        return {
          success: false,
          code: 'LICENSE_REQUIRED',
          error: '🔒 License required for speed test',
        };
      }
      return undefined;
    });

    const selectBtn = document.getElementById('select-drive-1');
    const runBtn = document.getElementById('test-selected-drives');
    const results = document.getElementById('drive-test-results');

    selectBtn.click();
    await flushPromises();

    runBtn.click();
    await flushPromises();

    expect(results.textContent).toContain(localizedMessage);
  });

  test.each([
    ['PARSE_ERROR', 'Speed test returned unreadable results. Please try again.'],
    ['TIMEOUT', 'Speed test timed out. Please try again.'],
    ['DEPENDENCY_MISSING', 'Network test tool is missing. Please reinstall the app.'],
    ['BROWSER_MISSING', 'Browser dependency for the network test is missing. Please reinstall the app or run the browser download step.'],
  ])('maps network error code %s to a user-friendly message', async (code, expectedMessage) => {
    ipc.invoke.mockResolvedValue({ success: false, code });

    document.getElementById('start-network-test').click();
    await flushPromises();

    expect(document.getElementById('network-test-results').textContent).toContain(expectedMessage);
    expect(document.getElementById('start-network-test').disabled).toBe(false);
    expect(document.getElementById('cancel-network-test').disabled).toBe(true);
  });

  test('uses localized generic fallback for unmapped network error codes', async () => {
    const fallback = 'Localized unknown network error';
    window.i18n.t.mockImplementation(key => (
      key === 'speedTestUnknownError' ? fallback : key
    ));
    ipc.invoke.mockResolvedValue({
      success: false,
      code: 'SOME_NEW_BACKEND_ERROR',
      error: 'Internal backend diagnostic details',
    });

    document.getElementById('start-network-test').click();
    await flushPromises();

    const text = document.getElementById('network-test-results').textContent;
    expect(text).toContain(fallback);
    expect(text).not.toContain('Internal backend diagnostic details');
  });

  test('supports network cancel success and unlocks controls', async () => {
    const runDeferred = createDeferred();
    ipc.invoke.mockImplementation((channel) => {
      if (channel === 'run-network-test') return runDeferred.promise;
      if (channel === 'cancel-network-test') return Promise.resolve(true);
      return Promise.resolve(undefined);
    });

    const runBtn = document.getElementById('start-network-test');
    const cancelBtn = document.getElementById('cancel-network-test');

    runBtn.click();
    await flushPromises();
    expect(runBtn.disabled).toBe(true);
    expect(cancelBtn.disabled).toBe(false);

    cancelBtn.click();
    await flushPromises();
    expect(ipc.invoke).toHaveBeenCalledWith('cancel-network-test');

    runDeferred.resolve({ cancelled: true });
    await flushPromises();

    expect(document.getElementById('network-test-results').textContent).toContain('🛑 Network test cancelled.');
    expect(runBtn.disabled).toBe(false);
    expect(cancelBtn.disabled).toBe(true);
  });

  test('shows inline message when network cancel request fails, then unlocks after completion', async () => {
    const runDeferred = createDeferred();
    ipc.invoke.mockImplementation((channel) => {
      if (channel === 'run-network-test') return runDeferred.promise;
      if (channel === 'cancel-network-test') return Promise.reject(new Error('bridge offline'));
      return Promise.resolve(undefined);
    });

    const runBtn = document.getElementById('start-network-test');
    const cancelBtn = document.getElementById('cancel-network-test');
    const inlineStatus = document.getElementById('network-test-inline-status');

    runBtn.click();
    await flushPromises();
    cancelBtn.click();
    await flushPromises();

    expect(inlineStatus.textContent).toContain('❌ Cancel failed: bridge offline');
    expect(cancelBtn.disabled).toBe(false);

    runDeferred.resolve({ success: false, code: 'TIMEOUT' });
    await flushPromises();

    expect(runBtn.disabled).toBe(false);
    expect(cancelBtn.disabled).toBe(true);
    expect(inlineStatus.textContent).toBe('');
  });

  test('renders insufficient disk-space payload and read-only drive errors', async () => {
    ipc.selectFolder.mockResolvedValue('/Volumes/FastDrive');
    ipc.invoke.mockImplementation(async channel => {
      if (channel === 'reset-drive-test-cancel') return undefined;
      if (channel === 'run-drive-test') {
        return {
          success: false,
          code: 'INSUFFICIENT_DISK_SPACE',
          requiredBytes: 1024 * 1024 * 1024,
          freeBytes: 512 * 1024 * 1024,
        };
      }
      return undefined;
    });

    document.getElementById('select-drive-1').click();
    await flushPromises();
    document.getElementById('test-selected-drives').click();
    await flushPromises();
    await new Promise(resolve => setTimeout(resolve, 450));

    const results = document.getElementById('drive-test-results').textContent;
    expect(results).toContain('Insufficient free space (need ~1.0 GiB free, have 512 MiB)');

    ipc.invoke.mockImplementation(async channel => {
      if (channel === 'reset-drive-test-cancel') return undefined;
      if (channel === 'run-drive-test') {
        return { success: false, code: 'DRIVE_NOT_WRITABLE' };
      }
      return undefined;
    });

    document.getElementById('test-selected-drives').click();
    await flushPromises();
    expect(document.getElementById('drive-test-results').textContent).toContain('Drive is read-only or lacks write permissions.');
  });


  test('renders multiple warning payloads while keeping result summary format stable', async () => {
    ipc.selectFolder.mockResolvedValue('/Volumes/FastDrive');
    ipc.invoke.mockImplementation(async channel => {
      if (channel === 'reset-drive-test-cancel') return undefined;
      if (channel === 'run-drive-test') {
        return {
          success: true,
          write: 700,
          writeMin: 650,
          writeMax: 750,
          read: 800,
          readMin: 780,
          readMax: 820,
          warning: [
            { code: 'DISK_SPACE_CHECK_FAILED' }
          ]
        };
      }
      return undefined;
    });

    document.getElementById('select-drive-1').click();
    await flushPromises();
    document.getElementById('test-selected-drives').click();
    await flushPromises();

    const results = document.getElementById('drive-test-results').textContent;
    expect(results).toContain('⚠️ Unable to verify free space; proceeding at your own risk.');
    expect(results).toContain('Drive 1 (/Volumes/FastDrive) Results:');
    expect(results).toContain('🔹 Write: 700 MiB/s (min: 650, max: 750)');
    expect(results).toContain('🔹 Read:  800 MiB/s (min: 780, max: 820)');
  });

  test('uses localized generic fallback for unmapped drive warnings', async () => {
    const fallbackWarning = 'Localized generic drive warning';
    window.i18n.t.mockImplementation(key => (
      key === 'driveTestUnknownWarning' ? fallbackWarning : key
    ));
    ipc.selectFolder.mockResolvedValue('/Volumes/FastDrive');
    ipc.invoke.mockImplementation(async channel => {
      if (channel === 'reset-drive-test-cancel') return undefined;
      if (channel === 'run-drive-test') {
        return {
          success: true,
          write: 700,
          writeMin: 650,
          writeMax: 750,
          read: 800,
          readMin: 780,
          readMax: 820,
          warning: [
            {
              code: 'UNMAPPED_WARNING_CODE',
              error: 'Raw backend warning details should stay hidden'
            }
          ]
        };
      }
      return undefined;
    });

    document.getElementById('select-drive-1').click();
    await flushPromises();
    document.getElementById('test-selected-drives').click();
    await flushPromises();

    const results = document.getElementById('drive-test-results').textContent;
    expect(results).toContain(`⚠️ ${fallbackWarning}`);
    expect(results).not.toContain('Raw backend warning details should stay hidden');
  });

  test('inserts disk-space-check warnings before per-drive output and avoids duplicate listeners across runs', async () => {
    ipc.selectFolder.mockResolvedValue('/Volumes/FastDrive');
    const runDeferred = createDeferred();
    ipc.invoke.mockImplementation((channel) => {
      if (channel === 'reset-drive-test-cancel') return Promise.resolve(undefined);
      if (channel === 'run-drive-test') return runDeferred.promise;
      return Promise.resolve(undefined);
    });

    document.getElementById('select-drive-1').click();
    await flushPromises();
    document.getElementById('test-selected-drives').click();
    await flushPromises();

    expect(listeners.has('drive-test-progress')).toBe(true);
    expect(listeners.has('drive-test-warning')).toBe(true);

    const warningHandler = getLatestListener('drive-test-warning');
    expect(typeof warningHandler).toBe('function');
    warningHandler(null, { code: 'DISK_SPACE_CHECK_FAILED' });
    const runningText = document.getElementById('drive-test-results').textContent;
    expect(runningText.indexOf('⚠️ Unable to verify free space; proceeding at your own risk.')).toBeGreaterThan(-1);
    expect(runningText.indexOf('⚠️ Unable to verify free space; proceeding at your own risk.')).toBeLessThan(
      runningText.indexOf('⏳ Testing Drive 1 at /Volumes/FastDrive...')
    );

    runDeferred.resolve({ success: true, write: 800, writeMin: 700, writeMax: 900, read: 900, readMin: 850, readMax: 950 });
    await flushPromises();
    await new Promise(resolve => setTimeout(resolve, 450));

    expect(listeners.has('drive-test-progress')).toBe(false);
    expect(listeners.has('drive-test-warning')).toBe(false);

    const secondRunDeferred = createDeferred();
    ipc.selectFolder.mockResolvedValue('/Volumes/FastDrive');
    document.getElementById('select-drive-1').click();
    await flushPromises();
    ipc.invoke.mockImplementation((channel) => {
      if (channel === 'reset-drive-test-cancel') return Promise.resolve(undefined);
      if (channel === 'run-drive-test') return secondRunDeferred.promise;
      return Promise.resolve(undefined);
    });
    document.getElementById('test-selected-drives').click();
    await flushPromises();
    expect(listeners.has('drive-test-progress')).toBe(true);
    expect(listeners.has('drive-test-warning')).toBe(true);

    secondRunDeferred.resolve({ success: true, write: 600, writeMin: 500, writeMax: 700, read: 650, readMin: 550, readMax: 750 });
    await flushPromises();
    await new Promise(resolve => setTimeout(resolve, 450));

    const onProgressCalls = ipc.on.mock.calls.filter(([channel]) => channel === 'drive-test-progress').length;
    const offProgressCalls = ipc.off.mock.calls.filter(([channel]) => channel === 'drive-test-progress').length;
    expect(onProgressCalls).toBe(2);
    expect(offProgressCalls).toBeGreaterThanOrEqual(2);
  });




  test('handles cancellation during a multi-drive run and restores controls/dropdowns', async () => {
    const firstRun = createDeferred();
    ipc.selectFolder
      .mockResolvedValueOnce('/Volumes/DriveOne')
      .mockResolvedValueOnce('/Volumes/DriveTwo');
    ipc.invoke.mockImplementation((channel, path) => {
      if (channel === 'reset-drive-test-cancel') return Promise.resolve(undefined);
      if (channel === 'run-drive-test' && path === '/Volumes/DriveOne') return firstRun.promise;
      if (channel === 'run-drive-test' && path === '/Volumes/DriveTwo') return Promise.resolve({ success: true, write: 500, writeMin: 450, writeMax: 550, read: 600, readMin: 580, readMax: 620 });
      if (channel === 'cancel-drive-test') return Promise.resolve(true);
      return Promise.resolve(undefined);
    });

    document.getElementById('select-drive-1').click();
    document.getElementById('select-drive-2').click();
    await flushPromises();

    const runBtn = document.getElementById('test-selected-drives');
    const cancelBtn = document.getElementById('cancel-speedtest');
    const testSizeInput = document.querySelector('#test-size').closest('.dropdown-wrapper').querySelector('.chosen-value');
    const modeInput = document.querySelector('#io-mode').closest('.dropdown-wrapper').querySelector('.chosen-value');

    runBtn.click();
    await flushPromises();
    expect(runBtn.disabled).toBe(true);
    expect(cancelBtn.disabled).toBe(false);
    expect(testSizeInput.disabled).toBe(true);
    expect(modeInput.disabled).toBe(true);

    cancelBtn.click();
    await flushPromises();
    firstRun.resolve({ cancelled: true });
    await flushPromises();
    await new Promise(resolve => setTimeout(resolve, 450));

    expect(ipc.invoke.mock.calls.filter(([channel]) => channel === 'run-drive-test').length).toBe(1);
    expect(document.getElementById('drive-test-results').textContent).toContain('🛑 Drive test cancelled.');
    expect(runBtn.disabled).toBe(false);
    expect(cancelBtn.disabled).toBe(true);
    expect(testSizeInput.disabled).toBe(false);
    expect(modeInput.disabled).toBe(false);
  });

  test('restores network and drive placeholders after output without losing i18n placeholders', async () => {
    ipc.invoke.mockImplementation(async channel => {
      if (channel === 'run-network-test') return { success: true, download: 100, upload: 50, ping: 5 };
      if (channel === 'reset-drive-test-cancel') return undefined;
      if (channel === 'run-drive-test') return { success: true, write: 300, writeMin: 250, writeMax: 350, read: 400, readMin: 350, readMax: 450 };
      return undefined;
    });
    ipc.selectFolder.mockResolvedValue('/Volumes/FastDrive');

    document.getElementById('start-network-test').click();
    await flushPromises();
    expect(document.getElementById('network-test-results').textContent).toContain('Download: 100 Mbps');
    document.getElementById('reset-network-test').click();
    expect(document.getElementById('network-test-results').innerHTML).toContain('data-i18n="noNetworkResults"');

    document.getElementById('select-drive-1').click();
    await flushPromises();
    document.getElementById('test-selected-drives').click();
    await flushPromises();
    expect(document.getElementById('drive-test-results').textContent).toContain('Drive 1 (/Volumes/FastDrive) Results');
    await new Promise(resolve => setTimeout(resolve, 450));

    document.getElementById('reset-speedtest').click();
    await flushPromises();
    expect(document.getElementById('drive-test-results').innerHTML).toContain('data-i18n="noDriveResults"');
  });
});
