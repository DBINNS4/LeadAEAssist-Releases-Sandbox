const path = require('path');

const { getFileListRelativePath } = require('../modules/ingest');

describe('ingest file list relative paths', () => {
  test('namespaces duplicate basenames with parent folders for multi-select', () => {
    const first = getFileListRelativePath('/Volumes/A/clip.mov', {
      useParentFolderPrefix: true
    });
    const second = getFileListRelativePath('/Volumes/B/clip.mov', {
      useParentFolderPrefix: true
    });

    expect(first).toBe(path.join('A', 'clip.mov'));
    expect(second).toBe(path.join('B', 'clip.mov'));
    expect(first).not.toBe(second);
  });
});
