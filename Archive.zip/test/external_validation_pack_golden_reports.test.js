'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

function _normalizeFailingCueTimecodes(reportText) {
  // The QC report can legitimately drift by ~1 frame in the *displayed* cue span
  // due to quantization/scheduling changes (start-floor / end-ceil policy, DF rounding).
  // We keep the regression signal on: structure, thresholds, PASS/FAIL, and failure codes.
  const TC = /\d{2}:\d{2}:\d{2}[:;]\d{2}/g;
  return String(reportText || '')
    .replace(/^•\s+.*$/gm, (line) => line.replace(TC, '<TC>'))
    .replace(/^>\s+.*$/gm, (line) => line.replace(TC, '<TC>'));
}

function normalizeReportText(txt) {
  const s = String(txt || '').replace(/\r\n/g, '\n');
  // The report includes an absolute output path on the `File:` line.
  // Normalise it so goldens are portable across machines/temp dirs.
  //
  // NOTE: "Observed:" lines include derived QC stats (CPS/WPM/minDur/minGap) that can
  // drift slightly with benign timing quantization / schedule changes. We treat the
  // structure + thresholds + PASS/FAIL as the regression signal, not the exact floats.
  return _normalizeFailingCueTimecodes(s)
    .replace(/^File:.*$/m, 'File: <PATH>')
    .replace(/^Observed:.*$/gm, (line) => {
      return String(line).replace(/-?\d+(?:\.\d+)?/g, '<N>');
    })
    .trimEnd() + '\n';
}

test('External validation pack: golden MCC QC reports (NLE, Broadcast, edge case)', () => {
  const repoRoot = path.resolve(__dirname, '..');
  const outRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-external-pack-'));
  const script = path.join(repoRoot, 'tools', 'validation', 'generateExternalValidationPack.js');

  const goldenRoot = path.join(repoRoot, '_external_pack');

  const cases = [
    {
      label: 'VAL01 NLE (608 on; dual grade enabled)',
      rel: path.join(
        'exports',
        'VAL01_basic_popon_safe',
        'VAL01_basic_popon_safe__mcc_nle.mcc.report.txt'
      )
    },
    {
      label: 'VAL01 Broadcast (608 off; legacy projection path)',
      rel: path.join(
        'exports',
        'VAL01_basic_popon_safe',
        'VAL01_basic_popon_safe__mcc_broadcast.mcc.report.txt'
      )
    },
    {
      label: 'VAL05 Edge case (708 fails, 608 passes)',
      rel: path.join(
        'exports',
        'VAL05_708_fail_608_pass',
        'VAL05_708_fail_608_pass__mcc_nle.mcc.report.txt'
      )
    }
  ];

  try {
    execFileSync(process.execPath, [script, outRoot], {
      cwd: repoRoot,
      stdio: 'pipe'
    });

    for (const c of cases) {
      const goldenPath = path.join(goldenRoot, c.rel);
      const genPath = path.join(outRoot, c.rel);

      assert.equal(fs.existsSync(goldenPath), true, `Golden report missing: ${goldenPath}`);
      assert.equal(fs.existsSync(genPath), true, `Generated report missing: ${genPath}`);

      const golden = normalizeReportText(fs.readFileSync(goldenPath, 'utf8'));
      const gen = normalizeReportText(fs.readFileSync(genPath, 'utf8'));

      assert.equal(
        gen,
        golden,
        `Golden mismatch (${c.label}).\nGenerated: ${genPath}\nGolden: ${goldenPath}`
      );
    }
  } finally {
    fs.rmSync(outRoot, { recursive: true, force: true });
  }
});
