const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const runtimeAssetService = require('../services/runtimeAssetService');
const { sha256DirectoryTreeHex } = require('../utils/runtimeAssetIntegrity');
const {
  setupRuntimeAssetTest,
  createHttpServer,
  closeServer,
  writeFile,
  sha256Hex
} = require('./helpers/runtimeAssetTestUtils');

test('runtime asset service: checksum verification', async (t) => {
  await t.test('rejects downloaded assets whose sha256 does not match the manifest', async () => {
    const payload = Buffer.from('definitely the wrong bytes', 'utf8');
    const expectedSha = sha256Hex(Buffer.from('the bytes we wish existed', 'utf8'));
    const { server, origin } = await createHttpServer((req, res) => {
      res.writeHead(200, {
        'Content-Type': 'application/octet-stream',
        'Content-Length': String(payload.length)
      });
      res.end(payload);
    });

    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'checksum.download': {
          type: 'file',
          installPath: 'checksum/download.bin',
          downloadUrl: `${origin}/checksum.download`,
          sha256: expectedSha
        }
      }
    });

    try {
      await assert.rejects(
        runtimeAssetService.ensureAsset('checksum.download'),
        (error) => {
          assert.equal(error.code, 'ASSET_CHECKSUM_MISMATCH');
          return true;
        }
      );

      const installedPath = runtimeAssetService.getInstalledAssetPath('checksum.download');
      assert.equal(fs.existsSync(installedPath), false);
    } finally {
      await closeServer(server);
      ctx.restore();
    }
  });

  await t.test('rejects seeded assets whose sha256 does not match the manifest', async () => {
    const seedPayload = Buffer.from('seed bytes but not the right ones', 'utf8');
    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'checksum.seed': {
          type: 'file',
          installPath: 'checksum/seed.bin',
          seedPaths: ['legacy/checksum.seed.bin'],
          sha256: sha256Hex(Buffer.from('expected seed bytes', 'utf8'))
        }
      }
    });

    try {
      writeFile(`${ctx.root}/legacy/checksum.seed.bin`, seedPayload);
      await assert.rejects(
        runtimeAssetService.ensureAsset('checksum.seed'),
        (error) => {
          assert.equal(error.code, 'ASSET_CHECKSUM_MISMATCH');
          assert.match(error.message, /Seed checksum mismatch/);
          return true;
        }
      );

      const installedPath = runtimeAssetService.getInstalledAssetPath('checksum.seed');
      assert.equal(fs.existsSync(installedPath), false);
    } finally {
      ctx.restore();
    }
  });

  await t.test('revalidates a matching installed file asset when the state entry is missing and backfills checksum metadata', async () => {
    const payload = Buffer.from('existing whisper bytes that already match the manifest', 'utf8');
    const expectedSha = sha256Hex(payload);
    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'checksum.installed.reuse': {
          type: 'file',
          installPath: 'whisper/models/ggml-base.en.bin',
          sha256: expectedSha
        }
      }
    });

    try {
      const installedPath = runtimeAssetService.getInstalledAssetPath('checksum.installed.reuse');
      writeFile(installedPath, payload);

      const events = [];
      const reused = await runtimeAssetService.ensureAsset('checksum.installed.reuse', {
        onProgress(event) {
          events.push({
            phase: event.phase,
            status: event.status,
            source: event.source || null,
            checksumSource: event.checksumSource || null
          });
        }
      });

      assert.equal(reused.source, 'installed');
      assert.equal(fs.readFileSync(reused.path, 'utf8'), payload.toString('utf8'));
      assert.ok(events.some(event => event.phase === 'verify' && event.status === 'complete' && event.source === 'installed'));
      assert.ok(events.some(event => event.phase === 'complete' && event.status === 'reused' && event.source === 'installed'));

      const state = runtimeAssetService.readInstalledState();
      assert.equal(state.installed['checksum.installed.reuse'].sha256, expectedSha);
      assert.equal(state.installed['checksum.installed.reuse'].path, reused.path);
      assert.equal(state.installed['checksum.installed.reuse'].size, payload.length);
      assert.ok(Number.isFinite(Number(state.installed['checksum.installed.reuse'].mtimeMs)));
    } finally {
      ctx.restore();
    }
  });

  await t.test('treats a stale installed file asset as outdated and re-downloads the manifest version', async () => {
    const stalePayload = Buffer.from('old whisper bytes that should not survive the upgrade', 'utf8');
    const freshPayload = Buffer.from('new whisper bytes from the current manifest', 'utf8');
    const expectedSha = sha256Hex(freshPayload);
    let requestCount = 0;

    const { server, origin } = await createHttpServer((req, res) => {
      requestCount += 1;
      res.writeHead(200, {
        'Content-Type': 'application/octet-stream',
        'Content-Length': String(freshPayload.length)
      });
      res.end(freshPayload);
    });

    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'checksum.installed.refresh': {
          type: 'file',
          installPath: 'whisper/models/ggml-base.en.bin',
          downloadUrl: `${origin}/whisper/model.bin`,
          sha256: expectedSha
        }
      }
    });

    try {
      const installedPath = runtimeAssetService.getInstalledAssetPath('checksum.installed.refresh');
      writeFile(installedPath, stalePayload);
      runtimeAssetService.writeInstalledState({
        schemaVersion: 1,
        installed: {
          'checksum.installed.refresh': {
            path: installedPath,
            source: 'download',
            installedAt: 123,
            sha256: sha256Hex(stalePayload),
            size: stalePayload.length,
            mtimeMs: 1
          }
        }
      });

      const events = [];
      const refreshed = await runtimeAssetService.ensureAsset('checksum.installed.refresh', {
        onProgress(event) {
          events.push({
            phase: event.phase,
            status: event.status,
            source: event.source || null,
            errorCode: event.errorCode || null
          });
        }
      });

      assert.equal(refreshed.source, 'download');
      assert.equal(requestCount, 1);
      assert.equal(fs.readFileSync(refreshed.path, 'utf8'), freshPayload.toString('utf8'));
      assert.ok(events.some(event => event.phase === 'verify' && event.status === 'stale' && event.source === 'installed' && event.errorCode === 'ASSET_CHECKSUM_MISMATCH'));
      assert.ok(events.some(event => event.phase === 'download' && event.status === 'start'));
      assert.ok(events.some(event => event.phase === 'complete' && event.status === 'complete' && event.source === 'download'));

      const state = runtimeAssetService.readInstalledState();
      assert.equal(state.installed['checksum.installed.refresh'].sha256, expectedSha);
      assert.equal(state.installed['checksum.installed.refresh'].size, freshPayload.length);
      assert.ok(Number.isFinite(Number(state.installed['checksum.installed.refresh'].mtimeMs)));
    } finally {
      await closeServer(server);
      ctx.restore();
    }
  });


  await t.test('falls back to download when a seed candidate exists but fails verification', async () => {
    const seedPayload = Buffer.from('seed bytes but not the right ones', 'utf8');
    const downloadPayload = Buffer.from('these are the bytes we really want', 'utf8');
    const expectedSha = sha256Hex(downloadPayload);

    const { server, origin } = await createHttpServer((req, res) => {
      if (req.url !== '/whisper/model.bin') {
        res.writeHead(404);
        res.end('not found');
        return;
      }
      res.writeHead(200, {
        'Content-Type': 'application/octet-stream',
        'Content-Length': String(downloadPayload.length)
      });
      res.end(downloadPayload);
    });

    const previousBaseUrl = process.env.LEADAE_ASSETS_BASE_URL;
    process.env.LEADAE_ASSETS_BASE_URL = origin;

    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'checksum.seed.fallback': {
          type: 'file',
          installPath: 'checksum/fallback.bin',
          seedPaths: ['legacy/checksum.fallback.bin'],
          relativeUrl: 'whisper/model.bin',
          sha256: expectedSha
        }
      }
    });

    try {
      writeFile(`${ctx.root}/legacy/checksum.fallback.bin`, seedPayload);

      const events = [];
      const installed = await runtimeAssetService.ensureAsset('checksum.seed.fallback', {
        onProgress(event) {
          events.push({
            phase: event.phase,
            status: event.status,
            source: event.source || null,
            reason: event.reason || null,
            errorCode: event.errorCode || null
          });
        }
      });

      assert.equal(installed.source, 'download');
      assert.equal(fs.readFileSync(installed.path, 'utf8'), downloadPayload.toString('utf8'));
      assert.ok(events.some(e => e.phase === 'seed' && e.status === 'skipped' && e.errorCode === 'ASSET_CHECKSUM_MISMATCH'));
      assert.ok(events.some(e => e.phase === 'download' && e.status === 'start'));
      assert.ok(events.some(e => e.phase === 'complete' && e.status === 'complete' && e.source === 'download'));
    } finally {
      await closeServer(server);
      if (previousBaseUrl === undefined) delete process.env.LEADAE_ASSETS_BASE_URL;
      else process.env.LEADAE_ASSETS_BASE_URL = previousBaseUrl;
      ctx.restore();
    }
  });

  await t.test('rejects archive directory seeds whose seedSha256 does not match the manifest', async () => {
    const legacyRoot = path.join('legacy', 'puppeteer');
    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'checksum.archive.seed': {
          type: 'archive',
          archiveFormat: 'zip',
          installDir: 'puppeteer/cache/chrome-127.0.6533.88/darwin-arm64',
          seedPaths: [legacyRoot],
          sha256: sha256Hex(Buffer.from('download archive bytes', 'utf8')),
          seedSha256: sha256Hex(Buffer.from('definitely the wrong directory hash', 'utf8')),
          entrypoint: 'chrome/mac_arm-127.0.6533.88/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
        }
      }
    });

    try {
      const legacyAbsoluteRoot = path.join(ctx.root, legacyRoot);
      const binaryPath = path.join(
        legacyAbsoluteRoot,
        'chrome',
        'mac_arm-127.0.6533.88',
        'chrome-mac-arm64',
        'Google Chrome for Testing.app',
        'Contents',
        'MacOS',
        'Google Chrome for Testing'
      );
      writeFile(binaryPath, '#!/bin/sh\nexit 0\n');

      const actualDigest = sha256DirectoryTreeHex(legacyAbsoluteRoot);
      assert.notEqual(actualDigest, sha256Hex(Buffer.from('definitely the wrong directory hash', 'utf8')));

      await assert.rejects(
        runtimeAssetService.ensureAsset('checksum.archive.seed'),
        (error) => {
          assert.equal(error.code, 'ASSET_CHECKSUM_MISMATCH');
          assert.match(error.message, /Seed checksum mismatch/);
          assert.equal(error.checksumSource, 'seedSha256');
          return true;
        }
      );

      const installedPath = runtimeAssetService.getInstalledAssetPath('checksum.archive.seed');
      assert.equal(fs.existsSync(installedPath), false);
    } finally {
      ctx.restore();
    }
  });
});
