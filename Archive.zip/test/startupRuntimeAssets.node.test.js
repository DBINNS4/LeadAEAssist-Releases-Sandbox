'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const startupRuntimeAssets = require('../utils/startupRuntimeAssets');

function createImmediateSnapshot(overrides = {}) {
  return {
    ok: true,
    state: 'installed',
    active: false,
    installed: true,
    ready: true,
    ...overrides
  };
}

test('startup runtime asset bootstrap prepares chromium plus both whisper models sequentially', async () => {
  const calls = [];
  const bootstrap = startupRuntimeAssets.createStartupRuntimeAssetBootstrap({
    electron: {
      isPackaged: true,
      assets: {}
    },
    assetsApi: {
      prefetch() { return Promise.resolve(null); }
    },
    assetUi: {
      async startRuntimeAssetPrefetch(_assetsApi, request, options = {}) {
        calls.push({ request: { ...request }, languageLabel: options.languageLabel || null });

        if (request.feature === 'chromium') {
          return {
            immediate: true,
            snapshot: createImmediateSnapshot({
              assetId: 'chrome-1',
              feature: 'chromium'
            })
          };
        }

        if (request.feature === 'whisper' && request.language === 'en') {
          return {
            immediate: false,
            settled: false,
            lastProgressRatio: 0.5,
            promise: Promise.resolve(createImmediateSnapshot({
              assetId: 'whisper-en',
              feature: 'whisper',
              language: 'en'
            }))
          };
        }

        return {
          immediate: true,
          snapshot: createImmediateSnapshot({
            assetId: 'whisper-multi',
            feature: 'whisper',
            language: 'es'
          })
        };
      }
    }
  });

  assert.equal(bootstrap.shouldBlockFeature('chromium'), true);
  assert.equal(bootstrap.shouldBlockFeature('whisper'), true);

  const changes = [];
  const unsubscribe = bootstrap.onChange((snapshot) => changes.push(snapshot));
  const finalState = await bootstrap.start();
  unsubscribe();

  assert.deepEqual(
    calls.map(entry => entry.request),
    [
      { feature: 'chromium' },
      { feature: 'whisper', language: 'en' },
      { feature: 'whisper', language: 'es' }
    ]
  );

  assert.equal(finalState.finished, true);
  assert.equal(finalState.successful, true);
  assert.equal(finalState.overall.ready, true);
  assert.equal(finalState.features.chromium.ready, true);
  assert.equal(finalState.features.chromium.pending, false);
  assert.equal(finalState.features.whisper.ready, true);
  assert.equal(finalState.features.whisper.pending, false);
  assert.equal(finalState.features.whisper.languageLabel, 'All non-English languages');
  assert.equal(bootstrap.isFeatureReady('chromium'), true);
  assert.equal(bootstrap.isFeatureReady('whisper'), true);
  assert.equal(bootstrap.shouldBlockFeature('whisper'), false);
  assert.ok(changes.length >= 2);
});

test('startup runtime asset bootstrap continues after a feature download failure', async () => {
  const calls = [];
  const bootstrap = startupRuntimeAssets.createStartupRuntimeAssetBootstrap({
    electron: {
      isPackaged: true,
      assets: {}
    },
    assetsApi: {
      prefetch() { return Promise.resolve(null); }
    },
    assetUi: {
      async startRuntimeAssetPrefetch(_assetsApi, request) {
        calls.push({ ...request });

        if (request.feature === 'chromium') {
          const error = new Error('Browser dependency download failed.');
          error.code = 'ASSET_DOWNLOAD_FAILED';
          throw error;
        }

        return {
          immediate: true,
          snapshot: createImmediateSnapshot({
            assetId: `asset-${request.language}`,
            feature: 'whisper',
            language: request.language
          })
        };
      }
    }
  });

  const finalState = await bootstrap.start();

  assert.deepEqual(calls, [
    { feature: 'chromium' },
    { feature: 'whisper', language: 'en' },
    { feature: 'whisper', language: 'es' }
  ]);
  assert.equal(finalState.finished, true);
  assert.equal(finalState.successful, false);
  assert.equal(finalState.errorCount, 1);
  assert.equal(finalState.features.chromium.ready, false);
  assert.equal(finalState.features.chromium.pending, false);
  assert.equal(finalState.features.chromium.error.code, 'ASSET_DOWNLOAD_FAILED');
  assert.equal(finalState.features.whisper.ready, true);
});

test('installStartupRuntimeAssetBootstrap skips auto-enable in non-packaged windows', () => {
  const listeners = [];
  const fakeWindow = {
    location: { search: '' },
    document: {
      readyState: 'complete',
      addEventListener() {}
    },
    electron: {
      isPackaged: false,
      assets: {}
    },
    runtimeAssetUi: {
      startRuntimeAssetPrefetch() {
        throw new Error('should not run in non-packaged windows');
      }
    },
    dispatchEvent(evt) {
      listeners.push(evt?.detail || null);
    }
  };

  const bootstrap = startupRuntimeAssets.installStartupRuntimeAssetBootstrap({
    windowObj: fakeWindow,
    documentObj: fakeWindow.document,
    autoStart: false
  });

  assert.equal(bootstrap.getState().enabled, false);
  assert.equal(bootstrap.shouldBlockFeature('chromium'), false);
  assert.equal(bootstrap.shouldBlockFeature('whisper'), false);
  assert.equal(typeof fakeWindow.runtimeAssetBootstrap.getState, 'function');
  assert.equal(listeners.length, 0);
});


test('installStartupRuntimeAssetBootstrap auto-starts in packaged windows when runtime assets are enabled', async () => {
  const calls = [];
  const fakeWindow = {
    location: { search: '' },
    document: {
      readyState: 'complete',
      addEventListener() {
        throw new Error('DOMContentLoaded listener should not be required for a complete document');
      }
    },
    electron: {
      isPackaged: true,
      assets: {
        prefetch() {
          return Promise.resolve({ ok: true, installed: true, ready: true, active: false, state: 'installed' });
        }
      }
    },
    runtimeAssetUi: {
      async startRuntimeAssetPrefetch(_assetsApi, request) {
        calls.push({ ...request });
        return {
          immediate: true,
          snapshot: createImmediateSnapshot({
            feature: request.feature,
            language: request.language || null
          })
        };
      }
    },
    dispatchEvent() {}
  };

  const bootstrap = startupRuntimeAssets.installStartupRuntimeAssetBootstrap({
    windowObj: fakeWindow,
    documentObj: fakeWindow.document
  });

  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.equal(bootstrap.getState().enabled, true);
  assert.equal(bootstrap.getState().started, true);
  assert.equal(bootstrap.getState().finished, true);
  assert.equal(bootstrap.getState().successful, true);
  assert.deepEqual(calls, [
    { feature: 'chromium' },
    { feature: 'whisper', language: 'en' },
    { feature: 'whisper', language: 'es' }
  ]);
});
