const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const {
  loadRuntimeAssetsManifest,
  resolveManifestCandidatePaths
} = require('../utils/runtimeAssetsManifest');

function makeTempDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'leadae-runtime-manifest-'));
}

function writeJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

test('runtime assets manifest: packaged builds fall back to the bundled app config path when extraResources copy is absent', () => {
  const root = makeTempDir();
  const appRoot = path.join(root, 'LeadAEAssist.app', 'Contents', 'Resources', 'app.asar');
  const resourcesRoot = path.join(root, 'LeadAEAssist.app', 'Contents', 'Resources');
  const cwdRoot = path.join(root, 'cwd');

  writeJson(path.join(appRoot, 'config', 'runtime.assets.manifest.json'), {
    schemaVersion: 7,
    assets: {
      'asset.from.app.bundle': {
        type: 'file',
        installPath: 'example.bin'
      }
    }
  });
  fs.mkdirSync(resourcesRoot, { recursive: true });
  fs.mkdirSync(cwdRoot, { recursive: true });

  const manifest = loadRuntimeAssetsManifest({
    isPackaged: true,
    appRootOverride: appRoot,
    resourcesPathOverride: resourcesRoot,
    cwdOverride: cwdRoot
  });

  assert.equal(manifest.schemaVersion, 7);
  assert.ok(manifest.assets['asset.from.app.bundle']);
});

test('runtime assets manifest: packaged builds still prefer an extraResources/config copy when present', () => {
  const root = makeTempDir();
  const appRoot = path.join(root, 'LeadAEAssist.app', 'Contents', 'Resources', 'app.asar');
  const resourcesRoot = path.join(root, 'LeadAEAssist.app', 'Contents', 'Resources');

  writeJson(path.join(appRoot, 'config', 'runtime.assets.manifest.json'), {
    schemaVersion: 3,
    assets: {
      'asset.from.app.bundle': { type: 'file', installPath: 'from-app.bin' }
    }
  });
  writeJson(path.join(resourcesRoot, 'config', 'runtime.assets.manifest.json'), {
    schemaVersion: 9,
    assets: {
      'asset.from.resources': { type: 'file', installPath: 'from-resources.bin' }
    }
  });

  const manifest = loadRuntimeAssetsManifest({
    isPackaged: true,
    appRootOverride: appRoot,
    resourcesPathOverride: resourcesRoot,
    cwdOverride: root
  });

  assert.equal(manifest.schemaVersion, 9);
  assert.ok(manifest.assets['asset.from.resources']);
  assert.equal(manifest.assets['asset.from.app.bundle'], undefined);
});

test('runtime assets manifest: candidate order includes extraResources first, then app bundle fallback', () => {
  const candidates = resolveManifestCandidatePaths({
    isPackaged: true,
    resourcesPathOverride: '/tmp/resources',
    appRootOverride: '/tmp/app.asar',
    cwdOverride: '/tmp/cwd'
  });

  assert.deepEqual(candidates, [
    path.join('/tmp/resources', 'config', 'runtime.assets.manifest.json'),
    path.join('/tmp/resources', 'runtime.assets.manifest.json'),
    path.join('/tmp/app.asar', 'config', 'runtime.assets.manifest.json'),
    path.join('/tmp/cwd', 'config', 'runtime.assets.manifest.json')
  ]);
});
