/** @jest-environment node */

jest.mock('../utils/trustedIpcSender', () => ({
  assertTrustedIpcSender: jest.fn()
}));

const mockWriteState = jest.fn(() => ({ ok: true }));
const mockReadState = jest.fn(() => ({ preferences: {} }));

jest.mock('../utils/state', () => ({
  readState: () => mockReadState(),
  writeState: (...args) => mockWriteState(...args)
}));

const registerPrefsHandlers = require('../ipc/prefs.handlers');

function buildIpcMain() {
  const handlers = new Map();
  const listeners = new Map();
  return {
    handlers,
    listeners,
    ipcMain: {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn)),
      on: jest.fn((channel, fn) => listeners.set(channel, fn))
    }
  };
}

describe('prefs handlers payload validation', () => {
  beforeEach(() => {
    mockReadState.mockReset();
    mockWriteState.mockReset();
    mockReadState.mockReturnValue({ preferences: {} });
    mockWriteState.mockReturnValue({ ok: true });
  });

  test('rejects invalid theme enum in prefs:set-preferences', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    const result = await handlers.get('prefs:set-preferences')({ sender: { id: 1 } }, {
      preferences: { theme: 'blue' }
    });

    expect(result.ok).toBe(false);
    expect(result.code).toBe('PREFS_INVALID_THEME');
    expect(result.params).toEqual(expect.objectContaining({ allowed: expect.any(String) }));
    expect(mockWriteState).not.toHaveBeenCalled();
  });

  test('rejects non-boolean crashReporting in prefs:set-preferences', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    const result = await handlers.get('prefs:set-preferences')({ sender: { id: 1 } }, {
      preferences: { crashReporting: 'yes' }
    });

    expect(result.ok).toBe(false);
    expect(result.code).toBe('PREFS_VALUE_TYPE_BOOLEAN');
    expect(mockWriteState).not.toHaveBeenCalled();
  });

  test('rejects out-of-range tempMaxAgeDays in prefs:set-preferences', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    const result = await handlers.get('prefs:set-preferences')({ sender: { id: 1 } }, {
      preferences: { tempMaxAgeDays: 5000 }
    });

    expect(result.ok).toBe(false);
    expect(result.code).toBe('PREFS_TEMP_MAX_AGE_OUT_OF_RANGE');
    expect(result.params).toEqual({ min: 0, max: 3650 });
    expect(mockWriteState).not.toHaveBeenCalled();
  });

  test('ignores unsupported preference keys in prefs:set-preferences while applying known keys', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    const result = await handlers.get('prefs:set-preferences')({ sender: { id: 1 } }, {
      preferences: { unknownSetting: true, theme: 'dark' }
    });

    expect(result).toEqual({
      ok: true,
      preferences: { theme: 'dark' }
    });
    expect(mockWriteState).toHaveBeenCalledTimes(1);
    expect(mockWriteState).toHaveBeenCalledWith({ preferences: { theme: 'dark' } });
  });

  test('rejects invalid webhook URL in prefs:set-preferences', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    const result = await handlers.get('prefs:set-preferences')({ sender: { id: 1 } }, {
      preferences: { webhookUrl: 'ftp://example.com/hook' }
    });

    expect(result.ok).toBe(false);
    expect(result.code).toBe('PREFS_INVALID_WEBHOOK_URL');
    expect(mockWriteState).not.toHaveBeenCalled();
  });

  test('accepts empty webhook URL in prefs:set-preferences', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    const result = await handlers.get('prefs:set-preferences')({ sender: { id: 1 } }, {
      preferences: { webhookUrl: '' }
    });

    expect(result.ok).toBe(true);
    expect(mockWriteState).toHaveBeenCalled();
  });

  test('returns sanitized preferences from prefs:get-preferences', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    mockReadState.mockReturnValue({
      preferences: {
        theme: 'dark',
        language: 'en',
        crashReporting: true,
        tempMaxAgeDays: 30
      }
    });

    const result = await handlers.get('prefs:get-preferences')({ sender: { id: 1 } });
    expect(result).toEqual({
      ok: true,
      preferences: {
        theme: 'dark',
        language: 'en',
        crashReporting: true,
        tempMaxAgeDays: 30
      }
    });
  });

  test('prefs:get-preferences drops unknown legacy keys and rewrites cleaned preferences', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    mockReadState.mockReturnValue({
      preferences: {
        theme: 'dark',
        language: 'en',
        fontBody: 'Inter',
        fontHeadings: 'Inter Tight',
        aiModel: 'gpt-4',
        dualEngine: true
      },
      license: { tier: 'pro' }
    });

    const result = await handlers.get('prefs:get-preferences')({ sender: { id: 1 } });

    expect(result).toEqual({
      ok: true,
      preferences: {
        theme: 'dark',
        language: 'en'
      }
    });

    expect(mockWriteState).toHaveBeenCalledTimes(1);
    expect(mockWriteState).toHaveBeenCalledWith({
      preferences: {
        theme: 'dark',
        language: 'en'
      },
      license: { tier: 'pro' }
    });
  });

  test('prefs:get-preferences succeeds when one unknown key exists alongside valid known keys', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerPrefsHandlers(ipcMain);

    mockReadState.mockReturnValue({
      preferences: {
        theme: 'light',
        crashReporting: false,
        legacyUnknownKey: 'ignore-me'
      }
    });

    const result = await handlers.get('prefs:get-preferences')({ sender: { id: 1 } });

    expect(result).toEqual({
      ok: true,
      preferences: {
        theme: 'light',
        crashReporting: false
      }
    });
  });
});
