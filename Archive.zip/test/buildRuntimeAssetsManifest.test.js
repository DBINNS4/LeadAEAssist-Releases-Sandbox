const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const {
  buildRuntimeAssetsManifest,
  resolveRuntimeAssetsBaseUrl,
  resolveAssetSourcePath,
  isChromiumRuntimeAssetDescriptor
} = require('../scripts/build-runtime-assets-manifest');

function makeTempDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'leadae-build-runtime-assets-'));
}

function writeJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

test('build runtime assets manifest stages assets, updates packaged checksums, and writes release manifest URLs', () => {
  const projectRoot = makeTempDir();
  const configDir = path.join(projectRoot, 'config');
  const whisperDir = path.join(projectRoot, 'whisper.cpp', 'models');
  const chromeRoot = path.join(projectRoot, 'vendor', 'puppeteer', 'chrome');
  const chromeEntrypoint = path.join(
    path.dirname(chromeRoot),
    'chrome',
    'mac_arm-127.0.6533.88',
    'chrome-mac-arm64',
    'Google Chrome for Testing.app',
    'Contents',
    'MacOS',
    'Google Chrome for Testing'
  );

  fs.mkdirSync(whisperDir, { recursive: true });
  fs.mkdirSync(path.dirname(chromeEntrypoint), { recursive: true });
  fs.writeFileSync(path.join(whisperDir, 'ggml-base.en.bin'), 'english-model', 'utf8');
  fs.writeFileSync(path.join(whisperDir, 'ggml-base.bin'), 'multi-model', 'utf8');
  fs.writeFileSync(chromeEntrypoint, '#!/bin/sh\nexit 0\n', { mode: 0o755 });

  writeJson(path.join(projectRoot, 'package.json'), { name: 'lead-ae-assist', version: '1.2.3' });
  writeJson(path.join(configDir, 'public.runtime.selected.json'), {
    assets: {
      baseUrl: 'https://github.com/DBINNS4/LeadAEAssist-Releases-Sandbox/releases/download/v{{APP_VERSION}}'
    }
  });
  writeJson(path.join(configDir, 'runtime.assets.manifest.json'), {
    schemaVersion: 1,
    assets: {
      'whisper.model.base.en': {
        type: 'file',
        installPath: 'whisper/models/ggml-base.en.bin',
        relativeUrl: 'ggml-base.en.bin',
        downloadUrl: null,
        sha256: null,
        size: null
      },
      'whisper.model.base.multi': {
        type: 'file',
        installPath: 'whisper/models/ggml-base.bin',
        relativeUrl: 'ggml-base.bin',
        downloadUrl: null,
        sha256: null,
        size: null
      },
      'puppeteer.cache.darwin.arm64': {
        type: 'archive',
        archiveFormat: 'zip',
        installDir: 'puppeteer/cache/chrome-127.0.6533.88/darwin-arm64',
        relativeUrl: 'chromium-mac-arm64-127.0.6533.88.zip',
        entrypoint: 'chrome/mac_arm-127.0.6533.88/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',
        downloadUrl: null,
        sha256: null,
        seedSha256: null,
        size: null
      }
    }
  });

  const result = buildRuntimeAssetsManifest({ projectRoot });

  assert.equal(result.version, '1.2.3');
  assert.equal(result.releaseTarget.provider, 'github');
  assert.equal(result.releaseTarget.owner, 'DBINNS4');
  assert.equal(result.releaseTarget.repo, 'LeadAEAssist-Releases-Sandbox');
  assert.equal(result.releaseTarget.tag, 'v1.2.3');
  assert.equal(result.stagedAssets.length, 3);

  const packagedManifest = JSON.parse(fs.readFileSync(path.join(configDir, 'runtime.assets.manifest.json'), 'utf8'));
  assert.equal(packagedManifest.assets['whisper.model.base.en'].downloadUrl, null);
  assert.match(packagedManifest.assets['whisper.model.base.en'].sha256, /^[a-f0-9]{64}$/);
  assert.match(packagedManifest.assets['puppeteer.cache.darwin.arm64'].seedSha256, /^[a-f0-9]{64}$/);
  assert.ok(packagedManifest.assets['puppeteer.cache.darwin.arm64'].size > 0);

  const releaseManifestPath = path.join(projectRoot, 'release', 'runtime-assets', 'runtime.assets.manifest.json');
  const releaseManifest = JSON.parse(fs.readFileSync(releaseManifestPath, 'utf8'));
  assert.equal(releaseManifest.appVersion, '1.2.3');
  assert.equal(releaseManifest.release.owner, 'DBINNS4');
  assert.equal(releaseManifest.release.repo, 'LeadAEAssist-Releases-Sandbox');
  assert.equal(releaseManifest.release.tag, 'v1.2.3');
  assert.equal(
    releaseManifest.assets['whisper.model.base.en'].downloadUrl,
    'https://github.com/DBINNS4/LeadAEAssist-Releases-Sandbox/releases/download/v1.2.3/ggml-base.en.bin'
  );
  assert.equal(
    releaseManifest.assets['puppeteer.cache.darwin.arm64'].downloadUrl,
    'https://github.com/DBINNS4/LeadAEAssist-Releases-Sandbox/releases/download/v1.2.3/chromium-mac-arm64-127.0.6533.88.zip'
  );
  assert.match(releaseManifest.assets['puppeteer.cache.darwin.arm64'].seedSha256, /^[a-f0-9]{64}$/);

  assert.equal(fs.existsSync(path.join(projectRoot, 'release', 'runtime-assets', 'ggml-base.en.bin')), true);
  assert.equal(fs.existsSync(path.join(projectRoot, 'release', 'runtime-assets', 'ggml-base.bin')), true);
  assert.equal(fs.existsSync(path.join(projectRoot, 'release', 'runtime-assets', 'chromium-mac-arm64-127.0.6533.88.zip')), true);
});

test('resolveRuntimeAssetsBaseUrl prefers selected runtime config and templates app version later', () => {
  const projectRoot = makeTempDir();
  writeJson(path.join(projectRoot, 'config', 'public.runtime.selected.json'), {
    assets: {
      baseUrl: 'https://github.com/DBINNS4/LeadAEAssist-Releases/releases/download/v{{APP_VERSION}}'
    }
  });

  const baseUrl = resolveRuntimeAssetsBaseUrl(projectRoot, {});
  assert.equal(baseUrl, 'https://github.com/DBINNS4/LeadAEAssist-Releases/releases/download/v{{APP_VERSION}}');
});


test('build runtime assets manifest rejects nested relativeUrl values for GitHub Releases', () => {
  const projectRoot = makeTempDir();
  const configDir = path.join(projectRoot, 'config');
  const whisperDir = path.join(projectRoot, 'whisper.cpp', 'models');
  fs.mkdirSync(whisperDir, { recursive: true });
  fs.writeFileSync(path.join(whisperDir, 'ggml-base.en.bin'), 'english-model', 'utf8');

  writeJson(path.join(projectRoot, 'package.json'), { name: 'lead-ae-assist', version: '1.2.3' });
  writeJson(path.join(configDir, 'public.runtime.selected.json'), {
    assets: {
      baseUrl: 'https://github.com/DBINNS4/LeadAEAssist-Releases/releases/download/v{{APP_VERSION}}'
    }
  });
  writeJson(path.join(configDir, 'runtime.assets.manifest.json'), {
    schemaVersion: 1,
    assets: {
      'whisper.model.base.en': {
        type: 'file',
        installPath: 'whisper/models/ggml-base.en.bin',
        relativeUrl: 'whisper/ggml-base.en.bin',
        downloadUrl: null,
        sha256: null,
        size: null
      }
    }
  });

  assert.throws(
    () => buildRuntimeAssetsManifest({ projectRoot }),
    /GitHub release assets must use flat filenames/
  );
});



test('resolveAssetSourcePath prefers LEADAE_CHROMIUM_STAGE_DIR for Chromium assets', () => {
  const projectRoot = makeTempDir();
  const customChromeRoot = path.join(projectRoot, 'custom-chrome-root');
  fs.mkdirSync(customChromeRoot, { recursive: true });

  const prevNew = process.env.LEADAE_CHROMIUM_STAGE_DIR;
  const prevLegacy = process.env.LEADAE_PUPPETEER_CHROME_DIR;
  process.env.LEADAE_CHROMIUM_STAGE_DIR = customChromeRoot;
  process.env.LEADAE_PUPPETEER_CHROME_DIR = path.join(projectRoot, 'legacy-override');

  try {
    const resolved = resolveAssetSourcePath(projectRoot, 'puppeteer.cache.darwin.arm64', {
      type: 'archive',
      installDir: 'puppeteer/cache/chrome-127.0.6533.88/darwin-arm64',
      relativeUrl: 'chromium-mac-arm64-127.0.6533.88.zip',
      entrypoint: 'chrome/mac_arm-127.0.6533.88/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
    });

    assert.equal(resolved, customChromeRoot);
    assert.equal(isChromiumRuntimeAssetDescriptor({
      type: 'archive',
      relativeUrl: 'chromium-mac-arm64-127.0.6533.88.zip',
      entrypoint: 'chrome/mac_arm-127.0.6533.88/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
    }), true);
  } finally {
    if (typeof prevNew === 'string') process.env.LEADAE_CHROMIUM_STAGE_DIR = prevNew;
    else delete process.env.LEADAE_CHROMIUM_STAGE_DIR;
    if (typeof prevLegacy === 'string') process.env.LEADAE_PUPPETEER_CHROME_DIR = prevLegacy;
    else delete process.env.LEADAE_PUPPETEER_CHROME_DIR;
  }
});
