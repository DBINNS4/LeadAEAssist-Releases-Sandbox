const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const runtimeAssetService = require('../services/runtimeAssetService');
const { sha256DirectoryTreeHex } = require('../utils/runtimeAssetIntegrity');
const {
  setupRuntimeAssetTest,
  writeFile,
  sha256Hex
} = require('./helpers/runtimeAssetTestUtils');

function buildLegacyChromiumTree(rootDir) {
  const binaryPath = path.join(
    rootDir,
    'chrome',
    'mac_arm-127.0.6533.88',
    'chrome-mac-arm64',
    'Google Chrome for Testing.app',
    'Contents',
    'MacOS',
    'Google Chrome for Testing'
  );

  writeFile(binaryPath, '#!/bin/sh\nexit 0\n');

  const supportFile = path.join(rootDir, 'chrome', 'support', 'payload.txt');
  writeFile(supportFile, 'chromium support payload\n');

  const symlinkPath = path.join(rootDir, 'chrome', 'support', 'payload-link.txt');
  let symlinkCreated = false;
  try {
    fs.symlinkSync('payload.txt', symlinkPath);
    symlinkCreated = true;
  } catch {
    symlinkCreated = false;
  }

  return {
    binaryPath,
    symlinkCreated,
    symlinkPath
  };
}

test('runtime asset service: bundled seeding path', async (t) => {
  await t.test('seeds a bundled file asset into userData/assets and records installed state', async () => {
    const seedPayload = Buffer.from('seeded from bundled resource\n', 'utf8');
    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'seed.file': {
          type: 'file',
          installPath: 'whisper/models/ggml-base.en.bin',
          seedPaths: ['legacy/ggml-base.en.bin'],
          sha256: sha256Hex(seedPayload)
        }
      }
    });

    try {
      writeFile(path.join(ctx.root, 'legacy', 'ggml-base.en.bin'), seedPayload);

      const events = [];
      const installed = await runtimeAssetService.ensureAsset('seed.file', {
        onProgress(event) {
          events.push({ phase: event.phase, status: event.status, source: event.source || null });
        }
      });

      assert.equal(installed.source, 'seed');
      assert.equal(fs.readFileSync(installed.path, 'utf8'), seedPayload.toString('utf8'));
      assert.ok(events.some(event => event.phase === 'seed' && event.status === 'start'));
      assert.ok(events.some(event => event.phase === 'verify' && event.status === 'complete'));
      assert.ok(events.some(event => event.phase === 'install' && event.status === 'complete' && event.source === 'seed'));
      assert.ok(events.some(event => event.phase === 'complete' && event.status === 'complete' && event.source === 'seed'));

      const state = runtimeAssetService.readInstalledState();
      assert.equal(state.installed['seed.file'].source, 'seed');
      assert.equal(state.installed['seed.file'].path, installed.path);
      assert.equal(state.installed['seed.file'].sha256, sha256Hex(seedPayload));
      assert.equal(state.installed['seed.file'].size, seedPayload.length);
      assert.ok(Number.isFinite(Number(state.installed['seed.file'].mtimeMs)));

      const reused = await runtimeAssetService.ensureAsset('seed.file');
      assert.equal(reused.source, 'installed');
      assert.equal(reused.path, installed.path);
    } finally {
      ctx.restore();
    }
  });

  await t.test('seeds an archive directory even when the manifest only has the download sha256', async () => {
    const legacyRoot = path.join('legacy', 'puppeteer');
    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'seed.archive.compat': {
          type: 'archive',
          archiveFormat: 'zip',
          installDir: 'puppeteer/cache/chrome-127.0.6533.88/darwin-arm64',
          seedPaths: [legacyRoot],
          sha256: sha256Hex(Buffer.from('download archive bytes', 'utf8')),
          entrypoint: 'chrome/mac_arm-127.0.6533.88/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
        }
      }
    });

    try {
      const legacyAssetRoot = path.join(ctx.root, legacyRoot);
      buildLegacyChromiumTree(legacyAssetRoot);

      const events = [];
      const installed = await runtimeAssetService.ensureAsset('seed.archive.compat', {
        onProgress(event) {
          events.push({
            phase: event.phase,
            status: event.status,
            source: event.source || null,
            reason: event.reason || null
          });
        }
      });

      const installedBinary = path.join(
        installed.path,
        'chrome',
        'mac_arm-127.0.6533.88',
        'chrome-mac-arm64',
        'Google Chrome for Testing.app',
        'Contents',
        'MacOS',
        'Google Chrome for Testing'
      );

      assert.equal(installed.source, 'seed');
      assert.equal(fs.existsSync(installedBinary), true);
      assert.ok(events.some(event => event.phase === 'verify' && event.status === 'skipped'));
      assert.ok(events.some(event => event.reason === 'archive-directory-seed-has-only-download-sha256'));
      assert.ok(events.some(event => event.phase === 'complete' && event.status === 'complete' && event.source === 'seed'));
    } finally {
      ctx.restore();
    }
  });

  await t.test('verifies archive directory seeds with seedSha256 and preserves symlinks', async () => {
    const legacyRoot = path.join('legacy', 'puppeteer');
    const ctx = setupRuntimeAssetTest(runtimeAssetService, {
      schemaVersion: 1,
      assets: {
        'seed.archive.verified': {
          type: 'archive',
          archiveFormat: 'zip',
          installDir: 'puppeteer/cache/chrome-127.0.6533.88/darwin-arm64',
          seedPaths: [legacyRoot],
          sha256: sha256Hex(Buffer.from('download archive bytes', 'utf8')),
          seedSha256: null,
          entrypoint: 'chrome/mac_arm-127.0.6533.88/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
        }
      }
    });

    try {
      const legacyAbsoluteRoot = path.join(ctx.root, legacyRoot);
      const tree = buildLegacyChromiumTree(legacyAbsoluteRoot);
      const seedSha256 = sha256DirectoryTreeHex(legacyAbsoluteRoot);
      const manifest = JSON.parse(fs.readFileSync(ctx.manifestPath, 'utf8'));
      manifest.assets['seed.archive.verified'].seedSha256 = seedSha256;
      fs.writeFileSync(ctx.manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
      runtimeAssetService.__private?.resetForTests?.();

      const events = [];
      const installed = await runtimeAssetService.ensureAsset('seed.archive.verified', {
        onProgress(event) {
          events.push({
            phase: event.phase,
            status: event.status,
            source: event.source || null,
            checksumSource: event.checksumSource || null
          });
        }
      });

      const installedBinary = path.join(
        installed.path,
        'chrome',
        'mac_arm-127.0.6533.88',
        'chrome-mac-arm64',
        'Google Chrome for Testing.app',
        'Contents',
        'MacOS',
        'Google Chrome for Testing'
      );

      assert.equal(installed.source, 'seed');
      assert.equal(fs.existsSync(installedBinary), true);
      assert.ok(events.some(event => event.phase === 'verify' && event.status === 'complete' && event.checksumSource === 'seedSha256'));

      if (tree.symlinkCreated) {
        const installedSymlinkPath = path.join(installed.path, 'chrome', 'support', 'payload-link.txt');
        const installedSymlinkStats = fs.lstatSync(installedSymlinkPath);
        assert.equal(installedSymlinkStats.isSymbolicLink(), true);
        assert.equal(path.basename(fs.readlinkSync(installedSymlinkPath)), 'payload.txt');
      }
    } finally {
      ctx.restore();
    }
  });
});
