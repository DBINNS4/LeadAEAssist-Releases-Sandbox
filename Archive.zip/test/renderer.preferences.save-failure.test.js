const flushPromises = () => new Promise(resolve => setImmediate(resolve));

function buildPreferencesDOM() {
  document.body.innerHTML = `
    <div id="preferences" class="panel-section">
      <input type="checkbox" id="system-notifications" />
      <input type="checkbox" id="offline-mode" />
      <input type="checkbox" id="crash-reporting" checked />
      <div id="cep-panel-status"></div>
      <div id="cep-panel-error" hidden></div>
      <button id="cep-install-panel"></button>
      <button id="cep-uninstall-panel"></button>
      <button id="cep-open-folder"></button>
      <select id="language-select"><option value="en" selected>en</option></select>
      <input id="ai-api-key" />
      <input id="webhook-url" />
      <div id="webhook-url-error" hidden></div>
      <input type="checkbox" id="webhook-logging" />
      <input type="checkbox" id="webhook-only-fail" />
      <span id="temp-folder-path"></span>
      <div id="maintenance-status"></div>
      <button id="open-temp-folder"></button>
      <button id="clear-temp-now"></button>
      <button id="clear-cache-now"></button>
      <input type="checkbox" id="clear-temp-on-startup" />
      <input type="checkbox" id="clear-cache-on-startup" />
      <input type="number" id="temp-max-age-days" value="7" />
      <input type="checkbox" id="auto-update-check-on-launch" checked />
      <input type="checkbox" id="auto-update-auto-download" checked />
      <button id="check-updates-now"></button>
      <button id="download-update-now"></button>
      <button id="install-update-now"></button>
      <div id="update-status-text"></div>
      <progress id="update-download-progress" max="100" value="0"></progress>
      <button id="reset-preferences"></button>
      <span id="app-version"></span>
      <select id="theme-select"><option value="light" selected>Light</option><option value="dark">Dark</option></select>
      <input type="checkbox" id="theme-toggle" checked />
      <div id="preferences-save-error" hidden></div>
      <div id="prefs-toast"></div>
      <div id="preferences-overview-tooltip"></div>
    </div>
  `;
}

describe('renderer.preferences save failure handling', () => {
  let confirmResult = true;

  beforeEach(() => {
    jest.resetModules();
    ipc.invoke.mockReset();
    ipc.on.mockReset();
    window.electron.secrets.hasAiApiKey.mockReset();
    window.electron.secrets.setAiApiKey.mockReset();
    window.electron.secrets.deleteAiApiKey.mockReset();
    confirmResult = true;

    global.setupStyledDropdown = jest.fn();

    ipc.invoke.mockImplementation(async channel => {
      if (channel === 'app:get-version') return '0.0.0-test';
      if (channel === 'secure-store:has-ai-api-key') return false;
      if (channel === 'telemetry:set-enabled') return { ok: true };
      if (channel === 'prefs:get-preferences') return { ok: true, preferences: { crashReporting: true } };
      if (channel === 'prefs:set-preferences') return { ok: true, preferences: { crashReporting: true } };
      if (channel === 'show-confirm-dialog') return confirmResult;
      return undefined;
    });

    buildPreferencesDOM();

    window.electron.secrets.hasAiApiKey.mockResolvedValue(false);
    window.electron.secrets.setAiApiKey.mockResolvedValue({ ok: true });
    window.electron.secrets.deleteAiApiKey.mockResolvedValue({ ok: true });

    window.preferences = {
      get: jest.fn(async () => ({ ok: true, preferences: { crashReporting: true } })),
      set: jest.fn(async payload => ({ ok: true, preferences: payload.preferences }))
    };

    window.electron.resolvePath = jest.fn(() => '/mocked/path/config/state.json');
    window.electron.fileExistsAsync = jest.fn(async () => true);
    window.electron.readTextFileAsync = jest.fn(async () => JSON.stringify({ preferences: { crashReporting: true } }));
    window.electron.writeTextFileAtomicAsync = jest.fn(async () => undefined);
    window.rendererDialogs = undefined;
  });


  test('treats recoverable load mismatch as non-dirty warning state', async () => {
    window.preferences.get.mockResolvedValueOnce({
      ok: false,
      recoverable: true,
      code: 'PREFS_SCHEMA_UNSUPPORTED_LEGACY_KEYS',
      error: 'Unsupported legacy keys were ignored while loading preferences.'
    });

    require('../renderer.preferences.js');
    await flushPromises();

    const panel = document.getElementById('preferences');
    const saveError = document.getElementById('preferences-save-error');
    const toast = document.getElementById('prefs-toast');

    expect(panel.classList.contains('has-unsaved-changes')).toBe(false);
    expect(saveError.hidden).toBe(false);
    expect(saveError.textContent).toContain('Unsupported legacy keys were ignored');
    expect(toast.classList.contains('show')).toBe(true);
    expect(toast.classList.contains('toast-error')).toBe(false);
  });
  test('shows persistent error and leaves unsaved marker when crash runtime updated but IPC save rejects', async () => {
    window.preferences.set.mockResolvedValueOnce({
      ok: false,
      error: 'PREFS_TEMP_MAX_AGE_OUT_OF_RANGE',
      code: 'PREFS_TEMP_MAX_AGE_OUT_OF_RANGE',
      params: { min: 0, max: 3650 }
    });

    require('../renderer.preferences.js');
    await flushPromises();

    const crash = document.getElementById('crash-reporting');
    crash.checked = false;
    crash.dispatchEvent(new Event('change', { bubbles: true }));
    await flushPromises();
    await flushPromises();

    const panel = document.getElementById('preferences');
    const saveError = document.getElementById('preferences-save-error');
    const toast = document.getElementById('prefs-toast');

    expect(window.preferences.set).toHaveBeenCalled();
    expect(ipc.invoke).not.toHaveBeenCalledWith('prefs:set-preferences', expect.anything());
    expect(window.electron.writeTextFileAtomicAsync).not.toHaveBeenCalled();
    expect(ipc.invoke).toHaveBeenCalledWith('telemetry:set-enabled', { enabled: false, persist: false });
    expect(panel.classList.contains('has-unsaved-changes')).toBe(true);
    expect(saveError.hidden).toBe(false);
    expect(saveError.textContent).toContain('between 0 and 3650');
    expect(saveError.textContent).toContain('session only');
    expect(toast.classList.contains('show')).toBe(true);
  });

  test('surfaces crash reporting runtime IPC failure and skips preferences save writes', async () => {
    ipc.invoke.mockImplementation(async channel => {
      if (channel === 'app:get-version') return '0.0.0-test';
      if (channel === 'secure-store:has-ai-api-key') return false;
      if (channel === 'telemetry:set-enabled') return { ok: false, error: 'telemetry disabled by policy' };
      return undefined;
    });

    require('../renderer.preferences.js');
    await flushPromises();

    const crash = document.getElementById('crash-reporting');
    crash.checked = false;
    crash.dispatchEvent(new Event('change', { bubbles: true }));
    await flushPromises();
    await flushPromises();

    const panel = document.getElementById('preferences');
    const saveError = document.getElementById('preferences-save-error');

    expect(ipc.invoke).toHaveBeenCalledWith('telemetry:set-enabled', { enabled: false, persist: false });
    expect(window.preferences.set).not.toHaveBeenCalled();
    expect(ipc.invoke).not.toHaveBeenCalledWith('prefs:set-preferences', expect.anything());
    expect(window.electron.writeTextFileAtomicAsync).not.toHaveBeenCalled();
    expect(panel.classList.contains('has-unsaved-changes')).toBe(true);
    expect(saveError.hidden).toBe(false);
    expect(saveError.textContent).toContain('telemetry disabled by policy');
  });


  test('reset surfaces save failure as persistent error toast and suppresses success copy', async () => {
    window.preferences.set.mockResolvedValueOnce({ ok: false, error: 'disk full' });

    require('../renderer.preferences.js');
    await flushPromises();

    const resetButton = document.getElementById('reset-preferences');
    resetButton.dispatchEvent(new Event('click', { bubbles: true }));
    await flushPromises();
    await flushPromises();

    const panel = document.getElementById('preferences');
    const saveError = document.getElementById('preferences-save-error');
    const toast = document.getElementById('prefs-toast');

    expect(window.preferences.set).toHaveBeenCalled();
    expect(ipc.invoke).toHaveBeenCalledWith('show-confirm-dialog', expect.any(Object));
    expect(panel.classList.contains('has-unsaved-changes')).toBe(true);
    expect(saveError.hidden).toBe(false);
    expect(saveError.textContent).toContain('disk full');
    expect(toast.classList.contains('show')).toBe(true);
    expect(toast.classList.contains('toast-error')).toBe(true);
    expect(toast.textContent).toContain('disk full');
    expect(toast.textContent).not.toContain('Preferences reset');
    expect(ipc.invoke).not.toHaveBeenCalledWith('telemetry:set-enabled', { enabled: true, persist: false });
  });

  test('reset restores canonical auto update check default and shows success toast when preferences persist', async () => {
    require('../renderer.preferences.js');
    await flushPromises();

    const panel = document.getElementById('preferences');
    const saveError = document.getElementById('preferences-save-error');
    const toast = document.getElementById('prefs-toast');
    const autoUpdateCheckOnLaunch = document.getElementById('auto-update-check-on-launch');

    panel.classList.add('has-unsaved-changes');
    saveError.hidden = false;
    saveError.textContent = 'old unsaved message';
    autoUpdateCheckOnLaunch.checked = false;

    const resetButton = document.getElementById('reset-preferences');
    resetButton.dispatchEvent(new Event('click', { bubbles: true }));
    await flushPromises();
    await flushPromises();

    expect(window.preferences.set).toHaveBeenCalled();
    expect(ipc.invoke).toHaveBeenCalledWith('show-confirm-dialog', expect.any(Object));
    expect(window.preferences.set).toHaveBeenCalledWith(
      expect.objectContaining({
        preferences: expect.objectContaining({ autoUpdateCheckOnLaunch: true })
      })
    );
    expect(autoUpdateCheckOnLaunch.checked).toBe(true);
    expect(panel.classList.contains('has-unsaved-changes')).toBe(false);
    expect(saveError.hidden).toBe(true);
    expect(saveError.textContent).toBe('');
    expect(toast.classList.contains('show')).toBe(true);
    expect(toast.classList.contains('toast-error')).toBe(false);
    expect(toast.textContent).toContain('Preferences reset');
    expect(ipc.invoke).toHaveBeenCalledWith('telemetry:set-enabled', { enabled: true, persist: false });
  });

  test('reset aborts without side effects when confirmation is canceled', async () => {
    confirmResult = false;

    require('../renderer.preferences.js');
    await flushPromises();

    const toast = document.getElementById('prefs-toast');
    const resetButton = document.getElementById('reset-preferences');
    resetButton.dispatchEvent(new Event('click', { bubbles: true }));
    await flushPromises();

    expect(ipc.invoke).toHaveBeenCalledWith('show-confirm-dialog', expect.any(Object));
    expect(window.preferences.set).not.toHaveBeenCalled();
    expect(window.electron.secrets.deleteAiApiKey).not.toHaveBeenCalled();
    expect(toast.classList.contains('show')).toBe(false);
    expect(toast.textContent).not.toContain('Preferences reset');
  });

  test('reset proceeds with existing behavior when confirmation is accepted', async () => {
    confirmResult = true;

    require('../renderer.preferences.js');
    await flushPromises();

    const toast = document.getElementById('prefs-toast');
    const resetButton = document.getElementById('reset-preferences');
    resetButton.dispatchEvent(new Event('click', { bubbles: true }));
    await flushPromises();
    await flushPromises();

    expect(ipc.invoke).toHaveBeenCalledWith('show-confirm-dialog', expect.any(Object));
    expect(window.preferences.set).toHaveBeenCalled();
    expect(window.electron.secrets.deleteAiApiKey).toHaveBeenCalled();
    expect(toast.classList.contains('show')).toBe(true);
    expect(toast.classList.contains('toast-error')).toBe(false);
    expect(toast.textContent).toContain('Preferences reset');
  });
  test('shows structured thrown IPC error message and does not fallback to file write', async () => {
    window.preferences.set.mockRejectedValueOnce(new Error('ipc unavailable'));

    require('../renderer.preferences.js');
    await flushPromises();

    const crash = document.getElementById('crash-reporting');
    crash.checked = false;
    crash.dispatchEvent(new Event('change', { bubbles: true }));
    await flushPromises();
    await flushPromises();

    const panel = document.getElementById('preferences');
    const saveError = document.getElementById('preferences-save-error');

    expect(window.preferences.set).toHaveBeenCalled();
    expect(ipc.invoke).not.toHaveBeenCalledWith('prefs:set-preferences', expect.anything());
    expect(window.electron.writeTextFileAtomicAsync).not.toHaveBeenCalled();
    expect(panel.classList.contains('has-unsaved-changes')).toBe(true);
    expect(saveError.hidden).toBe(false);
    expect(saveError.textContent).toContain('ipc unavailable');
  });


  test('does not write API key when validation fails before preferences save', async () => {
    require('../renderer.preferences.js');
    await flushPromises();

    const apiKeyInput = document.getElementById('ai-api-key');
    const webhookUrl = document.getElementById('webhook-url');

    apiKeyInput.value = 'sk-test-validation-block';
    apiKeyInput.dispatchEvent(new Event('input', { bubbles: true }));
    webhookUrl.value = 'not-a-valid-url';
    webhookUrl.dispatchEvent(new Event('change', { bubbles: true }));
    await flushPromises();

    expect(window.preferences.set).not.toHaveBeenCalled();
    expect(window.electron.secrets.setAiApiKey).not.toHaveBeenCalled();
    expect(window.electron.secrets.deleteAiApiKey).not.toHaveBeenCalled();
    expect(ipc.invoke).not.toHaveBeenCalledWith('secure-store:set-ai-api-key', expect.anything());
    expect(ipc.invoke).not.toHaveBeenCalledWith('secure-store:delete-ai-api-key');
  });

  test('does not write API key when preferences save fails', async () => {
    require('../renderer.preferences.js');
    await flushPromises();

    window.preferences.set.mockReset();
    window.preferences.set.mockResolvedValueOnce({ ok: false, error: 'prefs save failed before secure-store write' });

    const apiKeyInput = document.getElementById('ai-api-key');
    const webhookLog = document.getElementById('webhook-logging');

    apiKeyInput.value = 'sk-test-prefs-save-failure';
    apiKeyInput.dispatchEvent(new Event('input', { bubbles: true }));
    webhookLog.checked = true;
    webhookLog.dispatchEvent(new Event('change', { bubbles: true }));
    await flushPromises();
    await flushPromises();

    expect(window.preferences.set).toHaveBeenCalled();
    expect(window.electron.secrets.setAiApiKey).not.toHaveBeenCalled();
    expect(window.electron.secrets.deleteAiApiKey).not.toHaveBeenCalled();
    expect(ipc.invoke).not.toHaveBeenCalledWith('secure-store:set-ai-api-key', expect.anything());
    expect(ipc.invoke).not.toHaveBeenCalledWith('secure-store:delete-ai-api-key');
  });

  test('keeps unsaved error state when secure-store API key write fails after preferences save', async () => {
    require('../renderer.preferences.js');
    await flushPromises();

    window.preferences.set.mockReset();
    window.preferences.set.mockResolvedValueOnce({ ok: true, preferences: { crashReporting: true, webhookLogging: true } });
    window.electron.secrets.setAiApiKey.mockResolvedValueOnce({ ok: false, error: 'vault locked' });

    const apiKeyInput = document.getElementById('ai-api-key');

    apiKeyInput.value = 'sk-test-vault-locked';
    apiKeyInput.dispatchEvent(new Event('input', { bubbles: true }));
    apiKeyInput.dispatchEvent(new Event('blur', { bubbles: true }));
    await flushPromises();
    await flushPromises();

    const panel = document.getElementById('preferences');
    const saveError = document.getElementById('preferences-save-error');
    const toast = document.getElementById('prefs-toast');

    expect(window.preferences.set).toHaveBeenCalled();
    expect(window.electron.secrets.setAiApiKey).toHaveBeenCalledWith('sk-test-vault-locked');
    expect(panel.classList.contains('has-unsaved-changes')).toBe(true);
    expect(saveError.hidden).toBe(false);
    expect(saveError.textContent).toContain('Could not write the API key to secure storage.');
    expect(toast.classList.contains('show')).toBe(true);
    expect(toast.classList.contains('toast-error')).toBe(true);
  });

  test('persists exactly once for a single theme dropdown change', async () => {
    require('../renderer.preferences.js');
    await flushPromises();

    window.preferences.set.mockClear();

    const themeSelect = document.getElementById('theme-select');
    themeSelect.value = 'dark';
    themeSelect.dispatchEvent(new Event('change', { bubbles: true }));
    await flushPromises();
    await flushPromises();

    expect(window.preferences.set).toHaveBeenCalledTimes(1);
    expect(window.preferences.set).toHaveBeenCalledWith(
      expect.objectContaining({
        preferences: expect.objectContaining({ theme: 'dark' })
      })
    );
  });
});
