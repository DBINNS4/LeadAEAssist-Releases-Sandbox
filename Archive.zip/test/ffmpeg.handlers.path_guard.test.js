/** @jest-environment node */

jest.mock('../utils/trustedIpcSender', () => ({
  assertTrustedIpcSender: jest.fn()
}));

const mockRunFfmpeg = jest.fn(async () => ({ ok: true }));

jest.mock('../services/ffmpegService', () => ({
  runFfmpeg: (...args) => mockRunFfmpeg(...args),
  runFfprobe: jest.fn(),
  runFfprobeJson: jest.fn(),
  probeMedia: jest.fn(),
  getCapabilities: jest.fn(),
  getMuxerFormats: jest.fn()
}));

const mockIsPathAllowed = jest.fn(() => true);

jest.mock('../utils/fsAccessControl', () => ({
  isPathAllowed: (...args) => mockIsPathAllowed(...args)
}));

const registerFfmpegHandlers = require('../ipc/ffmpeg.handlers');

function getExecFfmpegHandler() {
  const handlers = new Map();
  registerFfmpegHandlers({
    handle: jest.fn((channel, fn) => handlers.set(channel, fn))
  });
  return handlers.get('exec-ffmpeg');
}

describe('exec-ffmpeg path guard coverage', () => {
  const event = { sender: { id: 42 } };

  beforeEach(() => {
    mockRunFfmpeg.mockClear();
    mockIsPathAllowed.mockReset();
    mockIsPathAllowed.mockImplementation(() => true);
  });

  test('validates repeated inputs, filter-file refs, and output paths', async () => {
    const execFfmpeg = getExecFfmpegHandler();

    await execFfmpeg(event, [
      '-i', 'file:///tmp/a.mov',
      '-i', '/tmp/b.mov',
      '-filter_complex_script', '/tmp/complex.graph',
      '-vf', "subtitles='/tmp/captions.srt'",
      '/tmp/out.mov'
    ]);

    expect(mockRunFfmpeg).toHaveBeenCalledTimes(1);
    expect(mockIsPathAllowed).toHaveBeenCalledWith(42, '/tmp/a.mov');
    expect(mockIsPathAllowed).toHaveBeenCalledWith(42, '/tmp/b.mov');
    expect(mockIsPathAllowed).toHaveBeenCalledWith(42, '/tmp/complex.graph');
    expect(mockIsPathAllowed).toHaveBeenCalledWith(42, '/tmp/captions.srt');
    expect(mockIsPathAllowed).toHaveBeenCalledWith(42, '/tmp/out.mov');
  });

  test('rejects unapproved path referenced from filtergraph', async () => {
    const execFfmpeg = getExecFfmpegHandler();
    mockIsPathAllowed.mockImplementation((_, p) => p !== '/tmp/bad.srt');

    await expect(execFfmpeg(event, [
      '-i', '/tmp/in.mov',
      '-vf', "subtitles='/tmp/bad.srt'",
      '/tmp/out.mov'
    ])).rejects.toThrow('path not approved');

    expect(mockRunFfmpeg).not.toHaveBeenCalled();
  });

  test('fails closed on ambiguous path-like filter tokens', async () => {
    const execFfmpeg = getExecFfmpegHandler();

    await expect(execFfmpeg(event, [
      '-i', '/tmp/in.mov',
      '-vf', 'drawtext=textfile=/tmp/ok.txt:foo=/tmp/sneaky.txt',
      '/tmp/out.mov'
    ])).rejects.toThrow('ambiguous path-like token');

    expect(mockRunFfmpeg).not.toHaveBeenCalled();
  });

  test('keeps network URI blocking in place', async () => {
    const execFfmpeg = getExecFfmpegHandler();

    await expect(execFfmpeg(event, ['-i', 'https://example.com/video.mp4', '/tmp/out.mov']))
      .rejects.toThrow('URI/protocol not allowed');

    expect(mockRunFfmpeg).not.toHaveBeenCalled();
  });
});
