const test = require('node:test');
const assert = require('node:assert/strict');

const { generateSRT } = require('../ai/srtWriter');

function parseSrtTimestampToMs(ts) {
  // HH:MM:SS,mmm
  const m = String(ts).trim().match(/^(\d{2}):(\d{2}):(\d{2}),(\d{3})$/);
  if (!m) throw new Error(`Bad SRT timestamp: ${ts}`);
  const hh = Number(m[1]);
  const mm = Number(m[2]);
  const ss = Number(m[3]);
  const ms = Number(m[4]);
  return (((hh * 60 + mm) * 60) + ss) * 1000 + ms;
}

function parseSrtCues(srt) {
  const body = String(srt).replace(/^\uFEFF/, '');
  const blocks = body.trim().split(/\n\s*\n/);
  const cues = [];
  for (const b of blocks) {
    const lines = b.split(/\n/);
    if (lines.length < 2) continue;
    const idx = Number(lines[0].trim());
    const m = lines[1].match(/^(.*?)\s+-->\s+(.*?)$/);
    assert.ok(m, `Missing timecode line: ${lines[1]}`);
    const startMs = parseSrtTimestampToMs(m[1].trim());
    const endMs = parseSrtTimestampToMs(m[2].trim());
    const text = lines.slice(2).join('\n');
    cues.push({ idx, startMs, endMs, text });
  }
  return cues;
}

test('SRT: layout splitting produces sequential, non-overlapping cues (strict timing)', () => {
  const segments = [
    {
      start: 10,
      end: 14,
      text: 'This is a deliberately long line that should wrap into multiple lines and then split into multiple cues when max lines per block is low.'
    }
  ];

  const srt = generateSRT(segments, {
    strictTiming: true,
    maxCharsPerLine: 24,
    maxLinesPerBlock: 2,
    formats: {
      srt: {
        preventOverlaps: true,
        allowTimeExtension: false
      }
    }
  });

  const cues = parseSrtCues(srt);
  assert.ok(cues.length >= 2, 'Expected multiple cues from layout splitting');
  for (let i = 1; i < cues.length; i++) {
    assert.ok(cues[i].startMs >= cues[i - 1].endMs, 'Cues should not overlap');
  }
});

test('SRT: min duration + CPS can extend end time into gaps (bounded by max end-extension)', () => {
  const segments = [
    {
      start: 0,
      end: 0.5,
      text: 'This is a lot of text for half a second.'
    },
    {
      start: 5,
      end: 6,
      text: 'Next cue later.'
    }
  ];

  const srt = generateSRT(segments, {
    maxCharsPerLine: 42,
    maxLinesPerBlock: 2,
    formats: {
      srt: {
        maxCps: 10,
        minDurationSeconds: 1.0,
        allowTimeExtension: true,
        maxEndExtensionSeconds: 1.5,
        preventOverlaps: true
      }
    }
  });

  const cues = parseSrtCues(srt);
  assert.equal(cues.length, 2);
  // Original end: 500ms. Max extension: +1500ms => 2000ms.
  assert.equal(cues[0].startMs, 0);
  assert.equal(cues[0].endMs, 2000);
  // Ensure it did not collide with next cue.
  assert.ok(cues[0].endMs <= cues[1].startMs);
});

test('SRT: output hygiene (UTF-8 BOM + CRLF)', () => {
  const segments = [{ start: 0, end: 1.2, text: 'Hello world.' }];
  const srt = generateSRT(segments, {
    formats: {
      srt: {
        utf8Bom: true,
        lineEnding: 'crlf'
      }
    }
  });

  assert.ok(srt.startsWith('\uFEFF'), 'Expected UTF-8 BOM prefix');
  assert.ok(srt.includes('\r\n'), 'Expected CRLF line endings');
});
