'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { segmentsToCueList } = require('../ai/normalizeTranscription');
const scc = require('../modules/sccEncoder');
const {
  ensureCueSchema,
  serializeCueV2,
  setOverride608Text
} = require('../utils/cueSchema');

test('Phase 1 cue schema: legacy compat608Text migrates into overrides["608"].text', () => {
  const cue = {
    id: 'cue_1',
    start: 1,
    end: 2,
    text: 'CANON',
    compat608Text: 'OVR'
  };

  ensureCueSchema(cue);
  assert.equal(cue.overrides && typeof cue.overrides === 'object', true);
  assert.equal(cue.overrides['608'].text, 'OVR');
  assert.ok(String(cue.overrides['608']._baseCanonicalTextFp || '').length > 0);
});

test('Phase 1 cue schema: staleness flag flips when canonical text changes after override set', () => {
  const cue = { id: 'cue_2', start: 0, end: 2, text: 'HELLO' };
  setOverride608Text(cue, 'HELLO');

  // Change canonical text after override authored.
  cue.text = 'HELLO THERE';
  const v2 = serializeCueV2(cue);
  assert.equal(v2.overrides['608'].overridePossiblyStale, true);
});

test('Phase 1: derive608CuesFromCanonical uses overrides["608"].text when compat608Text is absent', () => {
  const cue = {
    id: 1,
    start: 0,
    end: 2,
    text: 'THIS IS CANONICAL',
    overrides: {
      '608': { text: 'THIS IS OVERRIDE', breaks: null }
    }
  };

  const derived = scc.derive608CuesFromCanonical([cue], { maxCols: 32, maxLines: 2 });
  assert.equal(Array.isArray(derived), true);
  assert.equal(derived[0].text, 'THIS IS OVERRIDE');
});

test('Phase 1: segmentsToCueList preserves embedded canonical/overrides objects', () => {
  const segments = [{
    id: 'cue_3',
    canonical: { start: 5, end: 6, text: 'CANONICAL' },
    overrides: { '608': { text: 'OVR' } },
    start: 5,
    end: 6,
    text: 'CANONICAL'
  }];

  const cues = segmentsToCueList(segments, 29.97, true);
  assert.equal(cues.length, 1);
  assert.equal(cues[0].canonical && cues[0].canonical.text, 'CANONICAL');
  assert.equal(cues[0].overrides && cues[0].overrides['608'].text, 'OVR');
});
