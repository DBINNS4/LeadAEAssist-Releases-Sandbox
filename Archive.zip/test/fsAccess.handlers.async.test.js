/** @jest-environment node */

const os = require('os');
const fs = require('fs');
const path = require('path');

jest.mock('../utils/fsAccessControl', () => ({
  evaluatePathAccess: jest.fn(),
  isPathAllowed: jest.fn()
}));

jest.mock('../utils/trustedIpcSender', () => ({
  assertTrustedIpcSender: jest.fn()
}));

const { evaluatePathAccess, isPathAllowed } = require('../utils/fsAccessControl');
const { assertTrustedIpcSender } = require('../utils/trustedIpcSender');
const registerFsAccessHandlers = require('../ipc/fsAccess.handlers');

function buildIpcMain() {
  const handlers = new Map();
  const listeners = new Map();
  return {
    handlers,
    listeners,
    ipcMain: {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn)),
      on: jest.fn((channel, fn) => listeners.set(channel, fn))
    }
  };
}

describe('fsAccess async IPC handlers', () => {
  let tempRoot;
  let event;

  beforeEach(() => {
    tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'fs-access-async-'));
    event = { sender: { id: 321 }, senderFrame: { url: 'app://renderer' } };
    isPathAllowed.mockReset();
    evaluatePathAccess.mockReset();
    assertTrustedIpcSender.mockReset();
    evaluatePathAccess.mockImplementation((senderId, targetPath) => ({
      allowed: isPathAllowed(senderId, targetPath),
      reason: 'not_approved',
    }));
  });

  afterEach(() => {
    fs.rmSync(tempRoot, { recursive: true, force: true });
  });

  test('denies async fs:readdir when path is not approved', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerFsAccessHandlers(ipcMain);

    isPathAllowed.mockReturnValue(false);

    await expect(handlers.get('fs:readdir')(event, tempRoot, {})).rejects.toThrow('permission_denied');
    expect(assertTrustedIpcSender).toHaveBeenCalledWith(event, 'fs:readdir');
    expect(isPathAllowed).toHaveBeenCalledWith(321, tempRoot);
  });

  test('denies async fs:readTextFile from untrusted sender before path checks', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerFsAccessHandlers(ipcMain);

    assertTrustedIpcSender.mockImplementation(() => {
      const err = new Error('Blocked fs:readTextFile from untrusted origin: https://evil.example');
      err.code = 'ERR_UNTRUSTED_ORIGIN';
      throw err;
    });

    await expect(handlers.get('fs:readTextFile')(event, path.join(tempRoot, 'a.txt'), 'utf8')).rejects.toMatchObject({ code: 'ERR_UNTRUSTED_ORIGIN' });
    expect(isPathAllowed).not.toHaveBeenCalled();
  });

  test('returns clear error for sensitive denied path and logs audit details', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerFsAccessHandlers(ipcMain);
    const sensitive = path.join(tempRoot, 'config', 'secrets.bin');
    const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});

    evaluatePathAccess.mockReturnValue({ allowed: false, reason: 'sensitive_path_denied', sensitivePath: 'config/secrets.bin' });

    await expect(handlers.get('fs:readTextFile')(event, sensitive, 'utf8'))
      .rejects.toThrow('permission_denied_sensitive_path:config/secrets.bin');

    expect(warnSpy).toHaveBeenCalledWith(
      '[fsAccess.handlers] filesystem access denied',
      expect.objectContaining({
        channel: 'fs:readTextFile',
        reason: 'sensitive_path_denied',
        sensitivePath: 'config/secrets.bin',
      })
    );
    warnSpy.mockRestore();
  });

  test('returns false for fs:exists when sender is untrusted', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerFsAccessHandlers(ipcMain);

    assertTrustedIpcSender.mockImplementation(() => {
      const err = new Error('Blocked fs:exists from untrusted origin: https://evil.example');
      err.code = 'ERR_UNTRUSTED_ORIGIN';
      throw err;
    });

    const exists = await handlers.get('fs:exists')(event, tempRoot);
    expect(exists).toBe(false);
    expect(isPathAllowed).not.toHaveBeenCalled();
  });

  test('enforces approval for both source and destination in fs:copyFile', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerFsAccessHandlers(ipcMain);

    const src = path.join(tempRoot, 'src.txt');
    const dst = path.join(tempRoot, 'nested', 'dst.txt');
    fs.writeFileSync(src, 'abc', 'utf8');

    isPathAllowed
      .mockReturnValueOnce(true)
      .mockReturnValueOnce(false);

    await expect(handlers.get('fs:copyFile')(event, src, dst)).rejects.toThrow('permission_denied');
    expect(isPathAllowed).toHaveBeenNthCalledWith(1, 321, src);
    expect(isPathAllowed).toHaveBeenNthCalledWith(2, 321, dst);
  });

  test('handles high-volume readdir/stat operations over large folders', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerFsAccessHandlers(ipcMain);

    const bigDir = path.join(tempRoot, 'big');
    fs.mkdirSync(bigDir, { recursive: true });
    for (let i = 0; i < 2000; i += 1) {
      fs.writeFileSync(path.join(bigDir, `file-${i}.txt`), String(i), 'utf8');
    }

    isPathAllowed.mockImplementation((_senderId, targetPath) => String(targetPath).startsWith(tempRoot));

    const names = await handlers.get('fs:readdir')(event, bigDir, {});
    expect(Array.isArray(names)).toBe(true);
    expect(names).toHaveLength(2000);
    expect(typeof names[0]).toBe('string');

    const firstStat = await handlers.get('fs:stat')(event, path.join(bigDir, names[0]));
    expect(firstStat).toEqual(expect.objectContaining({ isFile: true }));
    expect(firstStat).not.toHaveProperty('ok');

    const withTypes = await handlers.get('fs:readdir')(event, bigDir, { withFileTypes: true });
    expect(withTypes[0]).toEqual(expect.objectContaining({ name: expect.any(String), isFile: expect.any(Boolean) }));
    expect(withTypes[0]).not.toHaveProperty('ok');
  });
});
