/** @jest-environment node */

const fs = require('fs');
const fsp = fs.promises;

jest.mock('electron', () => ({
  app: {
    isPackaged: false,
    getPath: jest.fn(() => '/tmp'),
    getAppPath: jest.fn(() => '/app')
  },
  dialog: { showMessageBox: jest.fn(async () => ({ response: 1 })) },
  shell: {},
  session: {}
}));

const mockRunSequentialDriveTest = jest.fn();
jest.mock('../modules/diskBenchmark', () => ({
  runSequentialDriveTest: (...args) => mockRunSequentialDriveTest(...args),
  SEQUENTIAL_BENCHMARK_TEMP_FILE_COUNT: 3
}));

jest.mock('check-disk-space', () => ({ default: jest.fn(async () => ({ free: 1024 ** 4, size: 2 * (1024 ** 4) })) }));
jest.mock('../modules/pathExpander', () => ({ expandPaths: jest.fn((v) => v) }));
jest.mock('../modules/secureStore', () => ({}));
jest.mock('../modules/speedUtils', () => ({ estimateDiskWriteSpeed: jest.fn() }));
jest.mock('../utils/metadata', () => ({ getSourceMetadata: jest.fn() }));
jest.mock('../modules/project-organizer', () => ({ createProjectStructure: jest.fn() }));
jest.mock('../utils/appPaths', () => ({ ensureUserDataSubdir: jest.fn(() => '/tmp') }));
jest.mock('../utils/fsAccessControl', () => ({ approveRoot: jest.fn(), approveMany: jest.fn() }));
jest.mock('../utils/trustedIpcSender', () => ({ assertTrustedIpcSender: jest.fn() }));
jest.mock('../utils/maintenance', () => ({ clearTempFiles: jest.fn(), clearCacheFiles: jest.fn() }));
jest.mock('../ai/transcribeEngine', () => ({}));
jest.mock('../utils/ipcPathGuards', () => ({
  assertNoNetworkSchemes: jest.fn(),
  toLocalPathIfFileUrl: jest.fn((v) => v),
  assertApprovedPath: jest.fn((_senderId, p) => p),
  assertApprovedPaths: jest.fn(),
  extractAbsolutePathsFromObject: jest.fn(() => [])
}));

const mockCreateJobLogger = jest.fn(() => ({
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
  setStage: jest.fn(),
  getStructuredLogPath: jest.fn(() => '/tmp/structured.log'),
  getEntries: jest.fn(() => [])
}));

jest.mock('../modules/logUtils', () => ({
  readLogFiles: jest.fn(),
  createJobLogger: (...args) => mockCreateJobLogger(...args),
  writeJobLogToFile: jest.fn(() => '/tmp/job.log'),
  writeJobTextToFile: jest.fn(() => '/tmp/job.txt')
}));

jest.mock('../services/licenseService', () => ({
  isFeatureEnabled: jest.fn(() => true)
}));


jest.mock('../services/autoUpdateService', () => ({
  getLastStatus: jest.fn(() => ({ status: 'idle', info: null })),
  checkForUpdates: jest.fn(),
  downloadUpdate: jest.fn(),
  quitAndInstall: jest.fn()
}));

const miscHandlersModule = require('../ipc/misc.handlers');
const registerMiscHandlers = miscHandlersModule;

function buildIpcMain() {
  const handlers = new Map();
  const listeners = new Map();
  return {
    handlers,
    listeners,
    ipcMain: {
      handle: jest.fn((channel, fn) => handlers.set(channel, fn)),
      on: jest.fn((channel, fn) => listeners.set(channel, fn))
    }
  };
}
describe('ipc drive-test handlers', () => {

  beforeEach(() => {
    jest.clearAllMocks();
    miscHandlersModule.setSpeedtestLockStrategyForTests({
      acquireMarker: jest.fn(async () => ({ markerPath: null, runId: 'test-run' })),
      releaseMarker: jest.fn(async () => {})
    });
    miscHandlersModule.setDriveTestPreflightStrategyForTests({
      run: jest.fn(async () => ({ ok: true }))
    });
  });

  afterEach(() => {
    miscHandlersModule.resetSpeedtestLockStrategyForTests();
    miscHandlersModule.resetDriveTestPreflightStrategyForTests();
  });

  test('preserves result formatting fields without surfacing read-cache mitigation warnings', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    mockRunSequentialDriveTest.mockResolvedValueOnce({
      success: true,
      write: '100.0',
      writeMin: '90.0',
      writeMax: '110.0',
      read: '120.0',
      readMin: '115.0',
      readMax: '125.0',
      cacheMitigation: {
        fullyApplied: false,
        strategy: 'expanded_working_set_with_platform_drop'
      }
    });

    const send = jest.fn();
    const event = {
      sender: { id: 42, isDestroyed: () => false, send },
      senderFrame: { url: 'app://index.html' }
    };

    const res = await handlers.get('run-drive-test')(event, '/Volumes/Test', 256);

    expect(res.success).toBe(true);
    expect(res.write).toBe('100.0');
    expect(res.read).toBe('120.0');
    expect(res.warning).toBeUndefined();
    expect(send).not.toHaveBeenCalledWith('drive-test-warning', expect.anything());
  });


  test('sequential drive test can run twice for same sender without stale ALREADY_RUNNING', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    mockRunSequentialDriveTest
      .mockResolvedValueOnce({ success: true, write: '101.0', read: '121.0' })
      .mockResolvedValueOnce({ success: true, write: '102.0', read: '122.0' });

    const event = {
      sender: { id: 45, isDestroyed: () => false, send: jest.fn() },
      senderFrame: { url: 'app://index.html' }
    };

    const first = await handlers.get('run-drive-test')(event, '/Volumes/Test', 256);
    const second = await handlers.get('run-drive-test')(event, '/Volumes/Test', 256);

    expect(first).toEqual(expect.objectContaining({ success: true }));
    expect(second).toEqual(expect.objectContaining({ success: true }));
    expect(second).not.toEqual(expect.objectContaining({ code: 'ALREADY_RUNNING' }));
    expect(mockRunSequentialDriveTest).toHaveBeenCalledTimes(2);
  });

  test('cancellation path remains unchanged', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    mockRunSequentialDriveTest.mockRejectedValueOnce(Object.assign(new Error('cancelled'), { code: 'DRIVE_TEST_CANCELLED' }));

    const event = {
      sender: { id: 43, isDestroyed: () => false, send: jest.fn() },
      senderFrame: { url: 'app://index.html' }
    };

    const res = await handlers.get('run-drive-test')(event, '/Volumes/Test', 256);

    expect(res).toEqual(expect.objectContaining({ success: false, cancelled: true }));
  });

  test('sender destroy during test returns cancelled and clears cancellation flag after finalization', async () => {
    const { ipcMain, handlers } = buildIpcMain();
    registerMiscHandlers(ipcMain, {});

    let destroyedHandler = null;
    mockRunSequentialDriveTest.mockImplementationOnce(async ({ throwIfCancelled }) => {
      if (typeof destroyedHandler === 'function') destroyedHandler();
      throwIfCancelled();
      return { success: true, write: '1.0', read: '1.0' };
    });

    const event = {
      sender: {
        id: 44,
        isDestroyed: () => false,
        send: jest.fn(),
        once: jest.fn((eventName, cb) => {
          if (eventName === 'destroyed') destroyedHandler = cb;
        })
      },
      senderFrame: { url: 'app://index.html' }
    };

    const cancelled = await handlers.get('run-drive-test')(event, '/Volumes/Test', 256);

    expect(cancelled).toEqual(expect.objectContaining({ success: false, cancelled: true }));

    mockRunSequentialDriveTest.mockResolvedValueOnce({
      success: true,
      write: '100.0',
      writeMin: '90.0',
      writeMax: '110.0',
      read: '120.0',
      readMin: '115.0',
      readMax: '125.0'
    });

    const rerun = await handlers.get('run-drive-test')(event, '/Volumes/Test', 256);
    expect(rerun).toEqual(expect.objectContaining({ success: true }));
    expect(rerun).not.toHaveProperty('cancelled');
  });

});
