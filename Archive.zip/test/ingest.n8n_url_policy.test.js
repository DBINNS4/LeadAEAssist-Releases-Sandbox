/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');

async function withTempIngestPaths(fn) {
  const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lead-ae-n8n-policy-'));
  const source = path.join(tmpRoot, 'source');
  const destination = path.join(tmpRoot, 'dest');
  fs.mkdirSync(source, { recursive: true });
  fs.mkdirSync(destination, { recursive: true });

  try {
    await fn({ source, destination });
  } finally {
    fs.rmSync(tmpRoot, { recursive: true, force: true });
  }
}

describe('validateIngestConfig — n8n URL policy', () => {
  beforeEach(() => {
    delete process.env.LEADAE_ALLOW_INSECURE_N8N_HTTP;
    jest.resetModules();
  });

  test('rejects http webhook URL in packaged builds', async () => {
    const { validateIngestConfig } = require('../modules/ingest');

    await withTempIngestPaths(async ({ source, destination }) => {
      const errors = await validateIngestConfig({
        source,
        destination,
        enableN8N: true,
        n8nUrl: 'http://hooks.example.com/ingest',
        n8nAllowPrivate: true,
        isPackagedOverride: true,
      });

      expect(errors.join('\n')).toContain('must use https:// in packaged builds');
    });
  });

  test('accepts https webhook URL in packaged builds', async () => {
    const { validateIngestConfig } = require('../modules/ingest');

    await withTempIngestPaths(async ({ source, destination }) => {
      const errors = await validateIngestConfig({
        source,
        destination,
        enableN8N: true,
        n8nUrl: 'https://hooks.example.com/ingest',
        n8nAllowPrivate: true,
        isPackagedOverride: true,
      });

      expect(errors).toHaveLength(0);
    });
  });

  test('rejects webhook host not on allowlist', async () => {
    const { validateIngestConfig } = require('../modules/ingest');

    await withTempIngestPaths(async ({ source, destination }) => {
      const errors = await validateIngestConfig({
        source,
        destination,
        enableN8N: true,
        n8nUrl: 'https://hooks.example.com/ingest',
        n8nAllowlist: ['webhooks.internal.example'],
        n8nAllowPrivate: true,
      });

      expect(errors.join('\n')).toContain('host not allowed');
    });
  });

  test('accepts webhook host on allowlist', async () => {
    const { validateIngestConfig } = require('../modules/ingest');

    await withTempIngestPaths(async ({ source, destination }) => {
      const errors = await validateIngestConfig({
        source,
        destination,
        enableN8N: true,
        n8nUrl: 'https://hooks.example.com/ingest',
        n8nAllowedHosts: 'hooks.example.com, n8n.company.tld',
        n8nAllowPrivate: true,
      });

      expect(errors).toHaveLength(0);
    });
  });
});
