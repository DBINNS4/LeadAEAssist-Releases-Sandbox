const path = require('path');

const flushPromises = () => new Promise(resolve => setImmediate(resolve));
const waitForInvoke = async (channel, attempts = 25) => {
  for (let i = 0; i < attempts; i += 1) {
    if (ipc.invoke.mock.calls.some(([name]) => name === channel)) return;
    await flushPromises();
  }
  throw new Error(`Timed out waiting for ipc.invoke(${channel})`);
};

function buildIngestDOM() {
  document.body.innerHTML = `
    <div id="ingest">
      <div id="ingest-lock-wrapper">
        <button id="select-source" class="button">
          <span class="button_lg">
            <span class="button_sl"></span>
            <span class="button_text">Select Source</span>
          </span>
        </button>
        <button id="select-destination" class="button">
          <span class="button_lg">
            <span class="button_sl"></span>
            <span class="button_text">Select Destination</span>
          </span>
        </button>
        <button id="select-backup" class="button">
          <span class="button_lg">
            <span class="button_sl"></span>
            <span class="button_text">Select Backup</span>
          </span>
        </button>
        <input id="source-path" data-file-list="[]" />
        <input id="destination-path" />
        <input id="backup-path" />
        <input type="checkbox" id="dualCopy" />
        <input type="checkbox" id="flattenStructure" />
        <input type="checkbox" id="autoFolder" />
        <input type="checkbox" id="enable-clone" />
        <div id="clone-options">
          <input type="checkbox" id="clone-select-all-folders" />
          <input type="checkbox" id="clone-show-file-count" />
          <input id="clone-folder-filter" />
          <div id="clone-folder-tree"></div>
        </div>
        <div id="ingest-verification-logging-tooltip"></div>
        <div id="clone-mode-tooltip"></div>
        <div id="ingest-overview-tooltip"></div>
        <select id="checksum-method"></select>
        <input type="checkbox" id="skip-duplicates" checked />
        <input type="checkbox" id="include-hidden-files" />
        <input type="checkbox" id="include-cache" />
        <input type="checkbox" id="saveLog" />
        <textarea id="notes"></textarea>
        <input id="filter-include" />
        <input id="filter-exclude" />
        <input type="checkbox" id="enable-n8n" />
        <input id="n8n-url" />
        <input type="checkbox" id="n8n-allow-private" />
        <input type="checkbox" id="n8n-log" />
        <input type="checkbox" id="enable-watch-mode" />
        <input type="checkbox" id="ingest-watch-process-existing" />
        <input type="checkbox" id="ingest-parallel" />
        <input type="checkbox" id="ingest-auto-threads" />
        <input type="checkbox" id="ingest-retry-failures" />
        <span id="concurrency-value">1</span>
        <input type="range" id="concurrency-slider" value="1" />
        <select id="ingest-preset"></select>
        <button id="ingest-save-config" class="button">
          <span class="button_lg">
            <span class="button_sl"></span>
            <span class="button_text">Save Config</span>
          </span>
        </button>
        <button id="ingest-load-config" class="button">
          <span class="button_lg">
            <span class="button_sl"></span>
            <span class="button_text">Load Config</span>
          </span>
        </button>
        <pre id="log-output"></pre>
        <button id="start-ingest" class="button">
          <span class="button_lg">
            <span class="button_sl"></span>
            <span class="button_text">Start</span>
          </span>
        </button>
        <button id="reset-ingest-fields" class="button">
          <span class="button_lg">
            <span class="button_sl"></span>
            <span class="button_text">Reset</span>
          </span>
        </button>
        <button id="cancel-ingest" class="button">
          <span class="button_lg">
            <span class="button_sl"></span>
            <span class="button_text">Cancel</span>
          </span>
        </button>
        <progress id="ingest-progress"></progress>
        <output id="ingest-progress-output"></output>
        <div id="ingest-loader-inline"></div>
        <div id="ingest-job-status"></div>
        <textarea id="ingest-job-preview-box"></textarea>
      </div>
    </div>
  `;

  Object.defineProperty(document, 'readyState', {
    configurable: true,
    get: () => 'complete',
  });

  window.cloneUtils = {
    getSelectedFolders: jest.fn(() => ({
      selectedFolders: ['/source/Sub'],
      foldersOnly: [],
      excludedFolders: [],
      includeSourceRoot: false,
    })),
    calculateCloneBytes: jest.fn(async () => ({ total: 100, fileCount: 2, folderCount: 1 })),
    renderFolderTree: jest.fn(),
    updateCountsUI: jest.fn(),
  };


  window.electron.relative = path.relative;
  window.electron.dirname = path.dirname;
  window.electron.statSync = jest.fn(() => ({ isDirectory: () => true }));
  window.rendererDialogs = {
    confirmAction: jest.fn(async () => true),
    confirmTextInput: jest.fn(async () => ({ confirmed: false, value: '' })),
  };
}

describe('Ingest panel behaviors', () => {
  let pathMetaOverrides;

  const getQueueHandler = (eventName) => {
    const call = ipc.on.mock.calls.find(([name]) => name === eventName);
    expect(call).toBeTruthy();
    return call[1];
  };

  beforeEach(() => {
    pathMetaOverrides = {};
    window.localStorage?.clear?.();
    window.sessionStorage?.clear?.();
    jest.resetModules();
    const i18nHandlers = {};
    window.i18n = {
      language: 'en',
      t: jest.fn((key, opts = {}) => {
        const englishMap = {
          ingestVerificationTooltipHeader: 'VERIFICATION METHODS',
          cloneModeTooltipHeader: 'CLONE MODE OVERVIEW',
          ingestOverviewTooltipHeader: 'INGEST PANEL — Technical Overview',
          startIngest: 'Start',
          cancelIngest: 'Cancel',
          ingestStartWatching: 'Start Watching',
          ingestStopWatching: 'Stop Watching',
        };
        const spanishMap = {
          ingestVerificationTooltipHeader: 'MÉTODOS DE VERIFICACIÓN',
          cloneModeTooltipHeader: 'RESUMEN DEL MODO CLON',
          ingestOverviewTooltipHeader: 'PANEL DE INGESTA — Resumen técnico',
          startIngest: 'Iniciar',
          cancelIngest: 'Cancelar',
          ingestStartWatching: 'Iniciar monitoreo',
          ingestStopWatching: 'Detener monitoreo',
        };
        const map = window.i18n.language === 'es' ? spanishMap : englishMap;
        const template = map[key] || opts.defaultValue || key;
        return String(template).replace(/{{\s*([^{}\s]+)\s*}}/g, (match, token) => (
          Object.prototype.hasOwnProperty.call(opts, token) ? String(opts[token]) : match
        ));
      }),
      on: jest.fn((eventName, handler) => {
        i18nHandlers[eventName] = i18nHandlers[eventName] || [];
        i18nHandlers[eventName].push(handler);
      }),
      __emit: (eventName) => {
        (i18nHandlers[eventName] || []).forEach(fn => fn());
      },
      __handlers: i18nHandlers,
    };
    ipc.on.mockReset();
    ipc.invoke.mockReset();
    ipc.invoke.mockImplementation(async (channel, arg) => {
      if (channel === 'path-exists') return true;
      if (channel === 'normalize-path') return String(arg ?? '').trim();
      if (channel === 'ingest-validate-paths') {
        const list = Array.isArray(arg) ? arg : [];
        const results = Object.fromEntries(list.map((item) => [
          item,
          { exists: true, isDirectory: true, isFile: false, writable: true, writeReason: '', ...(pathMetaOverrides[item] || {}) },
        ]));
        return { success: true, results };
      }
      if (channel === 'calculate-ingest-bytes') {
        return { success: true, total: 1024, fileCount: 3, folderCount: 1, map: {} };
      }
      if (channel === 'queue-add-ingest') return 'job-123';
      if (channel === 'queue-start') return undefined;
      return undefined;
    });
    buildIngestDOM();
    require('../renderer.ingest.js');
  });

  test('"Include Cache" defaults off and inverts the backend ignore-pattern flag', () => {
    const includeCache = document.getElementById('include-cache');
    expect(includeCache).toBeTruthy();

    // Default UI state: unchecked (do not include caches)
    expect(includeCache.checked).toBe(false);

    const cfgDefault = globalThis.gatherIngestConfig();
    expect(cfgDefault.includeCache).toBe(false);
    expect(cfgDefault.useDefaultIgnorePatterns).toBe(true);

    // When explicitly enabled, include caches and disable default ignores.
    includeCache.checked = true;
    const cfgInclude = globalThis.gatherIngestConfig();
    expect(cfgInclude.includeCache).toBe(true);
    expect(cfgInclude.useDefaultIgnorePatterns).toBe(false);
  });





  test('skip duplicates defaults on and is restored by reset', () => {
    const skipDuplicates = document.getElementById('skip-duplicates');
    expect(skipDuplicates.checked).toBe(true);

    skipDuplicates.checked = false;
    document.getElementById('reset-ingest-fields').click();

    expect(skipDuplicates.checked).toBe(true);
  });

  test('defaults checksum method to blake3 with verification enabled', () => {
    const checksumMethod = document.getElementById('checksum-method');
    expect(checksumMethod.value).toBe('blake3');

    const cfg = globalThis.gatherIngestConfig();
    expect(cfg.verification.method).toBe('blake3');
    expect(cfg.verification.useChecksum).toBe(true);
  });

  test('refreshes ingest tooltip content on language change', () => {
    const verificationTooltip = document.getElementById('ingest-verification-logging-tooltip');
    const cloneTooltip = document.getElementById('clone-mode-tooltip');
    const overviewTooltip = document.getElementById('ingest-overview-tooltip');

    expect(verificationTooltip.textContent).toContain('VERIFICATION METHODS');
    expect(cloneTooltip.textContent).toContain('CLONE MODE OVERVIEW');
    expect(overviewTooltip.textContent).toContain('INGEST PANEL — Technical Overview');

    window.i18n.language = 'es';
    window.i18n.__emit('languageChanged');

    expect(verificationTooltip.textContent).toContain('MÉTODOS DE VERIFICACIÓN');
    expect(cloneTooltip.textContent).toContain('RESUMEN DEL MODO CLON');
    expect(overviewTooltip.textContent).toContain('PANEL DE INGESTA — Resumen técnico');
    expect(verificationTooltip.textContent).not.toContain('VERIFICATION METHODS');
  });

  test('disables checksum verification only when method is explicitly none', () => {
    const checksumMethod = document.getElementById('checksum-method');

    checksumMethod.value = 'bytecompare';
    let cfg = globalThis.gatherIngestConfig();
    expect(cfg.verification.method).toBe('bytecompare');
    expect(cfg.verification.useChecksum).toBe(true);

    checksumMethod.value = 'none';
    cfg = globalThis.gatherIngestConfig();
    expect(cfg.verification.method).toBe('none');
    expect(cfg.verification.useChecksum).toBe(false);
  });

  test('loading preset without verification method keeps blake3 default', async () => {
    await globalThis.applyIngestPreset({
      source: '/src',
      destination: '/dest',
      verification: {
        skipDuplicates: true,
      },
    });

    const checksumMethod = document.getElementById('checksum-method');
    expect(checksumMethod.value).toBe('blake3');

    const cfg = globalThis.gatherIngestConfig();
    expect(cfg.verification.method).toBe('blake3');
    expect(cfg.verification.useChecksum).toBe(true);
  });

  test('restores clone-style include/exclude and verification fields when nested keys are missing', async () => {
    await globalThis.applyIngestPreset({
      source: '/src',
      destination: '/dest',
      includeExtensions: '.mov,.wav',
      excludeExtensions: '.tmp,.ds_store',
      skipExisting: true,
      checksumMethod: 'bytecompare',
    });

    expect(document.getElementById('filter-include').value).toBe('.mov,.wav');
    expect(document.getElementById('filter-exclude').value).toBe('.tmp,.ds_store');
    expect(document.getElementById('skip-duplicates').checked).toBe(true);
    expect(document.getElementById('checksum-method').value).toBe('bytecompare');
  });

  test('clone-style checksum=false restores method to none when no method is provided', async () => {
    await globalThis.applyIngestPreset({
      source: '/src',
      destination: '/dest',
      checksum: false,
    });

    expect(document.getElementById('checksum-method').value).toBe('none');
  });


  test('restores source path from watch folder when source is empty', async () => {
    await globalThis.applyIngestPreset({
      source: '',
      watchFolder: '/watch/incoming',
      destination: '/dest',
    });

    expect(document.getElementById('source-path').value).toBe('/watch/incoming');
  });

  test('prefers source over watch folder when both are provided', async () => {
    await globalThis.applyIngestPreset({
      source: '/source/card-a',
      watchFolder: '/watch/incoming',
      destination: '/dest',
    });

    expect(document.getElementById('source-path').value).toBe('/source/card-a');
  });

  test('keeps folder source when preset sourceFiles is an empty array', async () => {
    const controls = {
      sourcePath: document.getElementById('source-path'),
      destinationPath: document.getElementById('destination-path'),
    };

    controls.sourcePath.value = '/show/project/card-01';
    controls.destinationPath.value = '/show/project/ingest';

    const saved = globalThis.gatherIngestConfig();
    expect(saved.source).toBe('/show/project/card-01');
    expect(saved.sourceFiles).toEqual([]);

    controls.sourcePath.value = '';

    await globalThis.applyIngestPreset(saved);

    expect(controls.sourcePath.value).toBe('/show/project/card-01');
    expect(controls.sourcePath.dataset.selectionMode).toBe('folder');
  });
  test('restores dual copy from preset dualCopy field', async () => {
    const dualCopy = document.getElementById('dualCopy');
    dualCopy.checked = false;

    await globalThis.applyIngestPreset({
      dualCopy: true,
    });

    expect(dualCopy.checked).toBe(true);
  });

  test('restores dual copy from legacy preset backup field when dualCopy is missing', async () => {
    const dualCopy = document.getElementById('dualCopy');
    dualCopy.checked = false;

    await globalThis.applyIngestPreset({
      backup: true,
    });

    expect(dualCopy.checked).toBe(true);
  });

  test('prefers dualCopy over backup when both preset fields are present', async () => {
    const dualCopy = document.getElementById('dualCopy');
    dualCopy.checked = true;

    await globalThis.applyIngestPreset({
      dualCopy: false,
      backup: true,
    });

    expect(dualCopy.checked).toBe(false);
  });






  test('clone mode with empty source path keeps foldersOnly as an array in saved config', () => {
    document.getElementById('enable-clone').checked = true;
    document.getElementById('source-path').value = '';

    const saved = globalThis.gatherIngestConfig();

    expect(saved.cloneMode).toBe(true);
    expect(Array.isArray(saved.selectedFolders)).toBe(true);
    expect(Array.isArray(saved.foldersOnly)).toBe(true);
    expect(Array.isArray(saved.excludedFolders)).toBe(true);
    expect(typeof saved.includeSourceRoot).toBe('boolean');
    expect(saved.foldersOnly).toEqual([]);
  });

  test('clone preset restores includeSourceRoot into clone selection model', async () => {
    document.getElementById('enable-clone').checked = true;
    document.getElementById('source-path').value = '/source';

    window.cloneUtils.getSelectedFolders.mockImplementation(() => ({
      selectedFolders: Array.isArray(window.cloneSelectedFolders) ? window.cloneSelectedFolders : ['/source/Sub'],
      foldersOnly: Array.isArray(window.cloneFoldersOnly) ? window.cloneFoldersOnly : [],
      excludedFolders: Array.isArray(window.cloneExcluded) ? window.cloneExcluded : [],
      includeSourceRoot: !!window.cloneIncludeSourceRoot,
    }));

    window.cloneIncludeSourceRoot = true;
    const saved = globalThis.gatherIngestConfig();
    expect(saved.cloneMode).toBe(true);
    expect(saved.includeSourceRoot).toBe(true);

    window.cloneSelectedFolders = [];
    window.cloneFoldersOnly = [];
    window.cloneExcluded = [];
    window.cloneIncludeSourceRoot = false;

    await globalThis.applyIngestPreset({
      source: '/source',
      cloneMode: true,
      selectedFolders: ['/source/Sub'],
      foldersOnly: [],
      excludedFolders: [],
      includeSourceRoot: true,
    });

    expect(window.cloneIncludeSourceRoot).toBe(true);
    expect(window.cloneUtils.renderFolderTree).toHaveBeenCalled();

    const roundTripped = globalThis.gatherIngestConfig();
    expect(roundTripped.includeSourceRoot).toBe(true);
  });

  test('clone preset controls round-trip through gather/apply preset', async () => {
    document.getElementById('enable-clone').checked = true;

    const cloneFilter = document.getElementById('clone-folder-filter');
    const cloneSelectAll = document.getElementById('clone-select-all-folders');
    const cloneShowCount = document.getElementById('clone-show-file-count');

    cloneFilter.value = 'bins';
    cloneSelectAll.checked = true;
    cloneShowCount.checked = true;

    const saved = globalThis.gatherIngestConfig();
    expect(saved.cloneFolderFilter).toBe('bins');
    expect(saved.cloneSelectAllFolders).toBe(true);
    expect(saved.cloneShowFileCount).toBe(true);

    cloneFilter.value = '';
    cloneSelectAll.checked = false;
    cloneShowCount.checked = false;

    await globalThis.applyIngestPreset({
      cloneMode: true,
      cloneFolderFilter: saved.cloneFolderFilter,
      cloneSelectAllFolders: saved.cloneSelectAllFolders,
      cloneShowFileCount: saved.cloneShowFileCount,
    });

    expect(cloneFilter.value).toBe('bins');
    expect(cloneSelectAll.checked).toBe(true);
    expect(cloneShowCount.checked).toBe(true);
    expect(window.cloneUtils.updateCountsUI).toHaveBeenCalled();
  });

  test('table-style ingest preset control round-trip restores every mapped UI field', async () => {
    const controls = {
      sourcePath: document.getElementById('source-path'),
      destinationPath: document.getElementById('destination-path'),
      backupPath: document.getElementById('backup-path'),
      dualCopy: document.getElementById('dualCopy'),
      autoFolder: document.getElementById('autoFolder'),
      flattenStructure: document.getElementById('flattenStructure'),
      includeCache: document.getElementById('include-cache'),
      includeHiddenFiles: document.getElementById('include-hidden-files'),
      filterInclude: document.getElementById('filter-include'),
      filterExclude: document.getElementById('filter-exclude'),
      checksumMethod: document.getElementById('checksum-method'),
      skipDuplicates: document.getElementById('skip-duplicates'),
      saveLog: document.getElementById('saveLog'),
      notes: document.getElementById('notes'),
      enableN8N: document.getElementById('enable-n8n'),
      n8nUrl: document.getElementById('n8n-url'),
      n8nAllowPrivate: document.getElementById('n8n-allow-private'),
      n8nLog: document.getElementById('n8n-log'),
      enableWatchMode: document.getElementById('enable-watch-mode'),
      processExisting: document.getElementById('ingest-watch-process-existing'),
      ingestParallel: document.getElementById('ingest-parallel'),
      autoThreads: document.getElementById('ingest-auto-threads'),
      concurrencySlider: document.getElementById('concurrency-slider'),
      retryFailures: document.getElementById('ingest-retry-failures'),
      enableClone: document.getElementById('enable-clone'),
      cloneFilter: document.getElementById('clone-folder-filter'),
      cloneSelectAll: document.getElementById('clone-select-all-folders'),
      cloneShowCount: document.getElementById('clone-show-file-count'),
    };

    // Phase A: non-clone controls, including Watch Mode.
    controls.sourcePath.value = '/RT/source-A001';
    controls.destinationPath.value = '/RT/destination-B002';
    controls.backupPath.value = '/RT/backup-C003';
    controls.dualCopy.checked = true;
    controls.autoFolder.checked = true;
    controls.flattenStructure.checked = true;
    controls.includeCache.checked = true;
    controls.includeHiddenFiles.checked = true;
    controls.filterInclude.value = '.ari,.r3d,.wav';
    controls.filterExclude.value = '.tmp,.bak,.proxy';
    controls.checksumMethod.value = 'xxhash64';
    controls.skipDuplicates.checked = false;
    controls.saveLog.checked = true;
    controls.notes.value = 'RT_NOTE__ingest_preset_mapping';
    controls.enableN8N.checked = true;
    controls.n8nUrl.value = 'https://hooks.example.com/ingest/RT-777';
    controls.n8nAllowPrivate.checked = true;
    controls.n8nLog.checked = true;
    controls.enableWatchMode.checked = true;
    controls.processExisting.checked = true;
    controls.ingestParallel.checked = true;
    controls.autoThreads.checked = false;
    controls.concurrencySlider.value = '7';
    controls.retryFailures.checked = true;
    controls.enableClone.checked = false;

    const saved = globalThis.gatherIngestConfig();
    expect(saved.source).toBe('/RT/source-A001');
    expect(saved.destination).toBe('/RT/destination-B002');
    expect(saved.backupPath).toBe('/RT/backup-C003');
    expect(saved.dualCopy).toBe(true);
    expect(saved.autoFolder).toBe(true);
    expect(saved.flattenStructure).toBe(true);
    expect(saved.includeCache).toBe(true);
    expect(saved.includeHiddenFiles).toBe(true);
    expect(saved.filters?.include).toBe('.ari,.r3d,.wav');
    expect(saved.filters?.exclude).toBe('.tmp,.bak,.proxy');
    expect(saved.verification?.method).toBe('xxhash64');
    expect(saved.verification?.skipDuplicates).toBe(false);
    expect(saved.saveLog).toBe(true);
    expect(saved.notes).toBe('RT_NOTE__ingest_preset_mapping');
    expect(saved.enableN8N).toBe(true);
    expect(saved.n8nUrl).toBe('https://hooks.example.com/ingest/RT-777');
    expect(saved.n8nAllowPrivate).toBe(true);
    expect(saved.n8nLog).toBe(true);
    expect(saved.watchMode).toBe(true);
    expect(saved.processExistingOnStart).toBe(true);
    expect(saved.enableThreads).toBe(true);
    expect(saved.autoThreads).toBe(false);
    expect(saved.maxThreads).toBe(7);
    expect(saved.retryFailures).toBe(true);

    controls.sourcePath.value = '';
    controls.destinationPath.value = '';
    controls.backupPath.value = '';
    controls.dualCopy.checked = false;
    controls.autoFolder.checked = false;
    controls.flattenStructure.checked = false;
    controls.includeCache.checked = false;
    controls.includeHiddenFiles.checked = false;
    controls.filterInclude.value = '';
    controls.filterExclude.value = '';
    controls.checksumMethod.value = 'blake3';
    controls.skipDuplicates.checked = true;
    controls.saveLog.checked = false;
    controls.notes.value = '';
    controls.enableN8N.checked = false;
    controls.n8nUrl.value = '';
    controls.n8nAllowPrivate.checked = false;
    controls.n8nLog.checked = false;
    controls.enableWatchMode.checked = false;
    controls.processExisting.checked = false;
    controls.ingestParallel.checked = false;
    controls.autoThreads.checked = false;
    controls.concurrencySlider.value = '1';
    controls.retryFailures.checked = false;

    await globalThis.applyIngestPreset(saved);

    expect(controls.sourcePath.value).toBe('/RT/source-A001');
    expect(controls.destinationPath.value).toBe('/RT/destination-B002');
    expect(controls.backupPath.value).toBe('/RT/backup-C003');
    expect(controls.dualCopy.checked).toBe(true);
    expect(controls.autoFolder.checked).toBe(true);
    expect(controls.flattenStructure.checked).toBe(true);
    expect(controls.includeCache.checked).toBe(true);
    expect(controls.includeHiddenFiles.checked).toBe(true);
    expect(controls.filterInclude.value).toBe('.ari,.r3d,.wav');
    expect(controls.filterExclude.value).toBe('.tmp,.bak,.proxy');
    expect(controls.checksumMethod.value).toBe('xxhash64');
    expect(controls.skipDuplicates.checked).toBe(false);
    expect(controls.saveLog.checked).toBe(true);
    expect(controls.notes.value).toBe('RT_NOTE__ingest_preset_mapping');
    expect(controls.enableN8N.checked).toBe(true);
    expect(controls.n8nUrl.value).toBe('https://hooks.example.com/ingest/RT-777');
    expect(controls.n8nAllowPrivate.checked).toBe(true);
    expect(controls.n8nLog.checked).toBe(true);
    expect(controls.enableWatchMode.checked).toBe(true);
    expect(controls.processExisting.checked).toBe(true);
    expect(controls.ingestParallel.checked).toBe(true);
    expect(controls.autoThreads.checked).toBe(false);
    expect(Number(controls.concurrencySlider.value)).toBeGreaterThanOrEqual(1);
    expect(Number(document.getElementById('concurrency-value').textContent || '0')).toBe(Number(controls.concurrencySlider.value));
    expect(controls.retryFailures.checked).toBe(true);

    // Phase B: clone controls.
    controls.enableClone.checked = true;
    controls.cloneFilter.value = 'dailies|cameraA';
    controls.cloneSelectAll.checked = true;
    controls.cloneShowCount.checked = true;

    const savedClone = globalThis.gatherIngestConfig();
    expect(savedClone.cloneMode).toBe(true);
    expect(savedClone.cloneFolderFilter).toBe('dailies|cameraA');
    expect(savedClone.cloneSelectAllFolders).toBe(true);
    expect(savedClone.cloneShowFileCount).toBe(true);

    controls.enableClone.checked = false;
    controls.cloneFilter.value = '';
    controls.cloneSelectAll.checked = false;
    controls.cloneShowCount.checked = false;

    await globalThis.applyIngestPreset(savedClone);

    expect(controls.enableClone.checked).toBe(true);
    expect(controls.cloneFilter.value).toBe('dailies|cameraA');
    expect(controls.cloneSelectAll.checked).toBe(true);
    expect(controls.cloneShowCount.checked).toBe(true);
  });

  test('blocks ingest when all selected source files are missing', async () => {
    const sourceInput = document.getElementById('source-path');
    sourceInput.value = '2 items selected';
    sourceInput.dataset.fileList = JSON.stringify(['/missing/a.mov', '/missing/b.mov']);
    sourceInput.dataset.selectionMode = 'files';
    document.getElementById('destination-path').value = '/dest';

    pathMetaOverrides['/missing/a.mov'] = { exists: false, isDirectory: false, isFile: false };
    pathMetaOverrides['/missing/b.mov'] = { exists: false, isDirectory: false, isFile: false };

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(document.getElementById('log-output').textContent)
      .toContain('None of the selected source files or folders exist');
    expect(ipc.invoke).not.toHaveBeenCalledWith('queue-add-ingest', expect.anything());
  });

  test('warns for partially missing selected files and still queues ingest', async () => {
    const sourceInput = document.getElementById('source-path');
    sourceInput.value = '2 items selected';
    sourceInput.dataset.fileList = JSON.stringify(['/source/good.mov', '/source/missing.mov']);
    sourceInput.dataset.selectionMode = 'files';
    document.getElementById('destination-path').value = '/dest';

    pathMetaOverrides['/source/good.mov'] = { exists: true, isDirectory: false, isFile: true };
    pathMetaOverrides['/source/missing.mov'] = { exists: false, isDirectory: false, isFile: false };

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(document.getElementById('log-output').textContent)
      .toContain('Source file not found: /source/missing.mov');
    expect(ipc.invoke).toHaveBeenCalledWith('queue-add-ingest', expect.objectContaining({
      config: expect.objectContaining({
        sourceFiles: ['/source/good.mov', '/source/missing.mov'],
      }),
    }));
    expect(ipc.invoke).toHaveBeenCalledWith('queue-start');
  });

  test('blocks invalid source/destination pairs during validation', async () => {
    const source = document.getElementById('source-path');
    const dest = document.getElementById('destination-path');
    source.value = '/media/card';
    dest.value = '/media/card/out';

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(document.getElementById('log-output').textContent)
      .toContain('Destination cannot be the same as the source or located inside the source folder');
    expect(ipc.invoke).not.toHaveBeenCalledWith('queue-add-ingest', expect.anything());
  });

  test('blocks overlapping destination and backup paths', async () => {
    document.getElementById('source-path').value = '/media/card';
    document.getElementById('destination-path').value = '/volumes/ingest';
    document.getElementById('backup-path').value = '/volumes/ingest/backup';
    document.getElementById('dualCopy').checked = true;

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(document.getElementById('log-output').textContent)
      .toContain('Destination and backup paths cannot match or contain each other');
    expect(ipc.invoke).not.toHaveBeenCalledWith('queue-add-ingest', expect.anything());
  });

  test('enforces webhook URL rules when webhook logging is enabled', async () => {
    document.getElementById('source-path').value = '/src';
    document.getElementById('destination-path').value = '/dest';
    document.getElementById('enable-n8n').checked = true;
    document.getElementById('n8n-url').value = 'http://127.0.0.1/hook';

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(document.getElementById('log-output').textContent)
      .toContain('cannot target localhost or private networks');
    expect(ipc.invoke).not.toHaveBeenCalledWith('queue-add-ingest', expect.anything());
  });

  test('allows private webhook targets when explicitly enabled', async () => {
    document.getElementById('source-path').value = '/src';
    document.getElementById('destination-path').value = '/dest';
    document.getElementById('enable-n8n').checked = true;
    document.getElementById('n8n-allow-private').checked = true;
    document.getElementById('n8n-url').value = 'http://127.0.0.1/hook';

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(ipc.invoke).toHaveBeenCalledWith('queue-add-ingest', expect.objectContaining({
      config: expect.objectContaining({
        enableN8N: true,
        n8nUrl: 'http://127.0.0.1/hook',
        n8nAllowPrivate: true,
      }),
    }));
    expect(ipc.invoke).toHaveBeenCalledWith('queue-start');
  });

  test('requires folder selection when clone mode is active', async () => {
    window.cloneUtils.getSelectedFolders.mockReturnValue({
      selectedFolders: [],
      foldersOnly: [],
      excludedFolders: [],
      includeSourceRoot: false,
    });
    document.getElementById('enable-clone').checked = true;
    document.getElementById('enable-clone').dispatchEvent(new Event('change'));
    document.getElementById('source-path').value = '/src';
    document.getElementById('destination-path').value = '/dest';

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(document.getElementById('log-output').textContent)
      .toContain('Select at least one folder to clone');
    expect(ipc.invoke).not.toHaveBeenCalledWith('queue-add-ingest', expect.anything());
  });

  test('renders job preview with sources, destinations, and webhook state', async () => {
    jest.useFakeTimers();
    try {
      document.getElementById('source-path').value = '/source';
      document.getElementById('destination-path').value = '/dest';
      document.getElementById('enable-n8n').checked = true;
      document.getElementById('n8n-url').value = 'https://hooks.example.com/ingest';
      document.getElementById('notes').value = 'Example notes';

      document.getElementById('source-path').dispatchEvent(new Event('input'));
      document.getElementById('destination-path').dispatchEvent(new Event('input'));
      document.getElementById('enable-n8n').dispatchEvent(new Event('change'));
      document.getElementById('n8n-url').dispatchEvent(new Event('input'));
      document.getElementById('notes').dispatchEvent(new Event('input'));

      await jest.advanceTimersByTimeAsync(500);
      await Promise.resolve();
      await Promise.resolve();

      const preview = document.getElementById('ingest-job-preview-box').value;
      expect(preview).toContain('Source: /source');
      expect(preview).toContain('Destination: /dest');
      expect(preview).toContain('n8n webhook: https://hooks.example.com/ingest');
      expect(preview).toContain('Notes: Example notes');
    } finally {
      jest.useRealTimers();
    }
  });


  test('requires confirmation before queueing when checksum method is none', async () => {
    document.getElementById('source-path').value = '/source';
    document.getElementById('destination-path').value = '/dest';
    document.getElementById('checksum-method').value = 'none';
    window.rendererDialogs.confirmAction.mockResolvedValue(false);

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(window.rendererDialogs.confirmAction).toHaveBeenCalledWith(expect.objectContaining({
      message: expect.stringContaining('Verification is set to None'),
      type: 'warning',
    }));
    expect(ipc.invoke).not.toHaveBeenCalledWith('queue-add-ingest', expect.anything());
  });

  test('queues when checksum method is none only after confirmation', async () => {
    document.getElementById('source-path').value = '/source';
    document.getElementById('destination-path').value = '/dest';
    document.getElementById('checksum-method').value = 'none';
    window.rendererDialogs.confirmAction.mockResolvedValue(true);

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(window.rendererDialogs.confirmAction).toHaveBeenCalledWith(expect.objectContaining({
      message: expect.stringContaining('Verification is set to None'),
      type: 'warning',
    }));
    expect(ipc.invoke).toHaveBeenCalledWith('queue-add-ingest', expect.objectContaining({
      config: expect.objectContaining({
        verification: expect.objectContaining({ method: 'none', useChecksum: false }),
      }),
    }));
  });

  test('cancels ingest when missing source override text confirmation is dismissed', async () => {
    document.getElementById('source-path').value = '/missing-source';
    document.getElementById('destination-path').value = '/dest';
    pathMetaOverrides['/missing-source'] = {
      exists: false,
      isDirectory: false,
      isFile: false,
    };
    window.rendererDialogs.confirmTextInput.mockResolvedValue({ confirmed: false, value: '' });

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(window.rendererDialogs.confirmTextInput).toHaveBeenCalledWith(expect.objectContaining({
      title: 'Missing source folder',
      expectedText: 'OVERRIDE',
    }));
    expect(ipc.invoke).not.toHaveBeenCalledWith('queue-add-ingest', expect.anything());
    expect(document.getElementById('log-output').textContent)
      .toContain('Ingest cancelled: source folder not found.');
  });

  test('queues ingest when missing source override text confirmation is accepted', async () => {
    document.getElementById('source-path').value = '/missing-source';
    document.getElementById('destination-path').value = '/dest';
    pathMetaOverrides['/missing-source'] = {
      exists: false,
      isDirectory: false,
      isFile: false,
    };
    window.rendererDialogs.confirmTextInput.mockResolvedValue({ confirmed: true, value: 'OVERRIDE' });

    document.getElementById('start-ingest').click();
    await waitForInvoke('queue-start');

    expect(window.rendererDialogs.confirmTextInput).toHaveBeenCalledWith(expect.objectContaining({
      title: 'Missing source folder',
      expectedText: 'OVERRIDE',
    }));
    expect(ipc.invoke).toHaveBeenCalledWith('queue-add-ingest', expect.objectContaining({
      config: expect.objectContaining({
        source: '/missing-source',
        destination: '/dest',
        allowMissingSourceOverride: true,
      }),
    }));
  });


  test('uses localized override token for guidance while enforcing canonical safety token', async () => {
    window.i18n.t.mockImplementation((key, opts = {}) => {
      if (key === 'ingestMissingSourceOverrideToken') return 'ANULAR';
      const template = opts.defaultValue || key;
      return String(template).replace(/{{\s*([^{}\s]+)\s*}}/g, (match, token) => (
        Object.prototype.hasOwnProperty.call(opts, token) ? String(opts[token]) : match
      ));
    });

    document.getElementById('source-path').value = '/missing-source';
    document.getElementById('destination-path').value = '/dest';
    pathMetaOverrides['/missing-source'] = {
      exists: false,
      isDirectory: false,
      isFile: false,
    };
    window.rendererDialogs.confirmTextInput.mockResolvedValue({ confirmed: false, value: '' });

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(window.rendererDialogs.confirmTextInput).toHaveBeenCalledWith(expect.objectContaining({
      inputLabel: 'Type ANULAR to continue',
      inputPlaceholder: 'ANULAR',
      expectedText: 'OVERRIDE',
      matchMode: 'case-insensitive',
    }));
  });



  test('blocks ingest when destination exists but is not writable', async () => {
    document.getElementById('source-path').value = '/source';
    document.getElementById('destination-path').value = '/dest';
    pathMetaOverrides['/dest'] = {
      exists: true,
      isDirectory: true,
      isFile: false,
      writable: false,
      writeReason: 'EACCES: permission denied',
    };

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(document.getElementById('log-output').textContent)
      .toContain('Destination folder is not writable');
    expect(ipc.invoke).not.toHaveBeenCalledWith('queue-add-ingest', expect.anything());
  });

  test('blocks ingest when dual copy backup exists but is not writable', async () => {
    document.getElementById('source-path').value = '/source';
    document.getElementById('destination-path').value = '/dest';
    document.getElementById('backup-path').value = '/backup';
    document.getElementById('dualCopy').checked = true;
    pathMetaOverrides['/backup'] = {
      exists: true,
      isDirectory: true,
      isFile: false,
      writable: false,
      writeReason: 'EACCES: permission denied',
    };

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(document.getElementById('log-output').textContent)
      .toContain('Backup folder is not writable');
    expect(ipc.invoke).not.toHaveBeenCalledWith('queue-add-ingest', expect.anything());
  });

  test('queues ingest jobs after successful validation', async () => {
    document.getElementById('source-path').value = '/source';
    document.getElementById('destination-path').value = '/dest';

    document.getElementById('start-ingest').click();
    await flushPromises();

    expect(ipc.invoke).toHaveBeenCalledWith('queue-add-ingest', expect.objectContaining({
      config: expect.objectContaining({ source: '/source', destination: '/dest' }),
    }));
    expect(ipc.invoke).toHaveBeenCalledWith('queue-start');
    expect(document.getElementById('log-output').textContent).toContain('job queued');
  });

  test('watch mode toggles labels and keeps backup options enabled', () => {
    const backupPath = document.getElementById('backup-path');
    const dualCopy = document.getElementById('dualCopy');
    backupPath.value = '/backup';
    dualCopy.checked = true;

    const watchToggle = document.getElementById('enable-watch-mode');
    watchToggle.checked = true;
    watchToggle.dispatchEvent(new Event('change'));

    const startBtn = document.getElementById('start-ingest');
    const cancelBtn = document.getElementById('cancel-ingest');
    const sourceBtn = document.getElementById('select-source');

    // ✅ Regression guard: toggling watch mode must NOT flatten the skinned button markup.
    // If anyone reintroduces `button.textContent = ...` in production code, these spans will disappear.
    const startLabel = startBtn.querySelector('.button_text');
    const cancelLabel = cancelBtn.querySelector('.button_text');
    const sourceLabel = sourceBtn.querySelector('.button_text');
    expect(startLabel).not.toBeNull();
    expect(cancelLabel).not.toBeNull();
    expect(sourceLabel).not.toBeNull();

    expect(startLabel.textContent).toBe('Start Watching');
    expect(cancelLabel.textContent).toBe('Stop Watching');
    expect(sourceLabel.textContent).toBe('Select Watch Folder');
    expect(backupPath.disabled).toBe(false);
    expect(backupPath.value).toBe('/backup');
    expect(dualCopy.checked).toBe(true);
    expect(dualCopy.disabled).toBe(false);
  });

  test('watch mode updates labels on language change while still in watch state', () => {
    const watchToggle = document.getElementById('enable-watch-mode');
    const startBtn = document.getElementById('start-ingest');
    const cancelBtn = document.getElementById('cancel-ingest');

    watchToggle.checked = true;
    watchToggle.dispatchEvent(new Event('change'));

    expect(startBtn.querySelector('.button_text').textContent).toBe('Start Watching');
    expect(cancelBtn.querySelector('.button_text').textContent).toBe('Stop Watching');

    window.i18n.language = 'es';
    window.i18n.__emit('languageChanged');

    expect(watchToggle.checked).toBe(true);
    expect(startBtn.querySelector('.button_text').textContent).toBe('Iniciar monitoreo');
    expect(cancelBtn.querySelector('.button_text').textContent).toBe('Detener monitoreo');
  });



  test('watch mode preserves current Parallel Copy and Auto Threads toggle states', () => {
    const watchToggle = document.getElementById('enable-watch-mode');
    const parallelToggle = document.getElementById('ingest-parallel');
    const autoThreadsToggle = document.getElementById('ingest-auto-threads');

    parallelToggle.checked = true;
    autoThreadsToggle.checked = true;

    watchToggle.checked = true;
    watchToggle.dispatchEvent(new Event('change'));

    expect(parallelToggle.checked).toBe(true);
    expect(autoThreadsToggle.checked).toBe(true);

    watchToggle.checked = false;
    watchToggle.dispatchEvent(new Event('change'));

    expect(parallelToggle.checked).toBe(true);
    expect(autoThreadsToggle.checked).toBe(true);

    parallelToggle.checked = false;
    autoThreadsToggle.checked = false;

    watchToggle.checked = true;
    watchToggle.dispatchEvent(new Event('change'));

    expect(parallelToggle.checked).toBe(false);
    expect(autoThreadsToggle.checked).toBe(false);
  });
  test('watch mode keeps Start/Stop Watching labels after queued jobs complete', () => {
    const watchToggle = document.getElementById('enable-watch-mode');
    watchToggle.checked = true;
    watchToggle.dispatchEvent(new Event('change'));

    const startBtn = document.getElementById('start-ingest');
    const cancelBtn = document.getElementById('cancel-ingest');

    // Simulate a backend job completion event that occurs while watch mode is active.
    const completeHandlerCall = ipc.on.mock.calls.find(call => call[0] === 'queue-job-complete');
    expect(completeHandlerCall).toBeTruthy();
    const completeHandler = completeHandlerCall[1];

    completeHandler({}, { panel: 'ingest', id: 'job-123', result: {} });

    expect(startBtn.querySelector('.button_text').textContent).toBe('Start Watching');
    expect(cancelBtn.querySelector('.button_text').textContent).toBe('Stop Watching');
    expect(cancelBtn.dataset.watchActive).toBe('1');
  });

  test('ignores progress updates for non-active ingest jobs', async () => {
    const progressHandler = getQueueHandler('queue-job-progress');
    const bar = document.getElementById('ingest-progress');
    const out = document.getElementById('ingest-progress-output');

    document.getElementById('source-path').value = '/source';
    document.getElementById('destination-path').value = '/dest';
    document.getElementById('start-ingest').click();
    await waitForInvoke('queue-start');
    expect(ipc.invoke).toHaveBeenCalledWith('queue-add-ingest', expect.anything());
    progressHandler({}, { panel: 'ingest', id: 'job-stale', percent: 63, eta: '00:10' });

    expect(bar.value).toBe(0);
    expect(out.value).toBe('');
  });

  test('tracks pending queued job id and only reacts to matching lifecycle events', async () => {
    ipc.invoke.mockImplementation(async (channel, arg) => {
      if (channel === 'path-exists') return true;
      if (channel === 'normalize-path') return String(arg ?? '').trim();
      if (channel === 'ingest-validate-paths') {
        const list = Array.isArray(arg) ? arg : [];
        const results = Object.fromEntries(list.map((item) => [
          item,
          { exists: true, isDirectory: true, isFile: false, writable: true, writeReason: '', ...(pathMetaOverrides[item] || {}) },
        ]));
        return { success: true, results };
      }
      if (channel === 'calculate-ingest-bytes') {
        return { success: true, total: 1024, fileCount: 3, folderCount: 1, map: {} };
      }
      if (channel === 'queue-add-ingest') return 'job-local';
      if (channel === 'queue-start') return undefined;
      return undefined;
    });

    document.getElementById('source-path').value = '/source';
    document.getElementById('destination-path').value = '/dest';

    document.getElementById('start-ingest').click();
    await waitForInvoke('queue-start');
    expect(ipc.invoke).toHaveBeenCalledWith('queue-add-ingest', expect.anything());

    const startHandler = getQueueHandler('queue-job-start');
    const completeHandler = getQueueHandler('queue-job-complete');
    const out = document.getElementById('ingest-progress-output');

    startHandler({}, { panel: 'ingest', id: 'job-other' });
    // Even after we move from pending->active, stale jobs stay ignored.
    startHandler({}, { panel: 'ingest', id: 'job-local' });
    out.value = '44';

    completeHandler({}, { panel: 'ingest', id: 'job-other', result: {} });
    expect(out.value).toBe('44');

    completeHandler({}, { panel: 'ingest', id: 'job-local', result: {} });
    expect(out.value).toBe('');
  });

  test('ignores stale completion events and only applies completion for the active job', async () => {
    const completeHandler = getQueueHandler('queue-job-complete');
    const out = document.getElementById('ingest-progress-output');

    document.getElementById('source-path').value = '/source';
    document.getElementById('destination-path').value = '/dest';
    document.getElementById('start-ingest').click();
    await waitForInvoke('queue-start');
    expect(ipc.invoke).toHaveBeenCalledWith('queue-add-ingest', expect.anything());
    out.value = '52';

    completeHandler({}, { panel: 'ingest', id: 'job-other', result: {} });
    expect(out.value).toBe('52');

    completeHandler({}, { panel: 'ingest', id: 'job-123', result: {} });
    expect(out.value).toBe('');
  });

  test('applies cancelled lifecycle when event matches cancelPendingJobId', async () => {
    const cancellingHandler = getQueueHandler('queue-job-cancelling');
    const cancelledHandler = getQueueHandler('queue-job-cancelled');
    const out = document.getElementById('ingest-progress-output');

    document.getElementById('source-path').value = '/source';
    document.getElementById('destination-path').value = '/dest';
    document.getElementById('start-ingest').click();
    await waitForInvoke('queue-start');
    expect(ipc.invoke).toHaveBeenCalledWith('queue-add-ingest', expect.anything());
    out.value = '37';

    cancellingHandler({}, { panel: 'ingest', id: 'job-123' });
    cancelledHandler({}, { panel: 'ingest', id: 'job-123', result: {} });

    expect(out.value).toBe('');
  });

});
