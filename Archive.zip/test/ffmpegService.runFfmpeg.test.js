/** @jest-environment node */

const { EventEmitter } = require('events');

const mockSpawn = jest.fn();

jest.mock('child_process', () => ({
  spawn: (...args) => mockSpawn(...args),
  execFile: jest.fn()
}));

jest.mock('../utils/ffmpegBridge', () => ({
  getBinaryPaths: () => ({ ffmpegPath: '/usr/bin/ffmpeg', ffprobePath: '/usr/bin/ffprobe' }),
  ffprobeJson: jest.fn()
}));

jest.mock('../utils/ffmpegCapabilities', () => ({
  getCapabilities: jest.fn(() => ({})),
  listMuxers: jest.fn(() => [])
}));

const { runFfmpeg } = require('../services/ffmpegService');

function createMockProcess() {
  const proc = new EventEmitter();
  proc.stdout = new EventEmitter();
  proc.stderr = new EventEmitter();
  proc.exitCode = null;
  proc.killed = false;
  proc.kill = jest.fn(signal => {
    proc.killed = true;
    proc.exitCode = 1;
    proc.emit('close', null, signal || 'SIGTERM');
    return true;
  });
  return proc;
}

describe('runFfmpeg output and timeout controls', () => {
  beforeEach(() => {
    jest.useRealTimers();
    mockSpawn.mockReset();
  });

  test('caps very large stderr output to maxCaptureBytes tail', async () => {
    const proc = createMockProcess();
    mockSpawn.mockReturnValue(proc);

    const maxCaptureBytes = 4096;
    const hugeStderr = 'x'.repeat(20000) + 'TAIL_MARKER';

    process.nextTick(() => {
      proc.stderr.emit('data', Buffer.from(hugeStderr));
      proc.emit('close', 0);
    });

    const result = await runFfmpeg(['-version'], { maxCaptureBytes });

    expect(result.exitCode).toBe(0);
    expect(Buffer.byteLength(result.stderr)).toBeLessThanOrEqual(maxCaptureBytes);
    expect(result.stderr.endsWith('TAIL_MARKER')).toBe(true);
    expect(result.maxCaptureBytes).toBe(maxCaptureBytes);
  });

  test('timeout kills ffmpeg and rejects with deterministic timeout shape', async () => {
    jest.useFakeTimers();

    const proc = createMockProcess();
    mockSpawn.mockReturnValue(proc);

    const pending = runFfmpeg(['-i', '/tmp/in.mov'], { timeoutMs: 50 });

    jest.advanceTimersByTime(55);

    await expect(pending).rejects.toMatchObject({
      code: 'FFMPEG_TIMEOUT',
      message: 'FFmpeg timed out after 50ms',
      timeoutMs: 50,
      exitCode: null,
      signal: 'SIGTERM',
      stderrTail: '',
      stdoutTail: ''
    });
    expect(proc.kill).toHaveBeenCalledWith('SIGTERM');
  });

  test('abort signal rejects with deterministic aborted shape', async () => {
    const proc = createMockProcess();
    mockSpawn.mockReturnValue(proc);
    const abortController = new AbortController();

    const pending = runFfmpeg(['-i', '/tmp/in.mov'], { signal: abortController.signal });
    abortController.abort();

    await expect(pending).rejects.toMatchObject({
      code: 'FFMPEG_ABORTED',
      message: 'FFmpeg execution aborted',
      signal: 'SIGTERM',
      stderrTail: '',
      stdoutTail: ''
    });
    expect(proc.kill).toHaveBeenCalledWith('SIGTERM');
  });

  test('spawn error rejects with deterministic spawn error shape', async () => {
    const proc = createMockProcess();
    mockSpawn.mockReturnValue(proc);

    const pending = runFfmpeg(['-i', '/tmp/in.mov']);
    process.nextTick(() => {
      proc.emit('error', new Error('spawn ENOENT'));
    });

    await expect(pending).rejects.toMatchObject({
      code: 'FFMPEG_SPAWN_ERROR',
      message: 'spawn ENOENT',
      exitCode: null,
      signal: null,
      stderrTail: '',
      stdoutTail: ''
    });
  });

  test('non-zero exit rejects with deterministic non-zero shape', async () => {
    const proc = createMockProcess();
    mockSpawn.mockReturnValue(proc);

    process.nextTick(() => {
      proc.stdout.emit('data', Buffer.from('stdout-tail'));
      proc.stderr.emit('data', Buffer.from('stderr-tail'));
      proc.emit('close', 2, null);
    });

    await expect(runFfmpeg(['-i', '/tmp/in.mov'])).rejects.toMatchObject({
      code: 'FFMPEG_EXIT_NON_ZERO',
      message: 'stderr-tail',
      exitCode: 2,
      signal: null,
      stderrTail: 'stderr-tail',
      stdoutTail: 'stdout-tail'
    });
  });
});
