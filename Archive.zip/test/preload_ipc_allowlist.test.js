/** @jest-environment node */

const fs = require('fs');
const path = require('path');

function readAllowedInvokeChannels() {
  const preloadPath = path.join(__dirname, '..', 'preload.js');
  const src = fs.readFileSync(preloadPath, 'utf8');
  const match = src.match(/const ALLOWED_INVOKE_CHANNELS = new Set\(\[([\s\S]*?)\]\);/);
  expect(match).toBeTruthy();

  const channels = [];
  const re = /'([^']+)'/g;
  let m;
  while ((m = re.exec(match[1])) !== null) channels.push(m[1]);

  return { channels, src };
}

function readAllowedOnChannels() {
  const preloadPath = path.join(__dirname, '..', 'preload.js');
  const src = fs.readFileSync(preloadPath, 'utf8');
  const match = src.match(/const ALLOWED_ON_CHANNELS = new Set\(\[([\s\S]*?)\]\);/);
  expect(match).toBeTruthy();

  const channels = [];
  const re = /'([^']+)'/g;
  let m;
  while ((m = re.exec(match[1])) !== null) channels.push(m[1]);

  return { channels, src };
}

describe('preload IPC invoke allowlist', () => {
  test('renderer-exposed invoke paths in api/codex/ffmpeg/subtitleEditor use invokeAllowed', () => {
    const { src } = readAllowedInvokeChannels();

    const scopedBlocks = [
      src.match(/const api = \{[\s\S]*?\n\};/),
      src.match(/contextBridge\.exposeInMainWorld\('codex', \{[\s\S]*?\n\}\);/),
      src.match(/contextBridge\.exposeInMainWorld\('ffmpeg', \{[\s\S]*?\n\}\);/),
      src.match(/contextBridge\.exposeInMainWorld\('subtitleEditor', \{[\s\S]*?\n\}\);/)
    ].filter(Boolean).map((m) => m[0]);

    expect(scopedBlocks.length).toBe(4);
    for (const block of scopedBlocks) {
      expect(block).not.toMatch(/ipcRenderer\.invoke\(/);
      expect(block).toMatch(/invokeAllowed\(/);
    }
  });

  test('allowlist contains channels used by renderer-exposed invoke helpers', () => {
    const { channels } = readAllowedInvokeChannels();
    const expected = [
      'cancel-ingest',
      'cancel-transcode',
      'run-clone',
      'cancel-clone',
      'get-source-metadata',
      'validate-codex-input',
      'get-folder-tree',
      'exec-ffprobe',
      'ffprobe-json',
      'exec-ffmpeg',
      'probe-media',
      'log-viewer:read-log-files',
      'is-media-composer-running',
      'expand-paths',
      'show-message-dialog',
      'show-confirm-dialog',
      'stat-path',
      'subtitle-editor:open',
      'codex:list-formats',
      'codex:list-audio-codecs',
      'codex:get-compatibility',
      'codex:get-audio-constraints',
      'codex:is-audio-container-valid',
      'codex:get-spec',
      'codex:get-format-capabilities',
      'ffmpeg:get-capabilities',
      'get-ffmpeg-formats',
      'fs:isDuplicate',
      'assets:getStatus',
      'assets:prefetch',
      'assets:cancel',
      'secure-store:has-ai-api-key',
      'secure-store:set-ai-api-key',
      'secure-store:delete-ai-api-key'
    ];

    for (const channel of expected) {
      expect(channels).toContain(channel);
    }
  });

  test('includes CEP installer channels in expected ordering', () => {
    const { channels } = readAllowedInvokeChannels();


    const getStatusIdx = channels.indexOf('cep:get-status');
    const installIdx = channels.indexOf('cep:install');
    const uninstallIdx = channels.indexOf('cep:uninstall');
    const openFolderIdx = channels.indexOf('cep:open-folder');

    expect(getStatusIdx).toBeGreaterThanOrEqual(0);
    expect(installIdx).toBeGreaterThan(getStatusIdx);
    expect(uninstallIdx).toBeGreaterThan(installIdx);
    expect(openFolderIdx).toBeGreaterThan(uninstallIdx);
  });

  test('renderer does not include legacy CEP PlayerDebugMode repair flow', () => {
    const { channels } = readAllowedInvokeChannels();
    const rendererPath = path.join(__dirname, '..', 'renderer.js');
    const rendererSrc = fs.readFileSync(rendererPath, 'utf8');

    expect(rendererSrc).not.toContain("cep:enable-player-debug");
    expect(channels).not.toContain('cep:enable-player-debug');
  });

  test('allowlist contains channels used by renderer-exposed ipc.on helpers', () => {
    const { channels, src } = readAllowedOnChannels();

    expect(channels).toContain('transcription-preview');
    expect(channels).toContain('license:changed');
    expect(channels).toContain('assets:progress');

    expect(src).toMatch(/onTranscriptionPreview:\s*\(cb\)\s*=>\s*\{[\s\S]*?onAllowed\('transcription-preview', listener\)/);
    expect(src).toMatch(/onLicenseChanged:\s*\(cb\)\s*=>\s*\{[\s\S]*?onAllowed\('license:changed', listener\)/);
    expect(src).toMatch(/assets:\s*\{[\s\S]*?onProgress:\s*\(cb\)\s*=>\s*\{[\s\S]*?onAllowed\('assets:progress', listener\)/);
  });

  test('blocked ipc.on channels fail closed', () => {
    const { src } = readAllowedOnChannels();

    const onAllowedBodyMatch = src.match(/function onAllowed\(channel, listener\) \{([\s\S]*?)\n\}/);
    expect(onAllowedBodyMatch).toBeTruthy();

    const onAllowedBody = onAllowedBodyMatch[1];
    expect(onAllowedBody).toContain('Blocked ipc.on channel:');
    expect(onAllowedBody).toContain('return;');
  });

  test('all renderer ipc.on subscriptions are allowlisted', () => {
    const { channels: onChannels } = readAllowedOnChannels();
    const allowed = new Set(onChannels);

    const rendererPath = path.join(__dirname, '..', 'renderer.js');
    const rendererSrc = fs.readFileSync(rendererPath, 'utf8');

    // Matches: ipc.on('x'...), ipc?.on('x'...), ipc?.on?.('x'...)
    const re = /ipc(?:\?\.)?\.on(?:\?\.)?\(\s*['"]([^'"]+)['"]/g;
    const found = new Set();
    let m;
    while ((m = re.exec(rendererSrc)) !== null) found.add(m[1]);

    for (const ch of found) {
      expect(allowed.has(ch)).toBe(true);
    }
  });

});
