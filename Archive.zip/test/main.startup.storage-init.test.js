/** @jest-environment node */

const path = require('path');

describe('main startup storage initialization failures', () => {
  test('aborts startup on unwritable userData directories and emits telemetry', async () => {
    jest.resetModules();

    const userDataPath = '/tmp/lead-ae-user-data';
    const shownErrors = [];
    const captureMessage = jest.fn();
    const sendLogMessage = jest.fn();
    const appExit = jest.fn();

    jest.doMock('electron', () => ({
      app: {
        isPackaged: false,
        getAppPath: jest.fn(() => '/workspace/LeadAEAssist'),
        getPath: jest.fn((key) => (key === 'userData' ? userDataPath : '/tmp')),
        setName: jest.fn(),
        setPath: jest.fn(),
        isReady: jest.fn(() => true),
        quit: jest.fn(),
        exit: appExit,
        on: jest.fn(),
        whenReady: jest.fn(() => Promise.resolve())
      },
      BrowserWindow: jest.fn(),
      dialog: {
        showErrorBox: jest.fn((title, message) => shownErrors.push({ title, message }))
      },
      ipcMain: {
        handle: jest.fn(),
        on: jest.fn()
      },
      session: { defaultSession: { webRequest: { onHeadersReceived: jest.fn() } } },
      screen: {
        getPrimaryDisplay: jest.fn(() => ({ workAreaSize: { width: 1920, height: 1080 } })),
        getDisplayMatching: jest.fn(() => ({ workAreaSize: { width: 1920, height: 1080 } }))
      },
      shell: { showItemInFolder: jest.fn() }
    }));

    jest.doMock('fs', () => {
      const actual = jest.requireActual('fs');
      return {
        ...actual,
        mkdirSync: jest.fn(),
        statSync: jest.fn(() => ({ isDirectory: () => true })),
        accessSync: jest.fn((targetPath) => {
          if (targetPath === path.join(userDataPath, 'logs')) {
            const err = new Error('EACCES: permission denied');
            err.code = 'EACCES';
            throw err;
          }
        }),
        existsSync: jest.fn(() => false),
        copyFileSync: jest.fn(),
        statfsSync: jest.fn(() => ({ bavail: 1, bsize: 4096 }))
      };
    });

    jest.doMock('../utils/trustedIpcSender', () => ({ assertTrustedIpcSender: jest.fn() }));
    jest.doMock('../utils/ipcPathGuards', () => ({ toLocalPathIfFileUrl: jest.fn((v) => v), assertApprovedPath: jest.fn((_, p) => p) }));
    jest.doMock('../utils/ffmpegBridge', () => ({ getBinaryPaths: jest.fn(() => ({ ffmpegPath: '/ffmpeg', ffprobePath: '/ffprobe' })) }));
    jest.doMock('../utils/ffmpegPreflight', () => ({ preflightFfmpegBinaries: jest.fn(), looksLikeGatekeeperKill: jest.fn(() => false) }));
    jest.doMock('../utils/ffmpegCapabilities', () => ({ configure: jest.fn(), listEncoders: jest.fn(() => []) }));
    jest.doMock('../utils/externalNavigationGuards', () => ({ installExternalNavigationGuards: jest.fn() }));
    jest.doMock('../services/licenseService', () => ({}));
    jest.doMock('../modules/clone', () => ({}));
    jest.doMock('../modules/logUtils', () => ({ sendLogMessage, createSessionLogWriter: jest.fn() }));
    jest.doMock('../modules/cepBridge', () => ({ startCEPBridge: jest.fn() }));
    jest.doMock('../services/bridgeServerService', () => ({ getCredentials: jest.fn() }));
    jest.doMock('../ipc', () => ({ registerIpcHandlers: jest.fn() }));
    jest.doMock('../services/telemetryService', () => ({ init: jest.fn(), captureMessage }));
    jest.doMock('../services/autoUpdateService', () => ({ initAutoUpdates: jest.fn() }));
    jest.doMock('../platform/paths', () => ({ getUserDataRoot: jest.fn(() => userDataPath), ensureDirSync: jest.fn() }));
    jest.doMock('../utils/fsSafe', () => ({ atomicWriteJson: jest.fn() }));
    jest.doMock('../utils/maintenance', () => ({ runStartupMaintenance: jest.fn() }));
    jest.doMock('../utils/state', () => ({ readState: jest.fn(() => ({})) }));
    jest.doMock('../utils/startupBootstrap', () => ({
      buildStartupHealth: jest.fn(() => ({ ok: true, criticalFailures: [], optionalFailures: [] })),
      loadStartupDependencies: jest.fn(async () => ({ health: { ok: true, criticalFailures: [], optionalFailures: [] }, deps: {} }))
    }));
    jest.doMock('../utils/globalErrorHandlers', () => ({ registerGlobalErrorHandlers: jest.fn() }));
    jest.doMock('../utils/watchRegistry', () => ({
      getSharedWatchRegistry: jest.fn(),
      flushSharedWatchRegistrySave: jest.fn(),
      createSessionKey: jest.fn(),
      createFileSignature: jest.fn(),
      isProcessed: jest.fn()
    }));

    jest.isolateModules(() => {
      require('../main');
    });

    await new Promise((resolve) => setImmediate(resolve));
    await new Promise((resolve) => setImmediate(resolve));

    expect(shownErrors).toHaveLength(1);
    expect(shownErrors[0].title).toBe('Startup Error');
    expect(shownErrors[0].message).toContain('Storage initialization failed.');
    expect(shownErrors[0].message).toContain(`Path: ${path.join(userDataPath, 'logs')}`);
    expect(shownErrors[0].message).toContain('Error Code: EACCES');
    expect(shownErrors[0].message).toContain('ensure sufficient free disk space');

    expect(captureMessage).toHaveBeenCalledWith(
      'startup/storage-init-failed',
      expect.objectContaining({
        level: 'fatal',
        tags: expect.objectContaining({
          scope: 'startup',
          subsystem: 'storage',
          event: 'startup/storage-init-failed'
        }),
        extra: expect.objectContaining({
          path: path.join(userDataPath, 'logs'),
          errorCode: 'EACCES'
        })
      })
    );

    expect(sendLogMessage).toHaveBeenCalledWith(
      'system',
      '❌ Startup storage initialization failed.',
      expect.stringContaining(`path=${path.join(userDataPath, 'logs')};code=EACCES`),
      false,
      '',
      'error'
    );
    expect(appExit).toHaveBeenCalledWith(1);
  });
});
