/** @jest-environment node */

const fs = require('fs');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');

jest.mock('electron', () => ({
  dialog: { showMessageBox: jest.fn().mockResolvedValue({ response: 1 }) },
  BrowserWindow: { getAllWindows: () => [{ isDestroyed: () => false }] },
  app: { isPackaged: false }
}), { virtual: true });

describe('runIngest rollback-safe replacement', () => {
  let tempDir;
  let runIngest;
  let originalCompare;

  beforeEach(() => {
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ingest-rollback-'));
    global.queue = new EventEmitter();

    jest.resetModules();
    const compare = require('../utils/compare');
    originalCompare = compare.compareFilesByteByByte;
    compare.compareFilesByteByByte = jest.fn(async () => false);

    delete require.cache[require.resolve('../modules/ingest')];
    runIngest = require('../modules/ingest').runIngest;
  });

  afterEach(() => {
    const compare = require('../utils/compare');
    compare.compareFilesByteByByte = originalCompare;

    fs.rmSync(tempDir, { recursive: true, force: true });
    delete global.queue;
    jest.clearAllMocks();
  });

  test('restores existing destination file when verification fails', async () => {
    const destDir = path.join(tempDir, 'dest');
    fs.mkdirSync(destDir);

    const sourceFile = path.join(tempDir, 'clip.mov');
    const destFile = path.join(destDir, 'clip.mov');
    fs.writeFileSync(sourceFile, 'NEW-CONTENT');
    fs.writeFileSync(destFile, 'ORIGINAL-DEST-CONTENT');

    const result = await runIngest({
      source: '1 item selected',
      sourceFiles: [sourceFile],
      destination: destDir,
      flattenStructure: false,
      backup: false,
      verification: { useChecksum: false, method: 'none', compareByte: true }
    });

    expect(result.success).toBe(false);
    expect(fs.readFileSync(destFile, 'utf8')).toBe('ORIGINAL-DEST-CONTENT');
    expect(fs.readdirSync(destDir).filter(name => name.includes('.preexisting.'))).toEqual([]);
  });
});
