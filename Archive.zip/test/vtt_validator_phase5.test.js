'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { validateVTT } = require('../ai/vttValidator');

test('Phase 5 VTT validator: flags invalid/missing WEBVTT header', () => {
  const vtt = `NOTVTT\n\n00:00:00.000 --> 00:00:01.000\nHi\n\n`;
  const rep = validateVTT(vtt, { formats: { vtt: { profile: 'streaming' } } });

  assert.equal(rep.kind, 'WebVTT_QC_Report');
  assert.ok(rep.errors.some(e => e.code === 'INVALID_HEADER'));
});

test('Phase 5 VTT validator: flags long line + high CPS', () => {
  const longLine = 'A'.repeat(120);
  const vtt = `WEBVTT\n\n1\n00:00:00.000 --> 00:00:01.000\n${longLine}\n\n`;

  const rep = validateVTT(vtt, { formats: { vtt: { profile: 'streaming', maxCharsPerLine: 42, maxCps: 20 } } });

  assert.ok(rep.warnings.some(w => w.code === 'LINE_TOO_LONG'));
  assert.ok(rep.warnings.some(w => w.code === 'CPS_TOO_HIGH'));
  assert.ok(rep.stats.worstCps > 20);
});

test('Phase 5 VTT validator: flags overlaps', () => {
  const vtt = [
    'WEBVTT',
    '',
    '1',
    '00:00:00.000 --> 00:00:02.000',
    'Hello',
    '',
    '2',
    '00:00:01.500 --> 00:00:03.000',
    'Overlap',
    ''
  ].join('\n');

  const rep = validateVTT(vtt, { formats: { vtt: { profile: 'streaming' } } });
  assert.ok(rep.warnings.some(w => w.code === 'OVERLAP'));
});

test('Phase 5 VTT validator: warns on unsafe/unsupported tags', () => {
  const vtt = [
    'WEBVTT',
    '',
    '1',
    '00:00:00.000 --> 00:00:02.000',
    'Hello <font color=red>world</font>',
    ''
  ].join('\n');

  const rep = validateVTT(vtt, { formats: { vtt: { profile: 'streaming' } } });
  assert.ok(rep.warnings.some(w => w.code === 'UNSUPPORTED_TAG'));
});

test('Phase 5 VTT validator: strict profile escalates QC warnings to errors for key codes', () => {
  const longLine = 'B'.repeat(120);
  const vtt = `WEBVTT\n\n1\n00:00:00.000 --> 00:00:01.000\n${longLine}\n\n`;

  const rep = validateVTT(vtt, { formats: { vtt: { profile: 'strict' } } });
  assert.ok(rep.errors.some(e => e.code === 'LINE_TOO_LONG'));
});
