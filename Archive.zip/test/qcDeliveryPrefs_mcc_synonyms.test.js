'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { buildMccOptions } = require('../utils/qcDeliveryPrefs');

test('buildMccOptions keeps includeCdpTimecode and embedCdpTimecode in sync', () => {
  const base = { exportPolicy: 'warn', qc: {} };

  const out1 = buildMccOptions(base, { includeCdpTimecode: true });
  assert.equal(out1.includeCdpTimecode, true);
  assert.equal(out1.embedCdpTimecode, true);

  const out2 = buildMccOptions(base, { embedCdpTimecode: true });
  assert.equal(out2.includeCdpTimecode, true);
  assert.equal(out2.embedCdpTimecode, true);

  const out3 = buildMccOptions({ ...base, includeCdpTimecode: true, embedCdpTimecode: true }, { includeCdpTimecode: false });
  assert.equal(out3.includeCdpTimecode, false);
  assert.equal(out3.embedCdpTimecode, false);
});

test('buildMccOptions keeps startTc and startTC in sync when provided', () => {
  const base = { exportPolicy: 'warn', qc: {} };

  const out1 = buildMccOptions(base, { startTc: '01:00:00:00' });
  assert.equal(out1.startTc, '01:00:00:00');
  assert.equal(out1.startTC, '01:00:00:00');

  const out2 = buildMccOptions(base, { startTC: '01:00:00;00' });
  assert.equal(out2.startTc, '01:00:00;00');
  assert.equal(out2.startTC, '01:00:00;00');
});
