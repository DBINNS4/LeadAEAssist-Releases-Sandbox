/** @jest-environment node */

jest.mock('electron', () => ({
  app: { getAppPath: jest.fn(() => '/app') },
  shell: { openExternal: jest.fn() }
}));

const { shell } = require('electron');
const {
  isAllowedInAppUrl,
  installExternalNavigationGuards,
  openExternalIfSafe
} = require('../utils/externalNavigationGuards');

describe('externalNavigationGuards.isAllowedInAppUrl', () => {
  test('allows valid localhost URLs with configured protocols', () => {
    expect(isAllowedInAppUrl('http://127.0.0.1/dashboard')).toBe(true);
    expect(isAllowedInAppUrl('https://127.0.0.1/index.html')).toBe(true);
    expect(isAllowedInAppUrl('ws://127.0.0.1/socket')).toBe(true);
    expect(isAllowedInAppUrl('wss://127.0.0.1/socket')).toBe(true);
  });

  test('rejects hostname prefix bypasses', () => {
    expect(isAllowedInAppUrl('http://127.0.0.1.evil.tld')).toBe(false);
    expect(isAllowedInAppUrl('https://127.0.0.1evil.tld/path')).toBe(false);
  });

  test('rejects userinfo host ambiguity tricks', () => {
    expect(isAllowedInAppUrl('http://127.0.0.1@evil.tld/path')).toBe(false);
    expect(isAllowedInAppUrl('https://username:password@127.0.0.1/path')).toBe(false);
  });

  test('accepts mixed-case hostnames when origin matches', () => {
    const opts = {
      allowedOrigins: [{ protocol: 'http:', hostname: 'localhost', port: '' }],
      allowedFileRoots: ['/app']
    };

    expect(isAllowedInAppUrl('http://LOCALHOST/ok', opts)).toBe(true);
    expect(isAllowedInAppUrl('HTTP://LocalHost/ok', opts)).toBe(true);
  });

  test('enforces explicit port matching', () => {
    expect(isAllowedInAppUrl('http://127.0.0.1:3000/path')).toBe(false);

    const opts = {
      allowedOrigins: [{ protocol: 'http:', hostname: '127.0.0.1', port: '3000' }],
      allowedFileRoots: ['/app']
    };

    expect(isAllowedInAppUrl('http://127.0.0.1:3000/path', opts)).toBe(true);
    expect(isAllowedInAppUrl('http://127.0.0.1/path', opts)).toBe(false);
  });

  test('keeps file URL handling delegated to allowed roots', () => {
    expect(isAllowedInAppUrl('file:///app/index.html', { allowedFileRoots: ['/app'] })).toBe(true);
    expect(isAllowedInAppUrl('file:///etc/passwd', { allowedFileRoots: ['/app'] })).toBe(false);
  });
});

describe('externalNavigationGuards external open failures', () => {
  beforeEach(() => {
    shell.openExternal.mockReset();
  });

  test('openExternalIfSafe consumes shell.openExternal rejections', async () => {
    shell.openExternal.mockRejectedValueOnce(new Error('open failed'));

    expect(() => openExternalIfSafe('https://example.com')).not.toThrow();

    await Promise.resolve();
    expect(shell.openExternal).toHaveBeenCalledWith('https://example.com');
  });

  test('navigation handlers always deny/prevent and do not surface rejected opens', async () => {
    shell.openExternal.mockRejectedValue(new Error('open failed'));

    const handlers = {};
    const webContents = {
      setWindowOpenHandler: jest.fn(handler => {
        handlers.windowOpen = handler;
      }),
      on: jest.fn((event, handler) => {
        handlers[event] = handler;
      })
    };

    installExternalNavigationGuards(webContents);

    expect(() => handlers.windowOpen({ url: 'https://example.com' })).not.toThrow();
    expect(handlers.windowOpen({ url: 'https://example.com' })).toEqual({ action: 'deny' });

    const navEvent = { preventDefault: jest.fn() };
    expect(() => handlers['will-navigate'](navEvent, 'https://example.com')).not.toThrow();
    expect(navEvent.preventDefault).toHaveBeenCalledTimes(1);

    const redirectEvent = { preventDefault: jest.fn() };
    expect(() => handlers['will-redirect'](redirectEvent, 'https://example.com')).not.toThrow();
    expect(redirectEvent.preventDefault).toHaveBeenCalledTimes(1);

    await Promise.resolve();
    expect(shell.openExternal).toHaveBeenCalledTimes(4);
  });
});
